package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.BlockedKeyword
import com.example.model.BlockedSite
import com.example.util.GoogleDriveBackupManager
import com.example.util.SaffahBlockRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @org.junit.Before
  fun setUp() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    SaffahBlockRepository.stopTimeDelay(context)
    context.getSharedPreferences("saffah_block_prefs", Context.MODE_PRIVATE)
      .edit()
      .clear()
      .commit()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("السَّفاح", appName)
  }

  @Test
  fun `test backup json generation and restore`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    SaffahBlockRepository.addBlockedKeyword(context, "testkeyword")
    SaffahBlockRepository.addBlockedSite(context, "testsite.org")
    SaffahBlockRepository.addPermanentBlockedPackage(context, "com.example.badapp")

    val json = GoogleDriveBackupManager.generateBackupJson(context)
    assertTrue(json.contains("testkeyword"))
    assertTrue(json.contains("testsite.org"))
    assertTrue(json.contains("com.example.badapp"))

    val restoreResult = GoogleDriveBackupManager.restoreBackupFromJson(context, json)
    assertTrue(restoreResult.isSuccess)
  }

  @Test
  fun `test time delay strictly forbids backup restore and import`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val json = GoogleDriveBackupManager.generateBackupJson(context)

    // Activate Time Delay for 2 hours
    SaffahBlockRepository.startTimeDelay(context, 2L)
    assertTrue(SaffahBlockRepository.isTimeDelayActive(context))

    // Attempting restore during Time Delay MUST fail
    val restoreResult = GoogleDriveBackupManager.restoreBackupFromJson(context, json)
    assertTrue(restoreResult.isFailure)
    assertTrue(restoreResult.exceptionOrNull()?.message?.contains("Time Delay") == true)

    // Backup creation MUST still succeed
    val newJson = GoogleDriveBackupManager.generateBackupJson(context)
    assertTrue(newJson.isNotEmpty())
  }

  @Test
  fun `test google play and settings suspension eligibility`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // Verify Google Play is not considered always exempt
    org.junit.Assert.assertFalse(SaffahBlockRepository.isAlwaysExemptPackage("com.android.vending"))
    org.junit.Assert.assertFalse(SaffahBlockRepository.isAlwaysExemptPackage("com.android.settings"))

    // Test adding to permanent block
    SaffahBlockRepository.addPermanentBlockedPackage(context, "com.android.vending")
    assertTrue(SaffahBlockRepository.isPackagePermanentlyBlocked(context, "com.android.vending"))

    SaffahBlockRepository.addPermanentBlockedPackage(context, "com.android.settings")
    assertTrue(SaffahBlockRepository.isPackagePermanentlyBlocked(context, "com.android.settings"))

    // Verify Bedtime mode setup
    SaffahBlockRepository.setBedtimeModeEnabled(context, true)
    SaffahBlockRepository.saveBedtimeAllowedApps(context, emptySet())
    val allowed = SaffahBlockRepository.getBedtimeAllowedApps(context)
    org.junit.Assert.assertFalse(allowed.contains("com.android.vending"))
    org.junit.Assert.assertFalse(allowed.contains("com.android.settings"))
  }

  @Test
  fun `test block log full 24h timestamp format`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val timestamp = SaffahBlockRepository.getCurrentFullTimestamp24h()
    
    // Pattern: HH:mm • yyyy/MM/dd (e.g. 18:05 • 2026/08/17)
    val regex = Regex("""^\d{2}:\d{2}\s•\s\d{4}/\d{2}/\d{2}$""")
    assertTrue(regex.matches(timestamp))

    // Add log and verify entry
    SaffahBlockRepository.addBlockLog(context, "testkeyword", "كلمة", "com.example.app")
    val logs = SaffahBlockRepository.getBlockLogs(context)
    assertTrue(logs.isNotEmpty())
    assertEquals("testkeyword", logs.first().blockedItem)
    assertTrue(regex.matches(logs.first().timestamp))
  }

  @Test
  fun `test urge suppression session start and quick settings tile integration`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // Ensure session is initially inactive
    org.junit.Assert.assertFalse(com.example.util.SaffahUrgeManager.isUrgeSessionActive(context))

    // Start 15-minute urge session
    val endTime = com.example.util.SaffahUrgeManager.startUrgeSession(context, 15)
    assertTrue(endTime > System.currentTimeMillis())
    assertTrue(com.example.util.SaffahUrgeManager.isUrgeSessionActive(context))
    val remainingMs = com.example.util.SaffahUrgeManager.getUrgeSessionRemainingMs(context)
    assertTrue(remainingMs > 0L)

    // Complete/Stop session
    com.example.util.SaffahUrgeManager.stopUrgeSession(context)
    org.junit.Assert.assertFalse(com.example.util.SaffahUrgeManager.isUrgeSessionActive(context))
  }

  @Test
  fun `test urge recommendation suggests highest success technique from history`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // Default suggestion with no prior urge history
    val defaultRecommendation = com.example.util.SaffahRecoveryManager.getTopUrgeDefenseRecommendation(context)
    assertTrue(defaultRecommendation.contains("85%"))
    assertTrue(defaultRecommendation.contains("تقنية الماء البارد") || defaultRecommendation.contains("تمارين التنفس"))

    // Log urge records with high success for cold water
    com.example.util.SaffahRecoveryManager.logUrge(
      context = context,
      intensity = com.example.model.UrgeIntensity.STRONG,
      trigger = com.example.model.RelapseTrigger.BOREDOM,
      technique = com.example.model.UrgeDefenseTechnique.COLD_WATER_RESET,
      resistedSuccessfully = true
    )
    com.example.util.SaffahRecoveryManager.logUrge(
      context = context,
      intensity = com.example.model.UrgeIntensity.CRITICAL,
      trigger = com.example.model.RelapseTrigger.STRESS,
      technique = com.example.model.UrgeDefenseTechnique.COLD_WATER_RESET,
      resistedSuccessfully = true
    )

    val customRecommendation = com.example.util.SaffahRecoveryManager.getTopUrgeDefenseRecommendation(context)
    assertTrue(customRecommendation.contains("تقنية الماء البارد"))
    assertTrue(customRecommendation.contains("100%"))

    // Start urge session and verify notification is dispatched
    com.example.util.SaffahUrgeManager.startUrgeSession(context, 15)
    val notifManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
    val notifs = notifManager.activeNotifications
    assertTrue(notifs.any { it.id == com.example.util.SaffahNotificationManager.NOTIF_ID_URGE_SUPPRESSION })

    com.example.util.SaffahUrgeManager.stopUrgeSession(context)
  }

  @Test
  fun `test immediate locktask enforcement on genuine vpn revocation without hysteresis delay`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // Setup: user intended VPN to be active
    com.example.util.SaffahLockTaskManager.setVpnEnabledByUser(context, true)
    assertTrue(com.example.util.SaffahLockTaskManager.isVpnIntendedActive(context))

    // Clear grace period and set VPN active override to false so test evaluates external revocation state immediately
    com.example.util.SaffahLockTaskManager.resetVpnGracePeriodForTesting()
    com.example.util.SaffahLockTaskManager.setVpnActiveOverrideForTesting(false)

    val prefs = context.getSharedPreferences("saffah_lock_task_prefs", Context.MODE_PRIVATE)
    prefs.edit().putBoolean("was_accessibility_ever_enabled", false).apply()

    // Test: updateStateAndCheck detects external revocation immediately (zero delay)
    val reason = com.example.util.SaffahLockTaskManager.updateStateAndCheck(context)
    assertEquals(com.example.util.SaffahLockTaskManager.LockReason.VPN_DISABLED, reason)
    assertTrue(com.example.util.SaffahLockTaskManager.isLockTaskActive(context))

    // Cleanup
    com.example.util.SaffahLockTaskManager.setVpnActiveOverrideForTesting(null)
    com.example.util.SaffahLockTaskManager.setVpnEnabledByUser(context, false)
    val restoredReason = com.example.util.SaffahLockTaskManager.updateStateAndCheck(context)
    assertEquals(com.example.util.SaffahLockTaskManager.LockReason.NONE, restoredReason)
  }

  @Test
  fun `test 3 consecutive wrong PIN attempts triggers security alarm and 24h freeze on recovery diaries`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // Setup: set PIN to "1234" and protect diaries
    com.example.util.SaffahPrivacyManager.setPin(context, "1234")
    com.example.util.SaffahPrivacyManager.protectSection(context, com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES)
    com.example.util.SaffahPrivacyManager.resetDiaryFreezeForTesting(context)

    org.junit.Assert.assertFalse(com.example.util.SaffahPrivacyManager.isDiaryFrozen(context))
    assertEquals(0, com.example.util.SaffahPrivacyManager.getDiaryFailedAttempts(context))

    // Attempt 1: Wrong PIN
    val res1 = com.example.util.SaffahPrivacyManager.verifyPinWithSecurity(
      context, "0000", com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES
    )
    assertTrue(res1 is com.example.util.SaffahPrivacyManager.VerifyPinResult.WrongPin)
    assertEquals(1, (res1 as com.example.util.SaffahPrivacyManager.VerifyPinResult.WrongPin).attemptsMade)
    assertEquals(2, res1.attemptsRemaining)
    org.junit.Assert.assertFalse(com.example.util.SaffahPrivacyManager.isDiaryFrozen(context))

    // Attempt 2: Wrong PIN
    val res2 = com.example.util.SaffahPrivacyManager.verifyPinWithSecurity(
      context, "1111", com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES
    )
    assertTrue(res2 is com.example.util.SaffahPrivacyManager.VerifyPinResult.WrongPin)
    assertEquals(2, (res2 as com.example.util.SaffahPrivacyManager.VerifyPinResult.WrongPin).attemptsMade)
    assertEquals(1, res2.attemptsRemaining)
    org.junit.Assert.assertFalse(com.example.util.SaffahPrivacyManager.isDiaryFrozen(context))

    // Attempt 3: Wrong PIN -> Trigger Alarm & Freeze for 24h
    val res3 = com.example.util.SaffahPrivacyManager.verifyPinWithSecurity(
      context, "9999", com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES
    )
    assertTrue(res3 is com.example.util.SaffahPrivacyManager.VerifyPinResult.Frozen)
    val frozenRes = res3 as com.example.util.SaffahPrivacyManager.VerifyPinResult.Frozen
    assertEquals("تم إدخال رمز PIN بشكل خاطئ 3 مرات.. تم تجميد محاولات الفتح لمدة 24 ساعة لحماية مذكراتك", frozenRes.message)
    assertTrue(frozenRes.remainingMillis > 0L)
    assertTrue(com.example.util.SaffahPrivacyManager.isDiaryFrozen(context))
    assertTrue(com.example.util.SaffahPrivacyManager.isSectionLocked(context, com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES))

    // Attempt 4 while frozen even with CORRECT PIN: Must remain FROZEN and rejected
    val res4 = com.example.util.SaffahPrivacyManager.verifyPinWithSecurity(
      context, "1234", com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES
    )
    assertTrue(res4 is com.example.util.SaffahPrivacyManager.VerifyPinResult.Frozen)

    // Cleanup
    com.example.util.SaffahPrivacyManager.resetDiaryFreezeForTesting(context)
    org.junit.Assert.assertFalse(com.example.util.SaffahPrivacyManager.isDiaryFrozen(context))
  }

  @Test
  fun `test leaving app locks all previously unlocked protected sections`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // Setup PIN and protected sections
    com.example.util.SaffahPrivacyManager.setPin(context, "5555")
    com.example.util.SaffahPrivacyManager.protectSection(context, com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER)
    com.example.util.SaffahPrivacyManager.protectSection(context, com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES)

    // Initially both are locked
    assertTrue(com.example.util.SaffahPrivacyManager.isSectionLocked(context, com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER))
    assertTrue(com.example.util.SaffahPrivacyManager.isSectionLocked(context, com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES))

    // User unlocks them
    com.example.util.SaffahPrivacyManager.unlockSection(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER)
    com.example.util.SaffahPrivacyManager.unlockSection(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES)

    // Now they should be unlocked
    org.junit.Assert.assertFalse(com.example.util.SaffahPrivacyManager.isSectionLocked(context, com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER))
    org.junit.Assert.assertFalse(com.example.util.SaffahPrivacyManager.isSectionLocked(context, com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES))

    // User leaves the app (onStop() -> lockAllSections())
    com.example.util.SaffahPrivacyManager.lockAllSections()

    // Returning to the app: both must be locked again and require PIN
    assertTrue(com.example.util.SaffahPrivacyManager.isSectionLocked(context, com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER))
    assertTrue(com.example.util.SaffahPrivacyManager.isSectionLocked(context, com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES))
  }
}

