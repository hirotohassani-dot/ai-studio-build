package com.example.model

/**
 * بيانات المحطات العلمية لاستشفاء وتجدد مستقبلات الدوبامين في الدماغ.
 * مبنية على حقائق البيولوجيا العصبية والـ Neuroplasticity أثناء التعافي.
 */
data class DopamineReceptorMilestone(
    val day: Int,
    val phaseTitle: String,
    val biologicalTitle: String,
    val biologicalChange: String,
    val practicalAdvice: String
)

object DopamineReceptorDataProvider {
    val milestones: List<DopamineReceptorMilestone> = listOf(
        DopamineReceptorMilestone(
            day = 1,
            phaseTitle = "24 ساعة صمود",
            biologicalTitle = "انحسار الطوفان العصبي وبداية التهدئة",
            biologicalChange = "توقف التدفق الاصطناعي الجارف للدوبامين، مما يسمح للخلايا العصبية في النواة المتكئة (Nucleus Accumbens) بالتقاط أنفاسها بعد فترات الاستنزاف الحاد، وبدء انخفاض التوتر الودي.",
            practicalAdvice = "اشرب كمية كافية من الماء وامنح جسدك راحة بدنية لتسريع تخلص الدماغ من الإنهاك الكيميائي."
        ),
        DopamineReceptorMilestone(
            day = 3,
            phaseTitle = "72 ساعة - اجتياز الفجوة الدوبامينية",
            biologicalTitle = "إعادة تحفيز التخليق الخلوي للمستقبلات",
            biologicalChange = "الدماغ يمر بحالة العجز الدوباميني المؤقتة (Dopamine Deficit State). هذا الفراغ هو المحفز البيولوجي الحقيقي الذي يدفع الجينات العصبية لبدء تكوين مستقبلات جديدة لاستشعار الإشارات الطبيعية.",
            practicalAdvice = "تقبل مشاعر الفتور أو الملل كعلامة حيوية على بدء مرحلة الصيانة وإعادة الضبط الداخلي."
        ),
        DopamineReceptorMilestone(
            day = 7,
            phaseTitle = "أسبوع كامل - نقطة التحول البيولوجي",
            biologicalTitle = "بدء تكاثر مستقبلات D2 و D1 (Upregulation)",
            biologicalChange = "ترصد الفحوصات العصبية بدء التكاثر الفعلي لمستقبلات الدوبامين D2 في مسار المكافأة المتوسطي، وتراجع ضبابية الدماغ مع استقرار هرمونات التيستوستيرون والدوبامين القاعدي.",
            practicalAdvice = "ابدأ بممارسة رياضة خفيفة أو المشي في الهواء الطلق لتحفيز إفراز الإندورفين والدوبامين الفطري."
        ),
        DopamineReceptorMilestone(
            day = 14,
            phaseTitle = "أسبوعان - تمكين الفص الجبهي",
            biologicalTitle = "استعادة السيطرة التنفيذية على اللوزة الدماغية",
            biologicalChange = "تعزيز الروابط المشبكية بين القشرة أمام الجبهية (PFC) المسؤولة عن قوة الإرادة ومراكز الانفعال البدائي، مما يمنحك سرعة فرملة عقلانية أعلى ضد الرغبات الاندفاعية.",
            practicalAdvice = "استغل صفاء ذهنك المتنامي في إنجاز مهام فكرية كانت تبدو مؤجلة وثقيلة في السابق."
        ),
        DopamineReceptorMilestone(
            day = 21,
            phaseTitle = "3 أسابيع - التشذيب المشبكي العصبي",
            biologicalTitle = "تفكيك المسارات الإدمانية القديمة (Synaptic Pruning)",
            biologicalChange = "يبدأ الدماغ في إضعاف وتفكيك الوصلات العصبية القديمة التي رسخها الإدمان عبر عملية التشذيب المشبكي، وتزداد حساسية المستقبلات للمحفزات الطبيعية البسيطة.",
            practicalAdvice = "استشعر متعة التفاصيل اليومية البسيطة: محادثة هادئة، كتاب مشوق، أو وجبة صحية متوازنة."
        ),
        DopamineReceptorMilestone(
            day = 30,
            phaseTitle = "شهر كامل - إعادة الضبط الكبرى",
            biologicalTitle = "توازن حساسية الدوبامين واستقرار النواقل",
            biologicalChange = "وصول كثافة مستقبلات D2 إلى مستويات تقارب النطاق الطبيعي المتزن. ينخفض مستوى التوتر الداخلي، وتستعيد دورة النوم العميق قدرتها على غسل السموم العصبية.",
            practicalAdvice = "لقد حققت قفزة بيولوجية كبرى؛ حافظ على روتين يومك ولا تتهاون أمام نوبات الفضول الخادع."
        ),
        DopamineReceptorMilestone(
            day = 45,
            phaseTitle = "45 يوماً - تعزيز المرونة العصبية",
            biologicalTitle = "تماسك المادة البيضاء وسرعة معالجة الإشارات",
            biologicalChange = "زيادة كثافة المادة البيضاء (White Matter) الناقلة للإشارات بين فصوص الدماغ، مما يرفع كفاءة التحليل المنطقي وسرعة اتخاذ القرارات الصحيحة تحت الضغط.",
            practicalAdvice = "نمّ مهارة فكرية أو بدنية جديدة، فعقلك الآن في أوج قابليته للتشكل العصبي الإيجابي."
        ),
        DopamineReceptorMilestone(
            day = 60,
            phaseTitle = "شهران - انحسار البروتين الإدماني",
            biologicalTitle = "تلاشي تراكم بروتين دلتا-فوس-بي (DeltaFosB)",
            biologicalChange = "الانخفاض الجذري لبروتين DeltaFosB التراكمي في النواة المتكئة، وهو البروتين الجزيئي المسؤول عن التثبيت طويل الأمد للرغبة الإدمانية في الذاكرة الخلوية.",
            practicalAdvice = "أنت الآن تمتلك جهازاً عصبياً متماسكاً؛ تذكر دائماً الفارق بين ذاتك الحالية وسنوات الشتات."
        ),
        DopamineReceptorMilestone(
            day = 90,
            phaseTitle = "3 أشهر - المحطة الذهبية لإعادة التشغيل",
            biologicalTitle = "اكتمال الترميم الأساسي لمسار المكافأة (Rebooting)",
            biologicalChange = "فحوصات fMRI تؤكد أن 90 يوماً من النقاء تعيد كثافة مستقبلات الدوبامين إلى مستويات الأصحاء تماماً، مع استقرار المزاج وتوهج الحضور الذهني والشجاعة النفسية.",
            practicalAdvice = "مبروك هذا الإنجاز التاريخي! أصبحت حراً بيولوجياً، ودرعك العصبي بات متيناً لا يُقهر."
        ),
        DopamineReceptorMilestone(
            day = 120,
            phaseTitle = "4 أشهر - ترسيخ الأنماط الفطرية",
            biologicalTitle = "تعميق استقرار المستقبلات العصبية D2/D3",
            biologicalChange = "تحول الأنماط السلوكية الصحية إلى عادات فطرية لا تتطلب جهداً ذهنياً لمقاومتها، مع ثبات مستويات الدوبامين دون تذبذبات حادة.",
            practicalAdvice = "استثمر هذا الاستقرار في وضع أهداف كبرى لحياتك المهنية والشخصية وبناء إنجازات مستدامة."
        ),
        DopamineReceptorMilestone(
            day = 180,
            phaseTitle = "6 أشهر - إعادة الهيكلة المعرفية الشاملة",
            biologicalTitle = "تناغم السيروتونين والدوبامين والاستقرار النفسي",
            biologicalChange = "اكتمال إعادة تشكيل دارات المكافأة المركزية وتناغم إفراز السيروتونين مع الدوبامين، مما ينتج هدوءاً نفسياً عميقاً وحصانة تامة ضد نوبات القلق المباغتة.",
            practicalAdvice = "أنت الآن ملهم حقيقي؛ فلتفخر بما أنجزته لخلايا عقلك ومستقبل حياتك."
        ),
        DopamineReceptorMilestone(
            day = 365,
            phaseTitle = "سنة كاملة - السيادة العصبية المطلقة",
            biologicalTitle = "التشكل العصبي الدائم (Neurogenesis) والولادة الجديدة",
            biologicalChange = "اكتمال دورة النمو العصبي الجديد وبناء شبكات عصبية صلبة ودائمة ترتكز على القوة والوعي، مع محو شبه كامل للمسارات الإدمانية القديمة من الذاكرة الإجرائية.",
            practicalAdvice = "أنت الآن قائد حقيقي لعقلك وسلوكك؛ لقد أعدت كتابة تاريخك العصبي للأبد."
        ),
        DopamineReceptorMilestone(
            day = 730,
            phaseTitle = "سنتان - قمة المناعة العصبية والخلود",
            biologicalTitle = "الرسوخ العصبي الفطري التام",
            biologicalChange = "تثبيت كلي وثيق للدارات العصبية السليمة واستحالة الانقياد التلقائي للمؤثرات الماضية؛ العقل في أعلى مراتب الصفاء والإنتاجية والسلام الداخلي.",
            practicalAdvice = "حافظ على تواضع القوي ويقظة الحكيم؛ الحياة أرحب بكثير في فضاء الحرية المطلقة."
        )
    )

    fun getMilestoneForDay(day: Int): DopamineReceptorMilestone? {
        return milestones.firstOrNull { it.day == day }
    }

    fun getLatestMilestoneUpTo(day: Int): DopamineReceptorMilestone? {
        return milestones.filter { it.day <= day }.maxByOrNull { it.day }
    }
}
