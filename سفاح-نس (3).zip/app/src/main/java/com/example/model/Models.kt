package com.example.model

import android.graphics.drawable.Drawable

enum class DnsFilterServer(
    val displayName: String,
    val primaryIp: String,
    val secondaryIp: String,
    val ipv6Primary: String,
    val ipv6Secondary: String,
    val description: String
) {
    CLEAN_BROWSING(
        "CleanBrowsing (Family Filter)",
        "185.228.168.168",
        "185.228.169.168",
        "2a0d:2a00:1::2",
        "2a0d:2a00:2::2",
        "حظر المواقع الإباحية والصريحة تلقائياً على مستوى DNS"
    ),
    CLOUDFLARE_FAMILIES(
        "Cloudflare Families (1.1.1.3)",
        "1.1.1.3",
        "1.0.0.3",
        "2606:4700:4700::1113",
        "2606:4700:4700::1003",
        "حظر البرمجيات الخبيثة والمحتوى الصريح بفرز أمني عالي"
    ),
    ADGUARD_FAMILY(
        "AdGuard DNS (Family Protection)",
        "94.140.14.15",
        "94.140.15.16",
        "2a10:50c0::ad1:ff",
        "2a10:50c0::ad2:ff",
        "حظر الإعلانات المزعجة ومواقع المحتوى الإباحي والضار"
    )
}

data class PermissionStatus(
    val isAccessibilityEnabled: Boolean = false,
    val isExactAlarmEnabled: Boolean = false,
    val isNotificationAccessEnabled: Boolean = false,
    val isDeviceOwnerActive: Boolean = false,
    val isVpnActive: Boolean = false
)

data class InstalledApp(
    val packageName: String,
    val appName: String,
    val isExcludedFromVpn: Boolean = false,
    val isBlocked: Boolean = false,
    val isSystemApp: Boolean = false,
    val iconDrawable: Drawable? = null
)

data class BlockedKeyword(
    val id: Long = System.currentTimeMillis(),
    val keyword: String,
    val dateAdded: String,
    val isEnabled: Boolean = true
)

data class BlockedSite(
    val id: Long = System.currentTimeMillis(),
    val domain: String,
    val dateAdded: String,
    val isEnabled: Boolean = true
)

data class BlockLogEntry(
    val id: Long = System.currentTimeMillis(),
    val blockedItem: String,
    val type: String, // "كلمة" أو "موقع" أو "تطبيق"
    val timestamp: String,
    val sourceApp: String
)

enum class AppBlockType {
    BLOCK_SPECIFIED,             // حظر استخدام التطبيقات المحددة
    ALLOW_SPECIFIED_BLOCK_OTHERS // السماح بالتطبيقات المحددة وحظر الباقي
}

data class ScheduleTimeRange(
    val startHour: Int = 9,
    val startMinute: Int = 0,
    val endHour: Int = 17,
    val endMinute: Int = 0
)

data class AppBlockScheduleRule(
    val id: Long = System.currentTimeMillis(),
    val name: String = "",
    val isEnabled: Boolean = false,
    val timeRanges: List<ScheduleTimeRange> = listOf(ScheduleTimeRange(startHour = 9, startMinute = 0, endHour = 17, endMinute = 0)),
    val startHour: Int = 9,
    val startMinute: Int = 0,
    val endHour: Int = 17,
    val endMinute: Int = 0,
    val activeDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7), // Calendar.SUNDAY(1)..SATURDAY(7)
    val blockType: AppBlockType = AppBlockType.BLOCK_SPECIFIED,
    val selectedPackages: Set<String> = emptySet()
) {
    fun getEffectiveTimeRanges(): List<ScheduleTimeRange> {
        return if (timeRanges.isNotEmpty()) {
            timeRanges
        } else {
            listOf(ScheduleTimeRange(startHour, startMinute, endHour, endMinute))
        }
    }
}

enum class UsageLimitType {
    DURATION,     // حد وقت الاستخدام (بالدقائق)
    LAUNCH_COUNT  // حد مرات الفتح (عدد المرات)
}

data class UsageBlockRule(
    val id: Long = System.currentTimeMillis(),
    val name: String = "",
    val isEnabled: Boolean = false,
    val activeDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7), // Calendar.SUNDAY(1)..SATURDAY(7)
    val limitType: UsageLimitType = UsageLimitType.DURATION,
    val limitValue: Int = 30, // 30 minutes OR 10 launches
    val selectedPackages: Set<String> = emptySet(),
    val createdAt: Long = System.currentTimeMillis(),
    val lastActivatedAt: Long = System.currentTimeMillis(),
    val packageAddedAt: Map<String, Long> = emptyMap()
)

data class BackupMetadata(
    val backupDate: String,
    val timestamp: Long,
    val keywordsCount: Int,
    val sitesCount: Int,
    val permanentBlockedCount: Int,
    val usageRulesCount: Int,
    val scheduleRulesCount: Int,
    val blockLogsCount: Int = 0,
    val vpnExcludedCount: Int = 0,
    val uninstallBlockedCount: Int = 0,
    val keywordExemptedCount: Int = 0,
    val contentFiltersCount: Int = 0,
    val securityRestrictionsCount: Int = 0,
    val notificationsCount: Int = 0,
    val diariesCount: Int = 0,
    val isBedtimeConfigured: Boolean = false,
    val isProductivityConfigured: Boolean = false,
    val isPenaltyConfigured: Boolean = false,
    val isUrgeRuleConfigured: Boolean = false,
    val isQrKeyConfigured: Boolean = false,
    val isPrivacyPinConfigured: Boolean = false,
    val deviceModel: String = "",
    val appVersion: String = "2.0"
)

data class BackupSummary(
    val lastBackupFormatted: String?,
    val lastBackupTimestamp: Long,
    val keywordsCount: Int,
    val sitesCount: Int,
    val permanentBlockedCount: Int,
    val usageRulesCount: Int,
    val scheduleRulesCount: Int,
    val blockLogsCount: Int = 0,
    val vpnExcludedCount: Int = 0,
    val uninstallBlockedCount: Int = 0,
    val keywordExemptedCount: Int = 0,
    val contentFiltersCount: Int = 0,
    val securityRestrictionsCount: Int = 0,
    val notificationsCount: Int = 0,
    val diariesCount: Int = 0,
    val isBedtimeConfigured: Boolean = false,
    val bedtimeSummaryText: String = "",
    val isProductivityConfigured: Boolean = false,
    val productivitySummaryText: String = "",
    val isPenaltyConfigured: Boolean = false,
    val isUrgeRuleConfigured: Boolean = false,
    val isQrKeyConfigured: Boolean = false,
    val isPrivacyPinConfigured: Boolean = false,
    val totalRulesCount: Int
)

data class ProductivityTargetApp(
    val packageName: String,
    val targetMinutes: Int, // سقف وقت الاستخدام اليومي بالدقائق
    val baselineMillis: Long = 0L, // خط الأساس بالمللي ثانية عند إضافة الهدف اليوم
    val addedAt: Long = 0L // وقت إضافة أو تجديد الهدف
)

data class ProductivityDisciplineRule(
    val id: Long = System.currentTimeMillis(),
    val name: String = "تحسين الإنتاجية والإنظباط",
    val isEnabled: Boolean = false,
    val activeDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7), // Calendar.SUNDAY(1)..SATURDAY(7)
    val targetApps: List<ProductivityTargetApp> = emptyList(), // التطبيقات المحددة مع سقف الاستخدام الخاص بكل تطبيق
    val allowedApps: Set<String> = emptySet() // التطبيقات المسموحة بحرية
)

data class CompiledKeywordRule(
    val id: Long,
    val keyword: String,
    val isStarBounded: Boolean,
    val targetWordLower: String,
    val targetWordNormalized: String = targetWordLower,
    val isArabicOrContainsAlef: Boolean = false
)

data class CompiledSiteRule(
    val id: Long,
    val domain: String,
    val normalizedDomain: String
)

