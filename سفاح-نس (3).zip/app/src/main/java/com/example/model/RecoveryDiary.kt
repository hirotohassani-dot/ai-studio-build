package com.example.model

enum class DiaryMediaType {
    AUDIO,
    IMAGE,
    VIDEO
}

enum class DiaryMediaSource {
    RECORDED_IN_APP,        // مسجل مباشرة داخل التطبيق
    UPLOADED_FROM_STORAGE   // مرفوع من مدير الملفات
}

data class DiaryMediaItem(
    val id: String,
    val type: DiaryMediaType,
    val source: DiaryMediaSource,
    val filePath: String,
    val fileName: String,
    val durationSeconds: Int = 0,
    val fileSizeBytes: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

enum class DiaryEmotionCategory(val title: String) {
    POSITIVE("مشاعر إيجابية"),
    NEUTRAL("مشاعر مُحايدة"),
    NEGATIVE("مشاعر سلبية")
}

data class DiaryEmotion(
    val id: String,
    val emoji: String,
    val label: String,
    val category: DiaryEmotionCategory
)

object DiaryEmotionList {
    val ALL: List<DiaryEmotion> = listOf(
        // مشاعر إيجابية (15)
        DiaryEmotion("pos_pride", "🌟", "فخر واعتزاز", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_strength", "💪", "قوة وعزيمة", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_peace", "🕊️", "سكينة واطمئنان", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_happy", "😊", "تفاؤل وسعادة", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_vitality", "⚡", "نشاط وحيوية", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_focus", "🎯", "تركيز وصفاء", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_zen", "🧘", "سلام داخلي", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_calm", "🌿", "راحة وهدوء", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_success", "🏆", "إنجاز ونجاح", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_gratitude", "🤲", "امتنان وشكر", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_resilience", "🧗", "صمود وثبات", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_hope", "✨", "أمل متجدد", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_secure", "🛡️", "أمان وحصانة", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_passion", "🔥", "حماس وشغف", DiaryEmotionCategory.POSITIVE),
        DiaryEmotion("pos_clarity", "☀️", "وضوح وبصيرة", DiaryEmotionCategory.POSITIVE),

        // مشاعر متوسطة / تأملية (11)
        DiaryEmotion("neu_calm", "😐", "هدوء محايد", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_reflect", "🤔", "تفكير وتأمل", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_patience", "⏳", "صبر وترقب", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_distracted", "🌪️", "تشتت ذهني", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_tired", "🥱", "تعب جسدي", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_silent", "😶", "صمت وشرود", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_balance", "⚖️", "توازن ومواكبة", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_change", "🔄", "رغبة بالتغيير", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_puzzled", "🧩", "حيرة وتردد", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_nostalgia", "💭", "حنين وتذكر", DiaryEmotionCategory.NEUTRAL),
        DiaryEmotion("neu_routine", "📅", "روتين عادي", DiaryEmotionCategory.NEUTRAL),

        // مشاعر سلبية / ضغوط ومحفزات (15)
        DiaryEmotion("neg_craving", "⚠️", "اشتهاء ورغبة ملحة", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_choked", "😣", "ضيق واختناق", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_sad", "😔", "حزن وكآبة", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_angry", "😠", "غضب وانفعال", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_anxious", "😰", "قلق وتوتر", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_exhausted", "😫", "إرهاق واستنزاف", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_empty", "🕳️", "فراغ ووحدة", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_regret", "💔", "ندم وحسرة", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_fear", "🥶", "خوف وهلع", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_frustrated", "📉", "إحباط ويأس", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_guilt", "🥺", "تأنب ضمير", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_boredom", "😑", "ملل وضجر", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_irritated", "💢", "انزعاج وتحفز", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_self_blame", "🤦‍♂️", "لوم الذات", DiaryEmotionCategory.NEGATIVE),
        DiaryEmotion("neg_burden", "🌧️", "كتمان وثقل", DiaryEmotionCategory.NEGATIVE)
    )

    fun findById(id: String): DiaryEmotion? = ALL.find { it.id == id }
}

enum class DiaryEntryType(
    val displayName: String
) {
    DIARY("يوميات"),
    NOTE("ملاحظة"),
    VICTORY("انتصار"),
    URGE("رغبة"),
    RELAPSE("انتكاسة"),
    REFLECTION("تأمل"),
    GOAL("هدف");

    companion object {
        val DEFAULT = NOTE

        val ALL_TYPES = listOf(
            DIARY,
            NOTE,
            VICTORY,
            URGE,
            RELAPSE,
            REFLECTION,
            GOAL
        )

        fun fromString(value: String?): DiaryEntryType {
            if (value.isNullOrBlank()) return DEFAULT
            val trimmed = value.trim()
            return entries.firstOrNull {
                it.displayName == trimmed || it.name.equals(trimmed, ignoreCase = true)
            } ?: DEFAULT
        }
    }
}

enum class DiaryDateFilter(val displayName: String) {
    ALL("الكل"),
    TODAY("اليوم"),
    LAST_7_DAYS("7 أيام"),
    LAST_30_DAYS("30 يومًا"),
    THIS_MONTH("هذا الشهر"),
    CUSTOM("مخصص");

    companion object {
        val ALL_FILTERS = listOf(ALL, TODAY, LAST_7_DAYS, LAST_30_DAYS, THIS_MONTH, CUSTOM)
    }
}

enum class DiarySortOrder(val displayName: String) {
    NEWEST_FIRST("الأحدث أولًا"),
    OLDEST_FIRST("الأقدم أولًا"),
    LAST_UPDATED("آخر تعديل"),
    LONGEST("الأكثر طولًا"),
    SHORTEST("الأقصر طولاً");

    companion object {
        val ALL_ORDERS = listOf(NEWEST_FIRST, OLDEST_FIRST, LAST_UPDATED, LONGEST, SHORTEST)
    }
}

data class RecoveryDiaryEntry(
    val id: String,
    val title: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val mediaList: List<DiaryMediaItem> = emptyList(),
    val emotions: List<String> = emptyList(),
    val type: String = DiaryEntryType.NOTE.displayName
)
