package com.example.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * بيئات ومناخات خريطة رحلة التعافي المستوحاة من الطبيعة
 */
enum class BiomeType(
    val arabicName: String,
    val description: String,
    val primaryColorHex: Long,
    val secondaryColorHex: Long,
    val dayStart: Int,
    val dayEnd: Int
) {
    OASIS_FOOTHILLS(
        arabicName = "سفوح البدايات والواحة الخضراء",
        description = "مرحلة اليقظة الأولى وكسر الارتباط السلوكي الحاد",
        primaryColorHex = 0xFF10B981, // Emerald green
        secondaryColorHex = 0xFF059669,
        dayStart = 1,
        dayEnd = 28
    ),
    GOLDEN_DESERT(
        arabicName = "صحراء الصمود والرمال الذهبية",
        description = "مرحلة ترويض الرغبات واجتياز موجات الإلحاح الجافة",
        primaryColorHex = 0xFFF59E0B, // Amber / Desert Gold
        secondaryColorHex = 0xFFD97706,
        dayStart = 29,
        dayEnd = 63
    ),
    DEEP_FOREST(
        arabicName = "غابات اليقظة والصفاء الدماغي",
        description = "بداية استشفاء مستقبلات الدوبامين واستعادة التركيز العميق",
        primaryColorHex = 0xFF14B8A6, // Teal Forest
        secondaryColorHex = 0xFF0F766E,
        dayStart = 64,
        dayEnd = 105
    ),
    GRANITE_MOUNTAINS(
        arabicName = "قمم الجبال ودروب الصوان",
        description = "تجاوز حاجز الـ 90 يوماً وتثبيت الانضباط الفولاذي",
        primaryColorHex = 0xFF6366F1, // Indigo Mountains
        secondaryColorHex = 0xFF4338CA,
        dayStart = 106,
        dayEnd = 175
    ),
    CRYSTAL_RIVERS(
        arabicName = "وادي الأنهار والشلالات الهادرة",
        description = "تدفق الطاقة الحيوية، استقرار النوم ونقاء المشاعر",
        primaryColorHex = 0xFF06B6D4, // Cyan / River Blue
        secondaryColorHex = 0xFF0891B2,
        dayStart = 176,
        dayEnd = 252
    ),
    VOLCANIC_RIDGE(
        arabicName = "هضبة البراكين وترويض الحمم",
        description = "صقل الشخصية تحت ضغوط الحياة وبناء مناعة نفسية صلبة",
        primaryColorHex = 0xFFEA580C, // Fire / Volcanic Orange
        secondaryColorHex = 0xFFC2410C,
        dayStart = 253,
        dayEnd = 350
    ),
    GLACIER_PEAKS(
        arabicName = "جبال الجليد والنقاء الأزرق",
        description = "إتمام العام الأول، هدوء نفسي راسخ واندثار المحفزات القديمة",
        primaryColorHex = 0xFF38BDF8, // Ice Sky Blue
        secondaryColorHex = 0xFF0284C7,
        dayStart = 351,
        dayEnd = 490
    ),
    ROYAL_PLATEAU(
        arabicName = "السهول الملكية الشاسعة",
        description = "مرحلة السيادة والارتقاء، تحول الانضباط إلى طبع فطري",
        primaryColorHex = 0xFFEC4899, // Royal Rose / Magenta
        secondaryColorHex = 0xFFDB2777,
        dayStart = 491,
        dayEnd = 630
    ),
    CELESTIAL_SUMMIT(
        arabicName = "قمة السَّفاح الأسطورية وسماء الخلود",
        description = "730 يوماً من النقاء والحرية المطلقة - ختام رحلة السنتين",
        primaryColorHex = 0xFFA855F7, // Royal Purple / Apex Gold
        secondaryColorHex = 0xFF7E22CE,
        dayStart = 631,
        dayEnd = 730
    );

    companion object {
        fun getBiomeForDay(day: Int): BiomeType {
            return entries.firstOrNull { day in it.dayStart..it.dayEnd } ?: CELESTIAL_SUMMIT
        }
    }
}

/**
 * مجال التغير الإيجابي المدعوم علمياً
 */
data class PositiveChangeItem(
    val category: String, // الدماغ، الجسم، المزاج، النوم، التركيز، العلاقات والروح
    val details: String
)

/**
 * بيانات محطة من محطات خريطة رحلة التعافي (كل 7 أيام حتى 730 يوماً)
 */
data class RecoveryJourneyMilestone(
    val stationNumber: Int,              // رقم المحطة (1 إلى 105)
    val day: Int,                        // رقم اليوم (7، 14، 21، 28... 730)
    val title: String,                   // عنوان المحطة
    val durationLabel: String,           // تسمية المدة (مثال: أسبوع، شهر، 3 أشهر...)
    val biome: BiomeType,                // البيئة الطبيعية
    val motivationalQuoteTemplate: String, // نص التحفيز (يقبل اسم المستخدم)
    val positiveChanges: List<PositiveChangeItem>, // التغيرات الإيجابية الواقعية
    val symptomsAndWithdrawal: List<String>,       // الأعراض والتحديات الفعلية المتوقعة
    val scientificNote: String           // معلومة علمية رصينة عن هذه المرحلة
)
