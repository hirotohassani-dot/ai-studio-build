package com.example.model

/**
 * بيانات وإحصائيات مركز التعافي الأساسية
 */
data class RecoveryStats(
    val startTimestamp: Long,            // بداية التعافي الحالي
    val relapseCount: Int,               // عدد الانتكاسات
    val longestStreakDays: Int,          // أطول مدة تم تحقيقها بالأيام
    val longestStreakSeconds: Long       // أطول مدة تم تحقيقها بالثواني
)

/**
 * بيانات وثيقة عهد وميثاق التعافي
 */
data class RecoveryPledgeData(
    val pledgeText: String = "",
    val isSigned: Boolean = false,
    val signedDate: String = "",
    val signedTime: String = "",
    val signedTimestamp: Long = 0L,
    val signaturePointsJson: String = "",
    val videoPath: String = "",
    val signerName: String = ""
)

/**
 * سجل سلسلة تعافي تاريخية أو حالية (Recovery Streak Record)
 */
data class RecoveryStreakRecord(
    val id: String,
    val rank: Int = 1,
    val startTimestamp: Long,
    val endTimestamp: Long,
    val isOngoing: Boolean,
    val days: Int,
    val hours: Int,
    val minutes: Int,
    val totalSeconds: Long,
    val isAllTimeRecord: Boolean = false
)

/**
 * محفزات الانتكاسة السلوكية ونموذج HALT للتعافي الإدماني
 */
enum class RelapseTrigger(
    val id: String,
    val title: String,
    val description: String
) {
    BOREDOM("boredom", "الفراغ والملل", "عدم وجود هدف أو نشاط يشغل الذهن"),
    LATE_NIGHT("late_night", "السهر بمفردك", "البقاء مستيقظاً في خلوة مع الهاتف"),
    RANDOM_BROWSING("random_browsing", "التصفح العشوائي", "التنقل غير الهادف في مواقع التواصل"),
    STRESS("stress", "الضغط النفسي والتوتر", "الهروب من التحديات والواجبات اليومية"),
    LONELINESS("loneliness", "الوحدة والعزلة", "الشعور بالانفصال الاجتماعي أو العاطفي"),
    FATIGUE("fatigue", "الإرهاق والاستنزاف", "انخفاض طاقة الإرادة بسبب قلة النوم أو التعب"),
    ANGER("anger", "الغضب والإحباط", "البحث عن تنفيس وهمي للمشاعر السلبية"),
    OTHER("other", "محفز آخر", "سبب أو ظرف خاص")
}

/**
 * سجل حدث الانتكاسة مع التوقيت والتشريح السلوكي الدقيق
 */
data class RelapseRecord(
    val id: String,
    val timestamp: Long,
    val note: String = "",
    val triggerId: String = RelapseTrigger.OTHER.id,
    val defenseAction: String = "", // خطة الحماية والقرار الوقائي للجولة القادمة
    val initialSpark: String = "", // التسلسل الزمني للزلة: أين بدأت الشرارة الأولى؟
    val loopholeType: String = "", // الثغرة التقنية/السلوكية: كيف تم الوصول للمحتوى رغم الحظر؟
    val haltMoodState: String = "", // الحالة المزاجية قبل الزلة مباشرة (HALT)
    val preventiveDecision: String = "" // القرار الوقائي الإلزامي
)

/**
 * إحصائية انتشار وتكرار المحفز السلوكي
 */
data class TriggerStat(
    val trigger: RelapseTrigger,
    val count: Int,
    val percentage: Float,
    val isPrimary: Boolean
)

/**
 * مقاييس النقاء المطلق 100% والاستدامة السلوكية (100% Pure Days & MTBR)
 */
data class PureDaysPurityMetrics(
    val totalDaysTracked: Int,
    val totalPureDays: Int,
    val pureDaysPercentage: Float,               // نسبة الأيام الصافية تماماً من إجمالي الرحلة
    val meanTimeBetweenRelapsesDays: Float,       // متوسط زمن الاستدامة الصافي بين كل انتكاسة (MTBR)
    val currentStreakDays: Int,
    val longestStreakDays: Int,
    val totalRelapses: Int,
    val cleanPurityStatus: String                // توصيف مستوى الانضباط والنقاء
)

/**
 * المرحلة العلمية الحالية لإعادة تشكيل مسارات الدوبامين (Neuroplasticity Stage)
 */
data class NeuroRecoveryStage(
    val stageNumber: Int,
    val stageName: String,
    val scientificTitle: String,
    val dayRange: String,
    val biologicalExplanation: String,
    val targetDays: Int,
    val currentDays: Int,
    val progressPercent: Float,
    val keyActionableTip: String
)

/**
 * إحصائية خطورة اليوم في أيام الأسبوع
 */
data class DayRiskStat(
    val dayOfWeek: Int,                  // java.util.Calendar (SUNDAY=1 .. SATURDAY=7)
    val arabicName: String,              // "السبت", "الأحد", ...
    val shortName: String,               // "سبت", "أحد", ...
    val count: Int,                      // عدد الانتكاسات في هذا اليوم
    val percentage: Float,               // النسبة من إجمالي الانتكاسات (0.0f .. 1.0f)
    val isPeak: Boolean                  // هل هذا اليوم هو ذروة الخطورة
)

/**
 * إحصائية خطورة النطاق الزمني (بتنسيق 24h)
 */
data class TimeRiskStat(
    val rangeKey: String,                // "00:00 - 04:00"
    val startHour: Int,                  // 0, 4, 8, 12, 16, 20
    val endHour: Int,                    // 4, 8, 12, 16, 20, 24
    val title: String,                   // "منتصف الليل والفجر"
    val count: Int,                      // عدد الانتكاسات في هذا النطاق
    val percentage: Float,               // النسبة من إجمالي الانتكاسات (0.0f .. 1.0f)
    val isPeak: Boolean                  // هل هذا النطاق هو ذروة الخطورة
)

/**
 * درجات شدة نوبة الرغبة والشوق (Urge Intensity)
 */
enum class UrgeIntensity(val id: String, val title: String, val levelNumber: Int) {
    MILD("mild", "خفيفة (تشتت عابر)", 1),
    MODERATE("moderate", "متوسطة (إلحاح متصاعد)", 2),
    STRONG("strong", "شديدة (ضغط ذهني قوي)", 3),
    CRITICAL("critical", "حرجة / طارئة (ذروة النوبة)", 4)
}

/**
 * التقنيات السلوكية والعصبية لدحر موجة الشوق (Urge Surfing Techniques)
 */
enum class UrgeDefenseTechnique(val id: String, val title: String, val scientificBasis: String) {
    MINUTES_15_RULE("15_min_rule", "قاعدة الـ 15 دقيقة", "انتظار انحسار موجة الإفراز العصبي للدوبامين"),
    BREATHING_478("breathing_478", "تنفس استعادة السيطرة (4-7-8)", "تنشيط العصب الحائر وتخفيض نبضات القلب"),
    COLD_WATER_RESET("cold_water", "غسل الوجه بالماء البارد", "صدمة حرارية لإيقاف استثارة اللوزة الدماغية فوراً"),
    PHONE_DISPLACEMENT("phone_displacement", "إبعاد الجهاز ومغادرة الغرفة", "كسر الاقتران المكاني الحسي المباشر"),
    PHYSICAL_BURST("physical_burst", "نشاط بدني فوري مكثف (تمارين)", "تفريغ طاقة الأدرينالين وإعادة توجيه تدفق الدم"),
    COGNITIVE_REFRAME("cognitive_reframe", "تفكيك التبرير الوهمي وكتابة التشريح", "استعادة سيادة الفص الجبهي التنفيذي"),
    OTHER("other", "وسيلة دفاعية أخرى", "إجراء وقائي بديل")
}

/**
 * سجل حدث دحر وتجاوز نوبة الرغبة (Urge Surfing Log)
 */
data class UrgeLogEntry(
    val id: String,
    val timestamp: Long,
    val intensity: UrgeIntensity,
    val trigger: RelapseTrigger,
    val technique: UrgeDefenseTechnique,
    val durationMinutes: Int = 15,
    val resistedSuccessfully: Boolean = true,
    val note: String = "",
    val customTechnique: String = "",
    val customTrigger: String = "",
    val audioPath: String? = null
)

/**
 * إحصائيات رصد ومقاومة نوبات الشوق (Urge Surfing Analytics)
 */
data class UrgeSurfingAnalytics(
    val totalUrgesLogged: Int,
    val totalUrgesDefeated: Int,
    val resistanceSuccessRate: Float,
    val mostEffectiveTechniqueTitle: String,
    val primaryUrgeTriggerTitle: String,
    val recentUrges: List<UrgeLogEntry> = emptyList(),
    val totalUrgesFailed: Int = (totalUrgesLogged - totalUrgesDefeated).coerceAtLeast(0)
)

/**
 * الفحص البيولوجي اليومي لتوازن الدوبامين واستعادة وظائف الجهاز العصبي (Dopamine Baseline Bio-Check)
 */
data class DopamineBioCheck(
    val id: String,
    val dateKey: String, // "YYYY-MM-DD"
    val timestamp: Long,
    val brainClarityScore: Int,    // 1 to 5 (1 = ضباب دماغي حاد، 5 = صفاء وتركيز تام)
    val moodStabilityScore: Int,   // 1 to 5 (1 = تقلب وقلق انسحابي، 5 = اتزان نفسي ممتاز)
    val sleepQualityScore: Int,    // 1 to 5 (1 = أرق وتقطع، 5 = نوم عميق ومريح)
    val vitalEnergyScore: Int,     // 1 to 5 (1 = خمول واستنزاف، 5 = طاقة وحيوية عالية)
    val note: String = ""
)

/**
 * ملخص المؤشر البيولوجي للدوبامين
 */
data class DopamineBioSummary(
    val totalChecksCount: Int,
    val averageClarityScore: Float,
    val averageMoodScore: Float,
    val averageSleepScore: Float,
    val averageEnergyScore: Float,
    val overallDopamineBalancePercent: Float, // 0..100%
    val statusLabel: String,
    val latestCheck: DopamineBioCheck? = null
)

/**
 * مقياس ساعات الحياة والتركيز الذهني المستردة (Time & Energy Reclaimed)
 */
data class TimeReclaimedMetrics(
    val pureDaysCount: Int,
    val totalHoursReclaimed: Float,      // حساب 2.5 ساعة يومياً كانت تُهدر في البحث والتصفح والإرهاق
    val executiveFocusHours: Float,     // ساعات التركيز عالي الإنتاجية للفص الجبهي المستردة (1.5 ساعة/يوم)
    val booksEquivalentCount: Int,      // ما يعادل قراءة كتب (بمعدل 6 ساعات للكتاب)
    val workoutsEquivalentCount: Int    // ما يعادل حصص تدريب بدني (بمعدل 1.5 ساعة للحصة)
)

/**
 * مستويات الحذر والمخاطر اللحظية (Real-Time Vulnerability Level)
 */
enum class VulnerabilityLevel(val label: String, val levelNumber: Int) {
    SAFE("حصانة واستقرار تام", 1),
    MODERATE("انتباه وحذر معتدل", 2),
    HIGH_ALERT("منطقة مخاطر وحذر قصوى", 3)
}

/**
 * مؤشر الحذر والمخاطر اللحظي
 */
data class RealtimeVulnerabilityState(
    val level: VulnerabilityLevel,
    val title: String,
    val contextualReason: String,
    val recommendedAction: String
)

/**
 * خيارات الفترات الزمنية لتتبع سرعة التعافي ومقارنة التحسن
 */
enum class VelocityTimeWindow(
    val days: Int,
    val title: String,
    val shortLabel: String
) {
    PAST_WEEK(7, "مقارنة بالأسبوع السابق", "7 أيام"),
    PAST_HALF_MONTH(15, "مقارنة بنصف الشهر السابق", "15 يوم"),
    PAST_MONTH(30, "مقارنة بالشهر السابق", "30 يوم")
}

/**
 * مقاييس ومؤشرات تتبع سرعة التعافي وتحليل التحسن الزمني
 */
data class RecoveryVelocityMetrics(
    val window: VelocityTimeWindow,
    val currentPeriodAttempts: Int,        // إجمالي محاولات الحظر بالفترة الحالية
    val previousPeriodAttempts: Int,       // إجمالي محاولات الحظر بالفترة السابقة
    val currentKeywordsCount: Int,         // محاولات البحث والكلمات المحظورة بالفترة الحالية
    val previousKeywordsCount: Int,        // محاولات البحث والكلمات المحظورة بالفترة السابقة
    val currentSitesCount: Int,            // محاولات المواقع المحظورة بالفترة الحالية
    val previousSitesCount: Int,           // محاولات المواقع المحظورة بالفترة السابقة
    val changePercentage: Float,           // نسبة التغير المئوية
    val isImprovement: Boolean,
    val isZeroStable: Boolean,
    val velocityScore: Int,
    val velocityLevelTitle: String,
    val comparisonInsight: String
)

/**
 * الحزمة الشاملة لإحصائيات وتحليلات التعافي
 */
data class RecoveryAnalytics(
    val totalRelapses: Int,
    val purityMetrics: PureDaysPurityMetrics,
    val neuroStage: NeuroRecoveryStage,
    val triggerStats: List<TriggerStat>,
    val dayRiskStats: List<DayRiskStat>,
    val timeRiskStats: List<TimeRiskStat>,
    val mostDangerousDay: String?,
    val mostDangerousTimeRange: String?,
    val peakDayCount: Int,
    val peakTimeCount: Int,
    val history: List<RelapseRecord>,
    val velocityMetricsMap: Map<VelocityTimeWindow, RecoveryVelocityMetrics> = emptyMap(),
    val urgeAnalytics: UrgeSurfingAnalytics = UrgeSurfingAnalytics(0, 0, 1.0f, "قاعدة الـ 15 دقيقة", "الفراغ والملل"),
    val dopamineBioSummary: DopamineBioSummary = DopamineBioSummary(0, 4.0f, 4.0f, 4.0f, 4.0f, 80f, "استقرار أولي متوازن"),
    val timeReclaimedMetrics: TimeReclaimedMetrics = TimeReclaimedMetrics(0, 0f, 0f, 0, 0),
    val realtimeVulnerability: RealtimeVulnerabilityState = RealtimeVulnerabilityState(
        level = VulnerabilityLevel.SAFE,
        title = "حصانة واستقرار تام",
        contextualReason = "ساعات النهار النشطة مع مسار تعافٍ نقي",
        recommendedAction = "حافظ على التركيز والإنتاجية العالية"
    )
)

/**
 * فحص خط الأساس اليومي (Daily Baseline Index)
 * 4 مقاييس من 1 إلى 5:
 * 1. صفاء الذهن (Mental clarity)
 * 2. استقرار المزاج (Mood stability)
 * 3. جودة النوم والنشاط الصباحي (Sleep quality & morning vitality)
 * 4. مستوى الطاقة والحافز للإنجاز (Energy level & drive for achievement)
 */
data class DailyBaselineCheckIn(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val dateKey: String = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(timestamp)),
    val clarityOfMind: Int = 3,         // 1..5: صفاء الذهن
    val moodStability: Int = 3,         // 1..5: استقرار المزاج
    val sleepQuality: Int = 3,          // 1..5: جودة النوم والنشاط الصباحي
    val energyAndMotivation: Int = 3,   // 1..5: مستوى الطاقة والحافز للإنجاز
    val averageScore: Double = (clarityOfMind + moodStability + sleepQuality + energyAndMotivation) / 4.0,
    val scorePercentage: Int = (((clarityOfMind + moodStability + sleepQuality + energyAndMotivation) / 20.0) * 100.0).toInt().coerceIn(0, 100)
)

/**
 * فترات عرض مخطط خط الأساس
 */
enum class BaselineChartPeriod(val id: String, val titleAr: String, val titleEn: String) {
    DAY("day", "يومي", "Day"),
    WEEK("week", "أسبوعي", "Week"),
    MONTH("month", "شهري", "Month")
}

/**
 * نقطة بيانية في مخطط خط الأساس التفاعلي
 */
data class BaselineDataPoint(
    val key: String,
    val displayLabel: String,
    val subLabel: String? = null,
    val yearLabel: String? = null,
    val timestamp: Long,
    val scorePercentage: Int,
    val rawAverage: Double,
    val clarity: Double,
    val mood: Double,
    val sleep: Double,
    val energy: Double,
    val checkInCount: Int = 1
)

/**
 * ملخص بيانات النسخ الاحتياطي لمركز التعافي
 */
data class RecoveryBackupSummary(
    val currentStreakDays: Int = 0,
    val totalPureDays: Int = 0,
    val relapsesCount: Int = 0,
    val urgesCount: Int = 0,
    val diariesCount: Int = 0,
    val diariesTrashCount: Int = 0,
    val imagesCount: Int = 0,
    val videosCount: Int = 0,
    val audiosCount: Int = 0,
    val milestoneMediaCount: Int = 0,
    val calendarDaysCount: Int = 0,
    val isPledgeSigned: Boolean = false,
    val totalMediaSizeBytes: Long = 0L,
    val lastBackupFormatted: String? = null,
    val lastBackupTimestamp: Long = 0L
) {
    val totalMediaCount: Int
        get() = imagesCount + videosCount + audiosCount
}

/**
 * نتيجة تصدير النسخة الاحتياطية الشاملة
 */
data class RecoveryBackupResult(
    val totalFilesArchived: Int,
    val totalBytesWritten: Long,
    val backupDateFormatted: String,
    val summary: RecoveryBackupSummary
)

/**
 * نتيجة استيراد واستعادة النسخة الاحتياطية
 */
data class RecoveryRestoreResult(
    val diariesRestored: Int,
    val diariesTrashRestored: Int,
    val imagesRestored: Int,
    val videosRestored: Int,
    val audiosRestored: Int,
    val relapsesRestored: Int,
    val urgesRestored: Int,
    val milestonesRestored: Int,
    val calendarDaysRestored: Int = 0,
    val isPledgeRestored: Boolean,
    val message: String
)

/**
 * حالة تتبع اليوم في تقويم التعافي
 */
enum class DailyCalendarStatus(val id: String, val title: String) {
    SUCCESS("SUCCESS", "تم سحق وحش الإباحية بنجاح"),
    RELAPSE("RELAPSE", "انتكاسة"),
    SKIPPED("SKIPPED", "تخطي دون متابعة"),
    NONE("NONE", "غير محدد")
}

/**
 * سجل تقويم تتبع التعافي لليوم
 */
data class RecoveryCalendarEntry(
    val dateKey: String, // "yyyy-MM-dd"
    val status: DailyCalendarStatus,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)


