package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

import android.content.Intent
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.util.SaffahLockTaskManager
import com.example.util.SaffahProtectionManager

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lockTaskCheckRunnable: Runnable? = null

    private val packageChangeReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val pkg = intent.data?.schemeSpecificPart
            Log.i("MainActivity", "Dynamic package event received: ${intent.action} for $pkg")
            com.example.util.AppListHelper.notifyPackageChanged(context, pkg)
            viewModel.loadRealInstalledApps(forceRefresh = true)
            viewModel.loadFilteredAppsForBedtime(forceRefresh = true)
            viewModel.loadFilteredAppsForKeywordExemption(forceRefresh = true)
        }
    }

    override fun attachBaseContext(newBase: Context) {
        val arabicLocale = java.util.Locale.forLanguageTag("ar-u-nu-latn")
        java.util.Locale.setDefault(arabicLocale)
        val config = android.content.res.Configuration(newBase.resources.configuration)
        config.setLocale(arabicLocale)
        config.setLayoutDirection(arabicLocale)
        val localizedContext = newBase.createConfigurationContext(config)
        super.attachBaseContext(localizedContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            val arabicLocale = java.util.Locale.forLanguageTag("ar-u-nu-latn")
            java.util.Locale.setDefault(arabicLocale)
            val config = resources.configuration
            config.setLocale(arabicLocale)
            config.setLayoutDirection(arabicLocale)
            @Suppress("DEPRECATION")
            resources.updateConfiguration(config, resources.displayMetrics)
            window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        } catch (e: Exception) {
            Log.e("MainActivity", "Error setting RTL: ${e.message}")
        }

        enableHighRefreshRate()
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()
            val isPenaltyActive by viewModel.isPenaltyActive.collectAsState()
            val isUrgeActive by viewModel.isUrgeSessionActive.collectAsState()
            var isSplashVisible by remember { mutableStateOf(true) }

            val logoScale = remember { Animatable(0.70f) }
            val logoAlpha = remember { Animatable(0f) }
            val textAlpha = remember { Animatable(0f) }
            val textOffsetY = remember { Animatable(24f) }

            LaunchedEffect(Unit) {
                // Fast, fluid, premium entrance animation
                launch {
                    logoAlpha.animateTo(
                        targetValue = 1f,
                        animationSpec = tween(durationMillis = 280, easing = LinearOutSlowInEasing)
                    )
                }
                launch {
                    logoScale.animateTo(
                        targetValue = 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = 450f
                        )
                    )
                }
                delay(120)
                launch {
                    textAlpha.animateTo(
                        targetValue = 1f,
                        animationSpec = tween(durationMillis = 250, easing = LinearOutSlowInEasing)
                    )
                }
                launch {
                    textOffsetY.animateTo(
                        targetValue = 0f,
                        animationSpec = tween(durationMillis = 250, easing = FastOutSlowInEasing)
                    )
                }
                // Snappy display duration (approx 850ms)
                delay(850)
                isSplashVisible = false
            }

            // Force RTL direction for complete Arabic UI as requested
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                SaffahTheme(darkTheme = isDarkMode) {
                    AnimatedContent(
                        targetState = isSplashVisible,
                        transitionSpec = {
                            (fadeIn(tween(200, easing = LinearOutSlowInEasing)) togetherWith
                                (fadeOut(tween(220, easing = FastOutLinearInEasing)) + scaleOut(targetScale = 0.96f, animationSpec = tween(220))))
                        },
                        label = "SplashScreenTransition"
                    ) { showSplash ->
                        if (showSplash) {
                            // Official Saffah Splash Screen: Pure White Background (Not Dark) with premium animated logo & typography
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    androidx.compose.foundation.Image(
                                        painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_saffah_splash_logo),
                                        contentDescription = "شعار السفاح",
                                        modifier = Modifier
                                            .size(135.dp)
                                            .graphicsLayer {
                                                scaleX = logoScale.value
                                                scaleY = logoScale.value
                                                alpha = logoAlpha.value
                                            }
                                    )
                                    Spacer(modifier = Modifier.height(18.dp))
                                    Text(
                                        text = "السفّاح",
                                        style = MaterialTheme.typography.headlineLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF025DE6),
                                        modifier = Modifier.graphicsLayer {
                                            alpha = textAlpha.value
                                            translationY = textOffsetY.value
                                        }
                                    )
                                }
                            }
                        } else {
                            if (isPenaltyActive) {
                                BackHandler(enabled = true) { /* Prevent exiting locked penalty screen */ }
                                PenaltyLockOverlayScreen(
                                    onPenaltyFinished = {
                                        viewModel.refreshPenaltyStatus()
                                        evaluateLockTaskState()
                                    }
                                )
                            } else if (isUrgeActive) {
                                BackHandler(enabled = true) { /* Prevent exiting locked urge session */ }
                                UrgeSuppressionOverlayScreen(
                                    onFinished = {
                                        viewModel.refreshUrgeStatus()
                                        evaluateLockTaskState()
                                    }
                                )
                            } else {
                                if (currentLockReasonState != SaffahLockTaskManager.LockReason.NONE) {
                                    BackHandler(enabled = true) { /* Prevent exiting locked app */ }
                                }
                                MainAppScaffold(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }

        checkIntentForDirectVpn(intent)
        checkNotificationIntent(intent)

        // Asynchronously initialize heavy system restrictions & watchdog on background thread
        // to ensure 0ms cold-start latency and instant UI rendering
        lifecycleScope.launch(Dispatchers.IO) {
            SaffahProtectionManager.applyAllSystemImmunity(applicationContext)
            SaffahLockTaskManager.configureDeviceOwnerLockTaskPackages(applicationContext)
            SaffahProtectionManager.checkAndRequestBatteryOptimizationBypass(this@MainActivity)
        }

        // Immediate LockTask evaluation on launch with zero delay
        evaluateLockTaskState()
        startLockTaskMonitoring()

        // Register dynamic package change receiver to detect new app installs in real-time
        try {
            val filter = android.content.IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_FULLY_REMOVED)
                addAction(Intent.ACTION_PACKAGE_REPLACED)
                addDataScheme("package")
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(packageChangeReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(packageChangeReceiver, filter)
            }
        } catch (e: Exception) {
            Log.w("MainActivity", "Error registering package receiver: ${e.message}")
        }

        registerNotificationListenerObserver()
    }

    override fun onStart() {
        super.onStart()
        viewModel.refreshPenaltyStatus()
        viewModel.refreshUrgeStatus()
        evaluateLockTaskState(isFromResume = true)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        checkIntentForDirectVpn(intent)
        checkNotificationIntent(intent)
        viewModel.refreshPenaltyStatus()
        viewModel.refreshUrgeStatus()
        evaluateLockTaskState(isFromResume = true)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            viewModel.refreshPenaltyStatus()
            viewModel.refreshUrgeStatus()
            evaluateLockTaskState(isFromResume = true)
        }
    }

    private fun checkIntentForDirectVpn(intent: Intent?) {
        if (intent?.getBooleanExtra("START_VPN_DIRECTLY", false) == true) {
            val vpnIntent = android.net.VpnService.prepare(this)
            if (vpnIntent == null) {
                viewModel.toggleVpn(true)
            }
        }
    }

    private fun checkNotificationIntent(intent: Intent?) {
        val dest = intent?.getStringExtra(com.example.util.SaffahNotificationManager.EXTRA_NAV_DESTINATION)
        if (!dest.isNullOrBlank()) {
            viewModel.setNotificationNavDestination(dest)
        }
    }

    fun checkAndUnlockIfPermissionsGranted() {
        lifecycleScope.launch(Dispatchers.IO) {
            SaffahProtectionManager.ensureNotificationListenerAccess(applicationContext)
            val isNotifGranted = com.example.service.SaffahNotificationListenerService.isNotificationAccessGranted(applicationContext)
            withContext(Dispatchers.Main) {
                evaluateLockTaskState(isFromResume = true)
                if (isNotifGranted) {
                    android.widget.Toast.makeText(this@MainActivity, "تم التحقق: خدمة الإشعارات مفعّلة وتم فك التثبيت بنجاح", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    android.widget.Toast.makeText(this@MainActivity, "الخدمة ما زالت معطلة، يرجى تفعيلها من الإعدادات", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private var lockTaskCheckJob: Job? = null

    override fun onPause() {
        super.onPause()
        viewModel.stopUiPeriodicRefresh()
        lockTaskCheckJob?.cancel()
        lockTaskRetryRunnable?.let { lockTaskRetryHandler.removeCallbacks(it) }
    }

    override fun onStop() {
        super.onStop()
        // Always lock all privacy-protected sections immediately when the user leaves Saffah
        com.example.util.SaffahPrivacyManager.lockAllSections()
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPenaltyStatus()
        viewModel.refreshUrgeStatus()
        viewModel.startUiPeriodicRefresh()
        viewModel.checkPermissions()

        // Fast instant resume using memory cache - do NOT force refresh icons on every resume!
        viewModel.loadRealInstalledApps(forceRefresh = false)
        viewModel.loadFilteredAppsForBedtime(forceRefresh = false)
        viewModel.loadFilteredAppsForKeywordExemption(forceRefresh = false)

        lifecycleScope.launch(Dispatchers.IO) {
            SaffahProtectionManager.startKeeperService(this@MainActivity)
            com.example.service.SaffahKeeperService.ensureKeeperNotification(this@MainActivity)
            SaffahProtectionManager.ensureAccessibilityServiceEnabled(this@MainActivity)
            com.example.util.SaffahNotificationManager.initChannels(this@MainActivity)
            com.example.util.SaffahNotificationManager.ensureNotificationPermissionGranted(this@MainActivity)
            com.example.util.SaffahNotificationManager.evaluateAllNotifications(this@MainActivity)
            com.example.util.SaffahNotificationManager.scheduleAlarms(this@MainActivity)

            val lockReason = SaffahLockTaskManager.updateStateAndCheck(this@MainActivity)
            withContext(Dispatchers.Main) {
                if (!isFinishing && !isDestroyed) {
                    applyLockTaskDecision(lockReason)
                    startLockTaskMonitoring()
                }
            }
        }
    }

    private var lastAppliedLockReason: SaffahLockTaskManager.LockReason? = null
    private var currentLockReasonState by mutableStateOf(SaffahLockTaskManager.LockReason.NONE)

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val lockReason = SaffahLockTaskManager.getLockReason(this)
        if (lockReason != SaffahLockTaskManager.LockReason.NONE) {
            SaffahLockTaskManager.launchLockTaskApp(this, lockReason)
        }
    }

    private fun startLockTaskMonitoring() {
        lockTaskCheckJob?.cancel()
        lockTaskCheckJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(2500L)
                val isLocked = SaffahLockTaskManager.isCurrentlyInLockTaskMode(this@MainActivity) ||
                        SaffahLockTaskManager.isLockTaskActive(this@MainActivity)
                if (isLocked) {
                    val lockReason = SaffahLockTaskManager.updateStateAndCheck(this@MainActivity)
                    if (lockReason != lastAppliedLockReason || !isCurrentlyInLockTaskMode()) {
                        lastAppliedLockReason = lockReason
                        withContext(Dispatchers.Main) {
                            if (!isFinishing && !isDestroyed) {
                                applyLockTaskDecision(lockReason)
                            }
                        }
                    }
                } else {
                    lastAppliedLockReason = null
                }
            }
        }
    }

    private var lockTaskRetryHandler = Handler(Looper.getMainLooper())
    private var lockTaskRetryRunnable: Runnable? = null
    private var lockTaskRetryCount = 0

    private fun applyLockTaskDecision(lockReason: SaffahLockTaskManager.LockReason) {
        currentLockReasonState = lockReason
        viewModel.refreshPenaltyStatus()
        viewModel.refreshUrgeStatus()
        if (lockReason != SaffahLockTaskManager.LockReason.NONE) {
            val isPenaltyOrUrge = (lockReason == SaffahLockTaskManager.LockReason.PENALTY_ACTIVE ||
                                  lockReason == SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
            SaffahLockTaskManager.setLockTaskActive(this, true, lockReason)
            SaffahLockTaskManager.configureDeviceOwnerLockTaskPackages(this, isPenaltyOrUrge)
            attemptStartLockTask(lockReason)
        } else {
            lockTaskRetryRunnable?.let { lockTaskRetryHandler.removeCallbacks(it) }
            lockTaskRetryCount = 0
            val wasLockActiveInPrefs = SaffahLockTaskManager.isLockTaskActive(this)
            val isSystemLocked = isCurrentlyInLockTaskMode()

            if (wasLockActiveInPrefs || isSystemLocked) {
                Log.i("MainActivity", "Protection active or unconstrained! Exiting LockTask mode... (wasActive=$wasLockActiveInPrefs, isLocked=$isSystemLocked)")
                try {
                    stopLockTask()
                } catch (e: Exception) {
                    Log.e("MainActivity", "Error calling stopLockTask(): ${e.message}")
                }
                SaffahLockTaskManager.setLockTaskActive(this, false, SaffahLockTaskManager.LockReason.NONE)
                SaffahLockTaskManager.configureDeviceOwnerLockTaskPackages(this, false)
            }
        }
    }

    private fun evaluateLockTaskState(isFromResume: Boolean = false) {
        lifecycleScope.launch(Dispatchers.IO) {
            val lockReason = SaffahLockTaskManager.updateStateAndCheck(this@MainActivity)
            withContext(Dispatchers.Main) {
                if (!isFinishing && !isDestroyed) {
                    applyLockTaskDecision(lockReason)
                }
            }
        }
    }

    private fun attemptStartLockTask(reason: SaffahLockTaskManager.LockReason) {
        lockTaskRetryRunnable?.let { lockTaskRetryHandler.removeCallbacks(it) }
        val isPenaltyOrUrge = (reason == SaffahLockTaskManager.LockReason.PENALTY_ACTIVE ||
                              reason == SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)

        if (!isCurrentlyInLockTaskMode()) {
            if (!isFinishing && !isDestroyed) {
                try {
                    Log.i("MainActivity", "Attempting immediate startLockTask() due to $reason")
                    SaffahLockTaskManager.configureDeviceOwnerLockTaskPackages(this, isPenaltyOrUrge)
                    startLockTask()
                } catch (e: Exception) {
                    Log.w("MainActivity", "Immediate startLockTask error: ${e.message}")
                }
            }

            if (!isCurrentlyInLockTaskMode() && lockTaskRetryCount < 3) {
                val runnable = object : Runnable {
                    override fun run() {
                        if (!isFinishing && !isDestroyed) {
                            val currentLockReason = SaffahLockTaskManager.updateStateAndCheck(this@MainActivity)
                            if (currentLockReason != SaffahLockTaskManager.LockReason.NONE && !isCurrentlyInLockTaskMode()) {
                                try {
                                    val isCurrentPenaltyOrUrge = (currentLockReason == SaffahLockTaskManager.LockReason.PENALTY_ACTIVE ||
                                                                 currentLockReason == SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
                                    SaffahLockTaskManager.configureDeviceOwnerLockTaskPackages(this@MainActivity, isCurrentPenaltyOrUrge)
                                    startLockTask()
                                } catch (e: Exception) {
                                    Log.w("MainActivity", "Retry startLockTask error: ${e.message}")
                                }
                            }
                        }
                        lockTaskRetryCount++
                        if (!isFinishing && !isDestroyed && !isCurrentlyInLockTaskMode() && lockTaskRetryCount < 3 && SaffahLockTaskManager.updateStateAndCheck(this@MainActivity) != SaffahLockTaskManager.LockReason.NONE) {
                            lockTaskRetryHandler.postDelayed(this, 1500L)
                        }
                    }
                }
                lockTaskRetryRunnable = runnable
                lockTaskRetryHandler.postDelayed(runnable, 1500L)
            }
        } else {
            lockTaskRetryCount = 0
        }
    }

    private fun isCurrentlyInLockTaskMode(): Boolean {
        return SaffahLockTaskManager.isCurrentlyInLockTaskMode(this)
    }

    private fun enableHighRefreshRate() {
        try {
            window.setFlags(
                android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
            )
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                val display = display
                if (display != null) {
                    val modes = display.supportedModes
                    val highestRefreshRateMode = modes.maxByOrNull { it.refreshRate }
                    if (highestRefreshRateMode != null && highestRefreshRateMode.refreshRate >= 60f) {
                        val params = window.attributes
                        params.preferredDisplayModeId = highestRefreshRateMode.modeId
                        params.preferredRefreshRate = highestRefreshRateMode.refreshRate
                        window.attributes = params
                    }
                }
            } else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                val params = window.attributes
                params.preferredRefreshRate = 120f
                window.attributes = params
            }
        } catch (e: Exception) {
            Log.w("MainActivity", "Hardware acceleration & high refresh rate setup: ${e.message}")
        }
    }

    private var notifListenerObserver: ContentObserver? = null

    private fun registerNotificationListenerObserver() {
        try {
            val uri = Settings.Secure.getUriFor("enabled_notification_listeners")
            notifListenerObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) {
                    super.onChange(selfChange)
                    evaluateLockTaskState(isFromResume = true)
                }
            }
            contentResolver.registerContentObserver(uri, false, notifListenerObserver!!)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        try {
            notifListenerObserver?.let { contentResolver.unregisterContentObserver(it) }
        } catch (_: Exception) {}
        try {
            unregisterReceiver(packageChangeReceiver)
        } catch (e: Exception) { }
        lockTaskCheckJob?.cancel()
        lockTaskCheckRunnable?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacksAndMessages(null)
        lockTaskRetryRunnable?.let { lockTaskRetryHandler.removeCallbacks(it) }
        lockTaskRetryHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}


sealed class NavigationTab(
    val route: String,
    val title: String,
    val unselectedIcon: ImageVector,
    val selectedIcon: ImageVector
) {
    object Home : NavigationTab("home", "الرئيسية", Icons.Outlined.Home, Icons.Filled.Home)
    object Recovery : NavigationTab("recovery", "التعافي", Icons.Outlined.Shield, Icons.Filled.Shield)
    object BlockList : NavigationTab("block_list", "قائمة الحظر", Icons.Outlined.Block, Icons.Filled.Block)
    object BlockLogs : NavigationTab("block_logs", "سجل الحظر", Icons.Outlined.History, Icons.Filled.History)
    object Settings : NavigationTab("settings", "الإعدادات", Icons.Outlined.Settings, Icons.Filled.Settings)
}

@Composable
fun MainAppScaffold(viewModel: MainViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var activeHint by remember { mutableStateOf<com.example.ui.components.FeatureHintData?>(null) }
    var currentTabRoute by rememberSaveable { mutableStateOf("home") }
    var recoverySubScreen by rememberSaveable { mutableStateOf("hub") } // "hub", "counter", "stats", "diaries", "map"
    var statsInitialTab by rememberSaveable { mutableIntStateOf(0) }
    var statsPreviousSubScreen by rememberSaveable { mutableStateOf("hub") }
    var settingsSubScreen by rememberSaveable { mutableStateOf("main") } // "main" or "protection"

    val notifNavDest by viewModel.notificationNavDestination.collectAsState()
    LaunchedEffect(Unit) {
        viewModel.navigateToHomeEvent.collect {
            currentTabRoute = "home"
            settingsSubScreen = "main"
            recoverySubScreen = "hub"
        }
    }
    LaunchedEffect(notifNavDest) {
        when (notifNavDest) {
            com.example.util.SaffahNotificationManager.NAV_DEST_RECOVERY_COUNTER -> {
                currentTabRoute = "recovery"
                recoverySubScreen = "counter"
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_RECOVERY_MAP -> {
                currentTabRoute = "recovery"
                recoverySubScreen = "map"
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_DOPAMINE_SURVEY -> {
                currentTabRoute = "recovery"
                recoverySubScreen = "counter"
                viewModel.openDopamineAssessmentDialog()
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_BLOCK_LOGS -> {
                currentTabRoute = "block_logs"
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_BEDTIME -> {
                currentTabRoute = "home"
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_BLOCK_RULES -> {
                currentTabRoute = "block_list"
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_USAGE_RULES -> {
                currentTabRoute = "block_list"
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_PROTECTION -> {
                currentTabRoute = "settings"
                settingsSubScreen = "protection"
                viewModel.clearNotificationNavDestination()
            }
            com.example.util.SaffahNotificationManager.NAV_DEST_URGE_SESSION -> {
                currentTabRoute = "home"
                SaffahLockTaskManager.launchLockTaskApp(context, SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
                viewModel.clearNotificationNavDestination()
            }
        }
    }

    val tabs = listOf(
        NavigationTab.Home,
        NavigationTab.Recovery,
        NavigationTab.BlockList,
        NavigationTab.BlockLogs,
        NavigationTab.Settings
    )

    val currentTab = when (currentTabRoute) {
        "recovery" -> NavigationTab.Recovery
        "block_list" -> NavigationTab.BlockList
        "block_logs" -> NavigationTab.BlockLogs
        "settings" -> NavigationTab.Settings
        else -> NavigationTab.Home
    }

    val isFullScreenBaselineChart by viewModel.isFullScreenBaselineChart.collectAsState()
    val isRecoveryMap = (currentTab == NavigationTab.Recovery && recoverySubScreen == "map")
    val hideBottomBar = isRecoveryMap || isFullScreenBaselineChart

    val unlockedPrivacySections by viewModel.unlockedPrivacySections.collectAsState()
    val isEntireAppLocked = remember(unlockedPrivacySections) {
        viewModel.isEntireAppLocked()
    }

    if (isEntireAppLocked) {
        com.example.ui.components.PrivacyLockedScreenView(
            title = "تطبيق السفاح محمي برمز PIN",
            subtitle = "أدخل رمز PIN المكون من 4 أرقام للمتابعة",
            icon = Icons.Outlined.Lock,
            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_ENTIRE_APP,
            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_ENTIRE_APP) }
        )
        return
    }

    CompositionLocalProvider(
        com.example.ui.components.LocalFeatureHintShower provides { hint -> activeHint = hint }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!hideBottomBar) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        HorizontalDivider(
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.outline
                        )
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 0.dp,
                            windowInsets = WindowInsets.navigationBars,
                            modifier = Modifier.height(68.dp)
                        ) {
                            val haptic = LocalHapticFeedback.current
                            tabs.forEach { tab ->
                                val isSelected = currentTab == tab
                                val iconScale by animateFloatAsState(
                                    targetValue = if (isSelected) 1.10f else 1.0f,
                                    animationSpec = SaffahMotion.snappySpring(),
                                    label = "NavIconScale"
                                )
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        com.example.ui.theme.SaffahHaptics.tick(haptic)
                                        if (tab == NavigationTab.Recovery && currentTab != NavigationTab.Recovery) {
                                            recoverySubScreen = "hub"
                                        }
                                        if (tab == NavigationTab.Settings && currentTab != NavigationTab.Settings) {
                                            settingsSubScreen = "main"
                                        }
                                        currentTabRoute = tab.route
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.title,
                                            modifier = Modifier
                                                .size(24.dp)
                                                .graphicsLayer {
                                                    scaleX = iconScale
                                                    scaleY = iconScale
                                                }
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.title,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (hideBottomBar) PaddingValues(0.dp) else innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    val fromIndex = tabs.indexOf(initialState).coerceAtLeast(0)
                    val toIndex = tabs.indexOf(targetState).coerceAtLeast(0)
                    SaffahMotion.tabTransition(fromIndex, toIndex, isRtl = true)
                },
                label = "TabTransition"
            ) { tab ->
                when (tab) {
                    NavigationTab.Home -> HomeScreen(viewModel = viewModel)
                    NavigationTab.Recovery -> {
                        AnimatedContent(
                            targetState = recoverySubScreen,
                            transitionSpec = {
                                val isEnteringDetail = targetState != "hub" && initialState == "hub"
                                SaffahMotion.hierarchicalTransition(isEnteringDetail = isEnteringDetail, isRtl = true)
                            },
                            label = "RecoverySubTransition"
                        ) { sub ->
                            when (sub) {
                                "hub" -> RecoveryHubScreen(
                                    viewModel = viewModel,
                                    onBack = { currentTabRoute = "home" },
                                    onNavigateToPledge = { recoverySubScreen = "pledge" },
                                    onNavigateToCounter = { recoverySubScreen = "counter" },
                                    onNavigateToDiaries = { recoverySubScreen = "diaries" },
                                    onNavigateToStats = {
                                        statsInitialTab = 0
                                        statsPreviousSubScreen = "hub"
                                        recoverySubScreen = "stats"
                                    },
                                    onNavigateToMap = { recoverySubScreen = "map" }
                                )
                                "pledge" -> {
                                    if (viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_PLEDGE)) {
                                        com.example.ui.components.PrivacyLockedScreenView(
                                            title = "وثيقة تعهد التعافي محمية برمز PIN",
                                            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض وثيقة التعهد",
                                            icon = Icons.Outlined.HistoryEdu,
                                            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_PLEDGE,
                                            onBack = { recoverySubScreen = "hub" },
                                            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_PLEDGE) }
                                        )
                                    } else {
                                        RecoveryPledgeScreen(
                                            viewModel = viewModel,
                                            onBack = { recoverySubScreen = "hub" }
                                        )
                                    }
                                }
                                "counter" -> {
                                    if (viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER)) {
                                        com.example.ui.components.PrivacyLockedScreenView(
                                            title = "عداد التعافي محمي برمز PIN",
                                            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض عداد التعافي",
                                            icon = Icons.Outlined.Shield,
                                            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER,
                                            onBack = { recoverySubScreen = "hub" },
                                            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER) }
                                        )
                                    } else {
                                        RecoveryCenterScreen(
                                            viewModel = viewModel,
                                            onBack = { recoverySubScreen = "hub" },
                                            onNavigateToMap = { recoverySubScreen = "map" },
                                            onNavigateToStats = { tab ->
                                                statsInitialTab = tab
                                                statsPreviousSubScreen = "counter"
                                                recoverySubScreen = "stats"
                                            }
                                        )
                                    }
                                }
                                "diaries" -> {
                                    if (viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES)) {
                                        com.example.ui.components.PrivacyLockedScreenView(
                                            title = "مذكرات التعافي محمية برمز PIN",
                                            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض مذكرات التعافي",
                                            icon = Icons.Outlined.EditNote,
                                            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES,
                                            onBack = { recoverySubScreen = "hub" },
                                            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES) }
                                        )
                                    } else {
                                        RecoveryDiariesScreen(
                                            viewModel = viewModel,
                                            onBack = { recoverySubScreen = "hub" }
                                        )
                                    }
                                }
                                "stats" -> {
                                    if (viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_STATS)) {
                                        com.example.ui.components.PrivacyLockedScreenView(
                                            title = "إحصائيات التعافي محمية برمز PIN",
                                            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض الإحصائيات",
                                            icon = Icons.Outlined.Analytics,
                                            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_STATS,
                                            onBack = {
                                                val dest = statsPreviousSubScreen
                                                statsInitialTab = 0
                                                statsPreviousSubScreen = "hub"
                                                recoverySubScreen = dest
                                            },
                                            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_STATS) }
                                        )
                                    } else {
                                        RecoveryStatsScreen(
                                            viewModel = viewModel,
                                            initialTab = statsInitialTab,
                                            onBack = {
                                                val dest = statsPreviousSubScreen
                                                statsInitialTab = 0
                                                statsPreviousSubScreen = "hub"
                                                recoverySubScreen = dest
                                            }
                                        )
                                    }
                                }
                                "map" -> {
                                    if (viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_MAP)) {
                                        com.example.ui.components.PrivacyLockedScreenView(
                                            title = "خريطة رحلة التعافي محمية برمز PIN",
                                            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض خريطة رحلة التعافي",
                                            icon = Icons.Outlined.Map,
                                            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_MAP,
                                            onBack = { recoverySubScreen = "counter" },
                                            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_MAP) }
                                        )
                                    } else {
                                        RecoveryJourneyMapScreen(
                                            viewModel = viewModel,
                                            onBack = { recoverySubScreen = "counter" }
                                        )
                                    }
                                }
                                else -> RecoveryHubScreen(
                                    viewModel = viewModel,
                                    onBack = { currentTabRoute = "home" },
                                    onNavigateToPledge = { recoverySubScreen = "pledge" },
                                    onNavigateToCounter = { recoverySubScreen = "counter" },
                                    onNavigateToDiaries = { recoverySubScreen = "diaries" },
                                    onNavigateToStats = {
                                        statsInitialTab = 0
                                        statsPreviousSubScreen = "hub"
                                        recoverySubScreen = "stats"
                                    },
                                    onNavigateToMap = { recoverySubScreen = "map" }
                                )
                            }
                        }
                    }
                    NavigationTab.BlockList -> BlockListScreen(viewModel = viewModel)
                    NavigationTab.BlockLogs -> {
                        if (viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_LOGS)) {
                            com.example.ui.components.PrivacyLockedScreenView(
                                title = "سجل الحظر محمي برمز PIN",
                                subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض سجلات الحظر",
                                icon = Icons.Outlined.History,
                                sectionKey = com.example.util.SaffahPrivacyManager.SECTION_BLOCK_LOGS,
                                onBack = { currentTabRoute = "home" },
                                onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_LOGS) }
                            )
                        } else {
                            BlockLogsScreen(viewModel = viewModel)
                        }
                    }
                    NavigationTab.Settings -> {
                        AnimatedContent(
                            targetState = settingsSubScreen,
                            transitionSpec = {
                                val isEnteringDetail = targetState != "main" && initialState == "main"
                                SaffahMotion.hierarchicalTransition(isEnteringDetail = isEnteringDetail, isRtl = true)
                            },
                            label = "SettingsSubTransition"
                        ) { sub ->
                            when (sub) {
                                "main" -> SettingsScreen(
                                    viewModel = viewModel,
                                    onNavigateToRecovery = {
                                        recoverySubScreen = "hub"
                                        currentTabRoute = "recovery"
                                    },
                                    onNavigateToProtection = {
                                        settingsSubScreen = "protection"
                                    },
                                    onNavigateToNotifications = {
                                        settingsSubScreen = "notifications"
                                    }
                                )
                                "protection" -> ProtectionScreen(
                                    viewModel = viewModel,
                                    onBack = {
                                        settingsSubScreen = "main"
                                    }
                                )
                                "notifications" -> NotificationsScreen(
                                    viewModel = viewModel,
                                    onBack = {
                                        settingsSubScreen = "main"
                                    }
                                )
                                else -> SettingsScreen(
                                    viewModel = viewModel,
                                    onNavigateToRecovery = {
                                        recoverySubScreen = "hub"
                                        currentTabRoute = "recovery"
                                    },
                                    onNavigateToProtection = {
                                        settingsSubScreen = "protection"
                                    },
                                    onNavigateToNotifications = {
                                        settingsSubScreen = "notifications"
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    val showQrKeyVerificationDialog by viewModel.showQrKeyVerificationDialog.collectAsState()

    activeHint?.let { hint ->
        com.example.ui.components.FeatureHintDialog(
            hint = hint,
            onDismiss = { activeHint = null }
        )
    }

    if (showQrKeyVerificationDialog) {
        com.example.ui.components.QrKeyVerificationDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.dismissQrKeyDialog() }
        )
    }

    val showDopamineAssessmentDialog by viewModel.showDopamineAssessmentDialog.collectAsState()
    if (showDopamineAssessmentDialog) {
        val dailyHistory by viewModel.dailyBaselineHistory.collectAsState()
        val todayCheckIn = remember(dailyHistory) {
            dailyHistory.firstOrNull {
                val cal1 = java.util.Calendar.getInstance().apply { timeInMillis = it.timestamp }
                val cal2 = java.util.Calendar.getInstance()
                cal1.get(java.util.Calendar.YEAR) == cal2.get(java.util.Calendar.YEAR) &&
                cal1.get(java.util.Calendar.DAY_OF_YEAR) == cal2.get(java.util.Calendar.DAY_OF_YEAR)
            }
        }
        com.example.ui.components.DopamineAssessmentDialog(
            initialClarity = todayCheckIn?.clarityOfMind ?: 3,
            initialMood = todayCheckIn?.moodStability ?: 3,
            initialSleep = todayCheckIn?.sleepQuality ?: 3,
            initialEnergy = todayCheckIn?.energyAndMotivation ?: 3,
            onDismiss = { viewModel.closeDopamineAssessmentDialog() },
            onSave = { clarity, mood, sleep, energy ->
                viewModel.saveDailyBaselineCheckIn(clarity, mood, sleep, energy)
            }
        )
    }
}
}
