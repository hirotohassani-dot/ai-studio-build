package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Data class representing a concise hint and explanation for a feature.
 */
data class FeatureHintData(
    val key: String,
    val title: String,
    val explanation: String
)

/**
 * CompositionLocal providing hint shower function across the composition tree.
 */
val LocalFeatureHintShower = compositionLocalOf<((FeatureHintData) -> Unit)?> { null }

/**
 * CompositionLocal providing click action for titles inside clickable containers.
 */
val LocalFeatureTitleClickAction = compositionLocalOf<(() -> Unit)?> { null }

/**
 * Modifier to attach long-press hint trigger specifically to title texts and headers.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.featureTitleHint(
    hintKey: String,
    customTitle: String? = null,
    onClick: (() -> Unit)? = null
): Modifier {
    val showHint = LocalFeatureHintShower.current
    val haptic = LocalHapticFeedback.current
    val contextClick = LocalFeatureTitleClickAction.current
    val effectiveOnClick = onClick ?: contextClick

    // If no hint exists in registry, do not attach long click handler
    val hintData = AppFeatureHints.get(hintKey)
    if (hintData == null && customTitle == null) {
        return if (effectiveOnClick != null) {
            this.combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = { effectiveOnClick() }
            )
        } else {
            this
        }
    }

    return this.combinedClickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = { effectiveOnClick?.invoke() },
        onLongClick = {
            val hint = hintData?.let {
                if (customTitle != null) it.copy(title = customTitle) else it
            } ?: FeatureHintData(
                key = hintKey,
                title = customTitle ?: "إرشادات الميزة",
                explanation = "توجيهات استخدام هذه الخاصية لمساعدتك في تحقيق أقصى انضباط."
            )

            try {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            } catch (_: Exception) { }
            showHint?.invoke(hint)
        }
    )
}

/**
 * Clean, minimal popup dialog displaying concise feature explanation and close button.
 */
@Composable
fun FeatureHintDialog(
    hint: FeatureHintData,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .widthIn(max = 380.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                tonalElevation = 2.dp,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header: Title + Close (X) button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = hint.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Content: Concise explanation text only
                    Text(
                        text = hint.explanation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 22.sp,
                        fontSize = 13.5.sp
                    )
                }
            }
        }
    }
}

/**
 * Registry of essential feature hints and concise explanations.
 */
object AppFeatureHints {
    private val hints = mapOf(
        // === الشاشة الرئيسية (Home Screen) ===
        "ai_protection" to FeatureHintData(
            key = "ai_protection",
            title = "حجب الصور والفيديوهات الإباحية الواقعية",
            explanation = "نظام فحص ذكي متطور يحلل الإطارات البصرية فورياً أثناء التصفح لرصد وحظر الصور واللقطات الفاضحة والعري الصريح والملابس الكاشفة بدقة فائقة وإغلاق الصفحة أو التبويب تلقائياً لسد ثغرات محركات البحث والشبكات المصغرة ومعارض الصور دون إرسال أي بيانات أو صور لخارج هاتفك."
        ),
        "ai_protection_apps" to FeatureHintData(
            key = "ai_protection_apps",
            title = "التطبيقات المشمولة بالحجب البصري",
            explanation = "قائمة التطبيقات المحددة التي تبدأ خدمة الفحص البصري takeScreenshot() بالعمل فيها تلقائياً لرصد وحظر الصور والفيديوهات غير اللائقة، وتتوقف الخدمة تلقائياً عند مغادرتها أو التواجد في شاشة التطبيقات الحديثة، مع استمرار العمل في النوافذ العائمة والشاشات المقسمة."
        ),
        "vpn_protection" to FeatureHintData(
            key = "vpn_protection",
            title = "طبقة الحماية VPN",
            explanation = "مرشح شبكي محلي يعمل داخل جهازك بالكامل دون خوادم خارجية أو استهلاك للبيانات، يقوم باعتراض وحجب المواقع الإباحية والضارة والإعلانات المخلة فورياً قبل تحميلها."
        ),
        "vpn_exclusion" to FeatureHintData(
            key = "vpn_exclusion",
            title = "استثناء تطبيقات من الـ VPN",
            explanation = "توجيه تطبيقات محددة كالتطبيقات المصرفية أو الحكومية للاتصال بالإنترنت مباشرة خارج الـ VPN في حال كانت تمنع خدمات الشبكات الافتراضية."
        ),
        "penalty_screen" to FeatureHintData(
            key = "penalty_screen",
            title = "شاشة العقوبة المقفلة",
            explanation = "قفل إجباري مؤقت يظهر فوق الشاشة فور محاولة فتح تطبيق أو محتوى محظور، لكسر الاندفاع الذهني وإعادة توجيه انتباهك وإتاحة فرصة للتراجع."
        ),
        "urge_suppression_15" to FeatureHintData(
            key = "urge_suppression_15",
            title = "قاعدة 15 دقيقة لدحر الرغبة",
            explanation = "بروتوكول طوارئ يقفل الهاتف مؤقتاً لمدة 15 دقيقة مع تمارين تنفس وإرشادات سلوكية لإعطاء الدماغ المهلة البيولوجية اللازمة لانخفاض هرمونات الإثارة وكسر حدة الرغبة."
        ),
        "bedtime_mode" to FeatureHintData(
            key = "bedtime_mode",
            title = "ضبط وقت النوم",
            explanation = "جدول زمني يقفل التطبيقات المشتتة ويمنع تشغيل الوسائط أو تصفح الإنترنت ليلاً، لمساعدتك على النوم المبكر وحمايتك من أوقات الخلوة والضعف الليلي."
        ),
        "hardware_grayscale" to FeatureHintData(
            key = "hardware_grayscale",
            title = "الوضع الرمادي بالأجهزة",
            explanation = "تحويل ألوان الشاشة بالكامل إلى الأبيض والأسود لتقليل الإثارة البصرية للدوبامين وجعل استخدام الهاتف باهتاً وأقل جاذبية لعقلك."
        ),
        "lock_task_mode" to FeatureHintData(
            key = "lock_task_mode",
            title = "وضع القفل الحمياني (Lock Task)",
            explanation = "تثبيت شاشة التطبيق وإلغاء أزرار التنقل وشريط الإشعارات عند اكتشاف محاولة لتعطيل الصلاحيات أو التلاعب بالحماية، لمنع الخروج حتى استعادة الأمان."
        ),

        // === مركز الحماية والتحكم الصارم (Protection Center) ===
        "protection_center" to FeatureHintData(
            key = "protection_center",
            title = "مركز الحماية والتحكم الصارم",
            explanation = "منظومة دفاعية متكاملة تمنع إيقاف الحظر أو التراجع في لحظات الاندفاع، تشمل التأخير الزمني الإجباري، قفل QR المادي، وصلاحيات مشرف الجهاز."
        ),
        "protection_qr_barcode" to FeatureHintData(
            key = "protection_qr_barcode",
            title = "قفل مفتاح QR المادي",
            explanation = "منع تعديل أو تخفيف قيود الحماية إلا بمسح رمز QR أو باركود مطبوع ومحفوظ في مكان بعيد أو مع صديق موثوق، مما يمنع القرارات اللحظية المفاجئة."
        ),
        "qr_key_protection" to FeatureHintData(
            key = "qr_key_protection",
            title = "قفل مفتاح QR المادي",
            explanation = "منع تعديل أو تخفيف قيود الحماية إلا بمسح رمز QR أو باركود مطبوع ومحفوظ في مكان بعيد أو مع صديق موثوق، مما يمنع القرارات اللحظية المفاجئة."
        ),
        "time_delay" to FeatureHintData(
            key = "time_delay",
            title = "قفل التأخير الزمني الإجباري",
            explanation = "فرض فترة انتظار إلزامية (مثل 30 دقيقة أو 24 ساعة) قبل سريان أي تغيير على إعدادات الحماية، مما يمنحك وقتاً كافياً لاستعادة توازنك والعدول عن إلغاء القيود."
        ),
        "emergency_time_delay" to FeatureHintData(
            key = "emergency_time_delay",
            title = "قفل التأخير الزمني الإجباري",
            explanation = "فرض فترة انتظار إلزامية (مثل 30 دقيقة أو 24 ساعة) قبل سريان أي تغيير على إعدادات الحماية، مما يمنحك وقتاً كافياً لاستعادة توازنك والعدول عن إلغاء القيود."
        ),
        "device_owner_mode" to FeatureHintData(
            key = "device_owner_mode",
            title = "وضع مشرف الجهاز (Device Owner)",
            explanation = "أقوى مستوى حماية في نظام أندرويد يمنع إلغاء تثبيت التطبيق، أو فرض إيقافه، أو مسح بياناته، أو تعطيل صلاحياته عبر الإعدادات بأي وسيلة."
        ),
        "keeper_foreground_service" to FeatureHintData(
            key = "keeper_foreground_service",
            title = "خدمة الحماية الدائمة",
            explanation = "إبقاء التطبيق يعمل بنشاط في الواجهة الأمامية (Foreground Service) وفي قائمة التطبيقات النشطة في الخلفية دون الحاجة لتشغيل الـ VPN لمنع نظام أندرويد من تجميده أو قتله نهائياً."
        ),
        "disallow_safe_boot" to FeatureHintData(
            key = "disallow_safe_boot",
            title = "منع تشغيل الوضع الآمن",
            explanation = "تعطيل إمكانية إعادة تشغيل الجهاز في الوضع الآمن (Safe Mode)، لسد ثغرة تجاوز تطبيقات الحظر التي قد يستغلها البعض."
        ),
        "disallow_datetime_change" to FeatureHintData(
            key = "disallow_datetime_change",
            title = "منع التلاعب بالوقت والتاريخ",
            explanation = "قفل إعدادات التاريخ والوقت التلقائي لمنع تقديم الساعة يدوياً لتجاوز عدادات التأخير الزمني أو جداول الحظر الليلي المجدول."
        ),
        "disallow_date_time" to FeatureHintData(
            key = "disallow_date_time",
            title = "منع التلاعب بالوقت والتاريخ",
            explanation = "قفل إعدادات التاريخ والوقت التلقائي لمنع تقديم الساعة يدوياً لتجاوز عدادات التأخير الزمني أو جداول الحظر الليلي المجدول."
        ),
        "disallow_private_dns" to FeatureHintData(
            key = "disallow_private_dns",
            title = "تعطيل إعدادات DNS الخاص",
            explanation = "قفل خيار Private DNS في إعدادات الهاتف لمنع تغيير مسار الشبكة وتجاوز فلترة الـ VPN المدمج للتطبيق."
        ),
        "disallow_debugging" to FeatureHintData(
            key = "disallow_debugging",
            title = "حظر خيارات وتصحيح المطورين",
            explanation = "تعطيل تصحيح أخطاء USB (USB Debugging) وخيارات المطور لمنع تنفيذ أوامر الحاسوب (ADB) لإلغاء صلاحيات التطبيق."
        ),
        "block_unsupported_browsers" to FeatureHintData(
            key = "block_unsupported_browsers",
            title = "حظر المتصفحات غير المدعومة",
            explanation = "منع فتح المتصفحات المجهولة أو التي تحجب قراءة شريط العناوين، لحصر التصفح في المتصفحات الآمنة والخاضعة للرقابة الكاملة."
        ),
        "block_in_app_browsers" to FeatureHintData(
            key = "block_in_app_browsers",
            title = "حظر المتصفح المدمج داخل التطبيقات",
            explanation = "منع فتح الروابط داخل نوافذ مدمجة (Custom Tabs) في تطبيقات التواصل وإجبار فتحها عبر المتصفح الرئيسي المحمي لضمان فحص المحتوى."
        ),

        // === قواعد الحظر المتقدمة (Block Rules) ===
        "keyword_exemption" to FeatureHintData(
            key = "keyword_exemption",
            title = "استثناء تطبيقات من مراقبة الكلمات",
            explanation = "إعفاء تطبيقات الدراسة أو العمل الموثوقة من فحص النصوص لتجنب الإغلاق العرضي أثناء البحث الأكاديمي أو المراسلات المهنية."
        ),
        "app_usage_blocking" to FeatureHintData(
            key = "app_usage_blocking",
            title = "الحظر بناءً على الاستخدام والمرات",
            explanation = "تحديد سقف يومي بالدقائق لكل تطبيق أو عدد أقصى لمرات فتحه يومياً، ليتم قفله تلقائياً حتى منتصف الليل بمجرد استنفاد الحصة."
        ),
        "scheduled_app_blocking" to FeatureHintData(
            key = "scheduled_app_blocking",
            title = "عمليات الحظر المجدولة",
            explanation = "تحديد نوافذ وساعات محددة يومياً لقفل تطبيقات معينة تلقائياً (مثل أوقات العمل أو الدراسة أو النوم)."
        ),

        // === مركز التعافي والإحصائيات (Recovery & Stats) ===
        "brain_neuroplasticity" to FeatureHintData(
            key = "brain_neuroplasticity",
            title = "الحالة البيولوجية للدماغ",
            explanation = "مؤشر علمي يوضح مراحل إعادة تشكيل المسارات العصبية وترميم مستقبلات الدوبامين واستعادة حساسية المكافأة الطبيعية على مدار أيام تعافيك."
        ),
        "daily_baseline" to FeatureHintData(
            key = "daily_baseline",
            title = "فحص مؤشر التعافي اليومي",
            explanation = "تقييم يومي سريع يقيس 4 محاور أساسية: صفاء الذهن، استقرار المزاج، جودة النوم، ومستوى الطاقة الحيوية لمتابعة التطور بوضوح."
        ),
        "daily_baseline_chart" to FeatureHintData(
            key = "daily_baseline_chart",
            title = "مخطط مؤشر التعافي التراكمي",
            explanation = "رسم بياني يرصد منحنى تحسن المؤشرات الحيوية والنفسية عبر الأيام والأسابيع لإعطائك رؤية بصرية واضحة لثمار صمودك."
        ),
        "recovery_index_score" to FeatureHintData(
            key = "recovery_index_score",
            title = "مؤشر جودة التعافي",
            explanation = "درجة رقمية مركبة تحتسب تلقائياً من تقييماتك اليومية ونسبة صمودك لتعكس مستوى ثبات ونقاء نمط حياتك الحالي."
        ),
        "recovery_map" to FeatureHintData(
            key = "recovery_map",
            title = "خريطة رحلة التعافي والمحطات",
            explanation = "مسار بصري تفاعلي يوثق محطات انتصارك من اليوم الأول حتى إتمام عام كامل (365 يوماً) مع فتح محطات جديدة تدريجياً."
        ),
        "urge_defense_stats" to FeatureHintData(
            key = "urge_defense_stats",
            title = "إحصائيات مقاومة الرغبات",
            explanation = "تحليل رقمي دقيق لعدد نوبات الرغبة التي واجهتها، نسبة نجاحك في التصدي لها، والتقنيات الدفاعية الأكثر فاعلية معك."
        ),
        "time_risk_analysis" to FeatureHintData(
            key = "time_risk_analysis",
            title = "أخطر الأوقات وساعات الذروة",
            explanation = "خريطة حرارية ترصد الساعات التي تكثر فيها محاولاتك أو نوبات الضعف لمساعدتك على وضع خطة وقائية واستبدال الروتين بتلك الساعات."
        ),
        "triggers_breakdown_analysis" to FeatureHintData(
            key = "triggers_breakdown_analysis",
            title = "تشريح المحفزات السلوكية (HALT)",
            explanation = "تصنيف نفسي لدوافع الرغبات وفق نموذج HALT العالمي: الجوع (Hungry)، الغضب (Angry)، الوحدة (Lonely)، والإرهاق (Tired)."
        ),
        "day_risk_analysis" to FeatureHintData(
            key = "day_risk_analysis",
            title = "أخطر أيام الأسبوع",
            explanation = "رسم بياني يوضح توزيع نوبات الرغبة عبر أيام الأسبوع للتعرف على الأيام الحرجة (كنهاية الأسبوع) والاستعداد لها مبكراً."
        ),
        "recovery_velocity_tracker" to FeatureHintData(
            key = "recovery_velocity_tracker",
            title = "مؤشر وتيرة وسرعة التعافي",
            explanation = "مقياس يقارن وتيرة صمودك ومعدل تراجع المحاولات المحظورة بين الفترات الزمنية الحالية والسابقة لإثبات وتيرة تقدمك."
        ),
        "relapse_history_log" to FeatureHintData(
            key = "relapse_history_log",
            title = "سجل تشريح الانتكاسات والعثرات",
            explanation = "توثيق تحليلي لكل عثرة سابقة يشمل المحفز الذي قاد إليها، الحالة النفسية، والقرار الوقائي الحاسم لضمان عدم تكرار السيناريو ذاته."
        )
    )

    fun get(key: String): FeatureHintData? = hints[key] ?: hints[key.lowercase().trim()]
}
