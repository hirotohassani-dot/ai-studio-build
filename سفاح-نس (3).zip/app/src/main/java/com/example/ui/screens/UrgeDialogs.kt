package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

/**
 * نافذة تسجيل تفاصيل الرغبة بعد اكتمال جلسة الـ 15 دقيقة
 * تمكن المستخدم من توثيق الشدة والمحفز والمشاعر بدقة لدعم مسار التعافي
 * تصميم Minimalist دافئ خالٍ تماماً من الإيموجيات مع دعم كامل للوضع الليلي.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UrgeLogDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val isDark = isAppInDarkTheme()
    val warningColor = if (isDark) WarningAmberDark else WarningAmber
    val primaryColor = if (isDark) PrimaryBlueDarkTheme else MaterialTheme.colorScheme.primary
    val cardBorderColor = if (isDark) CardBorderDark else CardBorder
    var selectedIntensity by remember { mutableIntStateOf(2) } // 1..4
    var selectedTrigger by remember { mutableStateOf("الفراغ والملل") }
    var selectedEmotion by remember { mutableStateOf("عزيمة وهدوء") }
    var notesText by remember { mutableStateOf("") }

    val triggersList = remember {
        listOf(
            "الفراغ والملل",
            "السهر بمفردك",
            "التصفح العشوائي",
            "الضغط النفسي والتوتر",
            "الوحدة والعزلة",
            "الإرهاق والاستنزاف",
            "الغضب والإحباط",
            "محفز بصري أو فكري"
        )
    }

    val emotionsList = remember {
        listOf(
            "عزيمة وهدوء",
            "انتصار وثبات",
            "راحة نفسية",
            "تخلص من التوتر",
            "استعادة السيطرة",
            "يقظة ووعي"
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "توثيق انتصار دحر الرغبة",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "اكتملت 15 دقيقة بنجاح. سجّل التفاصيل لتعزيز مناعتك العصبية.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                // 1. Intensity Selector (1 to 4)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "1. مستوى شدة الرغبة التي تم تجاوزها:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val intensities = listOf(
                            Triple(1, "خفيفة", primaryColor),
                            Triple(2, "متوسطة", warningColor),
                            Triple(3, "شديدة", if (isDark) Color(0xFFA855F7) else MaterialTheme.colorScheme.tertiary),
                            Triple(4, "قصوى", if (isDark) ErrorRedDark else MaterialTheme.colorScheme.error)
                        )
                        intensities.forEach { (level, title, col) ->
                            val isSelected = selectedIntensity == level
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedIntensity = level },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) col.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = BorderStroke(
                                    1.5.dp,
                                    if (isSelected) col else Color.Transparent
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "$level",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) col else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) col else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Trigger Selector
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "2. المحفز والشرارة المبدئية:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        triggersList.forEach { trig ->
                            val isSelected = selectedTrigger == trig
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedTrigger = trig },
                                label = { Text(trig, style = MaterialTheme.typography.bodySmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (isDark) PrimaryBlueDarkContainer else MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = if (isDark) OnPrimaryBlueDarkContainer else MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                }

                // 3. Emotional State
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "3. حالتك النفسية والشعور بعد انكسار الموجة:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        emotionsList.forEach { em ->
                            val isSelected = selectedEmotion == em
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedEmotion = em },
                                label = { Text(em, style = MaterialTheme.typography.bodySmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (isDark) Color(0xFF27272A) else MaterialTheme.colorScheme.secondaryContainer,
                                    selectedLabelColor = if (isDark) Color(0xFFF4F4F5) else MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                        }
                    }
                }

                // 4. Notes TextField
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "4. ملاحظات أو دروس مستفادة (اختياري):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = {
                            Text("مثلاً: شربت ماء وتوضأت وتغيرت البيئة فانكسرت الرغبة فوراً...")
                        },
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = {
                            viewModel.recordCompletedUrgeSession(
                                intensity = selectedIntensity,
                                triggerStr = selectedTrigger,
                                emotionStr = selectedEmotion,
                                notes = notesText.trim()
                            )
                        },
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ التوثيق", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * نافذة تأكيد النصر بعد توثيق جلسة دحر الرغبة
 */
@Composable
fun UrgeVictoryDialog(
    onDismiss: () -> Unit
) {
    val isDark = isAppInDarkTheme()
    val victoryColor = if (isDark) SuccessGreenDark else SuccessGreen

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .wrapContentHeight()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            border = BorderStroke(1.dp, victoryColor.copy(alpha = 0.35f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = victoryColor.copy(alpha = 0.15f),
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = victoryColor,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Text(
                    text = "ثبات وانتصار جديد",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "تم حفظ تفاصيل الجلسة في سجلات التعافي بنجاح.\nكل موجة رغبة تصمد أمامها تعيد تشكيل مسارات الدوبامين وتبني حصانة عصبية أقوى.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = victoryColor,
                        contentColor = Color.White
                    )
                ) {
                    Text("متابعة المسار بنقاء تام", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
