package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.*
import com.example.util.SaffahQrKeyManager
import java.util.concurrent.Executors

/**
 * سطح مسح كاميرا QR Code عالي الكفاءة
 * مصمم مع إطار توجيه أنيق وتحكم بالفلاش وإيقاف فوري عند استلام الكود لضمان انعدام استهلاك الطاقة.
 */
@Composable
fun QrBarcodeScannerSurface(
    modifier: Modifier = Modifier,
    onCodeScanned: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    if (!hasCameraPermission) {
        Box(
            modifier = modifier
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(48.dp)
                )
                Text(
                    text = "يلزم منح إذن الكاميرا لمسح الرمز المطبوع",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("منح الإذن")
                }
            }
        }
        return
    }

    var cameraControl by remember { mutableStateOf<CameraControl?>(null) }
    var isTorchOn by remember { mutableStateOf(false) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            cameraExecutor.shutdown()
            try {
                ProcessCameraProvider.getInstance(context).get().unbindAll()
            } catch (_: Exception) {}
        }
    }

    // Laser scan animation
    val infiniteTransition = rememberInfiniteTransition(label = "laser_scan")
    val laserPosition by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_pos"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        // CameraX AndroidView
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder()
                        .build()
                        .also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                    val imageAnalysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                        .build()
                        .also {
                            it.setAnalyzer(
                                cameraExecutor,
                                SaffahQrKeyManager.ZxingQrBarcodeAnalyzer { scannedText ->
                                    // Trigger callback on Main Thread
                                    previewView.post {
                                        onCodeScanned(scannedText)
                                    }
                                }
                            )
                        }

                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                    try {
                        cameraProvider.unbindAll()
                        val camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageAnalysis
                        )
                        cameraControl = camera.cameraControl
                    } catch (exc: Exception) {
                        exc.printStackTrace()
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            }
        )

        // Overlay with scanning frame cutout and laser beam
        val primaryColor = MaterialTheme.colorScheme.primary
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val frameSize = canvasWidth.coerceAtMost(canvasHeight) * 0.72f
            val left = (canvasWidth - frameSize) / 2f
            val top = (canvasHeight - frameSize) / 2f
            val right = left + frameSize
            val bottom = top + frameSize

            // Dark semi-transparent background around viewfinder
            val path = Path().apply {
                addRect(Rect(0f, 0f, canvasWidth, canvasHeight))
                addRoundRect(
                    RoundRect(
                        rect = Rect(left, top, right, bottom),
                        cornerRadius = CornerRadius(24f, 24f)
                    )
                )
            }
            drawPath(
                path = path,
                color = Color.Black.copy(alpha = 0.55f)
            )

            // Viewfinder Corner Brackets
            val cornerLength = 36f
            val strokeWidth = 5f
            val cornerRadius = 16f

            // Top-Left
            drawLine(
                color = primaryColor,
                start = Offset(left, top + cornerLength),
                end = Offset(left, top + cornerRadius),
                strokeWidth = strokeWidth
            )
            drawLine(
                color = primaryColor,
                start = Offset(left + cornerRadius, top),
                end = Offset(left + cornerLength, top),
                strokeWidth = strokeWidth
            )

            // Top-Right
            drawLine(
                color = primaryColor,
                start = Offset(right - cornerLength, top),
                end = Offset(right - cornerRadius, top),
                strokeWidth = strokeWidth
            )
            drawLine(
                color = primaryColor,
                start = Offset(right, top + cornerRadius),
                end = Offset(right, top + cornerLength),
                strokeWidth = strokeWidth
            )

            // Bottom-Left
            drawLine(
                color = primaryColor,
                start = Offset(left, bottom - cornerLength),
                end = Offset(left, bottom - cornerRadius),
                strokeWidth = strokeWidth
            )
            drawLine(
                color = primaryColor,
                start = Offset(left + cornerRadius, bottom),
                end = Offset(left + cornerLength, bottom),
                strokeWidth = strokeWidth
            )

            // Bottom-Right
            drawLine(
                color = primaryColor,
                start = Offset(right - cornerLength, bottom),
                end = Offset(right - cornerRadius, bottom),
                strokeWidth = strokeWidth
            )
            drawLine(
                color = primaryColor,
                start = Offset(right, bottom - cornerRadius),
                end = Offset(right, bottom - cornerLength),
                strokeWidth = strokeWidth
            )

            // Animated Laser line with optical gradient beam inside viewfinder
            val laserY = top + (frameSize * laserPosition)
            val laserGlowBrush = Brush.verticalGradient(
                colors = listOf(
                    primaryColor.copy(alpha = 0f),
                    primaryColor.copy(alpha = 0.28f),
                    primaryColor.copy(alpha = 0f)
                ),
                startY = laserY - 12f,
                endY = laserY + 12f
            )
            drawRect(
                brush = laserGlowBrush,
                topLeft = Offset(left + 16f, laserY - 12f),
                size = Size(frameSize - 32f, 24f)
            )

            drawLine(
                color = primaryColor.copy(alpha = 0.95f),
                start = Offset(left + 16f, laserY),
                end = Offset(right - 16f, laserY),
                strokeWidth = 3f
            )
        }

        // Torch / Flash Toggle Button at Top End
        IconButton(
            onClick = {
                val newTorchState = !isTorchOn
                isTorchOn = newTorchState
                cameraControl?.enableTorch(newTorchState)
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .saffahPressMotion()
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                .size(40.dp)
        ) {
            Icon(
                imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                contentDescription = "تبديل ضوء الفلاش",
                tint = if (isTorchOn) MaterialTheme.colorScheme.primary else Color.White
            )
        }
    }
}
