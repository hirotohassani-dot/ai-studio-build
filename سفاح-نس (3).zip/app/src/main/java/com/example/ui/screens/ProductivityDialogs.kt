package com.example.ui.screens

import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.SaffahSwitch
import com.example.model.InstalledApp
import com.example.model.ProductivityDisciplineRule
import com.example.model.ProductivityTargetApp
import com.example.ui.components.rememberFastDrawablePainter

/**
 * Filter categories for app selection dialogs.
 */
enum class ProductivityAppFilter(val title: String) {
    ALL("الكل"),
    INSTALLED("المثبتة"),
    SYSTEM("النظام"),
    SELECTED("المحددة")
}

/**
 * Helper item for displaying educational info sections.
 */
@Composable
private fun ProductivityInfoSection(
    icon: ImageVector,
    title: String,
    description: String
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .size(22.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 19.sp,
                    fontSize = 12.5.sp
                )
            }
        }
    }
}

/**
 * Educational / Instructions Dialog explaining the Productivity and Discipline logic.
 */
@Composable
fun ProductivityInfoDialog(onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 440.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header: Title + Close (X) button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.TrendingUp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "تحسين الإنتاجية والإنضباط",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                    // Content: Detailed explanation sections
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 420.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ProductivityInfoSection(
                            icon = Icons.Outlined.TrendingUp,
                            title = "فكرة الميزة",
                            description = "تهدف الميزة إلى بناء عادات إيجابية بإلزامك بإكمال وقت استخدام محدد لتطبيقاتك المفيدة والمنتجة (مثل تطبيقات القراءة، الدراسة، أو العمل) قبل السماح بفتح باقي تطبيقات الهاتف."
                        )

                        ProductivityInfoSection(
                            icon = Icons.Default.AccessTime,
                            title = "فترة العمل اليومية (06:00 إلى 22:00)",
                            description = "خلال الأيام المحددة وضمن هذه الفترة، يتم قفل جميع التطبيقات تلقائياً باستثناء التطبيقات المسموحة وتطبيقات الهدف."
                        )

                        ProductivityInfoSection(
                            icon = Icons.Default.CheckCircle,
                            title = "تطبيقات الهدف وفك الحظر التلقائي",
                            description = "تظل تطبيقات الهدف متاحة للاستخدام حتى استهلاك سقف الوقت اليومي المحدد لها. فور اكتمال سقف الوقت لجميع تطبيقات الهدف، يُرفع الحظر فوراً عن كامل الجهاز لبقية اليوم."
                        )

                        ProductivityInfoSection(
                            icon = Icons.Default.Checklist,
                            title = "التطبيقات المسموحة للاستخدام الحر",
                            description = "يمكنك استثناء تطبيقات أساسية (مثل الهاتف، الرسائل، الخرائط، وأدوات العمل الضرورية) لتعمل بحرية تامة دون أي قيود."
                        )

                        ProductivityInfoSection(
                            icon = Icons.Default.LockReset,
                            title = "التجديد اليومي والتعديل الآمن",
                            description = "تتجدد عدادات الوقت تلقائياً كل يوم عند الساعة 00:00 (منتصف الليل). تخضع الميزة لنظام التأخير الزمني لمنع التراجع اللحظي (يُسمح بالتعديل بين 22:00 و 06:00)."
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = "فهمت ذلك",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

/**
 * Edit productivity rule settings (Name, Enable state, Active Days).
 */
@Composable
fun ProductivityRuleEditDialog(
    initialRule: ProductivityDisciplineRule?,
    isRestrictedByTimeDelay: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (ProductivityDisciplineRule) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initialRule?.name ?: "تحسين الإنتاجية والإنظباط") }
    var selectedDays by remember { mutableStateOf(initialRule?.activeDays ?: setOf(7, 1, 2, 3, 4, 5, 6)) }
    var showInfoDialog by remember { mutableStateOf(false) }

    val daysMap = listOf(
        java.util.Calendar.SATURDAY to "س",
        java.util.Calendar.SUNDAY to "أ",
        java.util.Calendar.MONDAY to "ن",
        java.util.Calendar.TUESDAY to "ث",
        java.util.Calendar.WEDNESDAY to "ع",
        java.util.Calendar.THURSDAY to "خ",
        java.util.Calendar.FRIDAY to "ج"
    )

    if (showInfoDialog) {
        ProductivityInfoDialog(onDismiss = { showInfoDialog = false })
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 460.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "إعدادات عملية الإنتاجية",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = { showInfoDialog = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Info,
                                    contentDescription = "شرح الميزة",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (isRestrictedByTimeDelay) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "التأخير الزمني نشط: لا يمكن استثناء الأيام المفعلة (يُسمح فقط بإضافة أيام).",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }

                        // Name field
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("اسم العملية") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Day Selection using Clean Circular Arabic Days (س، أ، ن، ث، ع، خ، ج)
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Text(
                                    text = "أيام سريان الحظر:",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    daysMap.forEach { (dayIndex, letter) ->
                                        val isSelected = selectedDays.contains(dayIndex)
                                        val isInitiallySelected = initialRule?.activeDays?.contains(dayIndex) == true

                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .clip(CircleShape)
                                                .clickable {
                                                    if (isSelected) {
                                                        if (isRestrictedByTimeDelay && isInitiallySelected) {
                                                            Toast.makeText(
                                                                context,
                                                                "لا يمكن استثناء أو إزالة أيام سريان الحظر أثناء سريان ميزة التأخير الزمني (يُسمح فقط بإضافة أيام).",
                                                                Toast.LENGTH_SHORT
                                                            ).show()
                                                        } else {
                                                            if (selectedDays.size > 1) {
                                                                selectedDays = selectedDays - dayIndex
                                                            } else {
                                                                Toast.makeText(context, "يجب تحديد يوم واحد على الأقل", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    } else {
                                                        selectedDays = selectedDays + dayIndex
                                                    }
                                                },
                                            shape = CircleShape,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                            border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                        ) {
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = letter,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            val rule = ProductivityDisciplineRule(
                                id = initialRule?.id ?: 1L,
                                name = name.ifBlank { "تحسين الإنتاجية والإنظباط" },
                                isEnabled = initialRule?.isEnabled ?: false,
                                activeDays = selectedDays,
                                targetApps = initialRule?.targetApps ?: emptyList(),
                                allowedApps = initialRule?.allowedApps ?: emptySet()
                            )
                            onSave(rule)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حفظ العملية",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

/**
 * Smooth infinite/cyclic scrollable wheel picker column.
 * - Displays 3 rows: previous (faded), selected (bold & prominent), next (faded)
 * - Supports fast flings and slow item-by-item dragging
 * - Snaps smoothly to the center item
 * - Disables manual keyboard entry; purely gesture-based
 */
@Composable
fun SaffahWheelColumn(
    value: Int,
    range: IntRange,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    unitLabel: String? = null,
    itemHeight: Dp = 52.dp,
    visibleItemsCount: Int = 3,
    columnWidth: Dp = 72.dp
) {
    val count = range.count()
    val repeatFactor = 1000
    val totalItems = count * repeatFactor
    val middleChunk = repeatFactor / 2

    val safeVal = (value - range.first).coerceIn(0, count - 1)
    val initialCenterIndex = remember { middleChunk * count + safeVal }

    val lazyListState = rememberLazyListState(
        initialFirstVisibleItemIndex = (initialCenterIndex - 1).coerceAtLeast(0)
    )

    val coroutineScope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    val activeCenterIndex by remember {
        derivedStateOf {
            val layoutInfo = lazyListState.layoutInfo
            val viewportCenter = (layoutInfo.viewportStartOffset + layoutInfo.viewportEndOffset) / 2
            layoutInfo.visibleItemsInfo.minByOrNull { item ->
                kotlin.math.abs((item.offset + item.size / 2) - viewportCenter)
            }?.index
        }
    }

    var lastReportedVal by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(activeCenterIndex) {
        val centerIdx = activeCenterIndex
        if (centerIdx != null) {
            val rawVal = ((centerIdx % count) + count) % count + range.first
            if (rawVal != lastReportedVal) {
                if (lastReportedVal != null && lazyListState.isScrollInProgress) {
                    try {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    } catch (_: Exception) {}
                }
                lastReportedVal = rawVal
                onValueChange(rawVal)
            }
        }
    }

    // Keep synced when value is changed externally (only when not actively scrolling)
    LaunchedEffect(value) {
        if (!lazyListState.isScrollInProgress) {
            val centerIdx = activeCenterIndex
            val currentVal = centerIdx?.let {
                ((it % count) + count) % count + range.first
            }
            if (currentVal != null && currentVal != value) {
                val diff = value - currentVal
                val targetCenter = centerIdx + diff
                lazyListState.scrollToItem((targetCenter - 1).coerceAtLeast(0))
            }
        }
    }

    val snapFlingBehavior = rememberSnapFlingBehavior(lazyListState = lazyListState)

    Box(
        modifier = modifier
            .width(columnWidth)
            .height(itemHeight * visibleItemsCount)
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        LazyColumn(
            state = lazyListState,
            flingBehavior = snapFlingBehavior,
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(
                count = totalItems,
                key = { it }
            ) { itemIndex ->
                val rawValue = ((itemIndex % count) + count) % count + range.first
                val formatted = String.format(java.util.Locale.US, "%02d", rawValue)

                val distanceFraction by remember {
                    derivedStateOf {
                        val layoutInfo = lazyListState.layoutInfo
                        val itemInfo = layoutInfo.visibleItemsInfo.firstOrNull { it.index == itemIndex }
                        if (itemInfo != null && itemInfo.size > 0) {
                            val viewportCenter = (layoutInfo.viewportStartOffset + layoutInfo.viewportEndOffset) / 2f
                            val itemCenter = itemInfo.offset + itemInfo.size / 2f
                            (kotlin.math.abs(itemCenter - viewportCenter) / itemInfo.size.toFloat()).coerceIn(0f, 1f)
                        } else {
                            if (activeCenterIndex == itemIndex) 0f else 1f
                        }
                    }
                }

                val alpha = (1.0f - distanceFraction * 0.65f).coerceIn(0.32f, 1.0f)
                val scale = (1.0f - distanceFraction * 0.12f).coerceIn(0.88f, 1.0f)
                val isCenter = distanceFraction < 0.4f
                val unitAlpha = ((1.0f - distanceFraction * 2.8f).coerceIn(0f, 1.0f))

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(itemHeight)
                        .clickable(
                            indication = null,
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                        ) {
                            val centerIdx = activeCenterIndex ?: return@clickable
                            if (itemIndex == centerIdx - 1) {
                                coroutineScope.launch {
                                    lazyListState.animateScrollToItem((centerIdx - 2).coerceAtLeast(0))
                                }
                            } else if (itemIndex == centerIdx + 1) {
                                coroutineScope.launch {
                                    lazyListState.animateScrollToItem(centerIdx)
                                }
                            }
                        }
                        .graphicsLayer {
                            this.alpha = alpha
                            scaleX = scale
                            scaleY = scale
                        }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = formatted,
                            style = if (isCenter) {
                                MaterialTheme.typography.displaySmall.copy(
                                    fontSize = 38.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            } else {
                                MaterialTheme.typography.headlineMedium.copy(
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
                                )
                            },
                            modifier = Modifier.alignByBaseline(),
                            textAlign = TextAlign.Center
                        )
                        if (!unitLabel.isNullOrEmpty()) {
                            Text(
                                text = unitLabel,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier
                                    .alignByBaseline()
                                    .padding(start = 2.5.dp)
                                    .graphicsLayer {
                                        this.alpha = unitAlpha
                                    }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Modern Time Wheel Picker component matching clean 2-column design (Hours & Minutes):
 * - Left: Hours (00..23) + 'h'
 * - Right: Minutes (00..59) + 'm'
 * - Colon separator between columns at the center row
 * - Purely gesture-driven (fast fling or slow step-by-step swipe), NO keyboard input
 */
@Composable
fun ProductivityMinutesStepper(
    minutes: Int,
    minAllowed: Int = 1,
    maxAllowed: Int = 1440,
    accentColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color(0xFF0166FF),
    titleText: String? = "سقف وقت الاستخدام اليومي:",
    onExceedMax: (() -> Unit)? = null,
    onMinutesChange: (Int) -> Unit
) {
    val initialH = (minutes / 60).coerceIn(0, 23)
    val initialM = (minutes % 60).coerceIn(0, 59)

    var hours by remember { mutableIntStateOf(initialH) }
    var currentMins by remember { mutableIntStateOf(initialM) }

    LaunchedEffect(minutes) {
        val h = (minutes / 60).coerceIn(0, 23)
        val m = (minutes % 60).coerceIn(0, 59)
        if (h != hours) hours = h
        if (m != currentMins) currentMins = m
    }

    val updateTime = remember(minAllowed, maxAllowed) {
        { h: Int, m: Int ->
            val totalM = h * 60 + m
            if (totalM > maxAllowed) {
                onExceedMax?.invoke()
            }
            val safeMinutes = totalM.coerceIn(minAllowed, maxAllowed)
            onMinutesChange(safeMinutes)
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!titleText.isNullOrEmpty()) {
                Text(
                    text = titleText,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Wheel Picker Container: Hours + h : Minutes + m
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. Hours (00..23) with 'h' directly beside the active number
                    SaffahWheelColumn(
                        value = hours,
                        range = 0..23,
                        onValueChange = { newH ->
                            hours = newH
                            updateTime(newH, currentMins)
                        },
                        unitLabel = "h",
                        columnWidth = 72.dp
                    )

                    // Colon separator
                    Text(
                        text = ":",
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )

                    // 2. Minutes (00..59) with 'm' directly beside the active number
                    SaffahWheelColumn(
                        value = currentMins,
                        range = 0..59,
                        onValueChange = { newM ->
                            currentMins = newM
                            updateTime(hours, newM)
                        },
                        unitLabel = "m",
                        columnWidth = 76.dp
                    )
                }
            }
        }
    }
}

/**
 * Filter Tabs Bar for App Selection Dialogs spanning 100% width cleanly with no clipped edges.
 */
@Composable
private fun AppFilterTabsBar(
    currentFilter: ProductivityAppFilter,
    selectedCount: Int,
    onFilterSelect: (ProductivityAppFilter) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProductivityAppFilter.values().forEach { filter ->
            val isSelected = currentFilter == filter
            val label = if (filter == ProductivityAppFilter.SELECTED) "${filter.title} ($selectedCount)" else filter.title

            Surface(
                onClick = { onFilterSelect(filter) },
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 2.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

/**
 * Add Target App Dialog with category filters and minute stepper (1-min precision).
 * Selected / existing target apps appear first in the sorted order.
 */
@Composable
fun ProductivityAddTargetAppDialog(
    installedApps: List<InstalledApp>,
    existingTargetApps: List<ProductivityTargetApp>,
    onDismiss: () -> Unit,
    onAddTarget: (ProductivityTargetApp) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedPackage by remember { mutableStateOf<String?>(null) }
    var targetMinutes by remember { mutableIntStateOf(30) }
    var currentFilter by remember { mutableStateOf(ProductivityAppFilter.ALL) }
    var showTimePickerDialog by remember { mutableStateOf(false) }

    val existingTargetPackageSet = remember(existingTargetApps) {
        existingTargetApps.map { it.packageName }.toSet()
    }

    // Filter & Sort: Selected/Target apps come FIRST, then sort alphabetically by app name
    val filteredApps = remember(installedApps, searchQuery, currentFilter, existingTargetPackageSet, selectedPackage) {
        var list = installedApps.asSequence()

        // 1. Search Query
        if (searchQuery.isNotBlank()) {
            list = list.filter {
                it.appName.contains(searchQuery, ignoreCase = true) ||
                it.packageName.contains(searchQuery, ignoreCase = true)
            }
        }

        // 2. Category Tab Filter
        list = when (currentFilter) {
            ProductivityAppFilter.ALL -> list
            ProductivityAppFilter.INSTALLED -> list.filter { !it.isSystemApp }
            ProductivityAppFilter.SYSTEM -> list.filter { it.isSystemApp }
            ProductivityAppFilter.SELECTED -> list.filter { existingTargetPackageSet.contains(it.packageName) || selectedPackage == it.packageName }
        }

        // 3. Priority Sorting: Selected/Targets ALWAYS first
        list.sortedWith(
            compareByDescending<InstalledApp> {
                it.packageName == selectedPackage || existingTargetPackageSet.contains(it.packageName)
            }.thenBy { it.appName.lowercase() }
        ).toList()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "إضافة تطبيق هدف",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن تطبيق...", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "مسح", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Filter Category Chips (الكل، المثبتة، النظام، المحددة)
                AppFilterTabsBar(
                    currentFilter = currentFilter,
                    selectedCount = existingTargetApps.size + (if (selectedPackage != null && !existingTargetPackageSet.contains(selectedPackage)) 1 else 0),
                    onFilterSelect = { currentFilter = it }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Apps List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val isSelected = selectedPackage == app.packageName
                        val isAlreadyTarget = existingTargetPackageSet.contains(app.packageName)

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    if (!isAlreadyTarget) {
                                        selectedPackage = if (selectedPackage == app.packageName) null else app.packageName
                                    }
                                },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val iconPainter = rememberFastDrawablePainter(app.iconDrawable)
                                    if (iconPainter != null) {
                                        Image(
                                            painter = iconPainter,
                                            contentDescription = app.appName,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                    } else {
                                        Surface(
                                            modifier = Modifier.size(36.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Android,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(6.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = app.appName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = app.packageName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                if (isAlreadyTarget) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.surface,
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Text(
                                            text = "مضاف مسبقاً",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            fontSize = 10.sp
                                        )
                                    }
                                } else {
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = { checked ->
                                            selectedPackage = if (checked) app.packageName else null
                                        },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = MaterialTheme.colorScheme.primary,
                                            checkmarkColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Compact usage cap stepper
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "سقف الاستخدام اليومي:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { if (targetMinutes > 1) targetMinutes-- },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "تقليل", modifier = Modifier.size(18.dp))
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showTimePickerDialog = true }
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$targetMinutes دقيقة",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(
                                onClick = { if (targetMinutes < 720) targetMinutes++ },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "زيادة", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        val pkg = selectedPackage
                        if (pkg != null) {
                            onAddTarget(ProductivityTargetApp(packageName = pkg, targetMinutes = targetMinutes))
                        }
                    },
                    enabled = selectedPackage != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إضافة التطبيق (${com.example.util.SaffahBlockRepository.formatUsageCeilingTime(targetMinutes)})",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
    }
}

    if (showTimePickerDialog) {
        val selectedAppInfo = remember(selectedPackage, installedApps) {
            installedApps.firstOrNull { it.packageName == selectedPackage }
        }
        ProductivityEditTargetAppDialog(
            targetApp = ProductivityTargetApp(
                packageName = selectedPackage ?: "",
                targetMinutes = targetMinutes
            ),
            appName = selectedAppInfo?.appName ?: "تحديد سقف الوقت",
            iconDrawable = selectedAppInfo?.iconDrawable,
            isRestrictedByTimeDelay = false,
            onDismiss = { showTimePickerDialog = false },
            onSaveMinutes = { newMins ->
                targetMinutes = newMins
                showTimePickerDialog = false
            }
        )
    }
}

/**
 * Edit Target App Time Cap Dialog
 */
@Composable
fun ProductivityEditTargetAppDialog(
    targetApp: ProductivityTargetApp,
    appName: String,
    iconDrawable: Drawable?,
    isRestrictedByTimeDelay: Boolean,
    onDismiss: () -> Unit,
    onSaveMinutes: (Int) -> Unit
) {
    var minutes by remember { mutableIntStateOf(targetApp.targetMinutes) }
    val minAllowed = if (isRestrictedByTimeDelay) targetApp.targetMinutes else 1

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 440.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(26.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val iconPainter = rememberFastDrawablePainter(iconDrawable)
                            if (iconPainter != null) {
                                Image(
                                    painter = iconPainter,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                            } else {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Icon(Icons.Default.Apps, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp))
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = "تعديل سقف الوقت",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = appName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 380.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (isRestrictedByTimeDelay) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "ساري التأخير الزمني: يُسمح بزيادة سقف الوقت فقط، ويُمنع إنقاصه حتى الساعة 22:00.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }

                        // Minutes Stepper
                        ProductivityMinutesStepper(
                            minutes = minutes,
                            minAllowed = minAllowed,
                            onMinutesChange = { minutes = it }
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { onSaveMinutes(minutes) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حفظ التعديل (${com.example.util.SaffahBlockRepository.formatUsageCeilingTime(minutes)})",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

/**
 * Confirm deletion dialog for target app on long press.
 */
@Composable
fun ProductivityDeleteTargetConfirmDialog(
    targetApp: ProductivityTargetApp,
    appName: String,
    onDismiss: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.90f)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                tonalElevation = 0.dp,
                shadowElevation = 10.dp
            ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = CircleShape,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "حذف تطبيق الهدف",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "هل تريد بالتأكيد إزالة تطبيق \"$appName\" من تطبيقات الهدف؟",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Button(
                        onClick = onConfirmDelete,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("حذف", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onError)
                    }
                }
            }
        }
    }
}
}

/**
 * Allowed Apps selector dialog with Category Tabs (الكل، المثبتة، النظام، المحددة).
 * Selected apps ALWAYS appear first in the order.
 */
@Composable
fun ProductivityAllowedAppsDialog(
    installedApps: List<InstalledApp>,
    allowedApps: Set<String>,
    isRestrictedByTimeDelay: Boolean = false,
    onDismiss: () -> Unit,
    onSaveAllowedApps: (Set<String>) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedSet by remember { mutableStateOf(allowedApps) }
    var currentFilter by remember { mutableStateOf(ProductivityAppFilter.ALL) }

    // Filter and Sort: Selected apps ALWAYS first, then alphabetical by name
    val filteredApps = remember(installedApps, searchQuery, currentFilter, selectedSet) {
        var list = installedApps.asSequence()

        // 1. Search filter
        if (searchQuery.isNotBlank()) {
            list = list.filter {
                it.appName.contains(searchQuery, ignoreCase = true) ||
                it.packageName.contains(searchQuery, ignoreCase = true)
            }
        }

        // 2. Category Tab filter
        list = when (currentFilter) {
            ProductivityAppFilter.ALL -> list
            ProductivityAppFilter.INSTALLED -> list.filter { !it.isSystemApp }
            ProductivityAppFilter.SYSTEM -> list.filter { it.isSystemApp }
            ProductivityAppFilter.SELECTED -> list.filter { selectedSet.contains(it.packageName) }
        }

        // 3. Priority Sorting: Selected apps ALWAYS first
        list.sortedWith(
            compareByDescending<InstalledApp> { selectedSet.contains(it.packageName) }
                .thenBy { it.appName.lowercase() }
        ).toList()
    }

    Dialog(
        onDismissRequest = {
            onSaveAllowedApps(selectedSet)
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "التطبيقات المسموحة (${selectedSet.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(
                        onClick = {
                            onSaveAllowedApps(selectedSet)
                            onDismiss()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن تطبيق...", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "مسح", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Category Tabs Bar
                AppFilterTabsBar(
                    currentFilter = currentFilter,
                    selectedCount = selectedSet.size,
                    onFilterSelect = { currentFilter = it }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Apps List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val isChecked = selectedSet.contains(app.packageName)

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    if (isChecked) {
                                        selectedSet = selectedSet - app.packageName
                                    } else {
                                        if (isRestrictedByTimeDelay && !allowedApps.contains(app.packageName)) {
                                            Toast.makeText(
                                                context,
                                                "ممنوع إضافة تطبيقات مسموحة جديدة أثناء سريان التأخير الزمني (يُسمح فقط بإلغاء التطبيقات).",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        } else {
                                            selectedSet = selectedSet + app.packageName
                                        }
                                    }
                                },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isChecked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            border = BorderStroke(
                                1.dp,
                                if (isChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val iconPainter = rememberFastDrawablePainter(app.iconDrawable)
                                    if (iconPainter != null) {
                                        Image(
                                            painter = iconPainter,
                                            contentDescription = app.appName,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                    } else {
                                        Surface(
                                            modifier = Modifier.size(36.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Android,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(6.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = app.appName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = app.packageName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        if (checked) {
                                            if (isRestrictedByTimeDelay && !allowedApps.contains(app.packageName)) {
                                                Toast.makeText(
                                                    context,
                                                    "ممنوع إضافة تطبيقات مسموحة جديدة أثناء سريان التأخير الزمني (يُسمح فقط بإلغاء التطبيقات).",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            } else {
                                                selectedSet = selectedSet + app.packageName
                                            }
                                        } else {
                                            selectedSet = selectedSet - app.packageName
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = MaterialTheme.colorScheme.primary,
                                        checkmarkColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
}
