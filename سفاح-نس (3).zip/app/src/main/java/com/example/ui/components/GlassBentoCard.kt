package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GlassBorder

import androidx.compose.foundation.clickable
import com.example.ui.theme.saffahPressMotion
import com.example.ui.theme.saffahCardFloat

@Composable
fun GlassBentoCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    backgroundColor: Color = MaterialTheme.colorScheme.surface,
    borderColor: Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
    animateSize: Boolean = true,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val animatedBgColor by animateColorAsState(
        targetValue = backgroundColor,
        animationSpec = tween(durationMillis = 220),
        label = "BentoCardBgColor"
    )
    val animatedBorderColor by animateColorAsState(
        targetValue = borderColor,
        animationSpec = tween(durationMillis = 220),
        label = "BentoCardBorderColor"
    )

    val shape = remember(cornerRadius) { RoundedCornerShape(cornerRadius) }
    val borderStroke = remember(animatedBorderColor) { BorderStroke(1.dp, animatedBorderColor) }

    val baseModifier = if (animateSize) {
        modifier.animateContentSize(
            animationSpec = spring(
                stiffness = Spring.StiffnessMediumLow,
                dampingRatio = Spring.DampingRatioNoBouncy
            )
        )
    } else {
        modifier
    }

    val finalModifier = if (onClick != null) {
        baseModifier
            .clip(shape)
            .saffahCardFloat(onClick = onClick)
    } else {
        baseModifier.clip(shape)
    }

    Surface(
        modifier = finalModifier,
        shape = shape,
        color = animatedBgColor,
        border = borderStroke,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .fillMaxWidth()
        ) {
            content()
        }
    }
}



