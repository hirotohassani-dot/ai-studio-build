package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.util.SaffahQrKeyManager
import com.example.viewmodel.MainViewModel

/**
 * حوار مسح رمز الحماية المسجل (QR Code Verification Gateway)
 * يتم استدعاؤه فورياً عند محاولة تعطيل أي حماية أو تخفيض القيود أو إزالة الحظر.
 */
@Composable
fun QrKeyVerificationDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val pendingActionDesc by viewModel.pendingProtectedActionDesc.collectAsState()
    val isPendingPrimaryOnly by viewModel.isPendingActionPrimaryOnly.collectAsState()
    val qrConfig by viewModel.qrKeyConfig.collectAsState()
    val primaryKey = qrConfig.primaryKey ?: qrConfig.keys.firstOrNull()

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(24.dp)
                    ),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Lock Icon
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(
                                if (isSuccess) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (isSuccess) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Title
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (isPendingPrimaryOnly) "امسح كود QR الأساسي الأول" else "امسح رمز QR المادي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isPendingPrimaryOnly) {
                                "يلزم مسح الكود الأساسي الأول${if (primaryKey != null) " (${primaryKey.label})" else ""} لتنفيذ هذا الإجراء:"
                            } else if (qrConfig.totalKeysCount > 1) {
                                "يلزم مسح أي رمز QR من الرموز المعتمدة (${qrConfig.totalKeysCount} أكواد مسجلة) للمتابعة:"
                            } else {
                                "يلزم مسح رمز الـ QR المطبوع لتأكيد فك القفل والمتابعة:"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }

                    // Target Action Badge
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = pendingActionDesc.ifBlank { "تعديل إعدادات الحماية" },
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }

                    // Live Camera Viewfinder
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(230.dp)
                            .clip(RoundedCornerShape(16.dp))
                    ) {
                        QrBarcodeScannerSurface(
                            modifier = Modifier.fillMaxSize(),
                            onCodeScanned = { scannedCode ->
                                if (isSuccess) return@QrBarcodeScannerSurface
                                val (matched, errorText) = viewModel.verifyQrKeyAndExecute(scannedCode)
                                if (matched) {
                                    isSuccess = true
                                    errorMessage = null
                                } else {
                                    errorMessage = errorText ?: "الرمز غير متطابق! يرجى مسح أحد رموز الحماية المعتمدة."
                                }
                            }
                        )
                    }

                    // Key Hint Info
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isPendingPrimaryOnly && primaryKey != null) {
                                "الكود المطلوب: ${primaryKey.label} (${SaffahQrKeyManager.formatMaskedPreview(primaryKey.preview)})"
                            } else if (qrConfig.totalKeysCount > 1) {
                                "${qrConfig.totalKeysCount} أكواد معتمدة مسجلة"
                            } else {
                                "بصمة الرمز: ${SaffahQrKeyManager.formatMaskedPreview(qrConfig.keyPreview)}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "0% استهلاك للطاقة",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Error Message display
                    AnimatedVisibility(visible = errorMessage != null) {
                        errorMessage?.let { msg ->
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = msg,
                                    modifier = Modifier.padding(8.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // Success Feedback
                    AnimatedVisibility(visible = isSuccess) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "تم التحقق بنجاح! جاري تنفيذ الإجراء المطلوب...",
                                modifier = Modifier.padding(8.dp),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Cancel button
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("إلغاء والاحتفاظ بالحماية")
                    }
                }
            }
        }
    }
}
