package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BiomeType
import com.example.model.RecoveryJourneyMilestone
import com.example.ui.components.MilestoneDetailsDialog
import com.example.ui.theme.*
import com.example.util.RecoveryJourneyDataProvider
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * بيانات نقطة المحطة على الطريق العضوي غير المنتظم (Organic Highway Station Node)
 */
private data class RoadNodeSpec(
    val xRatio: Float,
    val height: Dp,
    val curvatureBias: Float
)

/**
 * توليد مسار طبيعي غير متماثل لـ 105 محطة
 */
private fun getRoadNodeSpec(index: Int): RoadNodeSpec {
    val baseSide = if (index % 2 == 0) 1f else -1f
    
    val harmonic1 = sin(index * 0.73f) * 0.14f
    val harmonic2 = cos(index * 1.37f + 0.5f) * 0.10f
    val depthVariation = 0.50f + (baseSide * (0.28f + harmonic1 + harmonic2))
    val clampedX = depthVariation.coerceIn(0.18f, 0.82f)

    val heightDp = when (index % 5) {
        0 -> 140.dp
        1 -> 120.dp
        2 -> 150.dp
        3 -> 125.dp
        else -> 135.dp
    }

    val curvature = 0.20f + (sin(index * 0.9f) * 0.08f)

    return RoadNodeSpec(
        xRatio = clampedX,
        height = heightDp,
        curvatureBias = curvature
    )
}

/**
 * شاشة خريطة طريق التعافي مع أجواء بيئية حقيقية خفيفة واقتصادية
 * - ثلوج وجليد، صحاري وكثبان رملية، براكين وحمم، غابات خضراء، بحار وأنهار، قمم جبلية، وفضاء كوني
 * - أداء فائق السرعة وخفيف جداً على البطارية والمعالج (Zero CPU Waste / Direct Procedural Canvas)
 * - خالية تماماً من الإيموجيات وتعتمد على تصميم Bento UI الاحترافي
 */
@Composable
fun RecoveryJourneyMapScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val recoveryStats by viewModel.recoveryStats.collectAsState()
    val currentTimeMs by viewModel.recoveryCurrentTimeMs.collectAsState()
    val userName by viewModel.userName.collectAsState()

    val elapsedSec = remember(recoveryStats.startTimestamp, currentTimeMs) {
        ((currentTimeMs - recoveryStats.startTimestamp) / 1000L).coerceAtLeast(0L)
    }
    val currentStreakDays = (elapsedSec / 86400L).toInt()

    val allMilestones = remember { RecoveryJourneyDataProvider.getAllMilestones() }
    val completedCount = remember(currentStreakDays) {
        allMilestones.count { it.day <= currentStreakDays }
    }

    val currentMilestoneIndex = remember(currentStreakDays) {
        val idx = allMilestones.indexOfFirst { it.day >= currentStreakDays }
        if (idx == -1) allMilestones.size - 1 else idx
    }

    var selectedMilestoneForDetails by remember { mutableStateOf<RecoveryJourneyMilestone?>(null) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // التمرير التلقائي المباشر إلى المحطة والموقع الحالي بدقة
    LaunchedEffect(currentMilestoneIndex) {
        val targetLazyIndex = currentMilestoneIndex.coerceIn(0, allMilestones.size - 1)
        listState.scrollToItem(targetLazyIndex)
    }

    // نبض دائري خفيف للموقع الحالي
    val infiniteTransition = rememberInfiniteTransition(label = "roadBeaconPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // دورة حركة جزيئات الأجواء الطبيعية الخفيفة (صفر استهلاك للبطارية والمعالج)
    val ambientCycle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ambientCycle"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0F14))
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 76.dp,
                    bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 36.dp
                ),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                // مقاطع الطريق مع البيئات الطبيعية المتنوعة
                itemsIndexed(
                    items = allMilestones,
                    key = { _, milestone -> "road_segment_${milestone.day}" }
                ) { index, milestone ->
                    val isAchieved = currentStreakDays >= milestone.day
                    val isLocked = !isAchieved

                    val currentNode = remember(index) { getRoadNodeSpec(index) }
                    val nextNode = remember(index) { 
                        if (index < allMilestones.size - 1) getRoadNodeSpec(index + 1)
                        else RoadNodeSpec(0.50f, 130.dp, 0.2f)
                    }

                    val isFirstInBiome = remember(index) {
                        index == 0 || allMilestones[index - 1].biome != milestone.biome
                    }

                    val isLast = index == allMilestones.size - 1

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(getBiomeGradientColors(milestone.biome))),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // لافتة الدخول في بيئة ومناخ جديد
                        if (isFirstInBiome) {
                            BiomeAtmosphereBanner(biome = milestone.biome)
                        }

                        OrganicRoadSegment(
                            milestone = milestone,
                            index = index,
                            currentNode = currentNode,
                            nextNode = nextNode,
                            isAchieved = isAchieved,
                            isLocked = isLocked,
                            ambientProgress = { ambientCycle },
                            onSphereClick = {
                                if (!isLocked) {
                                    selectedMilestoneForDetails = milestone
                                }
                            }
                        )

                        if (isLast) {
                            FinalHighwaySummitBadge(isAchieved = isAchieved)
                        }
                    }
                }
            }
        }

        // شريط تحكم عائم زجاجي خفيف في الأعلى (Floating Glassmorphic Header)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                color = Color(0xFF131A26).copy(alpha = 0.88f),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF2E3D52).copy(alpha = 0.65f)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(38.dp)
                                .background(Color(0xFF1E293B).copy(alpha = 0.85f), RoundedCornerShape(10.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "رجوع",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "طريق رحلة التعافي",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "اليوم $currentStreakDays • المحطات: $completedCount / ${allMilestones.size}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    Surface(
                        onClick = {
                            coroutineScope.launch {
                                listState.animateScrollToItem(
                                    currentMilestoneIndex.coerceIn(0, allMilestones.size - 1)
                                )
                            }
                        },
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MyLocation,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "موقعي",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // نافذة التفاصيل العلمية والتوثيق
        selectedMilestoneForDetails?.let { milestone ->
            MilestoneDetailsDialog(
                milestone = milestone,
                userName = userName,
                currentStreakDays = currentStreakDays,
                viewModel = viewModel,
                onDismiss = { selectedMilestoneForDetails = null }
            )
        }
    }
}

/**
 * أيقونة احترافية لكل بيئة ومناخ
 */
private fun getBiomeIcon(biome: BiomeType): androidx.compose.ui.graphics.vector.ImageVector = when (biome) {
    BiomeType.OASIS_FOOTHILLS -> Icons.Default.Spa
    BiomeType.GOLDEN_DESERT -> Icons.Default.WbSunny
    BiomeType.GLACIER_PEAKS -> Icons.Default.AcUnit
    BiomeType.VOLCANIC_RIDGE -> Icons.Default.LocalFireDepartment
    BiomeType.DEEP_FOREST -> Icons.Default.Forest
    BiomeType.GRANITE_MOUNTAINS -> Icons.Default.Landscape
    BiomeType.CRYSTAL_RIVERS -> Icons.Default.Waves
    BiomeType.ROYAL_PLATEAU -> Icons.Default.MilitaryTech
    BiomeType.CELESTIAL_SUMMIT -> Icons.Default.AutoAwesome
}

/**
 * لوحة الألوان الأفقية المستمرة والمتصلة ككتلة واحدة لكل بيئة لمنع أي فواصل أو خطوط رأسية
 */
private fun getBiomeGradientColors(biome: BiomeType): List<Color> = when (biome) {
    BiomeType.OASIS_FOOTHILLS -> listOf(
        Color(0xFF03140B),
        Color(0xFF082817),
        Color(0xFF0E3E24),
        Color(0xFF082817),
        Color(0xFF03140B)
    )
    BiomeType.GOLDEN_DESERT -> listOf(
        Color(0xFF160902),
        Color(0xFF2B1406),
        Color(0xFF42200A),
        Color(0xFF2B1406),
        Color(0xFF160902)
    )
    BiomeType.CRYSTAL_RIVERS -> listOf(
        Color(0xFF02121A),
        Color(0xFF062331),
        Color(0xFF0A3347),
        Color(0xFF062331),
        Color(0xFF02121A)
    )
    BiomeType.DEEP_FOREST -> listOf(
        Color(0xFF02120A),
        Color(0xFF052314),
        Color(0xFF08321D),
        Color(0xFF052314),
        Color(0xFF02120A)
    )
    BiomeType.GRANITE_MOUNTAINS -> listOf(
        Color(0xFF060914),
        Color(0xFF0D1527),
        Color(0xFF14203B),
        Color(0xFF0D1527),
        Color(0xFF060914)
    )
    BiomeType.GLACIER_PEAKS -> listOf(
        Color(0xFF03101C),
        Color(0xFF072036),
        Color(0xFF0B2D4C),
        Color(0xFF072036),
        Color(0xFF03101C)
    )
    BiomeType.VOLCANIC_RIDGE -> listOf(
        Color(0xFF100301),
        Color(0xFF220703),
        Color(0xFF350B05),
        Color(0xFF220703),
        Color(0xFF100301)
    )
    BiomeType.ROYAL_PLATEAU -> listOf(
        Color(0xFF100314),
        Color(0xFF200727),
        Color(0xFF300B3B),
        Color(0xFF200727),
        Color(0xFF100314)
    )
    BiomeType.CELESTIAL_SUMMIT -> listOf(
        Color(0xFF070213),
        Color(0xFF130426),
        Color(0xFF1F063D),
        Color(0xFF130426),
        Color(0xFF070213)
    )
}

/**
 * لافتة أنيقة بتصميم Bento UI عند الدخول في بيئة ومناخ جديد
 */
@Composable
private fun BiomeAtmosphereBanner(biome: BiomeType) {
    val primaryColor = Color(biome.primaryColorHex)
    val secondaryColor = Color(biome.secondaryColorHex)
    val biomeIcon = getBiomeIcon(biome)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .shadow(elevation = 8.dp, shape = RoundedCornerShape(16.dp), spotColor = primaryColor.copy(alpha = 0.5f)),
            color = Color(0xFF131822).copy(alpha = 0.92f),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.2.dp, Brush.linearGradient(listOf(primaryColor.copy(alpha = 0.7f), secondaryColor.copy(alpha = 0.3f))))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .shadow(elevation = 6.dp, shape = CircleShape, spotColor = primaryColor)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(primaryColor.copy(alpha = 0.4f), Color(0xFF0F172A))
                            )
                        )
                        .border(1.5.dp, primaryColor.copy(alpha = 0.7f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = biomeIcon,
                        contentDescription = biome.arabicName,
                        tint = primaryColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = biome.arabicName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "الأيام (${biome.dayStart} - ${biome.dayEnd}) • ${biome.description}",
                        style = MaterialTheme.typography.bodySmall,
                        color = primaryColor.copy(alpha = 0.95f),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

/**
 * مقطع طريق طبيعي ثلاثي الأبعاد مع بيئة واقعية خفيفة على الكانفاس
 */
@Composable
private fun OrganicRoadSegment(
    milestone: RecoveryJourneyMilestone,
    index: Int,
    currentNode: RoadNodeSpec,
    nextNode: RoadNodeSpec,
    isAchieved: Boolean,
    isLocked: Boolean,
    ambientProgress: () -> Float,
    onSphereClick: () -> Unit
) {
    val roadWidthPx = with(LocalDensity.current) { 46.dp.toPx() }
    val curbWidthPx = with(LocalDensity.current) { 3.5.dp.toPx() }
    val centerLineDashPx = with(LocalDensity.current) { 10.dp.toPx() }
    val centerLineGapPx = with(LocalDensity.current) { 7.dp.toPx() }

    val asphaltColor = if (isAchieved) Color(0xFF1E242E) else Color(0xFF14181F)
    val asphaltBorderColor = if (isAchieved) Color(0xFF2F3847) else Color(0xFF1C222C)
    val curbHighlightColor = if (isAchieved) Color(0xFFCBD5E1) else Color(0xFF475569)
    val curbShadowColor = if (isAchieved) Color(0xFF334155) else Color(0xFF1E293B)
    val studColor = if (isAchieved) Color(0xFF10B981) else Color(0xFF334155)
    val centerLineColor = if (isAchieved) Color(0xFFFFFFFF) else Color(0xFF334155)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(currentNode.height)
    ) {
        // 1. رسم البيئة المحيطة + مسار الطريق الإسفلتي ثلاثي الأبعاد
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            val startX = w * currentNode.xRatio
            val endX = w * nextNode.xRatio

            // رسم بيئة ومناخ المحطة وتأثيراتها الحركية الخفيفة بالكانفاس النقي
            drawLightweightBiomeAtmosphere(
                biome = milestone.biome,
                index = index,
                w = w,
                h = h,
                roadStartX = startX,
                roadEndX = endX,
                ambientProgress = ambientProgress()
            )

            // مسار بيزيه الأساسي لسطح الطريق
            val roadPath = Path().apply {
                moveTo(startX, 0f)
                cubicTo(
                    startX, h * 0.50f,
                    endX, h * 0.50f,
                    endX, h
                )
            }

            // مسار الظل الساقط ثلاثي الأبعاد على تضاريس الأرضية
            val road3DShadowPath = Path().apply {
                moveTo(startX + 4f, 8f)
                cubicTo(
                    startX + 4f, h * 0.50f + 8f,
                    endX + 4f, h * 0.50f + 8f,
                    endX + 4f, h + 8f
                )
            }

            // مسار الهيكل الخرساني السفلي البارز للجسر
            val road3DExtrusionPath = Path().apply {
                moveTo(startX, 4f)
                cubicTo(
                    startX, h * 0.50f + 4f,
                    endX, h * 0.50f + 4f,
                    endX, h + 4f
                )
            }

            // أ. الظل التجسيمي الساقط
            val isDesert = milestone.biome == BiomeType.GOLDEN_DESERT
            val shadowBaseColor = if (isDesert) Color(0xFF5E3912) else Color.Black
            drawPath(
                path = road3DShadowPath,
                color = shadowBaseColor.copy(alpha = if (isLocked) (if (isDesert) 0.35f else 0.40f) else (if (isDesert) 0.50f else 0.65f)),
                style = Stroke(
                    width = roadWidthPx + 16f,
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )

            // ب. سمك وجدار الجسر الخرساني السفلي
            drawPath(
                path = road3DExtrusionPath,
                color = Color(0xFF0D1219),
                style = Stroke(
                    width = roadWidthPx + (curbWidthPx * 2) + 3f,
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )

            // ج. الرصيف الجانبي المظلل
            drawPath(
                path = roadPath,
                color = curbShadowColor,
                style = Stroke(
                    width = roadWidthPx + (curbWidthPx * 2),
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )

            // د. الرصيف العلوي المعدني العاكس للضوء
            drawPath(
                path = roadPath,
                color = curbHighlightColor,
                style = Stroke(
                    width = roadWidthPx + (curbWidthPx * 1.1f),
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )

            // هـ. سطح الإسفلت الرئيسي المجسم
            drawPath(
                path = roadPath,
                color = asphaltColor,
                style = Stroke(
                    width = roadWidthPx,
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )

            // و. تظليل حواف الإسفلت
            drawPath(
                path = roadPath,
                color = asphaltBorderColor.copy(alpha = 0.75f),
                style = Stroke(
                    width = roadWidthPx - 4f,
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )

            // ز. لمعان خفيف وإضاءة سطح المسار
            drawPath(
                path = roadPath,
                color = Color.White.copy(alpha = if (isAchieved) 0.03f else 0.015f),
                style = Stroke(
                    width = roadWidthPx * 0.50f,
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )

            // ح. عواكس ضوئية مجسمة على حواف الطريق
            for (step in 1..3) {
                val t = step / 4f
                val u = 1f - t
                val ptX = u * u * u * startX + 3f * u * u * t * startX + 3f * u * t * t * endX + t * t * t * endX
                val ptY = u * u * u * 0f + 3f * u * u * t * (h * 0.5f) + 3f * u * t * t * (h * 0.5f) + t * t * t * h
                val halfW = (roadWidthPx / 2f) + 1f

                drawCircle(
                    color = studColor.copy(alpha = if (isLocked) 0.4f else 0.85f),
                    radius = 2.2f,
                    center = Offset(ptX - halfW, ptY)
                )
                drawCircle(
                    color = studColor.copy(alpha = if (isLocked) 0.4f else 0.85f),
                    radius = 2.2f,
                    center = Offset(ptX + halfW, ptY)
                )
            }

            // ط. خط المسار المتقطع في المنتصف
            drawPath(
                path = roadPath,
                color = centerLineColor,
                style = Stroke(
                    width = 2.2.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(
                        floatArrayOf(centerLineDashPx, centerLineGapPx),
                        0f
                    )
                )
            )
        }

        // 2. دائرة ومجسم رقم المحطة في منتصف الطريق
        BoxWithConstraints(
            modifier = Modifier.fillMaxSize()
        ) {
            val totalWidth = maxWidth
            val sphereRadius = 18.dp
            val sphereOffsetX = (totalWidth * currentNode.xRatio) - sphereRadius
            val sphereOffsetY = 0.dp - sphereRadius + 14.dp

            Box(
                modifier = Modifier
                    .offset(x = sphereOffsetX, y = sphereOffsetY)
                    .size(36.dp),
                contentAlignment = Alignment.Center
            ) {
                RoadCenterSphere(
                    milestone = milestone,
                    isAchieved = isAchieved,
                    isLocked = isLocked,
                    onClick = onSphereClick
                )
            }
        }
    }
}

/**
 * رسم بيئة واقعية ومميزة لكل مناخ مع تأثيرات حركية فائقة الخفة واقتصادية جداً
 * (تطاير حبات الرمل، أوراق الأشجار، شرارات البراكين، ندف الثلج، رذاذ الأنهار، شُهُب السماء)
 * مصممة بهندسة متجهات نقية (Zero Allocation / 100% Hardware Accelerated Canvas)
 */
private fun DrawScope.drawLightweightBiomeAtmosphere(
    biome: BiomeType,
    index: Int,
    w: Float,
    h: Float,
    roadStartX: Float,
    roadEndX: Float,
    ambientProgress: Float
) {
    val seed = (index * 23 + 7) % 100

    // رسم الخلفية الأفقية المتصلة بانسجام كامل ككتلة واحدة ممتدة بدون أي فواصل رأسية أو خطوط بين المقاطع
    drawRect(
        brush = Brush.horizontalGradient(
            colors = getBiomeGradientColors(biome),
            startX = 0f,
            endX = w
        ),
        size = Size(w, h + 2.5f) // تداخل بمقدار 2.5 بكسل لضمان عدم حدوث أي فراغ ميكروسكوبي بين عناصر القائمة
    )

    when (biome) {
        BiomeType.VOLCANIC_RIDGE -> {
            // تطاير شرارات وجمرات نارية متوهجة تصعد للأعلى مع هالة وذيول ضوئية
            for (i in 0..10) {
                val pSeed = (seed + i * 29) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val py = (1f - pProgress) * (h + 35f) - 15f
                val px = (w * (0.06f + (pSeed % 88) * 0.01f)) + sin(pProgress * 6.283f * 2.5f + i) * 10f
                val emberAlpha = (sin(pProgress * 3.14159f) * 0.95f).coerceIn(0f, 0.95f)
                val emberSize = 1.6f + (pSeed % 3) * 0.9f

                drawCircle(
                    color = Color(0xFFEF4444).copy(alpha = emberAlpha * 0.40f),
                    radius = emberSize * 2.8f,
                    center = Offset(px, py)
                )
                drawCircle(
                    color = if (i % 3 == 0) Color(0xFFFEF08A) else Color(0xFFFB923C),
                    radius = emberSize,
                    center = Offset(px, py)
                )
                drawLine(
                    color = Color(0xFFEA580C).copy(alpha = emberAlpha * 0.50f),
                    start = Offset(px, py + 5.5f),
                    end = Offset(px, py),
                    strokeWidth = 1.3f,
                    cap = StrokeCap.Round
                )
            }
        }

        BiomeType.GLACIER_PEAKS -> {
            // بلورات ثلج سداسية متلألئة ناعمة
            drawSnowCrystal(Offset(w * 0.14f, h * 0.35f), size = 6.5f)
            drawSnowCrystal(Offset(w * 0.86f, h * 0.60f), size = 5.5f)

            // ندف ثلج متساقطة متلألئة في الهواء البارد
            for (i in 0..8) {
                val pSeed = (seed + i * 31) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val py = pProgress * (h + 25f) - 10f
                val px = (w * (0.04f + (pSeed % 92) * 0.01f)) + sin(pProgress * 6.283f * 1.5f + i) * 14f
                val snowAlpha = (sin(pProgress * 3.14159f) * 0.85f).coerceIn(0f, 0.90f)
                val snowSize = 1.6f + (pSeed % 3) * 0.8f

                drawCircle(
                    color = Color.White.copy(alpha = snowAlpha),
                    radius = snowSize,
                    center = Offset(px, py)
                )
                if (i % 3 == 0) {
                    drawCircle(
                        color = Color(0xFF7DD3FC).copy(alpha = snowAlpha * 0.35f),
                        radius = snowSize * 2.2f,
                        center = Offset(px, py)
                    )
                }
            }
        }

        BiomeType.GOLDEN_DESERT -> {
            // ذرات غبار ورمال ذهبية متلألئة تتطاير انسيابياً مع نسيم الصحراء
            for (i in 0..10) {
                val pSeed = (seed + i * 29) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val px = (pProgress * (w + 40f)) - 20f
                val py = (h * (0.15f + (pSeed % 70) * 0.01f)) + sin(pProgress * 6.283f * 2f + i) * 6f
                val dustAlpha = (sin(pProgress * 3.14159f) * 0.85f).coerceIn(0f, 0.90f)
                val dustSize = 1.4f + (pSeed % 3) * 0.7f

                drawCircle(
                    color = Color(0xFFFDE68A).copy(alpha = dustAlpha),
                    radius = dustSize,
                    center = Offset(px, py)
                )
                if (i % 2 == 0) {
                    drawCircle(
                        color = Color(0xFFF59E0B).copy(alpha = dustAlpha * 0.35f),
                        radius = dustSize * 2.2f,
                        center = Offset(px, py)
                    )
                }
            }
        }

        BiomeType.DEEP_FOREST -> {
            // يراعات مضيئة متوهجة تتنفس بالضوء
            val fireflyPhase = sin(ambientProgress * 6.283f * 2f) * 0.3f + 0.5f
            drawCircle(
                color = Color(0xFF34D399).copy(alpha = fireflyPhase * 0.35f),
                radius = 8f,
                center = Offset(w * 0.22f, h * 0.40f)
            )
            drawCircle(
                color = Color(0xFFA7F3D0).copy(alpha = fireflyPhase),
                radius = 2.4f,
                center = Offset(w * 0.22f, h * 0.40f)
            )
            drawCircle(
                color = Color(0xFF2DD4BF).copy(alpha = fireflyPhase * 0.30f),
                radius = 7f,
                center = Offset(w * 0.78f, h * 0.60f)
            )
            drawCircle(
                color = Color(0xFFCCFBF1).copy(alpha = fireflyPhase),
                radius = 2.2f,
                center = Offset(w * 0.78f, h * 0.60f)
            )

            // أوراق شجر زمردية متطايرة تتهادى برقة
            for (i in 0..5) {
                val pSeed = (seed + i * 23) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val py = pProgress * (h + 25f) - 10f
                val sway = sin(pProgress * 6.283f * 1.6f + i) * 16f
                val px = ((w * (0.08f + (pSeed % 84) * 0.01f)) + sway).coerceIn(8f, w - 8f)
                val leafAlpha = (sin(pProgress * 3.14159f) * 0.85f).coerceIn(0f, 0.90f)

                drawRealisticLeaf(
                    center = Offset(px, py),
                    angleRad = pProgress * 6.283f + i,
                    scale = 0.9f + (pSeed % 3) * 0.25f,
                    color = if (i % 2 == 0) Color(0xFF34D399).copy(alpha = leafAlpha) else Color(0xFF10B981).copy(alpha = leafAlpha)
                )
            }
        }

        BiomeType.CRYSTAL_RIVERS -> {
            // رذاذ ماء متصاعد متلألئ (Mist & Spray Particles)
            for (i in 0..8) {
                val pSeed = (seed + i * 27) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val py = (1f - pProgress) * (h + 20f) - 10f
                val px = (w * (0.08f + (pSeed % 84) * 0.01f)) + sin(pProgress * 6.283f * 2f + i) * 8f
                val sprayAlpha = (sin(pProgress * 3.14159f) * 0.80f).coerceIn(0f, 0.85f)
                val spraySize = 1.5f + (pSeed % 3) * 0.7f

                drawCircle(
                    color = Color(0xFFA5F3FC).copy(alpha = sprayAlpha),
                    radius = spraySize,
                    center = Offset(px, py)
                )
                if (i % 3 == 0) {
                    drawCircle(
                        color = Color(0xFF06B6D4).copy(alpha = sprayAlpha * 0.35f),
                        radius = spraySize * 2.2f,
                        center = Offset(px, py)
                    )
                }
            }
        }

        BiomeType.GRANITE_MOUNTAINS -> {
            // ضباب جبلي عابر بين القمم
            for (i in 0..4) {
                val pSeed = (seed + i * 37) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val px = (pProgress * (w + 90f)) - 45f
                val py = (h * (0.25f + (pSeed % 55) * 0.01f))
                val mistAlpha = (sin(pProgress * 3.14159f) * 0.45f).coerceIn(0f, 0.50f)

                drawLine(
                    color = Color(0xFFA5B4FC).copy(alpha = mistAlpha),
                    start = Offset(px - 32f, py),
                    end = Offset(px, py),
                    strokeWidth = 2.5f,
                    cap = StrokeCap.Round
                )
            }
        }

        BiomeType.CELESTIAL_SUMMIT -> {
            // نجوم ساطعة ذات محاور ضوئية رباعية
            drawSparkleStar(Offset(w * 0.20f, h * 0.22f), size = 5f, color = Color.White)
            drawSparkleStar(Offset(w * 0.82f, h * 0.28f), size = 6f, color = Color(0xFFE9D5FF))
            drawSparkleStar(Offset(w * 0.14f, h * 0.75f), size = 4.5f, color = Color(0xFFBAE6FD))

            // شُهُب فضائية عابرة مع ذيل طيفي متلاشٍ
            for (i in 0..5) {
                val pSeed = (seed + i * 37) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val px = (pProgress * (w + 70f)) - 35f
                val py = (pProgress * (h + 35f)) + (pSeed % 40)
                val starAlpha = (sin(pProgress * 3.14159f) * 0.90f).coerceIn(0f, 0.95f)

                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color(0xFFC084FC).copy(alpha = starAlpha * 0.7f), Color.White.copy(alpha = starAlpha)),
                        start = Offset(px - 22f, py - 12f),
                        end = Offset(px, py)
                    ),
                    start = Offset(px - 22f, py - 12f),
                    end = Offset(px, py),
                    strokeWidth = 1.6f,
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = Color.White.copy(alpha = starAlpha),
                    radius = 2.0f,
                    center = Offset(px, py)
                )
            }
        }

        BiomeType.ROYAL_PLATEAU -> {
            // ذرات طاقة متلألئة تصعد برقي
            for (i in 0..5) {
                val pSeed = (seed + i * 23) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val py = (1f - pProgress) * h
                val px = (w * (0.08f + (pSeed % 84) * 0.01f)) + sin(pProgress * 6.283f + i) * 10f
                val auraAlpha = (sin(pProgress * 3.14159f) * 0.75f).coerceIn(0f, 0.85f)

                drawCircle(
                    color = Color(0xFFF472B6).copy(alpha = auraAlpha * 0.35f),
                    radius = 5.5f,
                    center = Offset(px, py)
                )
                drawCircle(
                    color = Color(0xFFFDF2F8).copy(alpha = auraAlpha),
                    radius = 2.0f,
                    center = Offset(px, py)
                )
            }
        }

        BiomeType.OASIS_FOOTHILLS -> {
            // بتلات أزهار ربيعية متطايرة
            for (i in 0..6) {
                val pSeed = (seed + i * 19) % 100
                val pProgress = (ambientProgress + (pSeed / 100f)) % 1f
                val px = (pProgress * (w + 40f)) - 20f
                val py = (pProgress * h) + sin(pProgress * 6.283f + i) * 8f
                val petalAlpha = (sin(pProgress * 3.14159f) * 0.75f).coerceIn(0f, 0.85f)

                drawCircle(
                    color = Color(0xFFA7F3D0).copy(alpha = petalAlpha),
                    radius = 2.4f,
                    center = Offset(px, py)
                )
            }

            // ومضات يراعات ناعمة
            val fireflyPhase = sin(ambientProgress * 6.283f * 2f + seed) * 0.3f + 0.5f
            drawCircle(
                color = Color(0xFF34D399).copy(alpha = fireflyPhase * 0.35f),
                radius = 6f,
                center = Offset(w * 0.22f, h * 0.45f)
            )
            drawCircle(
                color = Color(0xFF6EE7B7).copy(alpha = fireflyPhase),
                radius = 2.0f,
                center = Offset(w * 0.22f, h * 0.45f)
            )
        }
    }
}

/**
 * رسم شكل ندفة ثلج هندسية واقعية متبلورة سداسية الأطراف على الكانفاس
 */
private fun DrawScope.drawSnowCrystal(center: Offset, size: Float) {
    val color = Color(0xFFE0F2FE).copy(alpha = 0.65f)
    val branchColor = Color(0xFFBAE6FD).copy(alpha = 0.45f)
    val strokeWidth = 1.4f

    // 3 محاور سداسية رئيسية (Hexagonal Arms)
    for (a in 0..2) {
        val angle = a * (3.1415927f / 3f)
        val dx = cos(angle) * size
        val dy = sin(angle) * size

        drawLine(color, Offset(center.x - dx, center.y - dy), Offset(center.x + dx, center.y + dy), strokeWidth)

        // تفرعات بلورية صغيرة (Crystal sub-branches)
        val subX = cos(angle) * (size * 0.6f)
        val subY = sin(angle) * (size * 0.6f)
        val perpAngle = angle + (3.1415927f / 2f)
        val pLen = size * 0.35f
        val px = cos(perpAngle) * pLen
        val py = sin(perpAngle) * pLen

        drawLine(
            branchColor,
            Offset(center.x + subX - px, center.y + subY - py),
            Offset(center.x + subX + px, center.y + subY + py),
            strokeWidth * 0.8f
        )
    }
}


/**
 * رسم ورقة شجر متطايرة واقعية مع عرق الورقة المركزي (Realistic Leaf with Vein)
 */
private fun DrawScope.drawRealisticLeaf(
    center: Offset,
    angleRad: Float,
    scale: Float,
    color: Color
) {
    val leafLength = 8f * scale
    val leafWidth = 4.2f * scale

    val cosA = cos(angleRad)
    val sinA = sin(angleRad)

    val tipX = center.x + leafLength * cosA
    val tipY = center.y + leafLength * sinA

    val baseX = center.x - leafLength * cosA
    val baseY = center.y - leafLength * sinA

    val leftX = center.x - leafWidth * sinA
    val leftY = center.y + leafWidth * cosA

    val rightX = center.x + leafWidth * sinA
    val rightY = center.y - leafWidth * cosA

    val leafPath = Path().apply {
        moveTo(tipX, tipY)
        quadraticTo(leftX, leftY, baseX, baseY)
        quadraticTo(rightX, rightY, tipX, tipY)
        close()
    }
    drawPath(leafPath, color)

    // عرق الورقة المركزي (Central Leaf Vein)
    drawLine(
        color = Color.White.copy(alpha = color.alpha * 0.45f),
        start = Offset(baseX, baseY),
        end = Offset(tipX, tipY),
        strokeWidth = 1.0f * scale,
        cap = StrokeCap.Round
    )
}

/**
 * رسم نجمة لامعة بأشعة ضوئية رباعية (4-Point Diffraction Sparkle Star)
 */
private fun DrawScope.drawSparkleStar(center: Offset, size: Float, color: Color) {
    val alpha = color.alpha
    val glowColor = color.copy(alpha = alpha * 0.35f)

    // هالة دائرية مركزية
    drawCircle(
        color = glowColor,
        radius = size * 1.2f,
        center = center
    )

    // شعاع أفقي وعمودي مدبب
    val spikeH = size * 2.2f
    val spikeW = size * 0.45f

    val starPath = Path().apply {
        moveTo(center.x, center.y - spikeH)
        quadraticTo(center.x + spikeW, center.y, center.x + spikeH, center.y)
        quadraticTo(center.x, center.y + spikeW, center.x, center.y + spikeH)
        quadraticTo(center.x - spikeW, center.y, center.x - spikeH, center.y)
        quadraticTo(center.x, center.y - spikeW, center.x, center.y - spikeH)
        close()
    }
    drawPath(starPath, color)
}

/**
 * دائرة رقم التعافي في وسط الطريق مع دعم الحالة المقفلة والمعطلة والباهتة
 */
@Composable
private fun RoadCenterSphere(
    milestone: RecoveryJourneyMilestone,
    isAchieved: Boolean,
    isLocked: Boolean,
    onClick: () -> Unit
) {
    val sphereGradient = if (isAchieved) {
        Brush.radialGradient(
            colors = listOf(
                Color(0xFF6EE7B7),
                Color(0xFF10B981),
                Color(0xFF065F46)
            )
        )
    } else {
        Brush.radialGradient( // Locked & Faded Slate
            colors = listOf(
                Color(0xFF334155),
                Color(0xFF1E293B),
                Color(0xFF0F172A)
            )
        )
    }

    Box(
        modifier = Modifier
            .size(38.dp)
            .then(
                if (!isLocked) Modifier
                    .saffahPressMotion()
                    .clickable { onClick() }
                else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        // ظل ملامس واقعي على سطح الإسفلت ثلاثي الأبعاد
        Box(
            modifier = Modifier
                .offset(y = 11.dp)
                .size(width = 28.dp, height = 8.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = if (isLocked) 0.25f else 0.55f))
        )

        // ظل الكبسولة الكروية للمحطات المفتوحة
        if (!isLocked) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .shadow(elevation = 6.dp, shape = CircleShape, clip = false)
            )
        }

        // الكرة مع رقم اليوم أو قفل للمحطات المقفلة المعطلة
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(sphereGradient)
                .border(
                    width = if (isLocked) 1.dp else 1.5.dp,
                    color = if (isLocked) Color(0xFF475569).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.9f),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isLocked) {
                // أيقونة القفل للمحطات المقفلة المعطلة
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "محطة مقفلة",
                    tint = Color(0xFF94A3B8).copy(alpha = 0.70f),
                    modifier = Modifier.size(13.dp)
                )
            } else {
                Text(
                    text = "${milestone.day}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * شارة القمة النهائية عند ختام الطريق (اليوم 730) بتصميم ثلاثي الأبعاد
 */
@Composable
private fun FinalHighwaySummitBadge(isAchieved: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = if (isAchieved) Color(0xFFA855F7) else Color(0xFF38BDF8)
            ),
            shape = RoundedCornerShape(18.dp),
            color = if (isAchieved) Color(0xFF221333) else Color(0xFF131A26),
            border = BorderStroke(
                1.5.dp,
                Brush.linearGradient(
                    if (isAchieved) listOf(Color(0xFFC084FC), Color(0xFFA855F7))
                    else listOf(Color(0xFF38BDF8), Color(0xFF1E293B))
                )
            )
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                if (isAchieved) listOf(Color(0xFFE9D5FF), Color(0xFFA855F7), Color(0xFF581C87))
                                else listOf(Color(0xFFBAE6FD), Color(0xFF0284C7), Color(0xFF0C4A6E))
                            )
                        )
                        .border(1.2.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isAchieved) Icons.Default.WorkspacePremium else Icons.Default.EmojiEvents,
                        contentDescription = "القمة والحرية",
                        tint = if (isAchieved) Color(0xFFE9D5FF) else Color(0xFFBAE6FD),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = "ختام الطريق: قمة السيادة والحرية المطلقة",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "730 يوماً • محطة التتويج والتعافي الكامل الدائم",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isAchieved) Color(0xFFE9D5FF) else Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
