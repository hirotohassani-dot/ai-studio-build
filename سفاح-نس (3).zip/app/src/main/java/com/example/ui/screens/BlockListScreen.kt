package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.example.ui.components.rememberFastDrawablePainter
import com.example.ui.components.WebsiteFavicon
import com.example.ui.components.ReorderableCardsList
import com.example.model.BlockedSite
import com.example.model.BlockedKeyword
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppBlockScheduleRule
import com.example.model.AppBlockType
import com.example.ui.components.ExcludedAppsBox
import com.example.ui.components.GlassBentoCard
import com.example.ui.components.featureTitleHint
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockListScreen(viewModel: MainViewModel) {
    val unlockedPrivacySections by viewModel.unlockedPrivacySections.collectAsState()
    val isKeywordsSitesLocked = remember(unlockedPrivacySections) {
        viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES)
    }

    var selectedTab by remember {
        mutableIntStateOf(if (isKeywordsSitesLocked) 2 else 0)
    }
    var showPinDialogForTab by remember { mutableStateOf<Int?>(null) }

    // Dialog for Verifying PIN when attempting to access Keywords (0) or Sites (1) tab
    if (showPinDialogForTab != null) {
        val targetTab = showPinDialogForTab!!
        val tabTitle = if (targetTab == 0) "حظر الكلمات" else "حظر المواقع"
        com.example.ui.components.PrivacyPinVerificationDialog(
            title = "تأكيد رمز PIN",
            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض $tabTitle",
            onDismiss = { showPinDialogForTab = null },
            onSuccess = {
                viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES)
                showPinDialogForTab = null
                selectedTab = targetTab
            }
        )
    }

    val blockedKeywords by viewModel.blockedKeywords.collectAsState()
    val blockedSites by viewModel.blockedSites.collectAsState()
    val isImportingBlockedData by viewModel.isImportingBlockedData.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()

    val context = LocalContext.current
    var showClearKeywordsConfirmDialog by remember { mutableStateOf(false) }
    var showClearSitesConfirmDialog by remember { mutableStateOf(false) }

    val handleClearKeywordsRequest = {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            viewModel.showFeedback("لا يمكن حذف وتفريغ الكلمات المحظورة أثناء سريان ميزة التأخير الزمني.")
        } else if (blockedKeywords.isEmpty()) {
            viewModel.showFeedback("قائمة الكلمات المحظورة فارغة بالفعل.")
        } else {
            showClearKeywordsConfirmDialog = true
        }
    }

    val handleClearSitesRequest = {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            viewModel.showFeedback("لا يمكن حذف وتفريغ المواقع المحظورة أثناء سريان ميزة التأخير الزمني.")
        } else if (blockedSites.isEmpty()) {
            viewModel.showFeedback("قائمة المواقع المحظورة فارغة بالفعل.")
        } else {
            showClearSitesConfirmDialog = true
        }
    }

    if (showClearKeywordsConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearKeywordsConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "تفريغ وحذف كل الكلمات المحظورة",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف وتفريغ جميع الكلمات المحظورة (${blockedKeywords.size} كلمة) دفعة واحدة بشكل نهائي؟\n\nفي حال كان قفل RQ مفعلاً، سيُطلب منك مسح مفتاح RQ لتأكيد الحذف.",
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearKeywordsConfirmDialog = false
                        viewModel.clearAllBlockedKeywords()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "تفريغ وحذف كل الكلمات المحظورة دفعة واحدة",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onError
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showClearKeywordsConfirmDialog = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء")
                }
            },
            shape = RoundedCornerShape(18.dp)
        )
    }

    if (showClearSitesConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearSitesConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "تفريغ وحذف كل المواقع المحظورة",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف وتفريغ جميع المواقع المحظورة (${blockedSites.size} موقع) دفعة واحدة بشكل نهائي؟\n\nفي حال كان قفل RQ مفعلاً، سيُطلب منك مسح مفتاح RQ لتأكيد الحذف.",
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearSitesConfirmDialog = false
                        viewModel.clearAllBlockedSites()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "تفريغ وحذف كل المواقع المحظورة دفعة واحدة",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onError
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showClearSitesConfirmDialog = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء")
                }
            },
            shape = RoundedCornerShape(18.dp)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "قوائم الحظر والمنع",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "البنية التحتية لإدارة الحظر التلقائي للكلمات، المواقع، والتطبيقات",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Modern Bento Segmented Tab Bar
        val tabItems = listOf(
            Triple(0, "حظر الكلمات", Icons.Default.TextFields),
            Triple(1, "حظر المواقع", Icons.Default.Language),
            Triple(2, "حظر التطبيقات", Icons.Default.Apps)
        )

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabItems.forEach { (index, label, icon) ->
                    val isSelected = selectedTab == index
                    val tabContainerColor by animateColorAsState(
                        targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                        label = "tabContainerColor"
                    )
                    val tabContentColor by animateColorAsState(
                        targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                        label = "tabContentColor"
                    )

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(tabContainerColor)
                            .saffahPressMotion()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                if ((index == 0 || index == 1) && viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES)) {
                                    showPinDialogForTab = index
                                } else {
                                    selectedTab = index
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = tabContentColor,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = tabContentColor,
                                maxLines = 1,
                                fontSize = 12.sp,
                                modifier = Modifier.featureTitleHint(
                                    hintKey = when (index) {
                                        0 -> "keyword_blocking"
                                        1 -> "site_blocking"
                                        else -> "app_blocking"
                                    },
                                    onClick = {
                                        if ((index == 0 || index == 1) && viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES)) {
                                            showPinDialogForTab = index
                                        } else {
                                            selectedTab = index
                                        }
                                    }
                                )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = {
                SaffahMotion.tabTransition(
                    fromIndex = initialState,
                    toIndex = targetState,
                    isRtl = true
                )
            },
            label = "BlockListTabTransition"
        ) { tab ->
            when (tab) {
                0 -> {
                    if (isKeywordsSitesLocked) {
                        com.example.ui.components.PrivacyLockedScreenView(
                            title = "حظر الكلمات محمي برمز PIN",
                            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض الكلمات المحظورة",
                            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES,
                            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES) }
                        )
                    } else {
                        KeywordBlockTab(
                            keywords = blockedKeywords,
                            isImporting = isImportingBlockedData,
                            onAdd = { keyword -> viewModel.addBlockedKeyword(keyword) },
                            onDelete = { id, keyword -> viewModel.removeBlockedKeyword(id, keyword) },
                            onImportLines = { lines -> viewModel.importBlockedKeywordsFromLines(lines) },
                            onShowFeedback = { msg -> viewModel.showFeedback(msg) },
                            onClearAllKeywords = handleClearKeywordsRequest
                        )
                    }
                }
                1 -> {
                    if (isKeywordsSitesLocked) {
                        com.example.ui.components.PrivacyLockedScreenView(
                            title = "حظر المواقع محمي برمز PIN",
                            subtitle = "أدخل رمز PIN المكون من 4 أرقام لعرض المواقع المحظورة",
                            sectionKey = com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES,
                            onUnlocked = { viewModel.unlockPrivacySection(com.example.util.SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES) }
                        )
                    } else {
                        SiteBlockTab(
                            sites = blockedSites,
                            isImporting = isImportingBlockedData,
                            onAdd = { site -> viewModel.addBlockedSite(site) },
                            onDelete = { id, domain -> viewModel.removeBlockedSite(id, domain) },
                            onImportLines = { lines -> viewModel.importBlockedSitesFromLines(lines) },
                            onShowFeedback = { msg -> viewModel.showFeedback(msg) },
                            onClearAllSites = handleClearSitesRequest
                        )
                    }
                }
                2 -> AppBlockTab(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeywordBlockTab(
    keywords: List<com.example.model.BlockedKeyword>,
    isImporting: Boolean = false,
    onAdd: (String) -> Unit,
    onDelete: (Long, String) -> Unit,
    onImportLines: (List<String>) -> Unit,
    onShowFeedback: (String) -> Unit,
    onClearAllKeywords: () -> Unit = {}
) {
    var inputVal by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var showHintDialog by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    val coroutineScope = rememberCoroutineScope()
    var visibleLimit by remember(searchQuery) { mutableIntStateOf(150) }
    var displayedKeywords by remember { mutableStateOf<List<com.example.model.BlockedKeyword>>(emptyList()) }
    var totalKeywordMatches by remember { mutableIntStateOf(keywords.size) }

    LaunchedEffect(keywords, searchQuery, visibleLimit) {
        if (searchQuery.isBlank()) {
            totalKeywordMatches = keywords.size
            displayedKeywords = if (keywords.size > visibleLimit) keywords.take(visibleLimit) else keywords
        } else {
            val q = searchQuery.trim().lowercase()
            val (matches, count) = withContext(Dispatchers.Default) {
                val list = ArrayList<com.example.model.BlockedKeyword>(visibleLimit)
                var matchedCount = 0
                for (item in keywords) {
                    if (item.keyword.contains(q, ignoreCase = true)) {
                        matchedCount++
                        if (list.size < visibleLimit) {
                            list.add(item)
                        }
                        if (matchedCount >= 1000) break
                    }
                }
                Pair(list, matchedCount)
            }
            totalKeywordMatches = count
            displayedKeywords = matches
        }
    }

    // File Import Launcher for Keywords (.txt) - Streamed asynchronously without UI lag
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        val reader = inputStream.bufferedReader(Charsets.UTF_8)
                        val lines = ArrayList<String>(50000)
                        reader.useLines { seq ->
                            for (line in seq) {
                                val trimmed = line.trim()
                                if (trimmed.isNotEmpty() && !trimmed.startsWith("#") && !trimmed.startsWith("//")) {
                                    lines.add(trimmed)
                                }
                            }
                        }
                        withContext(Dispatchers.Main) {
                            onImportLines(lines)
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        onShowFeedback("تعذر قراءة الملف: ${e.localizedMessage ?: "خطأ غير معروف"}")
                    }
                }
            }
        }
    }

    // File Export Launcher for Keywords (.txt) - Streamed asynchronously with 64KB buffer
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                            for (item in keywords) {
                                writer.write(item.keyword)
                                writer.write('\n'.code)
                            }
                        }
                    }
                    withContext(Dispatchers.Main) {
                        onShowFeedback("تم تصدير ${keywords.size} كلمة بنجاح إلى ملف TXT.")
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        onShowFeedback("تعذر حفظ الملف: ${e.localizedMessage ?: "خطأ غير معروف"}")
                    }
                }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        GlassBentoCard {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .combinedClickable(
                        onClick = {},
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            showHintDialog = true
                        }
                    )
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "إدارة الكلمات المحظورة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape
                    ) {
                        Text(
                            text = if (searchQuery.isNotBlank()) "$totalKeywordMatches / ${keywords.size}" else "${keywords.size}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputVal,
                    onValueChange = { inputVal = it },
                    placeholder = { Text("مثال: *word* أو badword", style = MaterialTheme.typography.bodyMedium) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = {
                        if (inputVal.isNotEmpty()) {
                            IconButton(onClick = { inputVal = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "مسح",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (inputVal.isNotBlank()) {
                                onAdd(inputVal)
                                inputVal = ""
                            }
                        }
                    )
                )
                Spacer(modifier = Modifier.width(10.dp))
                IconButton(
                    onClick = {
                        if (inputVal.isNotBlank()) {
                            onAdd(inputVal)
                            inputVal = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .saffahPressMotion()
                        .background(Color(0xFF2C3036), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إضافة الكلمة",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bento Actions Row: Import TXT & Export TXT (Soft Charcoal Text & Icons with subtle gray border)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        importLauncher.launch(arrayOf("text/plain", "*/*"))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .saffahPressMotion(),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "رفع ملف كلمات",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "رفع ملف TXT",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                OutlinedButton(
                    onClick = {
                        if (keywords.isEmpty()) {
                            onShowFeedback("لا توجد كلمات محظورة مضافة لتصديرها.")
                        } else {
                            val defaultFileName = "saffah_blocked_keywords_${System.currentTimeMillis()}.txt"
                            exportLauncher.launch(defaultFileName)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .saffahPressMotion(),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = "تصدير الكلمات المحظورة",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تصدير TXT",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            val isTimeDelayActive = remember { com.example.util.SaffahBlockRepository.isTimeDelayActive(context) }
            OutlinedButton(
                onClick = onClearAllKeywords,
                modifier = Modifier
                    .fillMaxWidth()
                    .saffahPressMotion(),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(
                    1.dp,
                    if (isTimeDelayActive) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.45f)
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isTimeDelayActive) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = if (isTimeDelayActive) Icons.Default.Lock else Icons.Default.DeleteForever,
                    contentDescription = "تفريغ وحذف كل الكلمات المحظورة دفعة واحدة",
                    tint = if (isTimeDelayActive) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "تفريغ وحذف كل الكلمات المحظورة دفعة واحدة",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Search Bar for Large Lists
            if (keywords.size > 15) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "بحث في الكلمات (${keywords.size})...",
                            style = MaterialTheme.typography.bodySmall
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "مسح البحث",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                )
            }
        }

        if (isImporting) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "جاري استيراد القائمة ومعالجتها في الخلفية بسرعة فائقة...",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (keywords.isEmpty()) {
            GlassBentoCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.FormatQuote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "لا توجد كلمات محظورة مضافة حالياً",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "يمكنك كتابة كلمة أو رفع ملف TXT جاهز يحتوي على قائمة كلمات",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else if (totalKeywordMatches == 0) {
            GlassBentoCard {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد نتائج مطابقة لكلمة البحث",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(displayedKeywords, key = { it.id }, contentType = { "keyword_item" }) { item ->
                    val initialChar = remember(item.keyword) {
                        val clean = item.keyword.trim().trim('*', '"', '\'', '`', '“', '”', ' ', '-', '_')
                        val first = clean.firstOrNull { it.isLetterOrDigit() }
                            ?: clean.firstOrNull()
                            ?: item.keyword.firstOrNull { !it.isWhitespace() }
                            ?: '#'
                        first.uppercase()
                    }
                    Box(
                        modifier = Modifier.animateItem(
                            fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                            fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                            placementSpec = androidx.compose.animation.core.spring(
                                stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                dampingRatio = 0.8f
                            )
                        )
                    ) {
                        GlassBentoCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        color = ErrorRed.copy(alpha = 0.12f),
                                        shape = CircleShape,
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = initialChar,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = ErrorRed,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = item.keyword,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "تاريخ الإضافة: ${item.dateAdded}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { onDelete(item.id, item.keyword) },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .saffahPressMotion()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف الكلمة",
                                        tint = ErrorRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                if (totalKeywordMatches > visibleLimit) {
                    item(key = "load_more_keywords") {
                        TextButton(
                            onClick = { visibleLimit += 150 },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = "عرض المزيد (+150 من أصل $totalKeywordMatches)",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    if (showHintDialog) {
        Dialog(
            onDismissRequest = { showHintDialog = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .widthIn(max = 380.dp)
                        .wrapContentHeight(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "إرشادات حظر الكلمات",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { showHintDialog = false },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        val hintText = buildAnnotatedString {
                            append("• الحظر الشامل:\nكتابة الكلمة مجردة (مثل adult) يحظرها أينما وردت في أي نص، بحث، رابط، أو عنوان صفحة حتى لو كانت جزءاً من كلمة أخرى.\n\n• الحظر الدقيق الصارم (*الكلمة*):\nوضع الكلمة بين نجمتين (مثل *hot* أو *عري*) يحظر الكلمة ككلمة مستقلة فقط، ويتفادى حظر الكلمات المشتقة والمشروعة (مثل ")
                            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                                append("p")
                            }
                            withStyle(SpanStyle(color = Color(0xFF0166FF), fontWeight = FontWeight.Bold)) {
                                append("hot")
                            }
                            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                                append("o")
                            }
                            append(" أو ")
                            withStyle(SpanStyle(color = Color(0xFF0166FF), fontWeight = FontWeight.Bold)) {
                                append("عري\u200D")
                            }
                            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                                append("\u200Dض")
                            }
                            append(").\n\n• معالجة الأحرف والتطبيع الذكي:\nمحرك الحظر يتعامل تلقائياً مع الحروف المتشابهة (الهمزات أ/إ/آ، التاء المربوطة، التشكيل، المدود، والمسافات والرموز المتداخلة).\n\n• الاستيراد والتصدير:\nيمكنك رفع ملف TXT جماعي يحتوي على آلاف الكلمات أو تصدير قائمتك بنقرة زر للاحتفاظ بنسخة احتياطية.")
                        }

                        Text(
                            text = hintText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 22.sp,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SiteBlockTab(
    sites: List<com.example.model.BlockedSite>,
    isImporting: Boolean = false,
    onAdd: (String) -> Unit,
    onDelete: (Long, String) -> Unit,
    onImportLines: (List<String>) -> Unit,
    onShowFeedback: (String) -> Unit,
    onClearAllSites: () -> Unit = {}
) {
    var inputVal by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var showSiteHintDialog by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val shakeOffsetX = remember { androidx.compose.animation.core.Animatable(0f) }
    var isWordError by remember { mutableStateOf(false) }

    val triggerWordError = {
        try {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        } catch (_: Exception) {}
        isWordError = true
        onShowFeedback("يرجى إدخال نطاق موقع مكتمل (مثل example.com) وليس كلمة مفردة.")
        coroutineScope.launch {
            shakeOffsetX.animateTo(-16f, tween(35))
            shakeOffsetX.animateTo(16f, tween(35))
            shakeOffsetX.animateTo(-12f, tween(35))
            shakeOffsetX.animateTo(12f, tween(35))
            shakeOffsetX.animateTo(-6f, tween(35))
            shakeOffsetX.animateTo(6f, tween(35))
            shakeOffsetX.animateTo(0f, tween(35))
        }
    }

    var visibleLimit by remember(searchQuery) { mutableIntStateOf(150) }
    var displayedSites by remember { mutableStateOf<List<BlockedSite>>(emptyList()) }
    var totalSiteMatches by remember { mutableIntStateOf(sites.size) }

    LaunchedEffect(sites, searchQuery, visibleLimit) {
        if (searchQuery.isBlank()) {
            totalSiteMatches = sites.size
            displayedSites = if (sites.size > visibleLimit) sites.take(visibleLimit) else sites
        } else {
            val q = searchQuery.trim().lowercase()
            val searchRes = withContext(Dispatchers.Default) {
                val list = ArrayList<BlockedSite>(visibleLimit)
                var matchedCount = 0
                for (item in sites) {
                    if (item.domain.contains(q, ignoreCase = true)) {
                        matchedCount++
                        if (list.size < visibleLimit) {
                            list.add(item)
                        }
                        if (matchedCount >= 1000) break
                    }
                }
                Pair(list, matchedCount)
            }
            totalSiteMatches = searchRes.second
            displayedSites = searchRes.first
        }
    }

    // File Import Launcher for Sites (.txt) - Streamed asynchronously without UI lag
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        val reader = inputStream.bufferedReader(Charsets.UTF_8)
                        val lines = ArrayList<String>(50000)
                        reader.useLines { seq ->
                            for (line in seq) {
                                val trimmed = line.trim()
                                if (trimmed.isNotEmpty() && !trimmed.startsWith("#") && !trimmed.startsWith("//")) {
                                    lines.add(trimmed)
                                }
                            }
                        }
                        withContext(Dispatchers.Main) {
                            onImportLines(lines)
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        onShowFeedback("تعذر قراءة الملف: ${e.localizedMessage ?: "خطأ غير معروف"}")
                    }
                }
            }
        }
    }

    // File Export Launcher for Sites (.txt) - Streamed asynchronously with 64KB buffer
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                            for (item in sites) {
                                writer.write(item.domain)
                                writer.write('\n'.code)
                            }
                        }
                    }
                    withContext(Dispatchers.Main) {
                        onShowFeedback("تم تصدير ${sites.size} موقع بنجاح إلى ملف TXT.")
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        onShowFeedback("تعذر حفظ الملف: ${e.localizedMessage ?: "خطأ غير معروف"}")
                    }
                }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        GlassBentoCard {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .combinedClickable(
                        onClick = {},
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            showSiteHintDialog = true
                        }
                    )
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "إدارة المواقع المحظورة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape
                    ) {
                        Text(
                            text = if (searchQuery.isNotBlank()) "$totalSiteMatches / ${sites.size}" else "${sites.size}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputVal,
                    onValueChange = {
                        inputVal = it
                        if (isWordError) isWordError = false
                    },
                    placeholder = { Text("مثال: example.com", style = MaterialTheme.typography.bodyMedium) },
                    isError = isWordError,
                    modifier = Modifier
                        .weight(1f)
                        .offset { IntOffset(shakeOffsetX.value.roundToInt(), 0) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = {
                        if (inputVal.isNotEmpty()) {
                            IconButton(onClick = {
                                inputVal = ""
                                isWordError = false
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "مسح",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val trimmed = inputVal.trim()
                            if (trimmed.isNotBlank()) {
                                val cleaned = com.example.util.SaffahBlockRepository.cleanAndExtractDomain(trimmed)
                                if (cleaned == null) {
                                    triggerWordError()
                                } else {
                                    isWordError = false
                                    onAdd(cleaned)
                                    inputVal = ""
                                }
                            }
                        }
                    )
                )
                Spacer(modifier = Modifier.width(10.dp))
                IconButton(
                    onClick = {
                        val trimmed = inputVal.trim()
                        if (trimmed.isNotBlank()) {
                            val cleaned = com.example.util.SaffahBlockRepository.cleanAndExtractDomain(trimmed)
                            if (cleaned == null) {
                                triggerWordError()
                            } else {
                                isWordError = false
                                onAdd(cleaned)
                                inputVal = ""
                            }
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .saffahPressMotion()
                        .background(Color(0xFF2C3036), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إضافة الموقع",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            AnimatedVisibility(
                visible = isWordError,
                enter = fadeIn(tween(200)) + expandVertically(tween(200)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "مفردة وليست موقعاً مكتصلاً! أدخل نطاقاً كاملاً مثل (example.com).",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bento Actions Row: Import TXT & Export TXT (Soft Charcoal Text & Icons with subtle gray border)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        importLauncher.launch(arrayOf("text/plain", "*/*"))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .saffahPressMotion(),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "رفع ملف مواقع",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "رفع ملف TXT",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                OutlinedButton(
                    onClick = {
                        if (sites.isEmpty()) {
                            onShowFeedback("لا توجد مواقع محظورة مضافة لتصديرها.")
                        } else {
                            val defaultFileName = "saffah_blocked_sites_${System.currentTimeMillis()}.txt"
                            exportLauncher.launch(defaultFileName)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .saffahPressMotion(),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = "تصدير المواقع المحظورة",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تصدير TXT",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            val isTimeDelayActive = remember { com.example.util.SaffahBlockRepository.isTimeDelayActive(context) }
            OutlinedButton(
                onClick = onClearAllSites,
                modifier = Modifier
                    .fillMaxWidth()
                    .saffahPressMotion(),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(
                    1.dp,
                    if (isTimeDelayActive) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.45f)
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isTimeDelayActive) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = if (isTimeDelayActive) Icons.Default.Lock else Icons.Default.DeleteForever,
                    contentDescription = "تفريغ وحذف كل المواقع المحظورة دفعة واحدة",
                    tint = if (isTimeDelayActive) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "تفريغ وحذف كل المواقع المحظورة دفعة واحدة",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Search Bar for Large Lists
            if (sites.size > 15) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "بحث في المواقع (${sites.size})...",
                            style = MaterialTheme.typography.bodySmall
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "مسح البحث",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                )
            }
        }

        if (isImporting) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "جاري استيراد القائمة ومعالجتها في الخلفية بسرعة فائقة...",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (sites.isEmpty()) {
            GlassBentoCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "لا توجد مواقع محظورة مضافة حالياً",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "يمكنك كتابة نطاق موقع أو رفع ملف TXT جاهز يحتوي على قائمة مواقع",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else if (totalSiteMatches == 0) {
            GlassBentoCard {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد نتائج مطابقة لنطاق الموقع",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(displayedSites, key = { it.id }, contentType = { "site_item" }) { item ->
                    Box(
                        modifier = Modifier.animateItem(
                            fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                            fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                            placementSpec = androidx.compose.animation.core.spring(
                                stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                dampingRatio = 0.8f
                            )
                        )
                    ) {
                        GlassBentoCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    WebsiteFavicon(
                                        domain = item.domain,
                                        size = 38.dp,
                                        iconSize = 20.dp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = item.domain,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "تاريخ الإضافة: ${item.dateAdded}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { onDelete(item.id, item.domain) },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .saffahPressMotion()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف الموقع",
                                        tint = ErrorRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                if (totalSiteMatches > visibleLimit) {
                    item(key = "load_more_sites") {
                        TextButton(
                            onClick = { visibleLimit += 150 },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = "عرض المزيد (+150 من أصل $totalSiteMatches)",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSiteHintDialog) {
        Dialog(
            onDismissRequest = { showSiteHintDialog = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .widthIn(max = 380.dp)
                        .wrapContentHeight(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "إرشادات حظر المواقع والمتصفحات",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { showSiteHintDialog = false },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Text(
                            text = "• حظر النطاقات والمواقع:\nأدخل اسم النطاق فقط (مثل example.com). حظر النطاق الرئيسي يحظر تلقائياً كافة النطاقات الفرعية التابعة له (مثل m.example.com أو api.example.com).\n\n• تصفية الـ DNS والـ VPN المحلي:\nيتم اعتراض طلبات النطاق فورياً على مستوى الشبكة لمنع تحميل الصفحات والوسائط بالكامل دون استهلاك بيانات خارجية لكافة التطبيقات.\n\n• المتصفحات المدعومة للفحص الفوري:\nيدعم محرك الحظر مراقبة شريط العناوين والروابط وإغلاقها فورياً في:\n- Google Chrome (الرسمي، Beta، Dev، Canary، Chromium)\n- Quetta Browser (net.quetta.browser)\n- 1DM / 1DM+ (idm.internet.download.manager)\n- Samsung Internet\n- Microsoft Edge\n- Brave Browser\n- Opera (الرسمي، Touch، GX، Mini)\n- DuckDuckGo & Vivaldi\n- Tor Browser & Spin وتبويبات Custom Tabs.\n\n• استيراد وتصدير النطاقات:\nيمكنك استيراد وتصدير آلاف النطاقات والمواقع بملفات TXT جاهزة بضغطة زر واحدة.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 22.sp,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppBlockTab(
    viewModel: MainViewModel
) {
    val masterEnabled by viewModel.isAppScheduleMasterEnabled.collectAsState()
    val rules by viewModel.appScheduleRules.collectAsState()

    val isUsageMasterEnabled by viewModel.isUsageMasterEnabled.collectAsState()
    val usageRules by viewModel.usageRules.collectAsState()
    val permanentBlockedPackages by viewModel.permanentBlockedPackages.collectAsState()
    val uninstallBlockedPackages by viewModel.uninstallBlockedPackages.collectAsState()
    val permissionStatus by viewModel.permissionStatus.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current

    val installedApps by viewModel.installedApps.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.loadRealInstalledApps()
    }

    var activeRuleForEdit by remember { mutableStateOf<AppBlockScheduleRule?>(null) }
    var isEditingRule by remember { mutableStateOf(false) }

    var activeUsageRuleForEdit by remember { mutableStateOf<com.example.model.UsageBlockRule?>(null) }
    var isEditingUsageRule by remember { mutableStateOf(false) }
    var isSelectingPermanentApps by remember { mutableStateOf(false) }
    var newlyAddedPermanentApps by remember { mutableStateOf<Set<String>>(emptySet()) }
    var appToRemoveFromPermanent by remember { mutableStateOf<String?>(null) }
    var isSelectingUninstallBlockedApps by remember { mutableStateOf(false) }
    var appToRemoveFromUninstallBlocked by remember { mutableStateOf<String?>(null) }
    val haptic = LocalHapticFeedback.current

    val allSelectableApps = remember(installedApps) {
        installedApps.filter { app ->
            app.packageName != context.packageName &&
            !com.example.util.SaffahBlockRepository.isAlwaysExemptPackage(app.packageName) &&
            !com.example.util.SaffahBlockRepository.isSystemSettingsPackage(context, app.packageName) &&
            !com.example.util.SaffahBlockRepository.isSystemSettingsPackageName(app.packageName)
        }.sortedWith(
            compareBy<com.example.model.InstalledApp> { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
    }

    val permanentAppMap = remember(allSelectableApps) { allSelectableApps.associateBy { it.packageName } }
    val uninstallBlockedAppMap = remember(allSelectableApps) { allSelectableApps.associateBy { it.packageName } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- SECTION 1: USAGE-BASED BLOCKING (الحظر بناءً على الإستخدام) ---
        item(key = "app_block_usage_section") {
            GlassBentoCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = Color(0xFF7C3AED).copy(alpha = 0.12f),
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.HourglassTop,
                                        contentDescription = null,
                                        tint = Color(0xFF7C3AED),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                LightningTypewriterText(
                                    text = "الحظر بناءً على الإستخدام",
                                    triggerState = isUsageMasterEnabled,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.featureTitleHint("app_usage_blocking")
                                )
                                Text(
                                    text = "حظر تلقائي عند تجاوز الوقت أو عدد الفتح",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        val isUsageRestricted = remember(usageRules) { com.example.util.SaffahBlockRepository.isUsageRuleModificationRestricted(context) }
                        SaffahSwitch(
                            checked = isUsageMasterEnabled,
                            onCheckedChange = { newVal ->
                                if (!newVal && isUsageRestricted) {
                                    val activeRules = usageRules.filter { it.isEnabled }
                                    if (activeRules.isNotEmpty()) {
                                        android.widget.Toast.makeText(
                                            context,
                                            "يمنع تعطيل ميزة الحظر بالاستخدام عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00)",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                        return@SaffahSwitch
                                    }
                                }
                                viewModel.toggleUsageMasterEnabled(newVal)
                            },
                            colors = saffahSwitchColors(checkedTrackColor = Color(0xFF7C3AED))
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            activeUsageRuleForEdit = com.example.model.UsageBlockRule(
                                id = System.currentTimeMillis(),
                                name = "",
                                isEnabled = true,
                                activeDays = setOf(1, 2, 3, 4, 5, 6, 7),
                                limitType = com.example.model.UsageLimitType.DURATION,
                                limitValue = 30,
                                selectedPackages = emptySet()
                            )
                            isEditingUsageRule = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF7C3AED),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة عملية حظر بالاستخدام جديدة", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (usageRules.isEmpty()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HourglassDisabled,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "لا توجد عمليات حظر بالاستخدام",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "اضغط على زر + أعلاه لإنشاء حد استخدام يومي أو حد لعدد مرات فتح التطبيقات",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        ReorderableCardsList(
                            items = usageRules,
                            key = { it.id },
                            onReorder = { reordered ->
                                viewModel.reorderUsageRules(reordered)
                            },
                            activeColor = Color(0xFF7C3AED),
                            hintText = "اضغط مطولاً على أي بطاقة واسحبها لتغيير الترتيب"
                        ) { rule, isDragging ->
                            UsageBlockRuleCard(
                                rule = rule,
                                allApps = allSelectableApps,
                                onEdit = {
                                    val latestRule = viewModel.usageRules.value.find { it.id == rule.id }
                                        ?: com.example.util.SaffahBlockRepository.getUsageRules(context).find { it.id == rule.id }
                                        ?: rule
                                    activeUsageRuleForEdit = latestRule
                                    isEditingUsageRule = true
                                },
                                onDelete = { viewModel.deleteUsageRule(rule.id) },
                                isDragging = isDragging
                            )
                        }
                    }
                }
            }
        }

        // --- SECTION 2: SCHEDULED BLOCKING (عمليات الحظر الدورية) ---
        item(key = "app_block_schedule_section") {
            GlassBentoCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AccessTimeFilled,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                LightningTypewriterText(
                                    text = "عمليات الحظر الدورية",
                                    triggerState = masterEnabled,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.featureTitleHint("scheduled_app_blocking")
                                )
                                Text(
                                    text = "جداول الحظر الزمني والتطبيقات المحددة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        val context = androidx.compose.ui.platform.LocalContext.current
                        val isScheduleRestricted = remember(rules) { com.example.util.SaffahBlockRepository.isAppScheduleRuleModificationRestricted(context) }
                        SaffahSwitch(
                            checked = masterEnabled,
                            onCheckedChange = { newVal ->
                                if (!newVal && isScheduleRestricted) {
                                    val activeRules = rules.filter { it.isEnabled }
                                    if (activeRules.isNotEmpty()) {
                                        android.widget.Toast.makeText(
                                            context,
                                            "يمنع تعطيل ميزة الحظر الدوري عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00)",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                        return@SaffahSwitch
                                    }
                                }
                                viewModel.toggleAppScheduleMasterEnabled(newVal)
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            activeRuleForEdit = AppBlockScheduleRule(
                                id = System.currentTimeMillis(),
                                name = "",
                                isEnabled = false,
                                startHour = 9,
                                startMinute = 0,
                                endHour = 17,
                                endMinute = 0,
                                activeDays = setOf(1, 2, 3, 4, 5, 6, 7),
                                blockType = AppBlockType.BLOCK_SPECIFIED,
                                selectedPackages = emptySet()
                            )
                            isEditingRule = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة عملية حظر جديدة", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (rules.isEmpty()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TimerOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "لا توجد عمليات حظر دورية مضافة",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "اضغط على زر + أعلاه لإنشاء جدول حظر جديد للتطبيقات",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        ReorderableCardsList(
                            items = rules,
                            key = { it.id },
                            onReorder = { reordered ->
                                viewModel.reorderAppScheduleRules(reordered)
                            },
                            activeColor = MaterialTheme.colorScheme.primary,
                            hintText = "اضغط مطولاً على أي بطاقة واسحبها لتغيير الترتيب"
                        ) { rule, isDragging ->
                            ScheduledBlockRuleCard(
                                rule = rule,
                                allApps = allSelectableApps,
                                onEdit = {
                                    val latestRule = viewModel.appScheduleRules.value.find { it.id == rule.id }
                                        ?: com.example.util.SaffahBlockRepository.getAppScheduleRules(context).find { it.id == rule.id }
                                        ?: rule
                                    activeRuleForEdit = latestRule
                                    isEditingRule = true
                                },
                                onDelete = { viewModel.deleteAppScheduleRule(rule.id) },
                                isDragging = isDragging
                            )
                        }
                    }
                }
            }
        }

        // --- SECTION 3: PERMANENT BLOCKING (الحظر المؤبد) ---
        item(key = "app_block_permanent_section") {
            GlassBentoCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = ErrorRed.copy(alpha = 0.12f),
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = ErrorRed,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "الحظر المؤبد",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "تعليق نهائي ودائم بدون جدول زمني",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (permanentBlockedPackages.isNotEmpty()) ErrorRed.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "${permanentBlockedPackages.size} تطبيق",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (permanentBlockedPackages.isNotEmpty()) ErrorRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { isSelectingPermanentApps = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .saffahPressMotion(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ErrorRed,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة تطبيقات للحظر المؤبد", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (permanentBlockedPackages.isEmpty()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "لا توجد تطبيقات في قائمة الحظر المؤبد",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "اضغط على زر + أعلاه لاختيار التطبيقات لتعليقها نهائياً",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 2.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TouchApp,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "اضغط باستمرار على أي تطبيق لحذفه من الحظر",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                            ) {
                                items(permanentBlockedPackages.toList(), key = { it }) { pkg ->
                                    val app = permanentAppMap[pkg]
                                    val iconPainter = rememberFastDrawablePainter(app?.iconDrawable)
                                    val appTitle = app?.appName ?: pkg

                                    val isJustAdded = pkg in newlyAddedPermanentApps
                                    val popScale = remember { androidx.compose.animation.core.Animatable(if (isJustAdded) 0.35f else 1f) }
                                    val glowAlpha = remember { androidx.compose.animation.core.Animatable(if (isJustAdded) 0.85f else 0f) }

                                    LaunchedEffect(pkg, isJustAdded) {
                                        if (isJustAdded) {
                                            popScale.animateTo(
                                                targetValue = 1f,
                                                animationSpec = androidx.compose.animation.core.spring(
                                                    stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                                    dampingRatio = 0.65f
                                                )
                                            )
                                            glowAlpha.animateTo(
                                                targetValue = 0f,
                                                animationSpec = androidx.compose.animation.core.tween(900)
                                            )
                                        }
                                    }

                                    Box(
                                        modifier = Modifier.animateItem(
                                            fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                                            fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                                            placementSpec = androidx.compose.animation.core.spring(
                                                stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                                dampingRatio = 0.8f
                                            )
                                        )
                                    ) {
                                        Surface(
                                            modifier = Modifier
                                                .width(90.dp)
                                                .scale(popScale.value)
                                                .saffahPressMotion()
                                                .clip(RoundedCornerShape(14.dp))
                                                .combinedClickable(
                                                    onClick = {
                                                        android.widget.Toast.makeText(
                                                            context,
                                                            "اضغط مطولاً لإزالة $appTitle من الحظر المؤبد",
                                                            android.widget.Toast.LENGTH_SHORT
                                                        ).show()
                                                    },
                                                    onLongClick = {
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                                                            viewModel.showFeedback("لا يمكن إزالة التطبيقات من الحظر المؤبد أثناء سريان ميزة التأخير الزمني.")
                                                        } else {
                                                            appToRemoveFromPermanent = pkg
                                                        }
                                                    }
                                                ),
                                            shape = RoundedCornerShape(14.dp),
                                            color = MaterialTheme.colorScheme.surface,
                                            border = if (glowAlpha.value > 0.02f) {
                                                BorderStroke(2.dp, Color(0xFF0166FF).copy(alpha = glowAlpha.value))
                                            } else {
                                                BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                            },
                                            shadowElevation = 1.dp
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 6.dp, vertical = 10.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Box(contentAlignment = Alignment.BottomEnd) {
                                                    Surface(
                                                        modifier = Modifier.size(46.dp),
                                                        shape = RoundedCornerShape(12.dp),
                                                        color = MaterialTheme.colorScheme.surfaceVariant
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            if (iconPainter != null) {
                                                                Image(
                                                                    painter = iconPainter,
                                                                    contentDescription = appTitle,
                                                                    modifier = Modifier.size(34.dp),
                                                                    colorFilter = GrayscaleFilter
                                                                )
                                                            } else {
                                                                Icon(
                                                                    imageVector = Icons.Default.Apps,
                                                                    contentDescription = null,
                                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                                    modifier = Modifier.size(24.dp)
                                                                )
                                                            }
                                                        }
                                                    }

                                                    Surface(
                                                        shape = CircleShape,
                                                        color = ErrorRed,
                                                        modifier = Modifier
                                                            .size(16.dp)
                                                            .offset(x = 2.dp, y = 2.dp)
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            Icon(
                                                                imageVector = Icons.Default.Lock,
                                                                contentDescription = null,
                                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                                modifier = Modifier.size(10.dp)
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                Text(
                                                    text = appTitle,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.Center
                                                )

                                                Spacer(modifier = Modifier.height(2.dp))

                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = ErrorRed.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = "معلق",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = ErrorRed,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- SECTION 4: PREVENT UNINSTALLING APPS (منع حذف التطبيقات - Device Owner) ---
        item(key = "app_block_uninstall_prevention_section") {
            GlassBentoCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Security,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "منع حذف التطبيقات",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "حظر إلغاء التثبيت عبر صلاحية مشرف الجهاز",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (uninstallBlockedPackages.isNotEmpty()) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "${uninstallBlockedPackages.size} تطبيق",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (uninstallBlockedPackages.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (!permissionStatus.isDeviceOwnerActive) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "تتطلب هذه الميزة تفعيل صلاحية مشرف الجهاز (Device Owner) لفرض منع إلغاء التثبيت من النظام.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { isSelectingUninstallBlockedApps = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة تطبيقات لمنع حذفها", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (uninstallBlockedPackages.isEmpty()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "لا توجد تطبيقات في قائمة منع الحذف",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "اضغط على زر + أعلاه لاختيار التطبيقات لمنع إلغاء تثبيتها من الجهاز",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 2.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TouchApp,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "اضغط باستمرار على أي تطبيق لإزالته والسماح بإلغاء تثبيته",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                            ) {
                                items(uninstallBlockedPackages.toList(), key = { "uninstall_blocked_$it" }) { pkg ->
                                    val app = uninstallBlockedAppMap[pkg]
                                    val iconPainter = rememberFastDrawablePainter(app?.iconDrawable)
                                    val appTitle = app?.appName ?: pkg

                                    Surface(
                                        modifier = Modifier
                                            .width(90.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .combinedClickable(
                                                onClick = {
                                                    android.widget.Toast.makeText(
                                                        context,
                                                        "اضغط مطولاً لإزالة $appTitle والسماح بإلغاء تثبيته",
                                                        android.widget.Toast.LENGTH_SHORT
                                                    ).show()
                                                },
                                                onLongClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                                                        viewModel.showFeedback("لا يمكن إزالة التطبيقات من قائمة منع الحذف أثناء سريان ميزة التأخير الزمني.")
                                                    } else {
                                                        appToRemoveFromUninstallBlocked = pkg
                                                    }
                                                }
                                            ),
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                        shadowElevation = 1.dp
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 6.dp, vertical = 10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Box(contentAlignment = Alignment.BottomEnd) {
                                                Surface(
                                                    modifier = Modifier.size(46.dp),
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        if (iconPainter != null) {
                                                            Image(
                                                                painter = iconPainter,
                                                                contentDescription = appTitle,
                                                                modifier = Modifier.size(34.dp)
                                                            )
                                                        } else {
                                                            Icon(
                                                                imageVector = Icons.Default.Apps,
                                                                contentDescription = null,
                                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                                modifier = Modifier.size(24.dp)
                                                            )
                                                        }
                                                    }
                                                }

                                                Surface(
                                                    shape = CircleShape,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier
                                                        .size(16.dp)
                                                        .offset(x = 2.dp, y = 2.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Icon(
                                                            imageVector = Icons.Default.Security,
                                                            contentDescription = null,
                                                            tint = Color.White,
                                                            modifier = Modifier.size(10.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))

                                            Text(
                                                text = appTitle,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                textAlign = TextAlign.Center
                                            )

                                            Spacer(modifier = Modifier.height(2.dp))

                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                            ) {
                                                Text(
                                                    text = "محمي",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- SECTION 5: EXCLUDE APPS FROM BLOCKED KEYWORDS (استثناء التطبيقات من الكلمات المحظورة) ---
        item(key = "app_block_keyword_exemption_section") {
            val keywordExemptedApps by viewModel.keywordExemptedApps.collectAsState()
            var showKeywordExemptionAppsDialog by remember { mutableStateOf(false) }

            if (showKeywordExemptionAppsDialog) {
                KeywordExemptionAppsDialog(
                    viewModel = viewModel,
                    onDismiss = { showKeywordExemptionAppsDialog = false }
                )
            }

            GlassBentoCard {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            shape = CircleShape,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Outlined.FilterAltOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "إستثناء التطبيقات من الكلمات المحظورة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .weight(1f)
                                .featureTitleHint("keyword_exemption")
                        )
                    }

                    val keywordExemptedAppIcons = remember(installedApps, keywordExemptedApps) {
                        keywordExemptedApps.map { pkg ->
                            pkg to (installedApps.find { it.packageName == pkg }?.iconDrawable
                                ?: com.example.util.AppListHelper.resolveIconFast(context, pkg))
                        }
                    }

                    ExcludedAppsBox(
                        title = if (keywordExemptedApps.isEmpty()) "تحديد التطبيقات المستثناة" else "تحديد التطبيقات المستثناة (${keywordExemptedApps.size} تطبيقات)",
                        apps = keywordExemptedAppIcons,
                        onClick = { showKeywordExemptionAppsDialog = true },
                        onLongClickItem = { pkg -> viewModel.removeKeywordExemptedApp(pkg) }
                    )
                }
            }
        }
    }

    if (isEditingRule && activeRuleForEdit != null) {
        androidx.compose.runtime.key(activeRuleForEdit!!.id) {
            EditAppBlockRuleDialog(
                initialRule = activeRuleForEdit!!,
                allApps = allSelectableApps,
                onDismiss = {
                    isEditingRule = false
                    activeRuleForEdit = null
                },
                onSave = { updatedRule ->
                    viewModel.upsertAppScheduleRule(updatedRule)
                    isEditingRule = false
                    activeRuleForEdit = null
                },
                onDelete = { ruleId ->
                    viewModel.deleteAppScheduleRule(ruleId)
                    isEditingRule = false
                    activeRuleForEdit = null
                }
            )
        }
    }

    if (isEditingUsageRule && activeUsageRuleForEdit != null) {
        androidx.compose.runtime.key(activeUsageRuleForEdit!!.id) {
            EditUsageBlockRuleDialog(
                initialRule = activeUsageRuleForEdit!!,
                allApps = allSelectableApps,
                onDismiss = {
                    isEditingUsageRule = false
                    activeUsageRuleForEdit = null
                },
                onSave = { updatedRule ->
                    viewModel.upsertUsageRule(updatedRule)
                    isEditingUsageRule = false
                    activeUsageRuleForEdit = null
                },
                onDelete = { ruleId ->
                    viewModel.deleteUsageRule(ruleId)
                    isEditingUsageRule = false
                    activeUsageRuleForEdit = null
                }
            )
        }
    }

    if (isSelectingPermanentApps) {
        AppSelectionSubDialog(
            allApps = allSelectableApps,
            currentlySelected = permanentBlockedPackages,
            onDismiss = { isSelectingPermanentApps = false },
            onConfirm = { selected ->
                val newlyAdded = selected - permanentBlockedPackages
                newlyAddedPermanentApps = newlyAdded
                viewModel.setPermanentBlockedPackages(selected)
                isSelectingPermanentApps = false
            }
        )
    }

    if (appToRemoveFromPermanent != null) {
        val appPkg = appToRemoveFromPermanent!!
        val appObj = permanentAppMap[appPkg]
        val appName = appObj?.appName ?: appPkg
        val isDelayActive = com.example.util.SaffahBlockRepository.isTimeDelayActive(context)

        Dialog(
            onDismissRequest = { appToRemoveFromPermanent = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .widthIn(max = 400.dp)
                        .wrapContentHeight(),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isDelayActive) "ميزة التأخير الزمني نشطة" else "إلغاء الحظر المؤبد",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = appName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = if (isDelayActive) {
                                "لا يمكن إزالة التطبيق من الحظر المؤبد حالياً بسبب سريان ميزة التأخير الزمني لحماية الإعدادات."
                            } else {
                                "هل أنت متأكد من رغبتك في إزالة هذا التطبيق من قائمة الحظر المؤبد؟"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        if (!isDelayActive) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { appToRemoveFromPermanent = null },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.8f))
                                ) {
                                    Text(
                                        text = "إلغاء",
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Button(
                                    onClick = {
                                        viewModel.removePermanentBlockedPackage(appPkg)
                                        appToRemoveFromPermanent = null
                                    },
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(46.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "إزالة من الحظر",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        } else {
                            Button(
                                onClick = { appToRemoveFromPermanent = null },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "حسناً",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (isSelectingUninstallBlockedApps) {
        AppSelectionSubDialog(
            allApps = allSelectableApps,
            currentlySelected = uninstallBlockedPackages,
            onDismiss = { isSelectingUninstallBlockedApps = false },
            onConfirm = { selected ->
                viewModel.setUninstallBlockedPackages(selected)
                isSelectingUninstallBlockedApps = false
            }
        )
    }

    if (appToRemoveFromUninstallBlocked != null) {
        val appPkg = appToRemoveFromUninstallBlocked!!
        val appObj = uninstallBlockedAppMap[appPkg]
        val appName = appObj?.appName ?: appPkg
        val isDelayActive = com.example.util.SaffahBlockRepository.isTimeDelayActive(context)

        Dialog(
            onDismissRequest = { appToRemoveFromUninstallBlocked = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .widthIn(max = 400.dp)
                        .wrapContentHeight(),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "السماح بإلغاء تثبيت التطبيق؟",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isDelayActive) {
                                "لا يمكن إزالة \"$appName\" من قائمة منع الحذف أثناء سريان ميزة التأخير الزمني."
                            } else {
                                "سيتم إزالة \"$appName\" من قائمة منع الحذف وسيكون بإمكانك إلغاء تثبيته من النظام بشكل طبيعي."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        if (!isDelayActive) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { appToRemoveFromUninstallBlocked = null },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.8f))
                                ) {
                                    Text(
                                        text = "إلغاء",
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Button(
                                    onClick = {
                                        viewModel.removeUninstallBlockedPackage(appPkg)
                                        appToRemoveFromUninstallBlocked = null
                                    },
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(46.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "إزالة والسماح",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        } else {
                            Button(
                                onClick = { appToRemoveFromUninstallBlocked = null },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "حسناً",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private val GrayscaleFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })

@Composable
private fun ScheduledBlockRuleCard(
    rule: AppBlockScheduleRule,
    allApps: List<com.example.model.InstalledApp>,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    isDragging: Boolean = false
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isRestricted = remember { com.example.util.SaffahBlockRepository.isAppScheduleRuleModificationRestricted(context) }
    val appMap = remember(allApps) { allApps.associateBy { it.packageName } }
    val daysList = listOf(
        java.util.Calendar.SATURDAY to "س",
        java.util.Calendar.SUNDAY to "ح",
        java.util.Calendar.MONDAY to "ن",
        java.util.Calendar.TUESDAY to "ث",
        java.util.Calendar.WEDNESDAY to "ع",
        java.util.Calendar.THURSDAY to "خ",
        java.util.Calendar.FRIDAY to "ج"
    )

    val isEnabled = rule.isEnabled

    val cardBg = when {
        isDragging -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)
        isEnabled -> MaterialTheme.colorScheme.surface
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    }
    val cardBorder = when {
        isDragging -> MaterialTheme.colorScheme.primary
        isEnabled -> MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }
    val titleColor = if (isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
    val timeColor = if (isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    val editIconTint = if (isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    val deleteIconTint = if (isRestricted) MaterialTheme.colorScheme.onSurfaceVariant else if (isEnabled) ErrorRed else MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = androidx.compose.foundation.BorderStroke(if (isDragging) 1.5.dp else 1.dp, cardBorder),
        shadowElevation = if (isDragging) 8.dp else if (isEnabled) 1.dp else 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (rule.name.isNotBlank()) rule.name else "عملية حظر دورية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = titleColor
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    val effectiveRanges = rule.getEffectiveTimeRanges()
                    val rangesText = effectiveRanges.joinToString(" • ") {
                        "${formatTime24H(it.startHour, it.startMinute)} - ${formatTime24H(it.endHour, it.endMinute)}"
                    }
                    Text(
                        text = rangesText,
                        style = MaterialTheme.typography.labelMedium,
                        color = timeColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.saffahPressMotion()
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = editIconTint)
                    }
                    IconButton(
                        onClick = {
                            if (isRestricted) {
                                android.widget.Toast.makeText(
                                    context,
                                    "يمنع حذف عمليات الحظر الدورية عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00)",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            } else {
                                onDelete()
                            }
                        },
                        modifier = Modifier.saffahPressMotion()
                    ) {
                        Icon(
                            imageVector = if (isRestricted) Icons.Default.Lock else Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = deleteIconTint
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                daysList.forEach { (dayId, dayLetter) ->
                    val isActive = rule.activeDays.contains(dayId)

                    val circleBg = when {
                        !isEnabled && isActive -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                        !isEnabled -> MaterialTheme.colorScheme.surfaceVariant
                        isActive -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }

                    val circleTextColor = when {
                        isActive -> MaterialTheme.colorScheme.onPrimary
                        !isEnabled -> MaterialTheme.colorScheme.onSurfaceVariant
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }

                    Surface(
                        color = circleBg,
                        shape = CircleShape,
                        border = if (!isActive && isEnabled) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = dayLetter,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                color = circleTextColor,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val isBlockSpecified = rule.blockType == AppBlockType.BLOCK_SPECIFIED
            val count = rule.selectedPackages.size

            val bannerBg = when {
                !isEnabled -> MaterialTheme.colorScheme.surfaceVariant
                isBlockSpecified -> ErrorRed.copy(alpha = 0.12f)
                else -> MaterialTheme.colorScheme.primaryContainer
            }

            val bannerTextColor = when {
                !isEnabled -> MaterialTheme.colorScheme.onSurfaceVariant
                isBlockSpecified -> ErrorRed
                else -> MaterialTheme.colorScheme.primary
            }

            Surface(
                color = bannerBg,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isBlockSpecified) "حظر التطبيقات المحددة ($count)" else "السماح بالمحددة وحظر الباقي ($count)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = bannerTextColor
                    )
                    Icon(
                        imageVector = if (isBlockSpecified) Icons.Default.Block else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = bannerTextColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            if (rule.selectedPackages.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(rule.selectedPackages.toList(), key = { it }) { pkg ->
                        val app = appMap[pkg]
                        val iconPainter = rememberFastDrawablePainter(app?.iconDrawable)
                        Surface(
                            shape = CircleShape,
                            color = if (isEnabled) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isEnabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (iconPainter != null) {
                                    Image(
                                        painter = iconPainter,
                                        contentDescription = app?.appName,
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape),
                                        colorFilter = if (!isEnabled) GrayscaleFilter else null
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Android,
                                        contentDescription = null,
                                        tint = if (isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditAppBlockRuleDialog(
    initialRule: AppBlockScheduleRule,
    allApps: List<com.example.model.InstalledApp>,
    onDismiss: () -> Unit,
    onSave: (AppBlockScheduleRule) -> Unit,
    onDelete: (Long) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isRestricted = remember { com.example.util.SaffahBlockRepository.isAppScheduleRuleModificationRestricted(context) }
    val isSavedRule = remember { com.example.util.SaffahBlockRepository.getAppScheduleRules(context).any { it.id == initialRule.id } }
    val isTighteningOnly = isSavedRule && isRestricted
    val initialSpanMinutes = remember {
        initialRule.getEffectiveTimeRanges().sumOf {
            com.example.util.SaffahBlockRepository.calculateScheduleSpanMinutes(
                it.startHour,
                it.startMinute,
                it.endHour,
                it.endMinute
            )
        }
    }

    var name by remember(initialRule.id) { mutableStateOf(initialRule.name) }
    var isEnabled by remember(initialRule.id) { mutableStateOf(initialRule.isEnabled) }
    var timeRanges by remember(initialRule.id) { mutableStateOf(initialRule.getEffectiveTimeRanges()) }
    var editingRangeIndex by remember(initialRule.id) { mutableStateOf<Int?>(null) }
    var editingIsStartTime by remember(initialRule.id) { mutableStateOf(true) }
    var showTimePickerDialog by remember(initialRule.id) { mutableStateOf(false) }
    var activeDays by remember(initialRule.id) { mutableStateOf(initialRule.activeDays) }
    var blockType by remember(initialRule.id) { mutableStateOf(initialRule.blockType) }
    var selectedPackages by remember(initialRule.id) { mutableStateOf(initialRule.selectedPackages) }

    var showAppPicker by remember { mutableStateOf(false) }

    val daysMap = listOf(
        java.util.Calendar.SATURDAY to "س",
        java.util.Calendar.SUNDAY to "أ",
        java.util.Calendar.MONDAY to "ن",
        java.util.Calendar.TUESDAY to "ث",
        java.util.Calendar.WEDNESDAY to "ع",
        java.util.Calendar.THURSDAY to "خ",
        java.util.Calendar.FRIDAY to "ج"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        SaffahSwitch(
                            checked = isEnabled,
                            onCheckedChange = { newVal ->
                                if (isTighteningOnly && initialRule.isEnabled && !newVal) {
                                    android.widget.Toast.makeText(
                                        context,
                                        "يمنع تعطيل عملية الحظر الدورية خارج فترة السماح اليومية (06:00 - 07:00)",
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    isEnabled = newVal
                                }
                            }
                        )
                        Text(
                            text = if (initialRule.name.isEmpty()) "عملية حظر جديدة" else "تعديل عملية الحظر",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isSavedRule) {
                            IconButton(onClick = {
                                if (isRestricted) {
                                    android.widget.Toast.makeText(
                                        context,
                                        "يمنع حذف عمليات الحظر الدورية عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00)",
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    onDelete(initialRule.id)
                                }
                            }) {
                                Icon(
                                    imageVector = if (isRestricted) Icons.Default.Lock else Icons.Default.Delete,
                                    contentDescription = "حذف",
                                    tint = if (isRestricted) MaterialTheme.colorScheme.onSurfaceVariant else ErrorRed
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (isTighteningOnly) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "وضع التشديد الصارم: خارج فترة السماح (06:00 - 07:00)، يُسمح فقط بتمديد نطاق الحظر، إضافة تطبيقات محظورة، تقليل التطبيقات المسموحة، أو إضافة أيام جديدة.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("اسم عملية الحظر") },
                        placeholder = { Text("مثال: حظر وسائل التواصل أثناء الدراسة") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val totalSpan = timeRanges.sumOf {
                        com.example.util.SaffahBlockRepository.calculateScheduleSpanMinutes(it.startHour, it.startMinute, it.endHour, it.endMinute)
                    }
                    val totalHours = totalSpan / 60
                    val totalMins = totalSpan % 60
                    val totalSpanText = if (totalHours > 0 && totalMins > 0) "$totalHours س و $totalMins د" else if (totalHours > 0) "$totalHours ساعة" else "$totalMins دقيقة"

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "النطاقات الزمنية (${timeRanges.size})",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "إجمالي المدة: $totalSpanText",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        timeRanges.forEachIndexed { index, range ->
                            val rangeSpan = com.example.util.SaffahBlockRepository.calculateScheduleSpanMinutes(
                                range.startHour, range.startMinute, range.endHour, range.endMinute
                            )
                            val rHours = rangeSpan / 60
                            val rMins = rangeSpan % 60
                            val rSpanText = if (rHours > 0 && rMins > 0) "$rHours س $rMins د" else if (rHours > 0) "$rHours س" else "$rMins د"

                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                            modifier = Modifier.size(22.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${index + 1}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }

                                        // Start time chip
                                        Surface(
                                            modifier = Modifier.clickable {
                                                editingRangeIndex = index
                                                editingIsStartTime = true
                                                showTimePickerDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(
                                                    "من",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontSize = 11.sp
                                                )
                                                Text(
                                                    formatTime24H(range.startHour, range.startMinute),
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }

                                        Text(
                                            "—",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                            fontWeight = FontWeight.Bold
                                        )

                                        // End time chip
                                        Surface(
                                            modifier = Modifier.clickable {
                                                editingRangeIndex = index
                                                editingIsStartTime = false
                                                showTimePickerDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(
                                                    "إلى",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontSize = 11.sp
                                                )
                                                Text(
                                                    formatTime24H(range.endHour, range.endMinute),
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = rSpanText,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.sp,
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 3.dp),
                                                maxLines = 1
                                            )
                                        }
                                    }

                                    if (timeRanges.size > 1) {
                                        IconButton(
                                            onClick = {
                                                val newRanges = timeRanges.toMutableList().apply { removeAt(index) }
                                                val newTotalSpan = newRanges.sumOf {
                                                    com.example.util.SaffahBlockRepository.calculateScheduleSpanMinutes(
                                                        it.startHour, it.startMinute, it.endHour, it.endMinute
                                                    )
                                                }
                                                if (isTighteningOnly && newTotalSpan < initialSpanMinutes) {
                                                    android.widget.Toast.makeText(
                                                        context,
                                                        "يمنع حذف النطاق إذا قلل إجمالي المدة خارج فترة السماح (06:00 - 07:00)",
                                                        android.widget.Toast.LENGTH_LONG
                                                    ).show()
                                                } else {
                                                    timeRanges = newRanges
                                                }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "حذف النطاق",
                                                tint = if (isTighteningOnly) MaterialTheme.colorScheme.onSurfaceVariant else ErrorRed,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedButton(
                        onClick = {
                            timeRanges = timeRanges + com.example.model.ScheduleTimeRange(startHour = 9, startMinute = 0, endHour = 17, endMinute = 0)
                        },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "إضافة نطاق زمني جديد",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "أيام الأسبوع السارية",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        daysMap.forEach { (dayId, dayLabel) ->
                            val selected = activeDays.contains(dayId)
                            val wasInitiallyActive = initialRule.activeDays.contains(dayId)
                            val isDayLocked = isTighteningOnly && wasInitiallyActive

                            SaffahDaySelectionChip(
                                dayLabel = dayLabel,
                                isSelected = selected,
                                onClick = {
                                    if (selected) {
                                        if (isDayLocked) {
                                            android.widget.Toast.makeText(
                                                context,
                                                "يمنع استثناء أو إزالة أيام التفعيل المحفوظة مسبقاً خارج فترة السماح (06:00 - 07:00)",
                                                android.widget.Toast.LENGTH_SHORT
                                            ).show()
                                        } else if (activeDays.size > 1) {
                                            activeDays = activeDays - dayId
                                        }
                                    } else {
                                        activeDays = activeDays + dayId
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "نوع الحظر (حدد نوعاً واحداً فقط)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val onSelectBlockSpecified = {
                        if (isTighteningOnly && initialRule.blockType != AppBlockType.BLOCK_SPECIFIED) {
                            android.widget.Toast.makeText(
                                context,
                                "يمنع تغيير نوع الحظر لعملية حظر دورية محفوظة خارج فترة السماح (06:00 - 07:00)",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            blockType = AppBlockType.BLOCK_SPECIFIED
                        }
                    }

                    val onSelectAllowSpecified = {
                        if (isTighteningOnly && initialRule.blockType != AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS) {
                            android.widget.Toast.makeText(
                                context,
                                "يمنع تغيير نوع الحظر لعملية حظر دورية محفوظة خارج فترة السماح (06:00 - 07:00)",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            blockType = AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS
                        }
                    }

                    Surface(
                        onClick = onSelectBlockSpecified,
                        shape = RoundedCornerShape(14.dp),
                        color = if (blockType == AppBlockType.BLOCK_SPECIFIED) ErrorRed.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (blockType == AppBlockType.BLOCK_SPECIFIED) ErrorRed else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = blockType == AppBlockType.BLOCK_SPECIFIED,
                                onClick = onSelectBlockSpecified,
                                colors = RadioButtonDefaults.colors(selectedColor = ErrorRed)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "حظر استخدام التطبيقات المحددة",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "منع فتح التطبيقات المحددة فقط خلال هذا الوقت",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = {
                                onSelectBlockSpecified()
                                showAppPicker = true
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "اختيار تطبيقات",
                                    tint = if (blockType == AppBlockType.BLOCK_SPECIFIED) ErrorRed else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        onClick = onSelectAllowSpecified,
                        shape = RoundedCornerShape(14.dp),
                        color = if (blockType == AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (blockType == AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = blockType == AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS,
                                onClick = onSelectAllowSpecified,
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "السماح بالمحددة وحظر الباقي",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "السماح بالتطبيقات المختارة ومنع كافة التطبيقات الأخرى",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = {
                                onSelectAllowSpecified()
                                showAppPicker = true
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "اختيار تطبيقات مسموحة",
                                    tint = if (blockType == AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showAppPicker = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "التطبيقات المختارة (${selectedPackages.size})",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val firstRange = timeRanges.firstOrNull() ?: com.example.model.ScheduleTimeRange()
                        val finalRule = initialRule.copy(
                            name = if (name.isBlank()) "عملية حظر دورية" else name,
                            isEnabled = isEnabled,
                            timeRanges = timeRanges,
                            startHour = firstRange.startHour,
                            startMinute = firstRange.startMinute,
                            endHour = firstRange.endHour,
                            endMinute = firstRange.endMinute,
                            activeDays = activeDays,
                            blockType = blockType,
                            selectedPackages = selectedPackages
                        )
                        val validationError = com.example.util.SaffahBlockRepository.validateAppScheduleRuleModification(context, finalRule)
                        if (validationError != null) {
                            android.widget.Toast.makeText(context, validationError, android.widget.Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        onSave(finalRule)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .saffahPressMotion(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حفظ عملية الحظر", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

    if (showTimePickerDialog && editingRangeIndex != null) {
        val currentIdx = editingRangeIndex!!
        val currentRange = timeRanges.getOrElse(currentIdx) { com.example.model.ScheduleTimeRange() }
        val initH = if (editingIsStartTime) currentRange.startHour else currentRange.endHour
        val initM = if (editingIsStartTime) currentRange.startMinute else currentRange.endMinute

        SimpleTimePickerDialog(
            initialHour = initH,
            initialMinute = initM,
            onDismiss = {
                showTimePickerDialog = false
                editingRangeIndex = null
            },
            onConfirm = { h, m ->
                val newRange = if (editingIsStartTime) {
                    currentRange.copy(startHour = h, startMinute = m)
                } else {
                    currentRange.copy(endHour = h, endMinute = m)
                }
                val newRanges = timeRanges.toMutableList().apply {
                    if (currentIdx in indices) set(currentIdx, newRange)
                }
                val newTotalSpan = newRanges.sumOf {
                    com.example.util.SaffahBlockRepository.calculateScheduleSpanMinutes(
                        it.startHour, it.startMinute, it.endHour, it.endMinute
                    )
                }
                if (isTighteningOnly && newTotalSpan < initialSpanMinutes) {
                    val prevHours = initialSpanMinutes / 60
                    val prevMins = initialSpanMinutes % 60
                    val durText = if (prevHours > 0 && prevMins > 0) "$prevHours س و $prevMins د" else if (prevHours > 0) "$prevHours ساعة" else "$prevMins دقيقة"
                    android.widget.Toast.makeText(
                        context,
                        "يمنع تقليص إجمالي نطاق وقت الحظر الدوري عن المدة السابقة ($durText). يسمح فقط بتمديد نطاق الحظر لتشديده.",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                } else {
                    timeRanges = newRanges
                    showTimePickerDialog = false
                    editingRangeIndex = null
                }
            }
        )
    }

    if (showAppPicker) {
        val isBlockSpecified = blockType == AppBlockType.BLOCK_SPECIFIED
        val lockedPkgs = if (isTighteningOnly && isBlockSpecified) initialRule.selectedPackages else emptySet()
        val disallowNew = isTighteningOnly && !isBlockSpecified

        AppSelectionSubDialog(
            allApps = allApps,
            currentlySelected = selectedPackages,
            lockedPackages = lockedPkgs,
            disallowAddingNew = disallowNew,
            lockMessage = "يمنع إزالة التطبيقات المحظورة خارج فترة السماح اليومية (06:00 - 07:00)",
            disallowAddingMessage = "يمنع إضافة تطبيقات مسموحة جديدة خارج فترة السماح (06:00 - 07:00). يسمح فقط بإزالة تطبيقات مسموحة لتشديد الحظر.",
            onDismiss = { showAppPicker = false },
            onConfirm = { newSelected ->
                selectedPackages = newSelected
                showAppPicker = false
            }
        )
    }
}

@Composable
private fun AppSelectionSubDialog(
    allApps: List<com.example.model.InstalledApp>,
    currentlySelected: Set<String>,
    lockedPackages: Set<String> = emptySet(),
    disallowAddingNew: Boolean = false,
    lockMessage: String? = null,
    disallowAddingMessage: String? = null,
    onDismiss: () -> Unit,
    onConfirm: (Set<String>) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isTimeDelayActive = remember { com.example.util.SaffahBlockRepository.isTimeDelayActive(context) }
    var searchQuery by remember { mutableStateOf("") }
    var filterCategory by remember { mutableStateOf("ALL") }
    var tempSelected by remember { mutableStateOf(currentlySelected + lockedPackages) }

    val completeAppList = remember(allApps, tempSelected) {
        val existingPkgSet = allApps.map { it.packageName }.toSet()
        val missingPkgs = tempSelected.filter { !existingPkgSet.contains(it) }
        if (missingPkgs.isEmpty()) {
            allApps
        } else {
            val synthesized = missingPkgs.map { pkg ->
                val label = com.example.util.AppListHelper.resolveAppLabelFast(context, pkg)
                val icon = com.example.util.AppListHelper.resolveIconFast(context, pkg)
                com.example.model.InstalledApp(
                    packageName = pkg,
                    appName = label,
                    isExcludedFromVpn = false,
                    isBlocked = false,
                    isSystemApp = false,
                    iconDrawable = icon
                )
            }
            allApps + synthesized
        }
    }

    val filtered = remember(searchQuery, filterCategory, completeAppList, tempSelected) {
        val baseList = completeAppList.filter { app ->
            val matchesSearch = searchQuery.isBlank() ||
                    app.appName.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)
            val matchesCategory = when (filterCategory) {
                "USER" -> !app.isSystemApp
                "SYSTEM" -> app.isSystemApp
                "SELECTED" -> tempSelected.contains(app.packageName)
                else -> true
            }
            matchesSearch && matchesCategory
        }
        baseList.sortedWith(
            compareByDescending<com.example.model.InstalledApp> { tempSelected.contains(it.packageName) }
                .thenBy { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
    }

    val confirmAndDismiss = {
        val finalConfirmed = if (lockedPackages.isNotEmpty()) tempSelected + lockedPackages else tempSelected
        onConfirm(finalConfirmed)
    }

    Dialog(
        onDismissRequest = confirmAndDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Header: Title and Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "اختيار التطبيقات (${tempSelected.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(
                        onClick = confirmAndDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث باسم التطبيق أو الحزمة...", fontSize = 13.sp) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Category Filter Tabs (Spanning 100% width cleanly with no clipped edges)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val categories = listOf(
                        "ALL" to "الكل (${completeAppList.size})",
                        "USER" to "المثبتة (${completeAppList.count { !it.isSystemApp }})",
                        "SYSTEM" to "النظام (${completeAppList.count { it.isSystemApp }})",
                        "SELECTED" to "المحددة (${tempSelected.size})"
                    )
                    categories.forEach { (key, label) ->
                        val isSelected = filterCategory == key
                        Surface(
                            onClick = { filterCategory = key },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 2.dp)
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Sleek quick actions: "تحديد المعروض" and "إلغاء المعروض"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إلغاء المعروض",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                if (isTimeDelayActive) {
                                    tempSelected = currentlySelected
                                    android.widget.Toast.makeText(
                                        context,
                                        "لا يمكن إلغاء التطبيقات المحظورة سابقاً أثناء سريان التأخير الزمني",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                } else if (lockedPackages.isNotEmpty()) {
                                    tempSelected = lockedPackages
                                    android.widget.Toast.makeText(
                                        context,
                                        lockMessage ?: "تم الإبقاء على التطبيقات المحفوظة سابقاً فقط (يمنع إزالتها خارج فترة السماح)",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    val filteredPkgs = filtered.map { it.packageName }.toSet()
                                    tempSelected = tempSelected - filteredPkgs
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تحديد المعروض (${filtered.size})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                if (disallowAddingNew) {
                                    android.widget.Toast.makeText(
                                        context,
                                        disallowAddingMessage ?: "يمنع إضافة تطبيقات مسموحة جديدة خارج فترة السماح (06:00 - 07:00)",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    tempSelected = tempSelected + filtered.map { it.packageName }.toSet() + lockedPackages
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (filtered.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.SearchOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "لا توجد تطبيقات مطابقة",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filtered, key = { it.packageName }) { app ->
                            val isChecked = tempSelected.contains(app.packageName)
                            val isLockedByTimeDelay = isTimeDelayActive && currentlySelected.contains(app.packageName)
                            val isLockedByUsageWindow = lockedPackages.contains(app.packageName)
                            val isLocked = isLockedByTimeDelay || isLockedByUsageWindow

                            val toggleSelection = {
                                if (isChecked) {
                                    if (isLockedByTimeDelay) {
                                        android.widget.Toast.makeText(
                                            context,
                                            "لا يمكن إزالة هذا التطبيق أثناء سريان ميزة التأخير الزمني",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } else if (isLockedByUsageWindow) {
                                        android.widget.Toast.makeText(
                                            context,
                                            lockMessage ?: "يمنع إزالة التطبيقات المحفوظة خارج فترة السماح اليومية (06:00 - 07:00)",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } else {
                                        tempSelected = tempSelected - app.packageName
                                    }
                                } else {
                                    if (disallowAddingNew) {
                                        android.widget.Toast.makeText(
                                            context,
                                            disallowAddingMessage ?: "يمنع إضافة تطبيقات جديدة خارج فترة السماح",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } else {
                                        tempSelected = tempSelected + app.packageName
                                    }
                                }
                            }

                            Box(
                                modifier = Modifier.animateItem(
                                    fadeInSpec = tween(180, easing = SaffahMotion.EmphasizedDecelerate),
                                    fadeOutSpec = tween(140, easing = SaffahMotion.EmphasizedAccelerate),
                                    placementSpec = androidx.compose.animation.core.spring(
                                        stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                        dampingRatio = 0.8f
                                    )
                                )
                            ) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .saffahPressMotion(),
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent,
                                    border = if (isChecked) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)) else null,
                                    onClick = { toggleSelection() }
                                ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val multiSelectIconPainter = rememberFastDrawablePainter(app.iconDrawable)
                                    if (multiSelectIconPainter != null) {
                                        Image(
                                            painter = multiSelectIconPainter,
                                            contentDescription = app.appName,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                    } else {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Default.Android,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = app.appName,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            if (isLocked) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Lock,
                                                    contentDescription = "محمي",
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = app.packageName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Checkbox(
                                        checked = isChecked,
                                        enabled = !isLocked,
                                        onCheckedChange = { toggleSelection() },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = MaterialTheme.colorScheme.primary,
                                            checkmarkColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }
                    }
                }
            }
        }
    }
}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleTimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int) -> Unit
) {
    val timePickerState = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = true
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .wrapContentWidth()
                    .wrapContentHeight()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "تحديد الوقت",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    TimePicker(
                        state = timePickerState,
                        colors = TimePickerDefaults.colors(
                            clockDialColor = MaterialTheme.colorScheme.surfaceVariant,
                            clockDialSelectedContentColor = MaterialTheme.colorScheme.onPrimary,
                            clockDialUnselectedContentColor = MaterialTheme.colorScheme.onSurface,
                            selectorColor = MaterialTheme.colorScheme.primary,
                            periodSelectorBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            periodSelectorSelectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            periodSelectorSelectedContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            periodSelectorUnselectedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            periodSelectorUnselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            timeSelectorSelectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            timeSelectorSelectedContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            timeSelectorUnselectedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            timeSelectorUnselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                onConfirm(timePickerState.hour, timePickerState.minute)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("تأكيد", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime24H(hour: Int, minute: Int): String {
    return String.format(java.util.Locale.US, "%02d:%02d", hour, minute)
}

@Composable
private fun UsageBlockRuleCard(
    rule: com.example.model.UsageBlockRule,
    allApps: List<com.example.model.InstalledApp>,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    isDragging: Boolean = false
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isRestricted = remember { com.example.util.SaffahBlockRepository.isUsageRuleModificationRestricted(context) }
    val appMap = remember(allApps) { allApps.associateBy { it.packageName } }
    val daysList = listOf(
        java.util.Calendar.SATURDAY to "س",
        java.util.Calendar.SUNDAY to "ح",
        java.util.Calendar.MONDAY to "ن",
        java.util.Calendar.TUESDAY to "ث",
        java.util.Calendar.WEDNESDAY to "ع",
        java.util.Calendar.THURSDAY to "خ",
        java.util.Calendar.FRIDAY to "ج"
    )

    val isEnabled = rule.isEnabled
    val accentColor = Color(0xFF7C3AED)

    val cardBg = when {
        isDragging -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)
        isEnabled -> MaterialTheme.colorScheme.surface
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    }
    val cardBorder = when {
        isDragging -> accentColor
        isEnabled -> accentColor.copy(alpha = 0.35f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }
    val titleColor = if (isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
    val editIconTint = if (isEnabled) accentColor else MaterialTheme.colorScheme.onSurfaceVariant
    val deleteIconTint = if (isRestricted) MaterialTheme.colorScheme.onSurfaceVariant else if (isEnabled) ErrorRed else MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = androidx.compose.foundation.BorderStroke(if (isDragging) 1.5.dp else 1.dp, cardBorder),
        shadowElevation = if (isDragging) 8.dp else if (isEnabled) 1.dp else 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (rule.name.isNotBlank()) rule.name else "عملية حظر بالاستخدام",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = titleColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.saffahPressMotion()
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = editIconTint)
                    }
                    IconButton(
                        onClick = {
                            if (isRestricted) {
                                android.widget.Toast.makeText(
                                    context,
                                    "يمنع حذف عمليات الحظر بالاستخدام عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00)",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            } else {
                                onDelete()
                            }
                        },
                        modifier = Modifier.saffahPressMotion()
                    ) {
                        Icon(
                            imageVector = if (isRestricted) Icons.Default.Lock else Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = deleteIconTint
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Circular days
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                daysList.forEach { (dayId, dayLetter) ->
                    val isActive = rule.activeDays.contains(dayId)

                    val circleBg = when {
                        !isEnabled && isActive -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                        !isEnabled -> MaterialTheme.colorScheme.surfaceVariant
                        isActive -> accentColor
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }

                    val circleTextColor = when {
                        isActive -> MaterialTheme.colorScheme.onPrimary
                        !isEnabled -> MaterialTheme.colorScheme.onSurfaceVariant
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }

                    Surface(
                        color = circleBg,
                        shape = CircleShape,
                        border = if (!isActive && isEnabled) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = dayLetter,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                color = circleTextColor,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Target Apps LazyRow (Horizontal scroll of app cards with live consumption metrics)
            val selectedStats = rule.selectedPackages.mapNotNull { pkg ->
                val app = appMap[pkg] ?: com.example.model.InstalledApp(packageName = pkg, appName = pkg, iconDrawable = null)
                val usedMinutes = com.example.util.SaffahBlockRepository.getUsageRuleConsumedMinutes(context, rule, pkg)
                val launches = com.example.util.SaffahBlockRepository.getUsageRuleConsumedLaunches(context, rule, pkg)
                val isExceeded = when (rule.limitType) {
                    com.example.model.UsageLimitType.DURATION -> usedMinutes >= rule.limitValue
                    com.example.model.UsageLimitType.LAUNCH_COUNT -> launches >= rule.limitValue
                }
                val statLabel = if (rule.limitType == com.example.model.UsageLimitType.DURATION) {
                    com.example.util.SaffahBlockRepository.formatUsagePair(usedMinutes, rule.limitValue)
                } else {
                    "$launches / ${rule.limitValue} مرة"
                }
                Triple(app, statLabel, isExceeded)
            }

            if (selectedStats.isEmpty()) {
                Text(
                    text = "لم يتم تحديد أي تطبيقات",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(selectedStats, key = { it.first.packageName }) { (app, statText, isExceeded) ->
                        val usageAppIconPainter = rememberFastDrawablePainter(app.iconDrawable)
                        val chipBg = when {
                            !isEnabled -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            isExceeded -> ErrorRed.copy(alpha = 0.12f)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        val chipBorderColor = when {
                            !isEnabled -> MaterialTheme.colorScheme.outlineVariant
                            isExceeded -> ErrorRed.copy(alpha = 0.5f)
                            else -> accentColor.copy(alpha = 0.2f)
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = chipBg,
                            border = androidx.compose.foundation.BorderStroke(1.dp, chipBorderColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (usageAppIconPainter != null) {
                                    Image(
                                        painter = usageAppIconPainter,
                                        contentDescription = app.appName,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape),
                                        colorFilter = if (!isEnabled) GrayscaleFilter else null
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Android,
                                        contentDescription = app.appName,
                                        tint = if (isEnabled) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Text(
                                    text = app.appName,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1
                                )

                                Surface(
                                    color = if (isExceeded && isEnabled) ErrorRed else accentColor.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = statText,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isExceeded && isEnabled) MaterialTheme.colorScheme.onError else accentColor,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditUsageBlockRuleDialog(
    initialRule: com.example.model.UsageBlockRule,
    allApps: List<com.example.model.InstalledApp>,
    onDismiss: () -> Unit,
    onSave: (com.example.model.UsageBlockRule) -> Unit,
    onDelete: (Long) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isRestricted = remember { com.example.util.SaffahBlockRepository.isUsageRuleModificationRestricted(context) }
    val isExistingSavedRule = remember(initialRule.id) {
        com.example.util.SaffahBlockRepository.getUsageRules(context).any { it.id == initialRule.id }
    }
    val isTighteningOnlyMode = isExistingSavedRule && isRestricted

    var name by remember(initialRule.id) { mutableStateOf(initialRule.name) }
    var isEnabled by remember(initialRule.id) { mutableStateOf(initialRule.isEnabled) }
    var activeDays by remember(initialRule.id) { mutableStateOf(initialRule.activeDays) }
    var limitType by remember(initialRule.id) { mutableStateOf(initialRule.limitType) }
    var limitValue by remember(initialRule.id) { mutableIntStateOf(initialRule.limitValue) }
    var selectedPackages by remember(initialRule.id) { mutableStateOf(initialRule.selectedPackages) }

    var customInputText by remember(initialRule.id) { mutableStateOf(initialRule.limitValue.toString()) }
    var showAppPicker by remember { mutableStateOf(false) }

    val accentColor = Color(0xFF7C3AED)

    val daysMap = listOf(
        java.util.Calendar.SATURDAY to "س",
        java.util.Calendar.SUNDAY to "أ",
        java.util.Calendar.MONDAY to "ن",
        java.util.Calendar.TUESDAY to "ث",
        java.util.Calendar.WEDNESDAY to "ع",
        java.util.Calendar.THURSDAY to "خ",
        java.util.Calendar.FRIDAY to "ج"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        SaffahSwitch(
                            checked = isEnabled,
                            onCheckedChange = { desired ->
                                if (!desired && isTighteningOnlyMode && initialRule.isEnabled) {
                                    android.widget.Toast.makeText(
                                        context,
                                        "يمنع تعطيل عملية الحظر المحفوظة خارج فترة السماح (06:00 - 07:00)",
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    isEnabled = desired
                                }
                            }
                        )
                        Text(
                            text = if (!isExistingSavedRule) "إضافة عملية حظر بالاستخدام" else "تعديل عملية الحظر",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isExistingSavedRule) {
                            IconButton(onClick = {
                                if (isTighteningOnlyMode) {
                                    android.widget.Toast.makeText(
                                        context,
                                        "يمنع حذف عمليات الحظر خارج فترة السماح اليومية (06:00 - 07:00)",
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    onDelete(initialRule.id)
                                }
                            }) {
                                Icon(
                                    imageVector = if (isTighteningOnlyMode) Icons.Default.Lock else Icons.Default.Delete,
                                    contentDescription = "حذف",
                                    tint = if (isTighteningOnlyMode) MaterialTheme.colorScheme.onSurfaceVariant else ErrorRed
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Tightening Notice Banner if outside allowed window
                    if (isTighteningOnlyMode) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = accentColor.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = accentColor,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "فترة التشديد فقط (خارج 06:00 - 07:00): يسمح فقط بتقليل وقت/مرات الاستخدام أو إضافة تطبيقات إضافية.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم عملية الحظر") },
                    placeholder = { Text("مثال: حد استخدام تطبيقات التواصل") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "أيام الأسبوع النشطة",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    daysMap.forEach { (dayId, dayLetter) ->
                        val isSelected = activeDays.contains(dayId)
                        val isDayLocked = isTighteningOnlyMode && initialRule.activeDays.contains(dayId)
                        SaffahDaySelectionChip(
                            dayLabel = dayLetter,
                            isSelected = isSelected,
                            activeColor = accentColor,
                            onClick = {
                                if (isSelected) {
                                    if (isDayLocked) {
                                        android.widget.Toast.makeText(
                                            context,
                                            "لا يمكن إزالة أيام التفعيل المحفوظة خارج فترة السماح (06:00 - 07:00)",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } else if (activeDays.size > 1) {
                                        activeDays = activeDays - dayId
                                    }
                                } else {
                                    activeDays = activeDays + dayId
                                }
                            },
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "نوع حد الاستخدام (اختر نوعاً واحداً)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                // TYPE 1: DURATION
                val durationSelectable = !isTighteningOnlyMode || initialRule.limitType == com.example.model.UsageLimitType.DURATION
                Surface(
                    onClick = {
                        if (isTighteningOnlyMode && initialRule.limitType != com.example.model.UsageLimitType.DURATION) {
                            android.widget.Toast.makeText(
                                context,
                                "لا يمكن تغيير نوع الحد لعملية محفوظة خارج فترة السماح (06:00 - 07:00)",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            limitType = com.example.model.UsageLimitType.DURATION
                            if (limitValue <= 0) {
                                limitValue = if (isTighteningOnlyMode) initialRule.limitValue else 30
                                customInputText = limitValue.toString()
                            }
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (limitType == com.example.model.UsageLimitType.DURATION) accentColor else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = limitType == com.example.model.UsageLimitType.DURATION,
                                onClick = {
                                    if (isTighteningOnlyMode && initialRule.limitType != com.example.model.UsageLimitType.DURATION) {
                                        android.widget.Toast.makeText(
                                            context,
                                            "لا يمكن تغيير نوع الحد لعملية محفوظة خارج فترة السماح (06:00 - 07:00)",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } else {
                                        limitType = com.example.model.UsageLimitType.DURATION
                                        if (limitValue <= 0) {
                                            limitValue = if (isTighteningOnlyMode) initialRule.limitValue else 30
                                            customInputText = limitValue.toString()
                                        }
                                    }
                                },
                                enabled = durationSelectable,
                                colors = RadioButtonDefaults.colors(selectedColor = accentColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "حد وقت الاستخدام اليومي",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "حظر التطبيقات لبقية اليوم بعد استهلاك الوقت المحدد",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (limitType == com.example.model.UsageLimitType.DURATION) {
                            Spacer(modifier = Modifier.height(10.dp))

                            ProductivityMinutesStepper(
                                minutes = limitValue,
                                minAllowed = 1,
                                maxAllowed = if (isTighteningOnlyMode) initialRule.limitValue else 1440,
                                accentColor = accentColor,
                                titleText = null,
                                onExceedMax = {
                                    android.widget.Toast.makeText(
                                        context,
                                        "يمنع رفع سقف الوقت عن ${com.example.util.SaffahBlockRepository.formatUsageCeilingTime(initialRule.limitValue)}.",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                },
                                onMinutesChange = {
                                    limitValue = it
                                    customInputText = it.toString()
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // TYPE 2: LAUNCH COUNT
                val launchCountSelectable = !isTighteningOnlyMode || initialRule.limitType == com.example.model.UsageLimitType.LAUNCH_COUNT
                Surface(
                    onClick = {
                        if (isTighteningOnlyMode && initialRule.limitType != com.example.model.UsageLimitType.LAUNCH_COUNT) {
                            android.widget.Toast.makeText(
                                context,
                                "لا يمكن تغيير نوع الحد لعملية محفوظة خارج فترة السماح (06:00 - 07:00)",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            limitType = com.example.model.UsageLimitType.LAUNCH_COUNT
                            if (limitValue <= 0) {
                                limitValue = if (isTighteningOnlyMode) initialRule.limitValue else 10
                                customInputText = limitValue.toString()
                            }
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (limitType == com.example.model.UsageLimitType.LAUNCH_COUNT) accentColor else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = limitType == com.example.model.UsageLimitType.LAUNCH_COUNT,
                                onClick = {
                                    if (isTighteningOnlyMode && initialRule.limitType != com.example.model.UsageLimitType.LAUNCH_COUNT) {
                                        android.widget.Toast.makeText(
                                            context,
                                            "لا يمكن تغيير نوع الحد لعملية محفوظة خارج فترة السماح (06:00 - 07:00)",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } else {
                                        limitType = com.example.model.UsageLimitType.LAUNCH_COUNT
                                        if (limitValue <= 0) {
                                            limitValue = if (isTighteningOnlyMode) initialRule.limitValue else 10
                                            customInputText = limitValue.toString()
                                        }
                                    }
                                },
                                enabled = launchCountSelectable,
                                colors = RadioButtonDefaults.colors(selectedColor = accentColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "حد عدد مرات الفتح اليومية",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "حظر التطبيقات لبقية اليوم بعد تجاوز عدد المرات المسموحة",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (limitType == com.example.model.UsageLimitType.LAUNCH_COUNT) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                listOf(5 to "5 مرات", 10 to "10 مرات", 15 to "15 مرة", 20 to "20 مرة").forEach { (cntVal, labelText) ->
                                    val isAllowedChip = !isTighteningOnlyMode || cntVal <= initialRule.limitValue
                                    val isSelected = limitValue == cntVal
                                    Surface(
                                        onClick = {
                                            if (!isAllowedChip) {
                                                android.widget.Toast.makeText(
                                                    context,
                                                    "يمنع رفع السقف عن ${initialRule.limitValue} مرة خارج فترة السماح (06:00 - 07:00)",
                                                    android.widget.Toast.LENGTH_SHORT
                                                ).show()
                                            } else {
                                                limitValue = cntVal
                                                customInputText = cntVal.toString()
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) Color(0xFFF3F4F6) else MaterialTheme.colorScheme.surface,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelected) Color(0xFF111827) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(38.dp)
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier.fillMaxSize()
                                        ) {
                                            Text(
                                                text = labelText,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color(0xFF111827) else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = customInputText,
                                onValueChange = { input ->
                                    customInputText = input
                                    val parsed = input.toIntOrNull()
                                    if (parsed != null && parsed > 0) {
                                        if (isTighteningOnlyMode && parsed > initialRule.limitValue) {
                                            android.widget.Toast.makeText(
                                                context,
                                                "يمنع رفع سقف عدد المرات عن ${initialRule.limitValue} مرة. يسمح بالتقليل فقط.",
                                                android.widget.Toast.LENGTH_SHORT
                                            ).show()
                                            limitValue = initialRule.limitValue
                                        } else {
                                            limitValue = parsed
                                        }
                                    }
                                },
                                label = {
                                    Text(
                                        if (isTighteningOnlyMode) "الحد بالمرات (الحد الأقصى المسموح: ${initialRule.limitValue} مرة)"
                                        else "أدخل الحد بعدد المرات"
                                    )
                                },
                                trailingIcon = {
                                    Text(
                                        text = "مرة",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(end = 12.dp)
                                    )
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                    focusedBorderColor = MaterialTheme.colorScheme.outline,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                ),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedButton(
                    onClick = { showAppPicker = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "التطبيقات المستهدفة (${selectedPackages.size})",
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    val effectivePackages = if (isTighteningOnlyMode) {
                        selectedPackages + initialRule.selectedPackages
                    } else {
                        selectedPackages
                    }
                    val effectiveLimitValue = if (isTighteningOnlyMode && limitValue > initialRule.limitValue) {
                        initialRule.limitValue
                    } else {
                        limitValue
                    }
                    val finalRule = initialRule.copy(
                        name = if (name.isBlank()) "عملية حظر بالاستخدام" else name,
                        isEnabled = if (isTighteningOnlyMode && initialRule.isEnabled) true else isEnabled,
                        activeDays = if (isTighteningOnlyMode) activeDays + initialRule.activeDays else activeDays,
                        limitType = if (isTighteningOnlyMode) initialRule.limitType else limitType,
                        limitValue = effectiveLimitValue,
                        selectedPackages = effectivePackages
                    )
                    onSave(finalRule)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .saffahPressMotion(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor)
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("حفظ عملية الحظر", fontWeight = FontWeight.Bold)
            }
        }
    }
}
}

    if (showAppPicker) {
        AppSelectionSubDialog(
            allApps = allApps,
            currentlySelected = selectedPackages,
            lockedPackages = if (isTighteningOnlyMode) initialRule.selectedPackages else emptySet(),
            onDismiss = { showAppPicker = false },
            onConfirm = { newSelected ->
                selectedPackages = if (isTighteningOnlyMode) newSelected + initialRule.selectedPackages else newSelected
                showAppPicker = false
            }
        )
    }
}

