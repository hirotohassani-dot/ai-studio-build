package com.example.ui.components

import android.graphics.PointF
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SaffahHaptics
import com.example.ui.theme.SaffahMotion
import com.example.ui.theme.saffahMicroPress
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * الحزمة الثانية الشاملة للمايكرو-إنترأكشن والحركة المتطورة لتطبيق السفاح
 * (Saffah Advanced Micro-Interactions & Motion Suite - Package 2)
 *
 * المبادئ الهندسية الصارمة:
 * 1. سرعة استجابة فائقة عند 90-120 FPS بدون أي استنزاف لعتاد الجهاز أو البطارية.
 * 2. الحساب والرسم بالكامل داخل طبقة المعالجة الرسومية (GPU Render Loop via graphicsLayer & drawWithCache).
 * 3. صفر إعادة تخطيط أو اهتزاز قياس (Zero Relayout / No Jitter).
 * 4. فيزياء زنبركية ديناميكية (Spring Physics) مستوحاة من الأجهزة الرائدة مع ردود فعل لمسية متقدمة.
 */

// =========================================================================
// MARK: - 1. إطار النيون المتدفق حول البطاقات (Neon Perimeter Trace)
// =========================================================================
/**
 * شعاع ضوئي نيون ينساب بانسيابية محيطية على أطراف البطاقة لإعطاء طابع الحماية النشطة أو الإنجاز الاستثنائي.
 */
fun Modifier.saffahNeonBorderTrace(
    enabled: Boolean = true,
    strokeWidth: Dp = 1.8.dp,
    neonColor: Color = Color(0xFF10B981),
    cornerRadius: Dp = 16.dp,
    durationMs: Int = 3200
): Modifier = composed {
    if (!enabled) return@composed this

    val infiniteTransition = rememberInfiniteTransition(label = "NeonBorderTrace")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "NeonPhase"
    )

    this.drawWithCache {
        val cornerRadiusPx = cornerRadius.toPx()
        val strokeWidthPx = strokeWidth.toPx()

        onDrawBehind {
            val w = size.width
            val h = size.height
            val perimeter = 2 * (w + h)
            val beamLength = perimeter * 0.28f

            val gradientBrush = Brush.sweepGradient(
                colors = listOf(
                    neonColor.copy(alpha = 0f),
                    neonColor.copy(alpha = 0.85f),
                    neonColor,
                    neonColor.copy(alpha = 0f)
                ),
                center = Offset(w / 2f, h / 2f)
            )

            drawRoundRect(
                brush = gradientBrush,
                topLeft = Offset(strokeWidthPx / 2, strokeWidthPx / 2),
                size = Size(w - strokeWidthPx, h - strokeWidthPx),
                cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
                style = Stroke(
                    width = strokeWidthPx,
                    pathEffect = PathEffect.dashPathEffect(
                        floatArrayOf(beamLength, perimeter - beamLength),
                        phase * perimeter
                    )
                )
            )
        }
    }
}

// =========================================================================
// MARK: - 2. نبض ضربات القلب الحيوية (Heartbeat Vitality Pulse)
// =========================================================================
/**
 * نبضة مزدوجة تحاكي ضربات القلب (Thump-Thump) للأزرار الحساسة وحالات الطوارئ (مثل دحر الرغبة أو كسر حاجز الخطر).
 */
fun Modifier.saffahHeartbeatPulse(
    enabled: Boolean = true,
    scalePeak: Float = 1.05f
): Modifier = composed {
    if (!enabled) return@composed this

    val scale = remember { Animatable(1f) }

    LaunchedEffect(enabled) {
        if (enabled) {
            while (true) {
                // النبضة الأولى (Beat 1)
                scale.animateTo(scalePeak, tween(110, easing = SaffahMotion.EmphasizedDecelerate))
                scale.animateTo(1f, tween(130, easing = SaffahMotion.EmphasizedAccelerate))
                delay(60)
                // النبضة الثانية الخفيفة (Beat 2)
                scale.animateTo(1f + (scalePeak - 1f) * 0.6f, tween(90, easing = SaffahMotion.EmphasizedDecelerate))
                scale.animateTo(1f, spring(Spring.StiffnessMediumLow, Spring.DampingRatioNoBouncy))
                // فترة راحة قبل النبضة التالية
                delay(1400)
            }
        }
    }

    this.graphicsLayer {
        scaleX = scale.value
        scaleY = scale.value
    }
}

// =========================================================================
// MARK: - 3. انطباق القفل والأمان الفيزيائي (Lock Snap Micro-interaction)
// =========================================================================
/**
 * دوران خاطف متوازن مع انضغاط زنبركي يحاكي نقرة غلق القفل الحقيقي.
 */
fun Modifier.saffahLockSnap(
    isLocked: Boolean,
    snapAngle: Float = 10f
): Modifier = composed {
    val rotation = remember { Animatable(0f) }
    val scale = remember { Animatable(1f) }

    LaunchedEffect(isLocked) {
        rotation.snapTo(if (isLocked) -snapAngle else snapAngle)
        scale.snapTo(1.14f)
        launch {
            rotation.animateTo(
                0f,
                spring(
                    stiffness = Spring.StiffnessMediumLow,
                    dampingRatio = Spring.DampingRatioMediumBouncy
                )
            )
        }
        scale.animateTo(
            1f,
            spring(
                stiffness = Spring.StiffnessHigh,
                dampingRatio = Spring.DampingRatioNoBouncy
            )
        )
    }

    this.graphicsLayer {
        rotationZ = rotation.value
        scaleX = scale.value
        scaleY = scale.value
    }
}

// =========================================================================
// MARK: - 4. هالة التوهج المحيطي الناعم (Ambient Hover Glow)
// =========================================================================
fun Modifier.saffahAmbientGlow(
    enabled: Boolean = true,
    glowColor: Color = Color(0xFF10B981),
    glowAlpha: Float = 0.22f,
    radiusDp: Dp = 20.dp
): Modifier = composed {
    if (!enabled) return@composed this

    val transition = rememberInfiniteTransition(label = "AmbientGlow")
    val alphaAnim by transition.animateFloat(
        initialValue = glowAlpha * 0.6f,
        targetValue = glowAlpha * 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowAlpha"
    )

    this.drawBehind {
        val radiusPx = radiusDp.toPx()
        val brush = Brush.radialGradient(
            colors = listOf(glowColor.copy(alpha = alphaAnim), Color.Transparent),
            center = center,
            radius = size.maxDimension / 2f + radiusPx
        )
        drawCircle(brush = brush, radius = size.maxDimension / 2f + radiusPx)
    }
}

// =========================================================================
// MARK: - 5. السحب للتأكيد الفيزيائي (SaffahSlideToConfirm)
// =========================================================================
/**
 * شريط سحب انسيابي فائق الفخامة والفيزياء (Slide to Confirm) للعمليات الحساسة
 * (مثل إعادة تعيين العداد، تفعيل القفل الصارم، أو بدء جلسة دحر الرغبة).
 * يتميز بـ:
 * - ارتداد زنبركي فوري إذا لم يكتمل السحب.
 * - اهتزاز حسي تدريجي أثناء السحب.
 * - انفجار إنجاز أخضر ناعم عند الاكتمال.
 */
@Composable
fun SaffahSlideToConfirm(
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier,
    title: String = "اسحب للتأكيد",
    confirmedTitle: String = "تم بنجاح!",
    thumbIcon: ImageVector = Icons.AutoMirrored.Filled.ArrowForward,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    confirmedColor: Color = Color(0xFF10B981),
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    height: Dp = 54.dp
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    var isConfirmed by remember { mutableStateOf(false) }
    val dragOffset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(height / 2))
            .background(if (isConfirmed) confirmedColor else containerColor)
            .border(
                1.dp,
                if (isConfirmed) confirmedColor else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                RoundedCornerShape(height / 2)
            ),
        contentAlignment = Alignment.CenterStart
    ) {
        val totalWidthPx = constraints.maxWidth.toFloat()
        val thumbSizePx = with(density) { (height - 8.dp).toPx() }
        val maxDragPx = (totalWidthPx - thumbSizePx - with(density) { 8.dp.toPx() }).coerceAtLeast(1f)

        val progress = (dragOffset.value / maxDragPx).coerceIn(0f, 1f)

        // خلفية التقدم التدريجي الملونة
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(with(density) { (dragOffset.value + thumbSizePx + 8.dp.toPx()).toDp() })
                .background(accentColor.copy(alpha = 0.25f))
        )

        // النص الإرشادي الشفاف تدريجياً مع السحب
        Text(
            text = if (isConfirmed) confirmedTitle else title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = if (isConfirmed) Color.White else contentColor.copy(alpha = (1f - progress * 0.9f).coerceIn(0.1f, 1f)),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
        )

        // زر السحب الزنبركي (Spring Thumb)
        Box(
            modifier = Modifier
                .offset { IntOffset(with(density) { (4.dp.toPx() + dragOffset.value).toInt() }, 0) }
                .size(height - 8.dp)
                .clip(CircleShape)
                .background(if (isConfirmed) Color.White else accentColor)
                .pointerInput(isConfirmed) {
                    if (isConfirmed) return@pointerInput
                    detectDragGestures(
                        onDragEnd = {
                            if (dragOffset.value >= maxDragPx * 0.85f) {
                                // اكتمل السحب بنجاح
                                isConfirmed = true
                                SaffahHaptics.success(null)
                                scope.launch {
                                    dragOffset.animateTo(maxDragPx, spring(Spring.StiffnessMedium, Spring.DampingRatioNoBouncy))
                                    delay(200)
                                    onConfirm()
                                }
                            } else {
                                // ارتداد فيزيائي للبداية
                                SaffahHaptics.tick(haptic)
                                scope.launch {
                                    dragOffset.animateTo(0f, spring(Spring.StiffnessMedium, Spring.DampingRatioMediumBouncy))
                                }
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val nextValue = (dragOffset.value + dragAmount.x).coerceIn(0f, maxDragPx)
                            scope.launch { dragOffset.snapTo(nextValue) }
                            // اهتزاز لمسي خفيف كل 20% سحب
                            val step = (nextValue / maxDragPx * 5).toInt()
                            val prevStep = (dragOffset.value / maxDragPx * 5).toInt()
                            if (step != prevStep) {
                                SaffahHaptics.tick(haptic)
                            }
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isConfirmed) Icons.Default.Check else thumbIcon,
                contentDescription = null,
                tint = if (isConfirmed) confirmedColor else Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

// =========================================================================
// MARK: - 6. العداد الدائري الرشيق بفيزياء الزنبرك (SaffahRadialGauge)
// =========================================================================
/**
 * عداد قوسي دائري أنيق وسلس للنسب المئوية ومستوى الدوبامين وأيام التعافي.
 */
@Composable
fun SaffahRadialGauge(
    percentage: Float, // 0.0f .. 1.0f
    modifier: Modifier = Modifier,
    size: Dp = 100.dp,
    strokeWidth: Dp = 9.dp,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    centerContent: @Composable () -> Unit = {}
) {
    val clamped = percentage.coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = clamped,
        animationSpec = spring(
            stiffness = Spring.StiffnessMediumLow,
            dampingRatio = Spring.DampingRatioNoBouncy
        ),
        label = "RadialGaugeProgress"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(strokeWidth / 2)) {
            val strokePx = strokeWidth.toPx()
            // القوس الخلفي (260 درجة)
            drawArc(
                color = trackColor,
                startAngle = 140f,
                sweepAngle = 260f,
                useCenter = false,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
            // قوس التقدم النشط
            if (animatedProgress > 0.005f) {
                drawArc(
                    color = primaryColor,
                    startAngle = 140f,
                    sweepAngle = 260f * animatedProgress,
                    useCenter = false,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }
        }
        centerContent()
    }
}

// =========================================================================
// MARK: - 7. كبسولة الأزرار المتحولة الحيوية (SaffahMorphingCapsuleButton)
// =========================================================================
/**
 * زر كبسولي ديناميكي يتحول بمرونة أثناء التحميل، النجاح، أو الضغط العادي:
 * - يدعم حالة التحميل المدمجة السلسة.
 * - يدعم علامة الإنجاز المؤقتة بعد النقر.
 */
@Composable
fun SaffahMorphingCapsuleButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isLoading: Boolean = false,
    isSuccess: Boolean = false,
    containerColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary,
    enabled: Boolean = true
) {
    val haptic = LocalHapticFeedback.current
    val buttonWidth by animateDpAsState(
        targetValue = if (isLoading || isSuccess) 52.dp else 160.dp,
        animationSpec = spring(stiffness = Spring.StiffnessMedium, dampingRatio = Spring.DampingRatioLowBouncy),
        label = "MorphingWidth"
    )

    Surface(
        onClick = {
            if (enabled && !isLoading && !isSuccess) {
                SaffahHaptics.tick(haptic)
                onClick()
            }
        },
        modifier = modifier
            .height(48.dp)
            .width(buttonWidth)
            .saffahMicroPress(enabled = enabled && !isLoading && !isSuccess),
        shape = RoundedCornerShape(24.dp),
        color = if (isSuccess) Color(0xFF10B981) else containerColor,
        enabled = enabled
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            when {
                isLoading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = contentColor,
                        strokeWidth = 2.5.dp
                    )
                }
                isSuccess -> {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                else -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        if (icon != null) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = contentColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = text,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = contentColor
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// MARK: - 8. حاوية الأكورديون الانسيابية (SaffahAccordionBento)
// =========================================================================
/**
 * حاوية أكورديون تطوى وتتمدد بنعومة فيزيائية بدون قفزات في الارتفاع.
 */
@Composable
fun SaffahAccordionBento(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    initiallyExpanded: Boolean = false,
    content: @Composable () -> Unit
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }
    val haptic = LocalHapticFeedback.current
    val chevronRotation by animateFloatAsState(
        targetValue = if (expanded) -90f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium, dampingRatio = Spring.DampingRatioNoBouncy),
        label = "ChevronRotation"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        SaffahHaptics.tick(haptic)
                        expanded = !expanded
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (icon != null) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (subtitle != null) {
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = if (expanded) "طي" else "توسيع",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(22.dp)
                        .graphicsLayer { rotationZ = chevronRotation }
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(spring(Spring.StiffnessMediumLow, Spring.DampingRatioNoBouncy)) + fadeIn(tween(160)),
                exit = shrinkVertically(spring(Spring.StiffnessMediumLow, Spring.DampingRatioNoBouncy)) + fadeOut(tween(100))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                ) {
                    content()
                }
            }
        }
    }
}

// =========================================================================
// MARK: - 9. أمواج التنفس واليقظة الذهنية (SaffahMindfulBreathingWave)
// =========================================================================
/**
 * أمواج تنفس حركية مهدئة مخصصة لشاشات دحر الرغبة (Urge Surfing) والملاحظات الذاتية
 * لتوجيه المستخدم في تنظيم التنفس والاسترخاء خلال لحظات اشتداد الرغبة.
 */
@Composable
fun SaffahMindfulBreathingWave(
    modifier: Modifier = Modifier,
    waveColor: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
    cycleDurationMs: Int = 4000
) {
    val transition = rememberInfiniteTransition(label = "MindfulBreathing")
    val waveScale by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(cycleDurationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathingScale"
    )
    val waveAlpha by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(cycleDurationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathingAlpha"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        // حلقة خارجية متمددة
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = waveScale
                    scaleY = waveScale
                    alpha = waveAlpha
                }
                .clip(CircleShape)
                .background(waveColor)
        )
        // دائرة مركزية ناعمة
        Box(
            modifier = Modifier
                .fillMaxSize(0.65f)
                .clip(CircleShape)
                .background(waveColor.copy(alpha = 0.65f))
        )
    }
}
