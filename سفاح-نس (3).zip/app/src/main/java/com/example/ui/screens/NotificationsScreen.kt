package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.ui.components.DopamineTimePickerDialog
import com.example.ui.components.GlassBentoCard
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel
import java.util.Locale

@Composable
fun NotificationsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    BackHandler {
        onBack()
    }

    val isCleanDayEnabled by viewModel.isCleanDayNotifEnabled.collectAsState()
    val isMapMilestoneEnabled by viewModel.isMapMilestoneNotifEnabled.collectAsState()
    val isDopamineSurveyEnabled by viewModel.isDopamineSurveyNotifEnabled.collectAsState()
    val isDangerWindowEnabled by viewModel.isDangerWindowNotifEnabled.collectAsState()
    val isBedtimeReminderEnabled by viewModel.isBedtimeReminderNotifEnabled.collectAsState()
    val isBedtimeModWindowEnabled by viewModel.isBedtimeModWindowNotifEnabled.collectAsState()
    val isUsageLimitEnabled by viewModel.isUsageLimitNotifEnabled.collectAsState()
    val isLaunchCountEnabled by viewModel.isLaunchCountNotifEnabled.collectAsState()
    val isRecordStreakEnabled by viewModel.isRecordStreakNotifEnabled.collectAsState()
    val isDopamineReceptorEnabled by viewModel.isDopamineReceptorNotifEnabled.collectAsState()
    val isNewTerrainEnabled by viewModel.isNewTerrainNotifEnabled.collectAsState()
    val isContentBlockEnabled by viewModel.isContentBlockNotifEnabled.collectAsState()
    val isModificationWindowEnabled by viewModel.isModificationWindowNotifEnabled.collectAsState()
    val isScheduledBlockEnabled by viewModel.isScheduledBlockNotifEnabled.collectAsState()
    val isProductivityGoalEnabled by viewModel.isProductivityGoalNotifEnabled.collectAsState()
    val isTimeDelayEnabled by viewModel.isTimeDelayNotifEnabled.collectAsState()

    val dopamineTime by viewModel.dopamineSurveyTime.collectAsState()

    var showTimePickerDialog by remember { mutableStateOf(false) }

    var hasPostNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPostNotificationPermission = isGranted
        if (isGranted) {
            viewModel.showFeedback("تم تفعيل إذن الإشعارات بنجاح.")
        } else {
            viewModel.showFeedback("لم يتم منح إذن الإشعارات.")
        }
    }

    // Time Picker Dialog
    if (showTimePickerDialog) {
        DopamineTimePickerDialog(
            initialHour = dopamineTime.first,
            initialMinute = dopamineTime.second,
            onDismiss = { showTimePickerDialog = false },
            onConfirm = { h, m ->
                viewModel.updateDopamineSurveyTime(h, m)
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("notifications_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item(key = "notifications_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .saffahPressMotion()
                        .testTag("notifications_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "رجوع",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "إدارة الإشعارات الذكية",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "تخصيص التنبيهات الوقائية، نافذة الخطر الزمني، والاستعداد للنوم",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Notification Permission Warning if not granted
        if (!hasPostNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            item(key = "notifications_permission_warning") {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(
                                text = "إذن الإشعارات غير مفعّل",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "يلزم منح الإذن لتصلك التنبيهات الوقائية وإشعارات النوم في موعدها",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "تفعيل الإذن",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // Feature 1: Clean Day Completion
        item(key = "feature_clean_day") {
            NotificationFeatureCard(
                icon = Icons.Outlined.EmojiEvents,
                title = "إنجاز يوم نظيف جديد",
                subtitle = "تهنئة وتكريم المتعافي عند إتمام كل 24 ساعة متصلة بنقاء وصمود مطلق.",
                isChecked = isCleanDayEnabled,
                onCheckedChange = { viewModel.toggleCleanDayNotification(it) },
                tagPrefix = "clean_day"
            )
        }

        // Feature 2: Map Milestone Unlocked
        item(key = "feature_map_milestone") {
            NotificationFeatureCard(
                icon = Icons.Outlined.Map,
                title = "فتح محطة جديدة في الخريطة",
                subtitle = "إشعار تفاعلي عند بلوغ محطة جديدة في خريطة الـ 105 محطة وفتح بيئة جديدة.",
                isChecked = isMapMilestoneEnabled,
                onCheckedChange = { viewModel.toggleMapMilestoneNotification(it) },
                tagPrefix = "map_milestone"
            )
        }

        // Feature 3: Dopamine Survey
        item(key = "feature_dopamine_survey") {
            val isChecked = isDopamineSurveyEnabled
            val borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
            val iconTint = MaterialTheme.colorScheme.onSurface
            GlassBentoCard(
                borderColor = borderColor,
                modifier = Modifier
                    .clickable { viewModel.toggleDopamineSurveyNotification(!isDopamineSurveyEnabled) }
                    .testTag("dopamine_survey_card")
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Psychology,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(24.dp)
                        )

                        Text(
                            text = "تذكير استبيان التوازن الدوباميني",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )

                        if (isChecked) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = "مفعّل",
                                tint = SuccessGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Text(
                        text = "تذكير مسائي يومي لتقييم صفاء الذهن والمزاج والنوم والطاقة، يرسل فقط إذا لم يتم تسجيل فحص اليوم.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    AnimatedVisibility(
                        visible = isDopamineSurveyEnabled,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.AccessTime,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    val formattedTime = String.format(
                                        Locale.US,
                                        "%02d:%02d",
                                        dopamineTime.first,
                                        dopamineTime.second
                                    )
                                    Text(
                                        text = "موعد التذكير المسائي: $formattedTime",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                OutlinedButton(
                                    onClick = { showTimePickerDialog = true },
                                    modifier = Modifier
                                        .defaultMinSize(minWidth = 64.dp)
                                        .height(34.dp)
                                        .saffahPressMotion(),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.5f)),
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) {
                                    Text(
                                        text = "تعديل",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryBlue,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Feature 4: Danger Window Warning (تحذير نافذة الخطر الزمني)
        item(key = "feature_danger_window") {
            NotificationFeatureCard(
                icon = Icons.Outlined.WarningAmber,
                title = "تحذير نافذة الخطر الزمني",
                subtitle = "تنبيه وقائي أسبوعي يسبق موعد الذروة الأكثر تسجيلاً لمحاولات البحث المحظورة لحمايتك مسبقاً.",
                isChecked = isDangerWindowEnabled,
                onCheckedChange = { viewModel.toggleDangerWindowNotification(it) },
                tagPrefix = "danger_window"
            )
        }

        // Feature 5: Bedtime Start Alert (بدء وقت النوم)
        item(key = "feature_bedtime_reminder") {
            NotificationFeatureCard(
                icon = Icons.Outlined.Bedtime,
                title = "تنبيه بدء وقت النوم",
                subtitle = "إشعار فوري وتنبيه فور بدء وقت النوم الفعلي لتفعيل الحماية وتعليق التطبيقات المحددة.",
                isChecked = isBedtimeReminderEnabled,
                onCheckedChange = { viewModel.toggleBedtimeReminderNotification(it) },
                tagPrefix = "bedtime_reminder"
            )
        }

        // Feature 5.1: Bedtime Modification Window Alert (تنبيه ضبط وقت النوم قبل 12:00)
        item(key = "feature_bedtime_mod_window") {
            NotificationFeatureCard(
                icon = Icons.Outlined.NightsStay,
                title = "تنبيه ضبط وقت النوم (11:30)",
                subtitle = "تنبيه استباقي يُرسل يومياً عند 11:30 (قبل الساعة 12:00 ظهراً بـ 30 دقيقة) لتذكيرك بضبط جدول وتطبيقات وضع النوم قبل إغلاق نافذة التعديل.",
                isChecked = isBedtimeModWindowEnabled,
                onCheckedChange = { viewModel.toggleBedtimeModWindowNotification(it) },
                tagPrefix = "bedtime_mod_window"
            )
        }

        // Card 6: Usage Limit Warnings (100%)
        item(key = "feature_usage_limit") {
            NotificationFeatureCard(
                icon = Icons.Outlined.HourglassTop,
                title = "تنبيه استنفاد وقت التطبيقات (100%)",
                subtitle = "إشعار فوري عند نفاد كامل الحد اليومي المسموح به لأحد التطبيقات المقيدة وبدء التعليق.",
                isChecked = isUsageLimitEnabled,
                onCheckedChange = { viewModel.toggleUsageLimitNotification(it) },
                tagPrefix = "notif_usage_limit"
            )
        }

        // Card 7: Launch Count Limit Warnings
        item(key = "feature_launch_count") {
            NotificationFeatureCard(
                icon = Icons.Outlined.TouchApp,
                title = "تنبيه بلوغ سقف مرات الفتح",
                subtitle = "إشعار فوري عند استهلاك كامل رصيد مرات فتح التطبيق المقيد المحددة لليوم لمنع التشتت والتحقق الاندفاعي المتكرر.",
                isChecked = isLaunchCountEnabled,
                onCheckedChange = { viewModel.toggleLaunchCountNotification(it) },
                tagPrefix = "notif_launch_count"
            )
        }

        // Card 8: Record-Breaking Streak Celebration
        item(key = "feature_record_streak") {
            NotificationFeatureCard(
                icon = Icons.Outlined.EmojiEvents,
                title = "تنبيه كسر الرقم القياسي للتعافي",
                subtitle = "إشعار احتفالي وتحفيزي يظهر في اللحظة التي تتجاوز فيها أطول سلسلة تعافٍ حققتها في سجلك التاريخي.",
                isChecked = isRecordStreakEnabled,
                onCheckedChange = { viewModel.toggleRecordStreakNotification(it) },
                tagPrefix = "notif_record_streak"
            )
        }

        // Card 9: Dopamine Receptor Biological Changes
        item(key = "feature_dopamine_receptor") {
            NotificationFeatureCard(
                icon = Icons.Outlined.Psychology,
                title = "تنبيه التغير الحيوي لمستقبلات الدوبامين",
                subtitle = "تنبيهات علمية مبنية على مراحل استشفاء الدماغ، تُرسل عند نقاط زمنية فارقة توضح التغير البيولوجي الحاصل.",
                isChecked = isDopamineReceptorEnabled,
                onCheckedChange = { viewModel.toggleDopamineReceptorNotification(it) },
                tagPrefix = "notif_dopamine_receptor"
            )
        }

        // Card: New Terrain Approaching
        item(key = "feature_new_terrain") {
            NotificationFeatureCard(
                icon = Icons.Outlined.Terrain,
                title = "إنذار دخول تضاريس جديدة",
                subtitle = "إنذار تحفيزي يُرسل قبل يوم واحد من الانتقال لبيئة جديدة على خريطة التعافي لتحذيرك وشحذ همتك.",
                isChecked = isNewTerrainEnabled,
                onCheckedChange = { viewModel.toggleNewTerrainNotification(it) },
                tagPrefix = "notif_new_terrain"
            )
        }

        // Card 12: Immediate Content Block
        item(key = "feature_content_block") {
            NotificationFeatureCard(
                icon = Icons.Outlined.Block,
                title = "إشعار حظر المحتوى الفوري",
                subtitle = "إشعار فوري عند حظر كلمة أو موقع محظور يتضمن اسم وأيقونة التطبيق وتحذيراً باسم السفَّاح.",
                isChecked = isContentBlockEnabled,
                onCheckedChange = { viewModel.toggleContentBlockNotification(it) },
                tagPrefix = "notif_content_block"
            )
        }

        // Card 13: Modification Window Entry Alert
        item(key = "feature_modification_window") {
            NotificationFeatureCard(
                icon = Icons.Outlined.EditCalendar,
                title = "التنبيه بدخول وقت السماح بالتعديل",
                subtitle = "تنبيه استباقي يُرسل فور دخول نافذة السماح اليومية (06:00 - 07:00) لتعديل أو إلغاء قواعد الحظر والحدود قبل إغلاقها.",
                isChecked = isModificationWindowEnabled,
                onCheckedChange = { viewModel.toggleModificationWindowNotification(it) },
                tagPrefix = "notif_modification_window"
            )
        }

        // Card 14: Scheduled Block Start & End Alert
        item(key = "feature_scheduled_block") {
            NotificationFeatureCard(
                icon = Icons.Outlined.Schedule,
                title = "تنبيه بدأ وانتهاء الحظر المجدول",
                subtitle = "إشعار مستمر بنطاق الحظر يتضمن أوقات البدء والانتهاء بصيغة 24H والعد التنازلي المباشر، مع إشعار عند رفع الحظر.",
                isChecked = isScheduledBlockEnabled,
                onCheckedChange = { viewModel.toggleScheduledBlockNotification(it) },
                tagPrefix = "notif_scheduled_block"
            )
        }

        // Card 15: Productivity Goal Achievement Alert
        item(key = "feature_productivity_goal") {
            NotificationFeatureCard(
                icon = Icons.Outlined.WorkspacePremium,
                title = "تنبيه تحقيق الهدف اليومي للتطبيقات",
                subtitle = "تهنئة وتحفيز فخم باسم المتعافي عند إتمام الهدف اليومي المحدد للتطبيقات، مع إظهار أيقونة واسم التطبيق والوقت المنجز.",
                isChecked = isProductivityGoalEnabled,
                onCheckedChange = { viewModel.toggleProductivityGoalNotification(it) },
                tagPrefix = "notif_productivity_goal"
            )
        }

        // Card 17: Time Delay Expiration Alert
        item(key = "feature_time_delay_expiration") {
            NotificationFeatureCard(
                icon = Icons.Outlined.HourglassBottom,
                title = "التنبيه بانتهاء مدة التأخير الزمني",
                subtitle = "إشعار وتنبيه فوري عند انتهاء مدة التأخير الزمني المحددة وإتاحة إجراء التعديلات على إعدادات الحماية.",
                isChecked = isTimeDelayEnabled,
                onCheckedChange = { viewModel.toggleTimeDelayNotification(it) },
                tagPrefix = "notif_time_delay_expiration"
            )
        }
    }
}

@Composable
private fun NotificationFeatureCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tagPrefix: String
) {
    val borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
    val iconTint = MaterialTheme.colorScheme.onSurface

    GlassBentoCard(
        borderColor = borderColor,
        onClick = { onCheckedChange(!isChecked) },
        modifier = Modifier.testTag("${tagPrefix}_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(24.dp)
                )

                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )

                AnimatedVisibility(
                    visible = isChecked,
                    enter = scaleIn(initialScale = 0.7f, animationSpec = SaffahMotion.bouncySpring()) + fadeIn(),
                    exit = scaleOut(targetScale = 0.7f, animationSpec = SaffahMotion.snappySpring()) + fadeOut()
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CheckCircle,
                        contentDescription = "مفعّل",
                        tint = SuccessGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
