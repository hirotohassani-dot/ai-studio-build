package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

/**
 * الشاشة الرئيسية لمركز التعافي (قائمة الأقسام Bento UI)
 * بتصميم عصري أحادي اللون (Monochrome Minimalist)
 */
@Composable
fun RecoveryHubScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToPledge: () -> Unit = {},
    onNavigateToCounter: () -> Unit,
    onNavigateToDiaries: () -> Unit = {},
    onNavigateToStats: () -> Unit = {},
    onNavigateToMap: () -> Unit = {}
) {
    val unlockedPrivacySections by viewModel.unlockedPrivacySections.collectAsState()
    val isPledgeLocked = remember(unlockedPrivacySections) {
        viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_PLEDGE)
    }
    val isCounterLocked = remember(unlockedPrivacySections) {
        viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER)
    }
    val isDiariesLocked = remember(unlockedPrivacySections) {
        viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES)
    }
    val isStatsLocked = remember(unlockedPrivacySections) {
        viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_STATS)
    }
    val isMapLocked = remember(unlockedPrivacySections) {
        viewModel.isSectionLocked(com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_MAP)
    }

    var pendingUnlockAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pendingSectionKey by remember { mutableStateOf("") }
    var pendingSectionName by remember { mutableStateOf("") }
    var showBackupSheet by remember { mutableStateOf(false) }

    if (showBackupSheet) {
        com.example.ui.components.RecoveryBackupSheet(
            viewModel = viewModel,
            onDismiss = { showBackupSheet = false }
        )
    }

    if (pendingUnlockAction != null) {
        com.example.ui.components.PrivacyPinVerificationDialog(
            title = "تأكيد رمز PIN",
            subtitle = "أدخل رمز PIN لعرض قسم $pendingSectionName",
            sectionKey = pendingSectionKey,
            onDismiss = {
                pendingUnlockAction = null
                pendingSectionKey = ""
                pendingSectionName = ""
            },
            onSuccess = {
                if (pendingSectionKey.isNotBlank()) {
                    viewModel.unlockPrivacySection(pendingSectionKey)
                }
                val action = pendingUnlockAction
                pendingUnlockAction = null
                pendingSectionKey = ""
                pendingSectionName = ""
                action?.invoke()
            }
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier
                                    .size(40.dp)
                                    .saffahPressMotion()
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "مركز التعافي",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        HorizontalDivider(
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // عنوان الأقسام الفرعية
                item(key = "recovery_hub_header") {
                    Text(
                        text = "أقسام منظومة التعافي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }

                // 0. بطاقة قسم وثيقة تعهد التعافي
                item(key = "section_recovery_pledge") {
                    RecoveryHubSectionCard(
                        title = "وثيقة تعهد التعافي",
                        subtitle = "ميثاق الشرف والعهد المغلظ للنقاء والكرامة",
                        icon = Icons.Outlined.HistoryEdu,
                        isLocked = isPledgeLocked,
                        onClick = {
                            if (isPledgeLocked) {
                                pendingSectionName = "وثيقة تعهد التعافي"
                                pendingSectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_PLEDGE
                                pendingUnlockAction = onNavigateToPledge
                            } else {
                                onNavigateToPledge()
                            }
                        }
                    )
                }

                // 1. بطاقة قسم عداد التعافي المباشر
                item(key = "section_recovery_counter") {
                    RecoveryHubSectionCard(
                        title = "عداد التعافي",
                        subtitle = "تتبع فترات الثبات ومراحل الإنجاز الحية",
                        icon = Icons.Outlined.Shield,
                        isLocked = isCounterLocked,
                        onClick = {
                            if (isCounterLocked) {
                                pendingSectionName = "عداد التعافي"
                                pendingSectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_COUNTER
                                pendingUnlockAction = onNavigateToCounter
                            } else {
                                onNavigateToCounter()
                            }
                        }
                    )
                }

                // 2. بطاقة قسم مذكرات التعافي
                item(key = "section_recovery_diaries") {
                    RecoveryHubSectionCard(
                        title = "مذكرات التعافي",
                        subtitle = "تدوين المشاعر والملاحظات وتوثيق المسار",
                        icon = Icons.Outlined.EditNote,
                        isLocked = isDiariesLocked,
                        onClick = {
                            if (isDiariesLocked) {
                                pendingSectionName = "مذكرات التعافي"
                                pendingSectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_DIARIES
                                pendingUnlockAction = onNavigateToDiaries
                            } else {
                                onNavigateToDiaries()
                            }
                        }
                    )
                }

                // 3. بطاقة قسم الإحصائيات (Recovery Statistics & Danger Patterns)
                item(key = "section_recovery_statistics") {
                    RecoveryHubSectionCard(
                        title = "إحصائيات التعافي",
                        subtitle = "تحليل أخطر الأيام والأوقات وكشف أنماط الانتكاس",
                        icon = Icons.Outlined.Analytics,
                        isLocked = isStatsLocked,
                        onClick = {
                            if (isStatsLocked) {
                                pendingSectionName = "إحصائيات التعافي"
                                pendingSectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_STATS
                                pendingUnlockAction = onNavigateToStats
                            } else {
                                onNavigateToStats()
                            }
                        }
                    )
                }

                // 4. بطاقة قسم خريطة رحلة التعافي
                item(key = "section_recovery_map") {
                    RecoveryHubSectionCard(
                        title = "خريطة رحلة التعافي",
                        subtitle = "مسار المحطات والتحديات والإنجازات الشخصية",
                        icon = Icons.Outlined.Map,
                        isLocked = isMapLocked,
                        onClick = {
                            if (isMapLocked) {
                                pendingSectionName = "خريطة رحلة التعافي"
                                pendingSectionKey = com.example.util.SaffahPrivacyManager.SECTION_RECOVERY_MAP
                                pendingUnlockAction = onNavigateToMap
                            } else {
                                onNavigateToMap()
                            }
                        }
                    )
                }

                // 5. بطاقة قسم النسخ الاحتياطي الشامل لمركز التعافي
                item(key = "section_recovery_backup") {
                    RecoveryHubSectionCard(
                        title = "النسخ الاحتياطي لمركز التعافي",
                        subtitle = "تصدير واستيراد شامل للبيانات والصور والفيديوهات والتسجيلات",
                        icon = Icons.Outlined.SaveAlt,
                        isLocked = false,
                        onClick = {
                            showBackupSheet = true
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun RecoveryHubSectionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isLocked: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .saffahCardFloat(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = if (isLocked) Icons.Outlined.Lock else Icons.Outlined.ChevronLeft,
                contentDescription = if (isLocked) "محمي برمز PIN" else "فتح القسم",
                tint = if (isLocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
