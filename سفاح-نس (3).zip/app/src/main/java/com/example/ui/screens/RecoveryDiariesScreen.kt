package com.example.ui.screens

import android.Manifest
import android.app.DatePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.ui.theme.*
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.model.DiaryEmotion
import com.example.model.DiaryEmotionCategory
import com.example.model.DiaryEmotionList
import com.example.model.DiaryMediaItem
import com.example.model.DiaryMediaSource
import com.example.model.DiaryMediaType
import com.example.model.DiaryDateFilter
import com.example.model.DiarySortOrder
import com.example.model.DiaryEntryType
import com.example.model.RecoveryDiaryEntry
import com.example.util.SaffahDiaryRepository
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

private val WarmPrimary = Color(0xFFD97706) // Warm Amber
private val WarmSecondary = Color(0xFFB45309)
private val WarmSurface = Color(0xFFFFFBEB)
private val DarkWarmSurface = Color(0xFF1E1C1A)

internal fun getDiaryTypeColor(typeStr: String): Pair<Color, Color> {
    val type = com.example.model.DiaryEntryType.fromString(typeStr)
    return when (type) {
        com.example.model.DiaryEntryType.VICTORY -> Pair(Color(0xFF16A34A), Color(0xFFDCFCE7)) // Success green
        com.example.model.DiaryEntryType.DIARY -> Pair(Color(0xFFD97706), Color(0xFFFEF3C7)) // Warm amber
        com.example.model.DiaryEntryType.NOTE -> Pair(Color(0xFF475569), Color(0xFFF1F5F9)) // Slate
        com.example.model.DiaryEntryType.URGE -> Pair(Color(0xFFEA580C), Color(0xFFFFEDD5)) // Urgent orange
        com.example.model.DiaryEntryType.RELAPSE -> Pair(Color(0xFFDC2626), Color(0xFFFEE2E2)) // Red/Rose
        com.example.model.DiaryEntryType.REFLECTION -> Pair(Color(0xFF7C3AED), Color(0xFFEDE9FE)) // Purple
        com.example.model.DiaryEntryType.GOAL -> Pair(Color(0xFF0284C7), Color(0xFFE0F2FE)) // Sky blue
    }
}

internal fun getDiaryTypeIcon(typeStr: String): ImageVector {
    val type = com.example.model.DiaryEntryType.fromString(typeStr)
    return when (type) {
        com.example.model.DiaryEntryType.VICTORY -> Icons.Outlined.EmojiEvents
        com.example.model.DiaryEntryType.DIARY -> Icons.Outlined.Book
        com.example.model.DiaryEntryType.NOTE -> Icons.Outlined.StickyNote2
        com.example.model.DiaryEntryType.URGE -> Icons.Outlined.WarningAmber
        com.example.model.DiaryEntryType.RELAPSE -> Icons.Outlined.Healing
        com.example.model.DiaryEntryType.REFLECTION -> Icons.Outlined.SelfImprovement
        com.example.model.DiaryEntryType.GOAL -> Icons.Outlined.Flag
    }
}

/**
 * شاشة مذكرات التعافي الرئيسية
 * بتصميم نظيف وبسيط وعصري (Minimalist Bento UI) بألوان دافئة ومريحة
 * بدون إيموجيات مع أيقونات احترافية وتنسيق 24h دقيق
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecoveryDiariesScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val diaryEntries by viewModel.diaryEntries.collectAsState()
    val trashedEntries by viewModel.trashedDiaryEntries.collectAsState()

    var showEditorDialog by remember { mutableStateOf(false) }
    var entryToEdit by remember { mutableStateOf<RecoveryDiaryEntry?>(null) }
    var selectedEntryForDetail by remember { mutableStateOf<RecoveryDiaryEntry?>(null) }
    var entryToDelete by remember { mutableStateOf<RecoveryDiaryEntry?>(null) }

    var showTrashScreen by remember { mutableStateOf(false) }
    var entryToPermanentlyDelete by remember { mutableStateOf<RecoveryDiaryEntry?>(null) }
    var showEmptyTrashConfirm by remember { mutableStateOf(false) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf<String?>(null) }
    var selectedDateFilter by remember { mutableStateOf(DiaryDateFilter.ALL) }
    var customStartDate by remember { mutableStateOf<Long?>(null) }
    var customEndDate by remember { mutableStateOf<Long?>(null) }
    var selectedSortOrder by remember { mutableStateOf(DiarySortOrder.NEWEST_FIRST) }
    var showFilterBottomSheet by remember { mutableStateOf(false) }

    val isTypeFilterActive = selectedTypeFilter != null
    val isDateFilterActive = selectedDateFilter != DiaryDateFilter.ALL
    val isSortFilterActive = selectedSortOrder != DiarySortOrder.NEWEST_FIRST
    val activeFiltersCount = (if (isTypeFilterActive) 1 else 0) +
            (if (isDateFilterActive) 1 else 0) +
            (if (isSortFilterActive) 1 else 0)
    val hasActiveFilters = activeFiltersCount > 0

    val filteredEntries = remember(
        diaryEntries,
        searchQuery,
        selectedTypeFilter,
        selectedDateFilter,
        customStartDate,
        customEndDate,
        selectedSortOrder
    ) {
        var list = diaryEntries

        // 1. فلترة حسب نوع المذكرة
        if (selectedTypeFilter != null) {
            val target = selectedTypeFilter!!
            list = list.filter { (it.type.ifBlank { "ملاحظة" }) == target }
        }

        // 2. فلترة حسب الفترة الزمنية
        when (selectedDateFilter) {
            DiaryDateFilter.ALL -> {}
            DiaryDateFilter.TODAY -> {
                val startOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val endOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 23)
                    set(Calendar.MINUTE, 59)
                    set(Calendar.SECOND, 59)
                    set(Calendar.MILLISECOND, 999)
                }.timeInMillis
                list = list.filter { it.createdAt in startOfToday..endOfToday }
            }
            DiaryDateFilter.LAST_7_DAYS -> {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -7)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                list = list.filter { it.createdAt >= cal.timeInMillis }
            }
            DiaryDateFilter.LAST_30_DAYS -> {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -30)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                list = list.filter { it.createdAt >= cal.timeInMillis }
            }
            DiaryDateFilter.THIS_MONTH -> {
                val startOfMonth = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                list = list.filter { it.createdAt >= startOfMonth }
            }
            DiaryDateFilter.CUSTOM -> {
                if (customStartDate != null || customEndDate != null) {
                    list = list.filter { entry ->
                        val afterStart = customStartDate?.let { entry.createdAt >= it } ?: true
                        val beforeEnd = customEndDate?.let { entry.createdAt <= it } ?: true
                        afterStart && beforeEnd
                    }
                }
            }
        }

        // 3. فلترة حسب نص البحث
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter { entry ->
                entry.title.contains(q, ignoreCase = true) ||
                entry.content.contains(q, ignoreCase = true) ||
                entry.type.contains(q, ignoreCase = true) ||
                entry.emotions.any { it.contains(q, ignoreCase = true) }
            }
        }

        // 4. ترتيب المذكرات
        when (selectedSortOrder) {
            DiarySortOrder.NEWEST_FIRST -> list.sortedByDescending { it.createdAt }
            DiarySortOrder.OLDEST_FIRST -> list.sortedBy { it.createdAt }
            DiarySortOrder.LAST_UPDATED -> list.sortedByDescending { it.updatedAt }
            DiarySortOrder.LONGEST -> list.sortedByDescending { it.content.length }
            DiarySortOrder.SHORTEST -> list.sortedBy { it.content.length }
        }
    }

    BackHandler(enabled = showFilterBottomSheet || showTrashScreen || selectedEntryForDetail != null || searchQuery.isNotEmpty() || hasActiveFilters) {
        if (showFilterBottomSheet) {
            showFilterBottomSheet = false
        } else if (selectedEntryForDetail != null) {
            selectedEntryForDetail = null
        } else if (showTrashScreen) {
            showTrashScreen = false
        } else if (searchQuery.isNotEmpty()) {
            searchQuery = ""
        } else if (hasActiveFilters) {
            selectedTypeFilter = null
            selectedDateFilter = DiaryDateFilter.ALL
            customStartDate = null
            customEndDate = null
            selectedSortOrder = DiarySortOrder.NEWEST_FIRST
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!showTrashScreen) {
                            IconButton(
                                onClick = {
                                    viewModel.audioPlayer.stopAudio()
                                    onBack()
                                },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "مذكرات التعافي",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (searchQuery.isNotBlank() || hasActiveFilters) "${filteredEntries.size} من أصل ${diaryEntries.size} مذكرة" else "${diaryEntries.size} مذكرة مسجلة",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (searchQuery.isNotBlank() || hasActiveFilters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (searchQuery.isNotBlank() || hasActiveFilters) FontWeight.Bold else FontWeight.Normal
                                )
                            }

                            // حاوية سلة المحذوفات بتصميم متوافق ومثالي للوضع الليلي والنهاري
                            Surface(
                                onClick = {
                                    viewModel.audioPlayer.stopAudio()
                                    showTrashScreen = true
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                                modifier = Modifier.clip(RoundedCornerShape(10.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "سلة المحذوفات",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    viewModel.audioPlayer.stopAudio()
                                    showTrashScreen = false
                                },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "رجوع للمذكرات",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "سلة المحذوفات",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${trashedEntries.size} مذكرة محذوفة",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (trashedEntries.isNotEmpty()) {
                                IconButton(
                                    onClick = { showEmptyTrashConfirm = true },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteSweep,
                                        contentDescription = "إفراغ السلة",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            },
            floatingActionButton = {
                if (!showTrashScreen) {
                    FloatingActionButton(
                        onClick = {
                            entryToEdit = null
                            showEditorDialog = true
                        },
                        modifier = Modifier.saffahPressMotion(),
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        shape = RoundedCornerShape(16.dp),
                        elevation = FloatingActionButtonDefaults.elevation(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "تدوين مذكرة جديدة",
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (showTrashScreen) {
                    TrashedDiariesView(
                        trashedEntries = trashedEntries,
                        onEntryClick = { selectedEntryForDetail = it },
                        onRestore = { entry ->
                            viewModel.restoreDiaryEntry(entry.id)
                        },
                        onPermanentDelete = { entry ->
                            entryToPermanentlyDelete = entry
                        }
                    )
                } else if (diaryEntries.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            modifier = Modifier.size(80.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Outlined.EditNote,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "لا توجد مذكرات حتى الآن",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "سجل مشاعرك، صوتك، أو أفكارك في لحظات القوة أو التحدي لمتابعة تقدمك في رحلة التعافي.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                entryToEdit = null
                                showEditorDialog = true
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تدوين أول مذكرة",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // صف البحث والفلترة الذكي المتناسق
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp),
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "بحث",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        if (searchQuery.isEmpty()) {
                                            Text(
                                                text = "البحث في كل المذكرات...",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                            )
                                        }
                                        BasicTextField(
                                            value = searchQuery,
                                            onValueChange = { searchQuery = it },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                                color = MaterialTheme.colorScheme.onSurface
                                            ),
                                            cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(
                                            onClick = { searchQuery = "" },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "مسح البحث",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // زر الفلترة الأنيق المتناسق في الارتفاع مع حقل البحث
                            Surface(
                                onClick = { showFilterBottomSheet = true },
                                shape = RoundedCornerShape(12.dp),
                                color = if (hasActiveFilters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                border = BorderStroke(
                                    1.dp,
                                    if (hasActiveFilters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier
                                    .height(44.dp)
                                    .saffahPressMotion()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Tune,
                                        contentDescription = "فلترة المذكرات",
                                        tint = if (hasActiveFilters) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "فلترة",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (hasActiveFilters) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (hasActiveFilters) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier
                                                .size(18.dp)
                                                .saffahPulseBadge()
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = activeFiltersCount.toString(),
                                                    color = MaterialTheme.colorScheme.primary,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // شريط الفلاتر النشطة (يظهر حصرياً عند وجود فلاتر مطبقة للحفاظ على نظافة الواجهة)
                        if (hasActiveFilters) {
                            val activeDateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.US) }
                            LazyRow(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (selectedTypeFilter != null) {
                                    item(key = "active_filter_type") {
                                        InputChip(
                                            selected = true,
                                            onClick = { selectedTypeFilter = null },
                                            label = {
                                                Text(
                                                    text = "النوع: $selectedTypeFilter",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            },
                                            trailingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "إلغاء فلتر النوع",
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }
                                if (selectedDateFilter != DiaryDateFilter.ALL) {
                                    item(key = "active_filter_date") {
                                        val label = if (selectedDateFilter == DiaryDateFilter.CUSTOM && (customStartDate != null || customEndDate != null)) {
                                            val s = customStartDate?.let { activeDateFormat.format(Date(it)) } ?: "..."
                                            val e = customEndDate?.let { activeDateFormat.format(Date(it)) } ?: "..."
                                            "الفترة: $s - $e"
                                        } else {
                                            "الفترة: ${selectedDateFilter.displayName}"
                                        }
                                        InputChip(
                                            selected = true,
                                            onClick = {
                                                selectedDateFilter = DiaryDateFilter.ALL
                                                customStartDate = null
                                                customEndDate = null
                                            },
                                            label = {
                                                Text(
                                                    text = label,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            },
                                            trailingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "إلغاء فلتر الفترة",
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }
                                if (selectedSortOrder != DiarySortOrder.NEWEST_FIRST) {
                                    item(key = "active_filter_sort") {
                                        InputChip(
                                            selected = true,
                                            onClick = { selectedSortOrder = DiarySortOrder.NEWEST_FIRST },
                                            label = {
                                                Text(
                                                    text = "ترتيب: ${selectedSortOrder.displayName}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            },
                                            trailingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "إلغاء الترتيب المخصص",
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }
                                item(key = "clear_all_filters_btn") {
                                    TextButton(
                                        onClick = {
                                            selectedTypeFilter = null
                                            selectedDateFilter = DiaryDateFilter.ALL
                                            customStartDate = null
                                            customEndDate = null
                                            selectedSortOrder = DiarySortOrder.NEWEST_FIRST
                                        },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "مسح الكل",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        if (filteredEntries.isEmpty() && (searchQuery.isNotBlank() || hasActiveFilters)) {
                            // Empty state
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.size(64.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Outlined.SearchOff,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = "لم يتم العثور على مذكرات",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val emptyMsg = if (hasActiveFilters && searchQuery.isNotBlank()) {
                                        "لا توجد نتائج تطابق البحث «$searchQuery» وخيارات الفلترة المحددة."
                                    } else if (hasActiveFilters) {
                                        "لا توجد مذكرات مطابقة لخيارات الفلترة المحددة."
                                    } else {
                                        "لا توجد أي مذكرات مطابقة للبحث: «$searchQuery»"
                                    }
                                    Text(
                                        text = emptyMsg,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    OutlinedButton(
                                        onClick = {
                                            searchQuery = ""
                                            selectedTypeFilter = null
                                            selectedDateFilter = DiaryDateFilter.ALL
                                            customStartDate = null
                                            customEndDate = null
                                            selectedSortOrder = DiarySortOrder.NEWEST_FIRST
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("عرض جميع المذكرات")
                                    }
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                if (searchQuery.isNotBlank() || hasActiveFilters) {
                                    item(key = "search_stats_header") {
                                        val filterLabel = if (selectedTypeFilter != null) "نوع «$selectedTypeFilter» • " else ""
                                        val dateLabel = if (selectedDateFilter != DiaryDateFilter.ALL) "فترة «${selectedDateFilter.displayName}» • " else ""
                                        val sortLabel = if (selectedSortOrder != DiarySortOrder.NEWEST_FIRST) "ترتيب «${selectedSortOrder.displayName}» • " else ""
                                        Text(
                                            text = "$filterLabel$dateLabel$sortLabel${filteredEntries.size} من أصل ${diaryEntries.size} مذكرة",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                items(
                                    items = filteredEntries,
                                    key = { it.id }
                                ) { entry ->
                                    Box(
                                        modifier = Modifier.animateItem(
                                            fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                                            fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                                            placementSpec = androidx.compose.animation.core.spring(
                                                stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                                dampingRatio = 0.8f
                                            )
                                        )
                                    ) {
                                        DiaryEntryCard(
                                            entry = entry,
                                            onClick = {
                                                selectedEntryForDetail = entry
                                            },
                                            onEdit = {
                                                entryToEdit = entry
                                                showEditorDialog = true
                                            },
                                            onDelete = {
                                                entryToDelete = entry
                                            }
                                        )
                                    }
                                }
                                // Bottom spacer for FAB
                                item {
                                    Spacer(modifier = Modifier.height(80.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Bottom Sheet for Filtering and Sorting Diaries
    if (showFilterBottomSheet) {
        DiaryFilterBottomSheet(
            allEntries = diaryEntries,
            currentTypeFilter = selectedTypeFilter,
            currentDateFilter = selectedDateFilter,
            currentCustomStartDate = customStartDate,
            currentCustomEndDate = customEndDate,
            currentSortOrder = selectedSortOrder,
            onApply = { type, date, start, end, sort ->
                selectedTypeFilter = type
                selectedDateFilter = date
                customStartDate = start
                customEndDate = end
                selectedSortOrder = sort
                showFilterBottomSheet = false
            },
            onReset = {
                selectedTypeFilter = null
                selectedDateFilter = DiaryDateFilter.ALL
                customStartDate = null
                customEndDate = null
                selectedSortOrder = DiarySortOrder.NEWEST_FIRST
            },
            onDismiss = { showFilterBottomSheet = false }
        )
    }

    // Modal Sheet / Dialog for Creating or Editing Diary Entry
    if (showEditorDialog) {
        DiaryEditorDialog(
            viewModel = viewModel,
            entryToEdit = entryToEdit,
            onDismiss = { showEditorDialog = false },
            onSave = { newOrUpdatedEntry ->
                viewModel.saveDiaryEntry(newOrUpdatedEntry)
                showEditorDialog = false
            }
        )
    }

    // Detail View Dialog
    selectedEntryForDetail?.let { entry ->
        DiaryDetailDialog(
            viewModel = viewModel,
            entry = entry,
            isFromTrash = showTrashScreen,
            onDismiss = {
                viewModel.audioPlayer.stopAudio()
                selectedEntryForDetail = null
            },
            onEdit = {
                viewModel.audioPlayer.stopAudio()
                selectedEntryForDetail = null
                entryToEdit = entry
                showEditorDialog = true
            },
            onDelete = {
                viewModel.audioPlayer.stopAudio()
                selectedEntryForDetail = null
                entryToDelete = entry
            },
            onRestore = {
                viewModel.audioPlayer.stopAudio()
                selectedEntryForDetail = null
                viewModel.restoreDiaryEntry(entry.id)
            },
            onPermanentDelete = {
                viewModel.audioPlayer.stopAudio()
                selectedEntryForDetail = null
                entryToPermanentlyDelete = entry
            }
        )
    }

    // Move to Trash Confirmation Dialog
    entryToDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { entryToDelete = null },
            shape = RoundedCornerShape(24.dp),
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            title = {
                Text(
                    text = "نقل إلى سلة المحذوفات",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = entry.title.ifBlank { "مذكرة بدون عنوان" },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "هل تريد نقل هذه المذكرة إلى سلة المحذوفات؟ يمكنك استرجاعها لاحقاً في أي وقت.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { entryToDelete = null },
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        onClick = {
                            viewModel.deleteDiaryEntry(entry.id)
                            entryToDelete = null
                        },
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("نقل للسلة", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = null
        )
    }

    // Permanent Delete Confirmation Dialog
    entryToPermanentlyDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { entryToPermanentlyDelete = null },
            shape = RoundedCornerShape(24.dp),
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            title = {
                Text(
                    text = "حذف نهائي للمذكرة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = entry.title.ifBlank { "مذكرة بدون عنوان" },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "هل أنت متأكد من الحذف النهائي لهذه المذكرة وكافة ملفاتها؟ سيتم محوها تماماً ولن يتبقى لها أي أثر، ولا يمكن استرجاعها مطلقاً.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { entryToPermanentlyDelete = null },
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        onClick = {
                            viewModel.permanentlyDeleteDiaryEntry(entry.id)
                            entryToPermanentlyDelete = null
                        },
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Outlined.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حذف نهائي", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = null
        )
    }

    // Empty Trash Confirmation Dialog
    if (showEmptyTrashConfirm) {
        AlertDialog(
            onDismissRequest = { showEmptyTrashConfirm = false },
            shape = RoundedCornerShape(24.dp),
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            title = {
                Text(
                    text = "إفراغ سلة المحذوفات",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف جميع المذكرات الموجودة في السلة (${trashedEntries.size} مذكرة) نهائياً؟ سيتم مسح كافة ملفاتها بالكامل بدون أي أثر.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showEmptyTrashConfirm = false },
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        onClick = {
                            viewModel.emptyTrash()
                            showEmptyTrashConfirm = false
                        },
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("إفراغ السلة", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = null
        )
    }
}

/**
 * بطاقة المذكرة المحفوظة في القائمة
 * تعرض: العنوان، التاريخ والوقت بتنسيق 24h، عدد الوسائط الموجودة مع أيقوناتها، وأزرار التعديل والحذف
 */
@Composable
private fun DiaryEntryCard(
    entry: RecoveryDiaryEntry,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.US) }
    val formattedDate = remember(entry.createdAt) { sdf.format(Date(entry.createdAt)) }

    val audioCount = remember(entry.mediaList) { entry.mediaList.count { it.type == DiaryMediaType.AUDIO } }
    val imageCount = remember(entry.mediaList) { entry.mediaList.count { it.type == DiaryMediaType.IMAGE } }
    val videoCount = remember(entry.mediaList) { entry.mediaList.count { it.type == DiaryMediaType.VIDEO } }
    val totalMediaCount = entry.mediaList.size

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .saffahCardFloat(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // الصف العلوي: التاريخ بتنسيق 24h + أزرار التعديل والحذف
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // نوع المذكرة ووقت وتاريخ حفظ المذكرة
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val currentType = entry.type.ifBlank { "ملاحظة" }
                    val (typeColor, typeBg) = getDiaryTypeColor(currentType)
                    Surface(
                        color = typeBg,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = getDiaryTypeIcon(currentType),
                                contentDescription = null,
                                tint = typeColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = currentType,
                                color = typeColor,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Schedule,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = formattedDate,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // أزرار التعديل والحذف
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = "تعديل المذكرة",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Delete,
                            contentDescription = "حذف المذكرة",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // عنوان المذكرة
            Text(
                text = entry.title.ifBlank { "مذكرة بدون عنوان" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // مقتطف النص
            if (entry.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = entry.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 20.sp
                )
            }

            // وسوم المشاعر المحددة في المذكرة
            if (entry.emotions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                val entryEmotions = remember(entry.emotions) {
                    entry.emotions.mapNotNull { DiaryEmotionList.findById(it) }
                }
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(entryEmotions) { emotion ->
                        val catColor = getEmotionCategoryColor(emotion.category)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = catColor.copy(alpha = 0.1f),
                            border = BorderStroke(0.8.dp, catColor.copy(alpha = 0.35f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = emotion.emoji,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = emotion.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // قسم إحصائيات الوسائط إن وجدت
            if (totalMediaCount > 0) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // بادج الصور
                    if (imageCount > 0) {
                        MediaBadge(
                            icon = Icons.Default.Image,
                            text = "$imageCount صور",
                            tint = Color(0xFF0284C7)
                        )
                    }

                    // بادج الصوتيات
                    if (audioCount > 0) {
                        MediaBadge(
                            icon = Icons.Default.Mic,
                            text = "$audioCount صوت",
                            tint = Color(0xFF16A34A)
                        )
                    }

                    // بادج الفيديو
                    if (videoCount > 0) {
                        MediaBadge(
                            icon = Icons.Default.Videocam,
                            text = "$videoCount فيديو",
                            tint = Color(0xFFEA580C)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Text(
                        text = "عرض التفاصيل",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

/**
 * واجهة سلة محذوفات المذكرات
 */
@Composable
private fun TrashedDiariesView(
    trashedEntries: List<RecoveryDiaryEntry>,
    onEntryClick: (RecoveryDiaryEntry) -> Unit,
    onRestore: (RecoveryDiaryEntry) -> Unit,
    onPermanentDelete: (RecoveryDiaryEntry) -> Unit
) {
    if (trashedEntries.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "سلة المحذوفات فارغة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "المذكرات التي تقوم بحذفها تظهر هنا مؤقتاً. يمكنك استرجاعها في أي وقت أو حذفها نهائياً بحيث لا يبقى لها أي أثر.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "المذكرات هنا محفوظة مؤقتاً، يمكنك استرجاع أي مذكرة لتعود لقائمتك، أو حذفها نهائياً بحيث لا يبقى لها أي أثر.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            items(
                items = trashedEntries,
                key = { it.id }
            ) { entry ->
                Box(
                    modifier = Modifier.animateItem(
                        fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                        fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                        placementSpec = androidx.compose.animation.core.spring(
                            stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                            dampingRatio = 0.8f
                        )
                    )
                ) {
                    TrashedDiaryCard(
                        entry = entry,
                        onClick = { onEntryClick(entry) },
                        onRestore = { onRestore(entry) },
                        onPermanentDelete = { onPermanentDelete(entry) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

/**
 * بطاقة المذكرة المحذوفة داخل سلة المحذوفات
 */
@Composable
private fun TrashedDiaryCard(
    entry: RecoveryDiaryEntry,
    onClick: () -> Unit,
    onRestore: () -> Unit,
    onPermanentDelete: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.US) }
    val formattedDate = remember(entry.createdAt) { sdf.format(Date(entry.createdAt)) }

    val audioCount = remember(entry.mediaList) { entry.mediaList.count { it.type == DiaryMediaType.AUDIO } }
    val imageCount = remember(entry.mediaList) { entry.mediaList.count { it.type == DiaryMediaType.IMAGE } }
    val videoCount = remember(entry.mediaList) { entry.mediaList.count { it.type == DiaryMediaType.VIDEO } }
    val totalMediaCount = entry.mediaList.size

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .saffahPressMotion(targetScale = 0.985f)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // الصف العلوي: التاريخ + نوع المذكرة + شارة محذوفة
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val currentType = entry.type.ifBlank { "ملاحظة" }
                    val (typeColor, typeBg) = getDiaryTypeColor(currentType)
                    Surface(
                        color = typeBg,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = getDiaryTypeIcon(currentType),
                                contentDescription = null,
                                tint = typeColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = currentType,
                                color = typeColor,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.Schedule,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = formattedDate,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = "محذوفة",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // عنوان المذكرة
            Text(
                text = entry.title.ifBlank { "مذكرة بدون عنوان" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // مقتطف النص
            if (entry.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = entry.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 20.sp
                )
            }

            // وسوم المشاعر
            if (entry.emotions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                val entryEmotions = remember(entry.emotions) {
                    entry.emotions.mapNotNull { DiaryEmotionList.findById(it) }
                }
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(entryEmotions) { emotion ->
                        val catColor = getEmotionCategoryColor(emotion.category)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = catColor.copy(alpha = 0.1f),
                            border = BorderStroke(0.8.dp, catColor.copy(alpha = 0.35f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = emotion.emoji,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = emotion.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // قسم إحصائيات الوسائط إن وجدت
            if (totalMediaCount > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (audioCount > 0) {
                        MediaBadge(
                            icon = Icons.Outlined.GraphicEq,
                            text = "$audioCount صوت",
                            tint = Color(0xFF0166FF)
                        )
                    }
                    if (imageCount > 0) {
                        MediaBadge(
                            icon = Icons.Outlined.Image,
                            text = "$imageCount صورة",
                            tint = Color(0xFF059669)
                        )
                    }
                    if (videoCount > 0) {
                        MediaBadge(
                            icon = Icons.Default.Videocam,
                            text = "$videoCount فيديو",
                            tint = Color(0xFFEA580C)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
            )
            Spacer(modifier = Modifier.height(12.dp))

            // أزرار الإجراءات: استرجاع وحذف نهائي
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // زر استرجاع
                OutlinedButton(
                    onClick = onRestore,
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .saffahPressMotion(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color(0xFF0166FF)
                    ),
                    border = BorderStroke(1.dp, Color(0xFF0166FF).copy(alpha = 0.5f)),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.RestoreFromTrash,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "استرجاع",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                // زر حذف نهائي
                Button(
                    onClick = onPermanentDelete,
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .saffahPressMotion(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteForever,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "حذف نهائي",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun MediaBadge(
    icon: ImageVector,
    text: String,
    tint: Color
) {
    Surface(
        color = tint.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = tint
            )
        }
    }
}

/**
 * نافذة محرر المذكرات (إنشاء / تعديل)
 * تتيح كتابة العنوان، نص المذكرة، تسجيل صوت فائق النقاء، تسجيل فيديو،
 * ورفع ملفات صوتية، صور، وفيديوهات مع تمييز المصدر
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DiaryEditorDialog(
    viewModel: MainViewModel,
    entryToEdit: RecoveryDiaryEntry?,
    onDismiss: () -> Unit,
    onSave: (RecoveryDiaryEntry) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(entryToEdit?.title ?: "") }
    var content by remember { mutableStateOf(entryToEdit?.content ?: "") }
    var mediaList by remember { mutableStateOf(entryToEdit?.mediaList ?: emptyList()) }
    var selectedEmotions by remember { mutableStateOf(entryToEdit?.emotions ?: emptyList()) }
    var selectedType by remember { mutableStateOf(entryToEdit?.type?.ifBlank { "ملاحظة" } ?: "ملاحظة") }
    var showEmotionsPickerSheet by remember { mutableStateOf(false) }

    // Audio recording state
    var isAudioRecording by remember { mutableStateOf(false) }
    var recordingDurationSec by remember { mutableStateOf(0) }
    var recordingFile by remember { mutableStateOf<File?>(null) }

    // Coroutine scope
    val coroutineScope = rememberCoroutineScope()

    var mediaItemToRename by remember { mutableStateOf<DiaryMediaItem?>(null) }
    var previewMediaItem by remember { mutableStateOf<DiaryMediaItem?>(null) }
    var pendingCameraAction by remember { mutableStateOf<String?>(null) } // "PHOTO" or "VIDEO"

    // Photo Capture Launcher
    var tempPhotoFile by remember { mutableStateOf<File?>(null) }
    var tempPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val photoCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { isSuccess ->
        if (isSuccess && tempPhotoFile != null && tempPhotoFile!!.exists() && tempPhotoFile!!.length() > 0) {
            coroutineScope.launch(Dispatchers.IO) {
                val compressedFile = com.example.util.SaffahMediaCompressor.compressImageFile(tempPhotoFile!!)
                val photoItem = DiaryMediaItem(
                    id = UUID.randomUUID().toString(),
                    type = DiaryMediaType.IMAGE,
                    source = DiaryMediaSource.RECORDED_IN_APP,
                    filePath = compressedFile.absolutePath,
                    fileName = "صورة ملتقطة",
                    fileSizeBytes = compressedFile.length(),
                    createdAt = System.currentTimeMillis()
                )
                withContext(Dispatchers.Main) {
                    mediaList = mediaList + photoItem
                    viewModel.showFeedback("تم تأمين وحفظ الصورة بنجاح")
                }
            }
        }
    }

    // Permissions launchers
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val audioFile = SaffahDiaryRepository.createInternalAudioFile(context)
            recordingFile = audioFile
            if (viewModel.audioRecorder.startRecording(audioFile)) {
                isAudioRecording = true
                recordingDurationSec = 0
            } else {
                viewModel.showFeedback("تعذر بدء التسجيل الصوتي")
            }
        } else {
            viewModel.showFeedback("يرجى منح صلاحية الميكروفون لتسجيل الصوت")
        }
    }

    // Video Recording Launcher
    var tempVideoFile by remember { mutableStateOf<File?>(null) }
    var tempVideoUri by remember { mutableStateOf<Uri?>(null) }

    val videoCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { isSuccess ->
        if (isSuccess && tempVideoFile != null && tempVideoFile!!.exists() && tempVideoFile!!.length() > 0) {
            coroutineScope.launch(Dispatchers.IO) {
                withContext(Dispatchers.Main) {
                    viewModel.showFeedback("جاري معالجة وتأمين الفيديو...")
                }
                val compressedVideo = com.example.util.SaffahMediaCompressor.compressVideoFile(tempVideoFile!!)
                var durationSec = 0
                try {
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(compressedVideo.absolutePath)
                    val durStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                    retriever.release()
                    durationSec = ((durStr?.toLongOrNull() ?: 0L) / 1000L).toInt()
                } catch (_: Exception) {}

                val videoItem = DiaryMediaItem(
                    id = UUID.randomUUID().toString(),
                    type = DiaryMediaType.VIDEO,
                    source = DiaryMediaSource.RECORDED_IN_APP,
                    filePath = compressedVideo.absolutePath,
                    fileName = "فيديو مسجل",
                    durationSeconds = durationSec,
                    fileSizeBytes = compressedVideo.length(),
                    createdAt = System.currentTimeMillis()
                )
                withContext(Dispatchers.Main) {
                    mediaList = mediaList + videoItem
                    viewModel.showFeedback("تم تأمين وحفظ الفيديو بنجاح")
                }
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            if (pendingCameraAction == "PHOTO") {
                val pFile = SaffahDiaryRepository.createInternalImageFile(context)
                tempPhotoFile = pFile
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pFile)
                tempPhotoUri = uri
                photoCaptureLauncher.launch(uri)
            } else {
                val vFile = SaffahDiaryRepository.createInternalVideoFile(context)
                tempVideoFile = vFile
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", vFile)
                tempVideoUri = uri
                videoCaptureLauncher.launch(uri)
            }
        } else {
            val msg = if (pendingCameraAction == "PHOTO") "يرجى منح صلاحية الكاميرا لالتقاط الصورة" else "يرجى منح صلاحية الكاميرا لتسجيل الفيديو"
            viewModel.showFeedback(msg)
        }
    }

    // File pickers
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                uris.forEach { uri ->
                    val item = SaffahDiaryRepository.importMediaFromUri(
                        context = context,
                        uri = uri,
                        type = DiaryMediaType.IMAGE,
                        source = DiaryMediaSource.UPLOADED_FROM_STORAGE
                    )
                    if (item != null) {
                        mediaList = mediaList + item
                    }
                }
                viewModel.showFeedback("تم استيراد وضغط الصور بنجاح")
            }
        }
    }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                val item = SaffahDiaryRepository.importMediaFromUri(
                    context = context,
                    uri = it,
                    type = DiaryMediaType.AUDIO,
                    source = DiaryMediaSource.UPLOADED_FROM_STORAGE
                )
                if (item != null) {
                    mediaList = mediaList + item
                    viewModel.showFeedback("تم استيراد الملف الصوتي بنجاح")
                }
            }
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                viewModel.showFeedback("جاري استيراد وضغط الفيديو...")
                val item = SaffahDiaryRepository.importMediaFromUri(
                    context = context,
                    uri = it,
                    type = DiaryMediaType.VIDEO,
                    source = DiaryMediaSource.UPLOADED_FROM_STORAGE
                )
                if (item != null) {
                    mediaList = mediaList + item
                    viewModel.showFeedback("تم ضغط واستيراد الفيديو بنجاح")
                }
            }
        }
    }

    // Audio recording timer loop
    LaunchedEffect(isAudioRecording) {
        if (isAudioRecording) {
            while (isActive && isAudioRecording) {
                delay(1000L)
                recordingDurationSec++
            }
        }
    }

    Dialog(
        onDismissRequest = {
            if (isAudioRecording) {
                viewModel.audioRecorder.stopRecording()
            }
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            color = MaterialTheme.colorScheme.background
        ) {
            Scaffold(
                topBar = {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        shadowElevation = 1.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    if (isAudioRecording) {
                                        viewModel.audioRecorder.stopRecording()
                                    }
                                    onDismiss()
                                },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(
                                text = if (entryToEdit == null) "تدوين مذكرة جديدة" else "تعديل المذكرة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )

                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .clickable {
                                        if (title.isBlank() && content.isBlank() && mediaList.isEmpty() && selectedEmotions.isEmpty()) {
                                            viewModel.showFeedback("يرجى كتابة عنوان أو نص أو اختيار مشاعر أو إرفاق وسائط للمذكرة")
                                            return@clickable
                                        }
                                        val now = System.currentTimeMillis()
                                        val entry = RecoveryDiaryEntry(
                                            id = entryToEdit?.id ?: UUID.randomUUID().toString(),
                                            title = title.trim(),
                                            content = content.trim(),
                                            createdAt = entryToEdit?.createdAt ?: now,
                                            updatedAt = now,
                                            mediaList = mediaList,
                                            emotions = selectedEmotions,
                                            type = selectedType
                                        )
                                        onSave(entry)
                                    }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.Save,
                                        contentDescription = "حفظ المذكرة",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                },
                containerColor = MaterialTheme.colorScheme.background
            ) { padding ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // حقل نوع المذكرة
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "نوع المذكرة",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    val (typeColor, typeBg) = getDiaryTypeColor(selectedType)
                                    Surface(
                                        color = typeBg,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = selectedType,
                                            color = typeColor,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    items(
                                        items = com.example.model.DiaryEntryType.ALL_TYPES,
                                        key = { it.name }
                                    ) { entryType ->
                                        val isSelected = selectedType == entryType.displayName
                                        val (tColor, tBg) = getDiaryTypeColor(entryType.displayName)
                                        Surface(
                                            onClick = { selectedType = entryType.displayName },
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (isSelected) tBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            border = BorderStroke(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) tColor else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = getDiaryTypeIcon(entryType.displayName),
                                                    contentDescription = null,
                                                    tint = if (isSelected) tColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Text(
                                                    text = entryType.displayName,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) tColor else MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // حقل عنوان المذكرة
                    item {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("عنوان المذكرة") },
                            placeholder = { Text("اكتب عنواناً مختصراً للمذكرة...") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // حقل نص ومشاعر المذكرة
                    item {
                        OutlinedTextField(
                            value = content,
                            onValueChange = { content = it },
                            label = { Text("نص المذكرة والأفكار") },
                            placeholder = { Text("سجل ما يدور في خاطرك، محفزاتك، أو مشاعر الانتصار والعزيمة...") },
                            minLines = 5,
                            maxLines = 12,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // قسم تحديد المشاعر (إيجابية، مُحايدة، وضغوط وتحديات)
                    item {
                        EmotionsSelectorSection(
                            selectedEmotions = selectedEmotions,
                            onOpenPicker = { showEmotionsPickerSheet = true },
                            onRemoveEmotion = { emotionId ->
                                selectedEmotions = selectedEmotions - emotionId
                            },
                            onClearEmotions = {
                                selectedEmotions = emptyList()
                            }
                        )
                    }

                    // لوحة تسجيل الصوت المباشر بتصميم عصري وأنيق (Bento UI) مع نبض صوتي
                    if (isAudioRecording) {
                        item {
                            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                            val pulseScale by infiniteTransition.animateFloat(
                                initialValue = 1f,
                                targetValue = 1.15f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(800, easing = FastOutSlowInEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "mic_scale"
                            )
                            val waveAlpha by infiniteTransition.animateFloat(
                                initialValue = 0.3f,
                                targetValue = 0.9f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(600, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "wave_alpha"
                            )

                            val isDarkRecording = isAppInDarkTheme()
                            val recBgColor = if (isDarkRecording) Color(0xFF241416) else Color(0xFFFEF2F2).copy(alpha = 0.6f)
                            val recBorderColor = if (isDarkRecording) Color(0xFF5A1E24) else Color(0xFFFECDD3)
                            val recHeaderTextColor = if (isDarkRecording) Color(0xFFFCA5A5) else Color(0xFFB91C1C)
                            val recTimerTextColor = MaterialTheme.colorScheme.onSurface

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = recBgColor,
                                border = BorderStroke(1.5.dp, recBorderColor),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    // أيقونة الميكروفون مع تأثير النبض العصري
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFEF4444).copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .scale(pulseScale)
                                                .clip(CircleShape)
                                                .background(Color(0xFFEF4444)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Mic,
                                                contentDescription = "تسجيل جاري",
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = "جاري تسجيل الصوت...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = recHeaderTextColor
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // عداد التوقيت بتصميم خط نقي وعصري
                                    val minutes = recordingDurationSec / 60
                                    val seconds = recordingDurationSec % 60
                                    Text(
                                        text = String.format(Locale.US, "%02d:%02d", minutes, seconds),
                                        style = MaterialTheme.typography.displaySmall,
                                        fontWeight = FontWeight.Black,
                                        color = recTimerTextColor,
                                        fontSize = 32.sp
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // محاكاة موجات صوتية ديناميكية وبسيطة
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.height(16.dp)
                                    ) {
                                        listOf(8.dp, 14.dp, 16.dp, 10.dp, 15.dp, 12.dp, 16.dp, 9.dp).forEachIndexed { idx, h ->
                                            val barScale = if (idx % 2 == 0) waveAlpha else (1.2f - waveAlpha)
                                            Box(
                                                modifier = Modifier
                                                    .width(3.dp)
                                                    .height(h * barScale)
                                                    .clip(RoundedCornerShape(2.dp))
                                                    .background(Color(0xFFEF4444).copy(alpha = if (isDarkRecording) 0.85f else 0.7f))
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(18.dp))

                                    // أزرار التحكم المتوازنة والمنظمة
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        // زر إلغاء التسجيل
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.audioRecorder.stopRecording()
                                                recordingFile?.delete()
                                                isAudioRecording = false
                                                recordingDurationSec = 0
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, if (isDarkRecording) Color(0xFF4B2328) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (isDarkRecording) Color(0xFF28181A) else Color.White,
                                                contentColor = if (isDarkRecording) Color(0xFFE5E7EB) else MaterialTheme.colorScheme.onSurface
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(44.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "إلغاء",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }

                                        // زر حفظ واعتماد التسجيل
                                        Button(
                                            onClick = {
                                                val savedFile = viewModel.audioRecorder.stopRecording()
                                                isAudioRecording = false
                                                if (savedFile != null && savedFile.exists() && savedFile.length() > 0) {
                                                    val audioItem = DiaryMediaItem(
                                                        id = UUID.randomUUID().toString(),
                                                        type = DiaryMediaType.AUDIO,
                                                        source = DiaryMediaSource.RECORDED_IN_APP,
                                                        filePath = savedFile.absolutePath,
                                                        fileName = "تسجيل صوتي",
                                                        durationSeconds = recordingDurationSec,
                                                        fileSizeBytes = savedFile.length(),
                                                        createdAt = System.currentTimeMillis()
                                                    )
                                                    mediaList = mediaList + audioItem
                                                    viewModel.showFeedback("تم حفظ التسجيل الصوتي بنجاح")
                                                }
                                                recordingDurationSec = 0
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isDarkRecording) Color(0xFF22C55E) else Color(0xFF16A34A),
                                                contentColor = Color.White
                                            ),
                                            modifier = Modifier
                                                .weight(1.3f)
                                                .height(44.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Done,
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "اعتماد الصوت",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // قسم أزرار إضافة وتسجيل الوسائط (Bento Style Action Cards)
                    item {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp)
                            ) {
                                Text(
                                    text = "إرفاق وسائط بالمذكرة",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                // أزرار التسجيل والالتقاط المباشر داخل التطبيق (صف مدمج وأنيق من 3 أزرار)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // زر تسجيل صوت
                                    CompactActionChip(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Default.Mic,
                                        label = "تسجيل صوت",
                                        tint = Color(0xFF16A34A),
                                        onClick = {
                                            if (isAudioRecording) return@CompactActionChip
                                            val hasPerm = ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.RECORD_AUDIO
                                            ) == PackageManager.PERMISSION_GRANTED

                                            if (hasPerm) {
                                                val audioFile = SaffahDiaryRepository.createInternalAudioFile(context)
                                                recordingFile = audioFile
                                                if (viewModel.audioRecorder.startRecording(audioFile)) {
                                                    isAudioRecording = true
                                                    recordingDurationSec = 0
                                                } else {
                                                    viewModel.showFeedback("تعذر بدء التسجيل الصوتي")
                                                }
                                            } else {
                                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            }
                                        }
                                    )

                                    // زر التقاط صورة
                                    CompactActionChip(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Default.PhotoCamera,
                                        label = "التقاط صورة",
                                        tint = Color(0xFF0D9488),
                                        onClick = {
                                            pendingCameraAction = "PHOTO"
                                            val hasPerm = ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.CAMERA
                                            ) == PackageManager.PERMISSION_GRANTED

                                            if (hasPerm) {
                                                val pFile = SaffahDiaryRepository.createInternalImageFile(context)
                                                tempPhotoFile = pFile
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pFile)
                                                tempPhotoUri = uri
                                                photoCaptureLauncher.launch(uri)
                                            } else {
                                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                            }
                                        }
                                    )

                                    // زر تسجيل فيديو
                                    CompactActionChip(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Default.Videocam,
                                        label = "تسجيل فيديو",
                                        tint = Color(0xFFEA580C),
                                        onClick = {
                                            pendingCameraAction = "VIDEO"
                                            val hasPerm = ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.CAMERA
                                            ) == PackageManager.PERMISSION_GRANTED

                                            if (hasPerm) {
                                                val vFile = SaffahDiaryRepository.createInternalVideoFile(context)
                                                tempVideoFile = vFile
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", vFile)
                                                tempVideoUri = uri
                                                videoCaptureLauncher.launch(uri)
                                            } else {
                                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                            }
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // أزرار الرفع من الملفات
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // رفع صوت (تحت تسجيل صوت)
                                    CompactActionChip(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Default.AudioFile,
                                        label = "رفع صوت",
                                        tint = Color(0xFF8B5CF6),
                                        onClick = {
                                            audioPickerLauncher.launch("audio/*")
                                        }
                                    )

                                    // رفع صور (تحت التقاط صورة)
                                    CompactActionChip(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Default.Image,
                                        label = "رفع صور",
                                        tint = Color(0xFF0284C7),
                                        onClick = {
                                            imagePickerLauncher.launch("image/*")
                                        }
                                    )

                                    // رفع فيديو (تحت تسجيل فيديو)
                                    CompactActionChip(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Default.VideoFile,
                                        label = "رفع فيديو",
                                        tint = Color(0xFFD97706),
                                        onClick = {
                                            videoPickerLauncher.launch("video/*")
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // قائمة الوسائط المرفقة بالمذكرة
                    if (mediaList.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "الوسائط المرفقة (${mediaList.size}):",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        items(
                            items = mediaList,
                            key = { it.id }
                        ) { media ->
                            Box(
                                modifier = Modifier.animateItem(
                                    fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                                    fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                                    placementSpec = androidx.compose.animation.core.spring(
                                        stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                        dampingRatio = 0.8f
                                    )
                                )
                            ) {
                                AttachedMediaItemRow(
                                    media = media,
                                    onPreview = {
                                        previewMediaItem = media
                                    },
                                    onRename = {
                                        mediaItemToRename = media
                                    },
                                    onRemove = {
                                        mediaList = mediaList.filter { it.id != media.id }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة تعديل اسم الملف المرفق
    mediaItemToRename?.let { item ->
        RenameMediaDialog(
            initialName = item.fileName,
            onDismiss = { mediaItemToRename = null },
            onConfirm = { updatedName ->
                mediaList = mediaList.map {
                    if (it.id == item.id) it.copy(fileName = updatedName) else it
                }
                mediaItemToRename = null
                viewModel.showFeedback("تم تحديث اسم الملف بنجاح")
            }
        )
    }

    // نافذة عائمة لمعاينة ملف الصوت أو الفيديو المضاف قبل حفظ المذكرة
    previewMediaItem?.let { item ->
        MediaPreviewFloatingDialog(
            media = item,
            viewModel = viewModel,
            onDismiss = {
                viewModel.audioPlayer.stopAudio()
                previewMediaItem = null
            }
        )
    }

    // شيت منتقي المشاعر المنظم والمدمج
    if (showEmotionsPickerSheet) {
        DiaryEmotionsPickerSheet(
            selectedEmotions = selectedEmotions,
            onToggleEmotion = { emotionId ->
                selectedEmotions = if (selectedEmotions.contains(emotionId)) {
                    selectedEmotions - emotionId
                } else {
                    selectedEmotions + emotionId
                }
            },
            onClearAll = {
                selectedEmotions = emptyList()
            },
            onDismiss = { showEmotionsPickerSheet = false }
        )
    }
}

@Composable
private fun CompactActionChip(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = tint.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.22f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = tint,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun AttachedMediaItemRow(
    media: DiaryMediaItem,
    onPreview: () -> Unit,
    onRename: () -> Unit,
    onRemove: () -> Unit
) {
    val isRecorded = media.source == DiaryMediaSource.RECORDED_IN_APP
    val sourceTint = if (isRecorded) Color(0xFF16A34A) else Color(0xFF0166FF)

    val icon = when (media.type) {
        DiaryMediaType.AUDIO -> Icons.Default.Mic
        DiaryMediaType.IMAGE -> Icons.Default.Image
        DiaryMediaType.VIDEO -> Icons.Default.Videocam
    }

    val sizeFormatted = formatFileSize(media.fileSizeBytes)

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, sourceTint.copy(alpha = 0.25f)),
        modifier = Modifier
            .fillMaxWidth()
            .saffahPressMotion()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // منطقة النقر للمعاينة السريعة قبل الحفظ
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onPreview() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                // صورة مصغرة فائقة الخفة أو أيقونة الوسيط مع مؤشر تشغيل للصوت والفيديو
                val context = LocalContext.current
                val thumbModel = remember(media.filePath) {
                    com.example.util.SaffahMediaCompressor.getThumbnailFile(context, media.filePath)
                }
                Box(
                    modifier = Modifier.size(38.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if ((media.type == DiaryMediaType.IMAGE || media.type == DiaryMediaType.VIDEO) && thumbModel.exists() && thumbModel.length() > 0) {
                        AsyncImage(
                            model = thumbModel,
                            contentDescription = null,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Surface(
                            color = sourceTint.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = sourceTint,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // مؤشر تشغيل صغير في حال كان فيديو أو تسجيل صوتي
                    if (media.type == DiaryMediaType.VIDEO || media.type == DiaryMediaType.AUDIO) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "معاينة",
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = media.fileName.ifBlank { "ملف وسائط" },
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (sizeFormatted.isNotBlank()) {
                            Text(
                                text = sizeFormatted,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = if (media.type == DiaryMediaType.AUDIO) "انقر للاستماع" else if (media.type == DiaryMediaType.VIDEO) "انقر للمعاينة" else "معاينة",
                            style = MaterialTheme.typography.labelSmall,
                            color = sourceTint,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // زر تعديل الاسم
            IconButton(
                onClick = onRename,
                modifier = Modifier
                    .size(28.dp)
                    .saffahPressMotion()
            ) {
                Icon(
                    imageVector = Icons.Outlined.Edit,
                    contentDescription = "تعديل الاسم",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(2.dp))

            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(28.dp)
                    .saffahPressMotion()
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إزالة",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * نافذة عائمة بحجم صغير متوسط وملائم لمعاينة الفيديو والاستماع للتسجيل الصوتي قبل حفظ المذكرة
 * تستخدم نفس مشغل الصوت والفيديو الخاص بمذكرات التعافي
 */
@Composable
private fun MediaPreviewFloatingDialog(
    media: DiaryMediaItem,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    DisposableEffect(media.filePath) {
        onDispose {
            viewModel.audioPlayer.stopAudio()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 420.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // شريط العنوان المدمج: أيقونة + اسم الوسيط + زر الإغلاق
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            val tint = when (media.type) {
                                DiaryMediaType.AUDIO -> Color(0xFF16A34A)
                                DiaryMediaType.VIDEO -> Color(0xFF0166FF)
                                DiaryMediaType.IMAGE -> Color(0xFF0284C7)
                            }
                            Surface(
                                color = tint.copy(alpha = 0.12f),
                                shape = CircleShape,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = when (media.type) {
                                            DiaryMediaType.AUDIO -> Icons.Default.Mic
                                            DiaryMediaType.VIDEO -> Icons.Default.Videocam
                                            DiaryMediaType.IMAGE -> Icons.Default.Image
                                        },
                                        contentDescription = null,
                                        tint = tint,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Text(
                                text = media.fileName.ifBlank { "معاينة الوسيط" },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    // مشغل الوسائط المناسب
                    when (media.type) {
                        DiaryMediaType.VIDEO -> {
                            val file = remember(media.filePath) { File(media.filePath) }
                            if (file.exists()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(220.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AndroidView(
                                        factory = { ctx ->
                                            VideoView(ctx).apply {
                                                setVideoPath(file.absolutePath)
                                                val mediaController = MediaController(ctx)
                                                mediaController.setAnchorView(this)
                                                setMediaController(mediaController)
                                                setOnPreparedListener { mp ->
                                                    mp.start()
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(120.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "ملف الفيديو غير موجود",
                                        color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                        DiaryMediaType.AUDIO -> {
                            PreviewAudioPlayerBody(viewModel = viewModel, media = media)
                        }
                        DiaryMediaType.IMAGE -> {
                            val file = remember(media.filePath) { File(media.filePath) }
                            if (file.exists()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 260.dp)
                                        .clip(RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = file,
                                        contentDescription = media.fileName,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .wrapContentHeight(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * جسم مشغل الصوت المدمج في النافذة العائمة للمعاينة (استخدام نفس مشغل الصوت الخاص بمذكرات التعافي)
 */
@Composable
private fun PreviewAudioPlayerBody(
    viewModel: MainViewModel,
    media: DiaryMediaItem
) {
    val playbackState by viewModel.audioPlayer.playbackState.collectAsState()
    val isPlayingThis = playbackState.isPlaying && playbackState.currentFilePath == media.filePath
    val isLoadedThis = playbackState.currentFilePath == media.filePath

    val isRecorded = media.source == DiaryMediaSource.RECORDED_IN_APP
    val sourceTint = if (isRecorded) Color(0xFF16A34A) else Color(0xFF0166FF)

    LaunchedEffect(isPlayingThis) {
        if (isPlayingThis) {
            while (isActive) {
                delay(250L)
                viewModel.audioPlayer.updateProgress()
            }
        }
    }

    val currentMs = if (isLoadedThis) playbackState.currentPositionMs else 0
    val totalMs = if (isLoadedThis && playbackState.durationMs > 0) playbackState.durationMs else (media.durationSeconds * 1000)
    val progress = if (totalMs > 0) (currentMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f

    var isSeeking by remember { mutableStateOf(false) }
    var seekProgress by remember { mutableFloatStateOf(0f) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, sourceTint.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // سطر التفاصيل: المصدر والحجم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val sourceLabel = if (isRecorded) "تسجيل صوتي مباشر" else "ملف صوتي مستورد"
                Text(
                    text = sourceLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = sourceTint,
                    fontWeight = FontWeight.Bold
                )
                val sizeStr = formatFileSize(media.fileSizeBytes)
                if (sizeStr.isNotBlank()) {
                    Text(
                        text = sizeStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // سطر التحكم: زر التشغيل + شريط السحب + الوقت
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // زر تشغيل دائري
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(sourceTint)
                        .clickable { viewModel.audioPlayer.playAudio(media.filePath) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlayingThis) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlayingThis) "إيقاف مؤقت" else "تشغيل",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                AudioProgressBar(
                    progress = if (isSeeking) seekProgress else progress,
                    onSeek = {
                        isSeeking = true
                        seekProgress = it
                    },
                    onSeekFinished = { finalFraction ->
                        isSeeking = false
                        if (totalMs > 0) {
                            val targetMs = (finalFraction * totalMs).toInt()
                            if (isLoadedThis) {
                                viewModel.audioPlayer.seekTo(targetMs)
                            } else {
                                viewModel.audioPlayer.playAudio(media.filePath)
                                viewModel.audioPlayer.seekTo(targetMs)
                            }
                        }
                    },
                    activeColor = sourceTint,
                    inactiveColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                    modifier = Modifier
                        .weight(1f)
                        .height(30.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                val displayCurrentSec = if (isSeeking) (seekProgress * totalMs / 1000).toInt() else (currentMs / 1000)
                val displayTotalSec = (totalMs / 1000).coerceAtLeast(0)
                Text(
                    text = "${formatDuration(displayCurrentSec)} / ${formatDuration(displayTotalSec)}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }
        }
    }
}

/**
 * نافذة مخصصة وبسيطة لتعديل وتغيير اسم ملف الصوت أو الفيديو أو الصورة
 */
@Composable
private fun RenameMediaDialog(
    initialName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newName by remember { mutableStateOf(initialName) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 400.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "تعديل اسم الملف",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("اسم الملف") },
                        placeholder = { Text("أدخل اسماً للملف...") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.8f),
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        ),
                        trailingIcon = if (newName.isNotBlank()) {
                            {
                                IconButton(onClick = { newName = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "مسح",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        } else null,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.8f))
                        ) {
                            Text(
                                text = "إلغاء",
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = {
                                if (newName.isNotBlank()) {
                                    onConfirm(newName.trim())
                                }
                            },
                            enabled = newName.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "حفظ",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * نافذة عرض تفاصيل المذكرة وسماع/مشاهدة كافة الوسائط بداخلها مباشرة
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DiaryDetailDialog(
    viewModel: MainViewModel,
    entry: RecoveryDiaryEntry,
    isFromTrash: Boolean = false,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRestore: (() -> Unit)? = null,
    onPermanentDelete: (() -> Unit)? = null
) {
    val sdf = remember { SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.US) }
    var currentEntry by remember(entry) { mutableStateOf(entry) }
    val formattedDate = remember(currentEntry.createdAt) { sdf.format(Date(currentEntry.createdAt)) }

    val imageList = remember(currentEntry.mediaList) { currentEntry.mediaList.filter { it.type == DiaryMediaType.IMAGE } }
    val audioList = remember(currentEntry.mediaList) { currentEntry.mediaList.filter { it.type == DiaryMediaType.AUDIO } }
    val videoList = remember(currentEntry.mediaList) { currentEntry.mediaList.filter { it.type == DiaryMediaType.VIDEO } }

    var fullScreenImageFile by remember { mutableStateOf<File?>(null) }
    var selectedVideoForPlay by remember { mutableStateOf<DiaryMediaItem?>(null) }
    var mediaItemToRename by remember { mutableStateOf<DiaryMediaItem?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            color = MaterialTheme.colorScheme.background
        ) {
            Scaffold(
                topBar = {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        shadowElevation = 1.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(
                                text = "تفاصيل المذكرة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )

                            if (!isFromTrash) {
                                IconButton(
                                    onClick = onEdit,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Edit,
                                        contentDescription = "تعديل",
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                IconButton(
                                    onClick = onDelete,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Delete,
                                        contentDescription = "حذف",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            } else {
                                if (onRestore != null) {
                                    IconButton(
                                        onClick = onRestore,
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.RestoreFromTrash,
                                            contentDescription = "استرجاع",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                if (onPermanentDelete != null) {
                                    IconButton(
                                        onClick = onPermanentDelete,
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.DeleteForever,
                                            contentDescription = "حذف نهائي",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                },
                containerColor = MaterialTheme.colorScheme.background
            ) { padding ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (isFromTrash) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.08f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "هذه المذكرة موجودة في سلة المحذوفات. يمكنك استرجاعها لتعود لمذكراتك أو حذفها نهائياً بحيث لا يبقى لها أي أثر.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                    // نوع المذكرة وتاريخ التدوين بتنسيق 24h
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val currentType = currentEntry.type.ifBlank { "ملاحظة" }
                            val (typeColor, typeBg) = getDiaryTypeColor(currentType)
                            Surface(
                                color = typeBg,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = getDiaryTypeIcon(currentType),
                                        contentDescription = null,
                                        tint = typeColor,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = currentType,
                                        color = typeColor,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Schedule,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = formattedDate,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // عنوان المذكرة
                    item {
                        Text(
                            text = currentEntry.title.ifBlank { "مذكرة بدون عنوان" },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // نص المذكرة
                    if (currentEntry.content.isNotBlank()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = currentEntry.content,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 26.sp,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }

                    // قسم المشاعر المرتبطة بالمذكرة
                    if (currentEntry.emotions.isNotEmpty()) {
                        item {
                            val entryEmotions = remember(currentEntry.emotions) {
                                currentEntry.emotions.mapNotNull { DiaryEmotionList.findById(it) }
                            }
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Mood,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "المشاعر المرتبطة بالمذكرة",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                        ) {
                                            Text(
                                                text = "${entryEmotions.size}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    FlowRow(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        entryEmotions.forEach { emotion ->
                                            val catColor = getEmotionCategoryColor(emotion.category)
                                            Surface(
                                                shape = RoundedCornerShape(10.dp),
                                                color = catColor.copy(alpha = 0.12f),
                                                border = BorderStroke(1.dp, catColor.copy(alpha = 0.35f))
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = emotion.emoji,
                                                        fontSize = 15.sp
                                                    )
                                                    Spacer(modifier = Modifier.width(5.dp))
                                                    Text(
                                                        text = emotion.label,
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = catColor.copy(alpha = 0.2f)
                                                    ) {
                                                        Text(
                                                            text = emotion.category.title,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontSize = 9.sp,
                                                            color = catColor,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // الوسائط المنظمة بشكل مدمج ومتناسق (Bento Media Sections)
                    // 1. قسم الصور (معرض صور مدمج ومضغوط وشبكة أنيقة)
                    if (imageList.isNotEmpty()) {
                        item {
                            CompactImageSection(
                                images = imageList,
                                onImageClick = { file -> fullScreenImageFile = file }
                            )
                        }
                    }

                    // 2. قسم الصوتيات (كبسولات صوتية مدمجة قابلة للتمرير وتغيير الاسم)
                    if (audioList.isNotEmpty()) {
                        item {
                            CompactAudioSection(
                                viewModel = viewModel,
                                audios = audioList,
                                onRenameAudio = { audioItem ->
                                    mediaItemToRename = audioItem
                                }
                            )
                        }
                    }

                    // 3. قسم الفيديوهات (بطاقات فيديو مدمجة قابلة لتغيير الاسم)
                    if (videoList.isNotEmpty()) {
                        item {
                            CompactVideoSection(
                                videos = videoList,
                                onPlayVideo = { videoItem ->
                                    selectedVideoForPlay = videoItem
                                },
                                onRenameVideo = { videoItem ->
                                    mediaItemToRename = videoItem
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // نافذة تعديل اسم الملف
    mediaItemToRename?.let { item ->
        RenameMediaDialog(
            initialName = item.fileName,
            onDismiss = { mediaItemToRename = null },
            onConfirm = { updatedName ->
                val updatedList = currentEntry.mediaList.map {
                    if (it.id == item.id) it.copy(fileName = updatedName) else it
                }
                val updatedEntry = currentEntry.copy(mediaList = updatedList, updatedAt = System.currentTimeMillis())
                currentEntry = updatedEntry
                viewModel.saveDiaryEntry(updatedEntry)
                mediaItemToRename = null
                viewModel.showFeedback("تم تحديث اسم الملف بنجاح")
            }
        )
    }

    // نافذة عرض الفيديو المدمج بملء الشاشة/نافذة مخصصة
    selectedVideoForPlay?.let { videoItem ->
        VideoPlayerDialog(
            videoItem = videoItem,
            onDismiss = { selectedVideoForPlay = null }
        )
    }

    // Full screen image viewer dialog
    fullScreenImageFile?.let { file ->
        Dialog(
            onDismissRequest = { fullScreenImageFile = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = file,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )

                IconButton(
                    onClick = { fullScreenImageFile = null },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

/**
 * 1. قسم الصور المدمج: يعرض الصور في شبكة/معرض مصغر متناسق
 */
@Composable
private fun CompactImageSection(
    images: List<DiaryMediaItem>,
    onImageClick: (File) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الصور المرفقة (${images.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "اضغط للتكبير",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // توزيع شبكي أنيق ومدمج حسب عدد الصور
            val context = LocalContext.current
            if (images.size == 1) {
                val media = images.first()
                val file = remember(media.filePath) { File(media.filePath) }
                val thumbFile = remember(media.filePath) {
                    com.example.util.SaffahMediaCompressor.getThumbnailFile(context, media.filePath)
                }
                if (file.exists()) {
                    val sourceTint = if (media.source == DiaryMediaSource.RECORDED_IN_APP) Color(0xFF0D9488) else Color(0xFF0284C7)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, sourceTint.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .clickable { onImageClick(file) }
                    ) {
                        AsyncImage(
                            model = thumbFile,
                            contentDescription = media.fileName,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            } else {
                // معرض أفقي مصغر
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(images, key = { it.id }) { media ->
                        val file = remember(media.filePath) { File(media.filePath) }
                        val thumbFile = remember(media.filePath) {
                            com.example.util.SaffahMediaCompressor.getThumbnailFile(context, media.filePath)
                        }
                        if (file.exists()) {
                            val sourceTint = if (media.source == DiaryMediaSource.RECORDED_IN_APP) Color(0xFF0D9488) else Color(0xFF0284C7)
                            Box(
                                modifier = Modifier
                                    .size(width = 110.dp, height = 110.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, sourceTint.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                    .clickable { onImageClick(file) }
                            ) {
                                AsyncImage(
                                    model = thumbFile,
                                    contentDescription = media.fileName,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2. قسم الصوتيات المدمج: كبسولات مشغل صوتي رفيعة مع شريط سحب وتقديم وتعديل الاسم
 */
@Composable
private fun CompactAudioSection(
    viewModel: MainViewModel,
    audios: List<DiaryMediaItem>,
    onRenameAudio: (DiaryMediaItem) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    tint = Color(0xFF16A34A),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "التسجيلات والملفات الصوتية (${audios.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                audios.forEach { media ->
                    CompactAudioItemCapsule(
                        viewModel = viewModel,
                        media = media,
                        onRename = { onRenameAudio(media) }
                    )
                }
            }
        }
    }
}

/**
 * كبسولة مشغل صوتي أنيقة ومضغوطة بتصميم Bento UI متوازن مع شريط سحب سلس وتعديل الاسم
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CompactAudioItemCapsule(
    viewModel: MainViewModel,
    media: DiaryMediaItem,
    onRename: () -> Unit
) {
    val playbackState by viewModel.audioPlayer.playbackState.collectAsState()
    val isPlayingThis = playbackState.isPlaying && playbackState.currentFilePath == media.filePath
    val isLoadedThis = playbackState.currentFilePath == media.filePath

    val isRecorded = media.source == DiaryMediaSource.RECORDED_IN_APP
    val sourceTint = if (isRecorded) Color(0xFF16A34A) else Color(0xFF0284C7)

    LaunchedEffect(isPlayingThis) {
        if (isPlayingThis) {
            while (isActive) {
                delay(250L)
                viewModel.audioPlayer.updateProgress()
            }
        }
    }

    val currentMs = if (isLoadedThis) playbackState.currentPositionMs else 0
    val totalMs = if (isLoadedThis && playbackState.durationMs > 0) playbackState.durationMs else (media.durationSeconds * 1000)
    val progress = if (totalMs > 0) (currentMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f

    var isSeeking by remember { mutableStateOf(false) }
    var seekProgress by remember { mutableFloatStateOf(0f) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, sourceTint.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            // السطر العلوي: اسم الملف على اليمين، والحجم وزر التعديل على اليسار
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = media.fileName.ifBlank { "تسجيل صوتي" },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val sizeStr = formatFileSize(media.fileSizeBytes)
                    if (sizeStr.isNotBlank()) {
                        Text(
                            text = sizeStr,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                            .clickable { onRename() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = "تعديل الاسم",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // السطر السفلي: زر التشغيل المدمج + شريط التمرير + العداد الزمني
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // زر تشغيل دائري أنيق ومتناسق الحجم
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(sourceTint)
                        .clickable { viewModel.audioPlayer.playAudio(media.filePath) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlayingThis) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlayingThis) "إيقاف مؤقت" else "تشغيل",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // شريط سحب تفاعلي متناسق ونظيف بدون أي نقاط ومحاذى 100% في المركز
                AudioProgressBar(
                    progress = if (isSeeking) seekProgress else progress,
                    onSeek = {
                        isSeeking = true
                        seekProgress = it
                    },
                    onSeekFinished = { finalFraction ->
                        isSeeking = false
                        if (totalMs > 0) {
                            val targetMs = (finalFraction * totalMs).toInt()
                            if (isLoadedThis) {
                                viewModel.audioPlayer.seekTo(targetMs)
                            } else {
                                viewModel.audioPlayer.playAudio(media.filePath)
                                viewModel.audioPlayer.seekTo(targetMs)
                            }
                        }
                    },
                    activeColor = sourceTint,
                    inactiveColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                val displayCurrentSec = if (isSeeking) (seekProgress * totalMs / 1000).toInt() else (currentMs / 1000)
                Text(
                    text = "${formatDuration(displayCurrentSec)} / ${formatDuration(totalMs / 1000)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
            }
        }
    }
}

/**
 * شريط تقدم صوتي تفاعلي فائق الدقة والأناقة ومحاذى هندسياً بنسبة 100% في المركز
 */
@Composable
private fun AudioProgressBar(
    progress: Float,
    onSeek: (Float) -> Unit,
    onSeekFinished: (Float) -> Unit,
    activeColor: Color,
    inactiveColor: Color,
    modifier: Modifier = Modifier
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragProgress by remember { mutableFloatStateOf(0f) }
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl

    val currentProgress = if (isDragging) dragProgress else progress.coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .pointerInput(isRtl) {
                detectTapGestures(
                    onPress = { offset ->
                        val w = size.width.toFloat()
                        if (w > 0) {
                            val rawFraction = (offset.x / w).coerceIn(0f, 1f)
                            val fraction = if (isRtl) (1f - rawFraction) else rawFraction
                            isDragging = true
                            dragProgress = fraction
                            onSeek(fraction)
                            val released = tryAwaitRelease()
                            isDragging = false
                            if (released) {
                                onSeekFinished(dragProgress)
                            }
                        }
                    }
                )
            }
            .pointerInput(isRtl) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        val w = size.width.toFloat()
                        if (w > 0) {
                            val rawFraction = (offset.x / w).coerceIn(0f, 1f)
                            val fraction = if (isRtl) (1f - rawFraction) else rawFraction
                            isDragging = true
                            dragProgress = fraction
                            onSeek(fraction)
                        }
                    },
                    onDragEnd = {
                        isDragging = false
                        onSeekFinished(dragProgress)
                    },
                    onDragCancel = {
                        isDragging = false
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val w = size.width.toFloat()
                        if (w > 0) {
                            val rawFraction = (change.position.x / w).coerceIn(0f, 1f)
                            val fraction = if (isRtl) (1f - rawFraction) else rawFraction
                            dragProgress = fraction
                            onSeek(fraction)
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(16.dp)) {
            val canvasW = size.width
            val canvasH = size.height
            val centerY = canvasH / 2f
            val trackH = 4.dp.toPx()
            val thumbRadius = 6.dp.toPx()

            val startX = thumbRadius
            val endX = canvasW - thumbRadius
            val availableW = (endX - startX).coerceAtLeast(1f)

            val thumbX = if (isRtl) {
                endX - (availableW * currentProgress)
            } else {
                startX + (availableW * currentProgress)
            }

            // 1. مسار الخلفية (الرمادي) مع حواف دائرية ناعمة متمركزة عمودياً
            drawRoundRect(
                color = inactiveColor,
                topLeft = Offset(startX, centerY - (trackH / 2f)),
                size = Size(availableW, trackH),
                cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
            )

            // 2. مسار التشغيل الفعّال
            if (currentProgress > 0f) {
                if (isRtl) {
                    val activeW = endX - thumbX
                    if (activeW > 0) {
                        drawRoundRect(
                            color = activeColor,
                            topLeft = Offset(thumbX, centerY - (trackH / 2f)),
                            size = Size(activeW, trackH),
                            cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
                        )
                    }
                } else {
                    val activeW = thumbX - startX
                    if (activeW > 0) {
                        drawRoundRect(
                            color = activeColor,
                            topLeft = Offset(startX, centerY - (trackH / 2f)),
                            size = Size(activeW, trackH),
                            cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
                        )
                    }
                }
            }

            // 3. دائرة المؤشر (متمركزة هندسياً 100% في نفس النقطة المركزية للمسار)
            drawCircle(
                color = activeColor,
                radius = thumbRadius,
                center = Offset(thumbX, centerY)
            )
            drawCircle(
                color = Color.White,
                radius = 1.8.dp.toPx(),
                center = Offset(thumbX, centerY)
            )
        }
    }
}

/**
 * 3. قسم الفيديوهات المدمج: بطاقات أنيقة مع زر تعديل الاسم
 */
@Composable
private fun CompactVideoSection(
    videos: List<DiaryMediaItem>,
    onPlayVideo: (DiaryMediaItem) -> Unit,
    onRenameVideo: (DiaryMediaItem) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = null,
                    tint = Color(0xFFEA580C),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "مقاطع الفيديو (${videos.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                videos.forEach { video ->
                    CompactVideoItemCard(
                        video = video,
                        onPlay = { onPlayVideo(video) },
                        onRename = { onRenameVideo(video) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CompactVideoItemCard(
    video: DiaryMediaItem,
    onPlay: () -> Unit,
    onRename: () -> Unit
) {
    val isRecorded = video.source == DiaryMediaSource.RECORDED_IN_APP
    val sourceTint = if (isRecorded) Color(0xFFEA580C) else Color(0xFF0284C7)
    val sizeStr = formatFileSize(video.fileSizeBytes)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onPlay() },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, sourceTint.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val context = LocalContext.current
            val thumbFile = remember(video.filePath) {
                com.example.util.SaffahMediaCompressor.getThumbnailFile(context, video.filePath)
            }
            Surface(
                color = sourceTint.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (thumbFile.exists() && thumbFile.name.endsWith("_thumb.jpg")) {
                        AsyncImage(
                            model = thumbFile,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.35f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            tint = sourceTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = video.fileName.ifBlank { "مقطع فيديو" },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (sizeStr.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = sizeStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp
                    )
                }
            }

            // زر تعديل اسم الفيديو
            IconButton(
                onClick = onRename,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Edit,
                    contentDescription = "تعديل الاسم",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            Text(
                text = "تشغيل",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = sourceTint
            )
        }
    }
}

/**
 * مشغل فيديو منبثق احترافي بملء الشاشة مع أدوات تحكم
 */
@Composable
private fun VideoPlayerDialog(
    videoItem: DiaryMediaItem,
    onDismiss: () -> Unit
) {
    val file = remember(videoItem.filePath) { File(videoItem.filePath) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            if (file.exists()) {
                AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            setVideoPath(file.absolutePath)
                            val mediaController = MediaController(ctx)
                            mediaController.setAnchorView(this)
                            setMediaController(mediaController)
                            setOnPreparedListener { mp ->
                                mp.start()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "ملف الفيديو غير موجود",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            // زر إغلاق الفيديو
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق",
                    tint = Color.White
                )
            }
        }
    }
}

private fun formatDuration(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format(Locale.US, "%02d:%02d", m, s)
}

private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return ""
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return if (mb >= 1.0) {
        String.format(Locale.US, "%.1f MB", mb)
    } else {
        String.format(Locale.US, "%d KB", kb.toLong())
    }
}

/**
 * قسم عرض واختيار المشاعر المدمج والأنيق في بطاقة المذكرة (Bento UI)
 * حجم مدمج ونظيف ومريح للعين مع أيقونات تعديل وحذف مدمجة دون نصوص زائدة
 */
@Composable
private fun EmotionsSelectorSection(
    selectedEmotions: List<String>,
    onOpenPicker: () -> Unit,
    onRemoveEmotion: (String) -> Unit,
    onClearEmotions: () -> Unit
) {
    val selectedObjects = remember(selectedEmotions) {
        selectedEmotions.mapNotNull { DiaryEmotionList.findById(it) }
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            // شريط العنوان مع عداد المشاعر وأيقونات التعديل والحذف
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Mood,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "المشاعر والحالة الوجدانية",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (selectedObjects.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${selectedObjects.size}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // أيقونات التحكم: تظهر فقط عند وجود مشاعر محددة (قلم التعديل وأيقونة الحذف)
                if (selectedObjects.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onOpenPicker,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Edit,
                                contentDescription = "تعديل المشاعر",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(2.dp))
                        IconButton(
                            onClick = onClearEmotions,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = "حذف المشاعر",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }

            if (selectedObjects.isEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                // بطاقة بسيطة تدعو لتحديد المشاعر
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onOpenPicker() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "حدد مشاعرك وحالتك النفسية أثناء كتابة هذه المذكرة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Outlined.AddCircleOutline,
                            contentDescription = null,
                            tint = Color(0xFF0166FF),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(10.dp))
                // قائمة أفقية أنيقة للمشاعر المحددة مع زر الإزالة لكل عنصر
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(selectedObjects, key = { it.id }) { emotion ->
                        val catColor = getEmotionCategoryColor(emotion.category)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = catColor.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, catColor.copy(alpha = 0.35f))
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 8.dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = emotion.emoji,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = emotion.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(
                                    onClick = { onRemoveEmotion(emotion.id) },
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "إزالة",
                                        tint = catColor,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * شيت منتقي المشاعر المنظم والمبوب بتصميم Material Design 3
 * يقسم المشاعر إلى 3 تبويبات واضحة مع شبكة عناصر مريحة غير متكدسة
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DiaryEmotionsPickerSheet(
    selectedEmotions: List<String>,
    onToggleEmotion: (String) -> Unit,
    onClearAll: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedCategoryTab by remember { mutableStateOf(0) }

    val categories = remember {
        listOf(
            DiaryEmotionCategory.POSITIVE,
            DiaryEmotionCategory.NEUTRAL,
            DiaryEmotionCategory.NEGATIVE
        )
    }

    val currentCategory = categories[selectedCategoryTab]
    val emotionsForCategory = remember(currentCategory) {
        DiaryEmotionList.ALL.filter { it.category == currentCategory }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            // شريط رأس الشيت
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "تحديد المشاعر والحالة الوجدانية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "اختر المشاعر التي تعبّر عنك أثناء هذه المذكرة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3 كبسولات تصنيف بتصميم Bento UI راقي وعصري بدون أي تكدس
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val posCount = remember { DiaryEmotionList.ALL.count { it.category == DiaryEmotionCategory.POSITIVE } }
                val neuCount = remember { DiaryEmotionList.ALL.count { it.category == DiaryEmotionCategory.NEUTRAL } }
                val negCount = remember { DiaryEmotionList.ALL.count { it.category == DiaryEmotionCategory.NEGATIVE } }

                val posSelected = remember(selectedEmotions) {
                    selectedEmotions.count { id -> DiaryEmotionList.findById(id)?.category == DiaryEmotionCategory.POSITIVE }
                }
                val neuSelected = remember(selectedEmotions) {
                    selectedEmotions.count { id -> DiaryEmotionList.findById(id)?.category == DiaryEmotionCategory.NEUTRAL }
                }
                val negSelected = remember(selectedEmotions) {
                    selectedEmotions.count { id -> DiaryEmotionList.findById(id)?.category == DiaryEmotionCategory.NEGATIVE }
                }

                val tabsData = listOf(
                    Triple("🌟", "إيجابية", posSelected),
                    Triple("⚖️", "مُحايدة", neuSelected),
                    Triple("⚠️", "تحديات", negSelected)
                )

                tabsData.forEachIndexed { index, (emoji, title, selCount) ->
                    val isTabSelected = selectedCategoryTab == index
                    val tabCatColor = getEmotionCategoryColor(categories[index])

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedCategoryTab = index },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isTabSelected) tabCatColor.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(
                            width = if (isTabSelected) 1.5.dp else 0.8.dp,
                            color = if (isTabSelected) tabCatColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = emoji,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium,
                                fontSize = 11.sp,
                                fontWeight = if (isTabSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isTabSelected) tabCatColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                            if (selCount > 0) {
                                Spacer(modifier = Modifier.width(3.dp))
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(tabCatColor.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$selCount",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = tabCatColor,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شريط إرشادي للتصنيف الحالي
            val categoryHint = when (currentCategory) {
                DiaryEmotionCategory.POSITIVE -> "مشاعر القوة، التفاؤل، والسكينة والامتنان"
                DiaryEmotionCategory.NEUTRAL -> "المشاعر التي لا تُصنَّف عادةً كإيجابية أو سلبية بوضوح"
                DiaryEmotionCategory.NEGATIVE -> "الرغبات الملحة، التوتر، الضغوط، ولحظات التحدي"
            }
            val catColor = getEmotionCategoryColor(currentCategory)

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = catColor.copy(alpha = 0.08f),
                border = BorderStroke(0.8.dp, catColor.copy(alpha = 0.2f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(catColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = categoryHint,
                        style = MaterialTheme.typography.labelSmall,
                        color = catColor,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شبكة منظمة من عمودين لكل تبويب مع إيموجيات واضحة ومريحة
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 330.dp)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(emotionsForCategory, key = { it.id }) { emotion ->
                        val isSelected = selectedEmotions.contains(emotion.id)

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .saffahPressMotion()
                                .clickable { onToggleEmotion(emotion.id) },
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) catColor.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) catColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // حاوية الإيموجي الدائرية
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) catColor.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surface),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = emotion.emoji,
                                        fontSize = 17.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // اسم الشعور
                                Text(
                                    text = emotion.label,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 12.5.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )

                                // شارة التحديد
                                AnimatedVisibility(
                                    visible = isSelected,
                                    enter = scaleIn(initialScale = 0.7f, animationSpec = SaffahMotion.bouncySpring()) + fadeIn(),
                                    exit = scaleOut(targetScale = 0.7f, animationSpec = SaffahMotion.snappySpring()) + fadeOut()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = catColor,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // شريط الإجراءات السفلي للشيت
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (selectedEmotions.isNotEmpty()) {
                    OutlinedButton(
                        onClick = onClearAll,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f)),
                        modifier = Modifier.height(46.dp)
                    ) {
                        Text(
                            text = "مسح الكل",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (selectedEmotions.isNotEmpty()) "تأكيد المشاعر (${selectedEmotions.size})" else "إغلاق",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * دالة استخراج اللون المناسب لتصنيف الشعور
 */
private fun getEmotionCategoryColor(category: DiaryEmotionCategory): Color {
    return when (category) {
        DiaryEmotionCategory.POSITIVE -> Color(0xFF16A34A)
        DiaryEmotionCategory.NEUTRAL -> Color(0xFFD97706)
        DiaryEmotionCategory.NEGATIVE -> Color(0xFFDC2626)
    }
}

/**
 * نافذة سفلية (Bottom Sheet) لفلترة وترتيب المذكرات
 * تتيح تحديد النوع، الفترة الزمنية مع خيار النطاق المخصص، وترتيب النتائج
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DiaryFilterBottomSheet(
    allEntries: List<RecoveryDiaryEntry>,
    currentTypeFilter: String?,
    currentDateFilter: DiaryDateFilter,
    currentCustomStartDate: Long?,
    currentCustomEndDate: Long?,
    currentSortOrder: DiarySortOrder,
    onApply: (typeFilter: String?, dateFilter: DiaryDateFilter, customStartDate: Long?, customEndDate: Long?, sortOrder: DiarySortOrder) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.US) }

    var tempTypeFilter by remember { mutableStateOf(currentTypeFilter) }
    var tempDateFilter by remember { mutableStateOf(currentDateFilter) }
    var tempCustomStartDate by remember { mutableStateOf(currentCustomStartDate) }
    var tempCustomEndDate by remember { mutableStateOf(currentCustomEndDate) }
    var tempSortOrder by remember { mutableStateOf(currentSortOrder) }

    // المعاينة الفورية لعدد النتائج عند تطبيق هذه الخيارات
    val previewCount = remember(
        allEntries,
        tempTypeFilter,
        tempDateFilter,
        tempCustomStartDate,
        tempCustomEndDate
    ) {
        var list = allEntries
        if (tempTypeFilter != null) {
            val target = tempTypeFilter!!
            list = list.filter { (it.type.ifBlank { "ملاحظة" }) == target }
        }
        when (tempDateFilter) {
            DiaryDateFilter.ALL -> {}
            DiaryDateFilter.TODAY -> {
                val startOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val endOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 23)
                    set(Calendar.MINUTE, 59)
                    set(Calendar.SECOND, 59)
                    set(Calendar.MILLISECOND, 999)
                }.timeInMillis
                list = list.filter { it.createdAt in startOfToday..endOfToday }
            }
            DiaryDateFilter.LAST_7_DAYS -> {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -7)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                list = list.filter { it.createdAt >= cal.timeInMillis }
            }
            DiaryDateFilter.LAST_30_DAYS -> {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -30)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                list = list.filter { it.createdAt >= cal.timeInMillis }
            }
            DiaryDateFilter.THIS_MONTH -> {
                val startOfMonth = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                list = list.filter { it.createdAt >= startOfMonth }
            }
            DiaryDateFilter.CUSTOM -> {
                if (tempCustomStartDate != null || tempCustomEndDate != null) {
                    list = list.filter { entry ->
                        val afterStart = tempCustomStartDate?.let { entry.createdAt >= it } ?: true
                        val beforeEnd = tempCustomEndDate?.let { entry.createdAt <= it } ?: true
                        afterStart && beforeEnd
                    }
                }
            }
        }
        list.size
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp)
        ) {
            // شريط العنوان العلوي
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Tune,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "فلترة المذكرات",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            sheetState.hide()
                            onDismiss()
                        }
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            // محتوى خيارات الفلترة القابل للتمرير
            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // قسم 1: النوع
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "النوع",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        item(key = "sheet_filter_type_all") {
                            val isSelected = tempTypeFilter == null
                            FilterChip(
                                selected = isSelected,
                                onClick = { tempTypeFilter = null },
                                label = {
                                    Text(
                                        text = "الكل",
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.Layers,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                    selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }

                        items(
                            items = DiaryEntryType.ALL_TYPES,
                            key = { it.name }
                        ) { entryType ->
                            val isSelected = tempTypeFilter == entryType.displayName
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    tempTypeFilter = if (isSelected) null else entryType.displayName
                                },
                                label = {
                                    Text(
                                        text = entryType.displayName,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = getDiaryTypeIcon(entryType.displayName),
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                    selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                // قسم 2: الفترة
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "الفترة:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val periods = listOf(
                        DiaryDateFilter.ALL to "الكل (جميع الأوقات)",
                        DiaryDateFilter.TODAY to "اليوم",
                        DiaryDateFilter.LAST_7_DAYS to "7 أيام",
                        DiaryDateFilter.LAST_30_DAYS to "30 يومًا",
                        DiaryDateFilter.THIS_MONTH to "هذا الشهر",
                        DiaryDateFilter.CUSTOM to "مخصص"
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        periods.forEach { (filterOption, label) ->
                            val isSelected = tempDateFilter == filterOption
                            Surface(
                                onClick = { tempDateFilter = filterOption },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { tempDateFilter = filterOption },
                                        modifier = Modifier.size(28.dp),
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    // في حال اختيار "مخصص"، يظهر حقل تاريخ البدء والانتهاء
                    AnimatedVisibility(
                        visible = tempDateFilter == DiaryDateFilter.CUSTOM,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "تحديد النطاق المخصص:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // من تاريخ
                                    OutlinedButton(
                                        onClick = {
                                            val cal = Calendar.getInstance().apply {
                                                timeInMillis = tempCustomStartDate ?: System.currentTimeMillis()
                                            }
                                            DatePickerDialog(
                                                context,
                                                { _, y, m, d ->
                                                    val selectedCal = Calendar.getInstance().apply {
                                                        set(y, m, d, 0, 0, 0)
                                                        set(Calendar.MILLISECOND, 0)
                                                    }
                                                    tempCustomStartDate = selectedCal.timeInMillis
                                                },
                                                cal.get(Calendar.YEAR),
                                                cal.get(Calendar.MONTH),
                                                cal.get(Calendar.DAY_OF_MONTH)
                                            ).show()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.CalendarToday,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = tempCustomStartDate?.let { "من: ${dateFormat.format(Date(it))}" } ?: "من تاريخ...",
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    // إلى تاريخ
                                    OutlinedButton(
                                        onClick = {
                                            val cal = Calendar.getInstance().apply {
                                                timeInMillis = tempCustomEndDate ?: System.currentTimeMillis()
                                            }
                                            DatePickerDialog(
                                                context,
                                                { _, y, m, d ->
                                                    val selectedCal = Calendar.getInstance().apply {
                                                        set(y, m, d, 23, 59, 59)
                                                        set(Calendar.MILLISECOND, 999)
                                                    }
                                                    tempCustomEndDate = selectedCal.timeInMillis
                                                },
                                                cal.get(Calendar.YEAR),
                                                cal.get(Calendar.MONTH),
                                                cal.get(Calendar.DAY_OF_MONTH)
                                            ).show()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Event,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = tempCustomEndDate?.let { "إلى: ${dateFormat.format(Date(it))}" } ?: "إلى تاريخ...",
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                if (tempCustomStartDate != null || tempCustomEndDate != null) {
                                    TextButton(
                                        onClick = {
                                            tempCustomStartDate = null
                                            tempCustomEndDate = null
                                        },
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Text(
                                            text = "مسح التواريخ المخصصة",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                // قسم 3: ترتيب حسب
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "ترتيب حسب:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val sortOrders = listOf(
                        DiarySortOrder.NEWEST_FIRST to "الأحدث أولًا",
                        DiarySortOrder.OLDEST_FIRST to "الأقدم أولًا",
                        DiarySortOrder.LAST_UPDATED to "آخر تعديل",
                        DiarySortOrder.LONGEST to "الأكثر طولًا",
                        DiarySortOrder.SHORTEST to "الأقصر طولاً"
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        sortOrders.forEach { (order, label) ->
                            val isSelected = tempSortOrder == order
                            Surface(
                                onClick = { tempSortOrder = order },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { tempSortOrder = order },
                                        modifier = Modifier.size(28.dp),
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            // Bottom Actions Row: [مسح الفلاتر] [عرض النتائج]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        tempTypeFilter = null
                        tempDateFilter = DiaryDateFilter.ALL
                        tempCustomStartDate = null
                        tempCustomEndDate = null
                        tempSortOrder = DiarySortOrder.NEWEST_FIRST
                        onReset()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "مسح الفلاتر",
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Button(
                    onClick = {
                        onApply(
                            tempTypeFilter,
                            tempDateFilter,
                            tempCustomStartDate,
                            tempCustomEndDate,
                            tempSortOrder
                        )
                        coroutineScope.launch {
                            sheetState.hide()
                            onDismiss()
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(
                        text = "عرض النتائج ($previewCount)",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
    }
}
