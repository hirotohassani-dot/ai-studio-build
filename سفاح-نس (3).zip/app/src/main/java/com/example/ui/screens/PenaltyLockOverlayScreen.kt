package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.rememberFastDrawablePainter
import com.example.ui.theme.*
import com.example.util.AppListHelper
import com.example.util.QuoteCategory
import com.example.util.SaffahPenaltyManager
import com.example.util.SaffahPenaltyQuotes
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Helper to get category icon without relying on emojis
 */
private fun getCategoryIcon(category: QuoteCategory): ImageVector {
    return when (category) {
        QuoteCategory.SAFFAH_FORTRESS -> Icons.Default.Security
        QuoteCategory.SPIRITUAL_PURITY -> Icons.Default.Favorite
        QuoteCategory.BRAIN_RECOVERY -> Icons.Default.Lightbulb
        QuoteCategory.HONOR_HEROISM -> Icons.Default.Star
    }
}

/**
 * Luxurious, Battery-Optimized Locked Penalty Screen (Bento UI)
 * Runs directly inside Saffah using Lock Task Mode.
 * Designed to fit seamlessly in a single viewport without unnecessary scrolling.
 */
@Composable
fun PenaltyLockOverlayScreen(
    onPenaltyFinished: () -> Unit
) {
    val context = LocalContext.current
    val isDark = com.example.ui.theme.isAppInDarkTheme()

    var remainingMs by remember { mutableStateOf(SaffahPenaltyManager.getRemainingPenaltyTimeMs(context)) }
    val totalMs = remember { SaffahPenaltyManager.getTotalPenaltyDurationMs(context) }
    val reason = remember { SaffahPenaltyManager.getPenaltyReason(context) }
    val detectedItem = remember { SaffahPenaltyManager.getPenaltyDetectedItem(context) }
    val detectedType = remember { SaffahPenaltyManager.getPenaltyDetectedType(context) }
    val sourcePkg = remember { SaffahPenaltyManager.getPenaltySourcePackage(context) }
    val sourceAppName = remember { SaffahPenaltyManager.getPenaltySourceAppName(context) }
    val penaltyStartTime = remember { SaffahPenaltyManager.getPenaltyStartTime(context) }

    // Resolve app icon and display name with multi-tier fallback
    val appIconDrawable = remember(sourcePkg, sourceAppName) {
        val primaryTarget = if (sourcePkg.isNotBlank()) sourcePkg else sourceAppName
        var icon = AppListHelper.resolveIconFast(context, primaryTarget)
        if (icon == null && sourceAppName.isNotBlank() && sourceAppName != primaryTarget) {
            icon = AppListHelper.resolveIconFast(context, sourceAppName)
        }
        icon
    }
    val appIconPainter = rememberFastDrawablePainter(appIconDrawable)

    val displayAppName = remember(sourceAppName, sourcePkg) {
        if (sourceAppName.isNotBlank() && !sourceAppName.contains(".")) {
            sourceAppName
        } else if (sourcePkg.isNotBlank()) {
            AppListHelper.resolveAppLabelFast(context, sourcePkg)
        } else {
            "تطبيق محمي"
        }
    }

    val displayPkgName = remember(sourcePkg, sourceAppName) {
        if (sourcePkg.isNotBlank() && sourcePkg.contains(".")) {
            sourcePkg
        } else if (sourceAppName.isNotBlank() && sourceAppName.contains(".")) {
            sourceAppName
        } else {
            ""
        }
    }

    // Format violation timestamp
    val formattedDateTime = remember(penaltyStartTime) {
        val sdf = SimpleDateFormat("HH:mm:ss • yyyy/MM/dd", Locale.US)
        sdf.format(Date(if (penaltyStartTime > 0L) penaltyStartTime else System.currentTimeMillis()))
    }

    // Countdown loop - Runs purely once per second with zero CPU overhead
    LaunchedEffect(Unit) {
        while (true) {
            val rem = SaffahPenaltyManager.getRemainingPenaltyTimeMs(context)
            remainingMs = rem
            if (rem <= 0L) {
                SaffahPenaltyManager.clearPenalty(context)
                onPenaltyFinished()
                break
            }
            delay(1000L)
        }
    }

    // Quotes state - cycles automatically every 9 seconds or immediately on click
    var currentQuoteIndex by remember {
        mutableIntStateOf(
            if (SaffahPenaltyQuotes.ALL_QUOTES.isNotEmpty()) (0 until SaffahPenaltyQuotes.ALL_QUOTES.size).random() else 0
        )
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(9000L)
            if (SaffahPenaltyQuotes.ALL_QUOTES.isNotEmpty()) {
                currentQuoteIndex = (currentQuoteIndex + 1) % SaffahPenaltyQuotes.ALL_QUOTES.size
            }
        }
    }

    val currentQuote = remember(currentQuoteIndex) {
        SaffahPenaltyQuotes.getQuoteForIndex(currentQuoteIndex)
    }

    // Time calculations
    val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val timeFormatted = String.format(Locale.US, "%02d:%02d", minutes, seconds)

    val targetProgress = if (totalMs > 0L) {
        (remainingMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val animatedProgress by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "ProgressAnimation"
    )

    // Subtle ambient breathing aura
    val infiniteTransition = rememberInfiniteTransition(label = "AuraBreath")
    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.60f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AuraAlpha"
    )

    // ==========================================
    // THEME PALETTES (Warm Minimalist Bento)
    // ==========================================
    val bgGradient = if (isDark) {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFF090D16),
                Color(0xFF0F172A),
                Color(0xFF151026),
                Color(0xFF080B11)
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFFFFBEB), // Soft Warm Amber Tint
                Color(0xFFFEF3C7),
                Color(0xFFF8FAFC),
                Color(0xFFF1F5F9)
            )
        )
    }

    val cardBg = if (isDark) Color(0xFF1E293B).copy(alpha = 0.88f) else Color(0xFFFFFFFF).copy(alpha = 0.96f)
    val cardBorder = if (isDark) Color(0xFF334155).copy(alpha = 0.7f) else Color(0xFFE2E8F0)
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else Color(0xFF334155)
    val textMuted = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)

    val timerProgressColor = if (isDark) Color(0xFFF59E0B) else Color(0xFFD97706)
    val timerTrackColor = if (isDark) Color(0xFF334155).copy(alpha = 0.5f) else Color(0xFFE2E8F0)

    val chipBg = if (isDark) Color(0xFF0F172A).copy(alpha = 0.8f) else Color(0xFFFFFBEB)
    val chipBorder = if (isDark) Color(0xFF334155).copy(alpha = 0.7f) else Color(0xFFFDE68A)
    val chipTextColor = if (isDark) Color(0xFFE2E8F0) else Color(0xFF92400E)

    val violationPillBg = if (isDark) Color(0xFF450A0A).copy(alpha = 0.65f) else Color(0xFFFEF2F2)
    val violationPillBorder = if (isDark) Color(0xFF991B1B).copy(alpha = 0.65f) else Color(0xFFFECACA)
    val violationPillText = if (isDark) Color(0xFFFEE2E2) else Color(0xFF991B1B)

    val quoteBorder = if (isDark) Color(0xFFF59E0B).copy(alpha = 0.45f) else Color(0xFFFDE68A)
    val quoteCategoryBg = if (isDark) Color(0xFFF59E0B).copy(alpha = 0.15f) else Color(0xFFFEF3C7)
    val quoteCategoryText = if (isDark) Color(0xFFFBBF24) else Color(0xFFB45309)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgGradient),
        contentAlignment = Alignment.Center
    ) {
        // Subtle background luxury radial aura
        Box(
            modifier = Modifier
                .size(320.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            (if (isDark) Color(0xFFF59E0B) else Color(0xFFFBBF24)).copy(alpha = auraAlpha * 0.18f),
                            (if (isDark) Color(0xFF6366F1) else Color(0xFF38BDF8)).copy(alpha = auraAlpha * 0.08f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Saffah Official Brand Header in Penalty Overlay
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.ic_saffah_brand_logo),
                    contentDescription = "شعار السفاح",
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "درع السفّاح • قفل تأديبي نشط",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = textMuted
                )
            }

            // ==========================================
            // Bento Card 1: Circular Countdown Timer
            // ==========================================
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = cardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, cardBorder),
                shadowElevation = if (isDark) 0.dp else 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(155.dp)
                    ) {
                        CircularProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier.fillMaxSize(),
                            color = timerProgressColor,
                            strokeWidth = 8.dp,
                            trackColor = timerTrackColor,
                        )
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(horizontal = 14.dp)
                        ) {
                            Text(
                                text = timeFormatted,
                                style = MaterialTheme.typography.displayMedium.copy(
                                    fontSize = 38.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.5.sp
                                ),
                                color = textPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "الوقت المتبقي لانتهاء الحجر",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Medium
                                ),
                                color = textMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Chips Row: Penalty Badge & Duration
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Strict Lock Badge
                        Surface(
                            modifier = Modifier.saffahBreathingPulse(minScale = 0.96f, maxScale = 1.04f, durationMs = 2000),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isDark) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFFFEE2E2),
                            border = androidx.compose.foundation.BorderStroke(
                                0.5.dp,
                                if (isDark) Color(0xFFEF4444).copy(alpha = 0.5f) else Color(0xFFFCA5A5)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = if (isDark) Color(0xFFFCA5A5) else Color(0xFFDC2626),
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "قفل تأديبي صارم",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = if (isDark) Color(0xFFFCA5A5) else Color(0xFFB91C1C)
                                )
                            }
                        }

                        // Duration chip
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = chipBg,
                            border = androidx.compose.foundation.BorderStroke(1.dp, chipBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HourglassBottom,
                                    contentDescription = null,
                                    tint = timerProgressColor,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "المدة: ${SaffahPenaltyManager.getPenaltyDurationMinutes(context)} دقيقة",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = chipTextColor
                                )
                            }
                        }
                    }
                }
            }

            // ==========================================
            // Bento Card 2: Detected Violation & App Details
            // ==========================================
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = cardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, cardBorder),
                shadowElevation = if (isDark) 0.dp else 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Radar,
                                contentDescription = null,
                                tint = if (isDark) Color(0xFFF87171) else Color(0xFFDC2626),
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "بيانات الرصد المكتشف",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = textPrimary
                            )
                        }

                        Text(
                            text = formattedDateTime,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = textMuted
                        )
                    }

                    HorizontalDivider(
                        color = if (isDark) Color(0xFF334155).copy(alpha = 0.5f) else Color(0xFFE2E8F0)
                    )

                    // App Row with guaranteed Real Icon Resolution
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)
                            ),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                if (appIconPainter != null) {
                                    Image(
                                        painter = appIconPainter,
                                        contentDescription = displayAppName,
                                        modifier = Modifier
                                            .size(26.dp)
                                            .clip(CircleShape)
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Apps,
                                        contentDescription = null,
                                        tint = if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = displayAppName,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp
                                ),
                                color = textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (displayPkgName.isNotBlank()) {
                                Text(
                                    text = displayPkgName,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                    color = textMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Blocked Item pill
                    val itemToDisplay = if (detectedItem.isNotBlank()) detectedItem else reason
                    val typeLabel = if (detectedType.isNotBlank()) detectedType else "العنصر المحظور"
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = violationPillBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, violationPillBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Block,
                                contentDescription = null,
                                tint = if (isDark) Color(0xFFF87171) else Color(0xFFDC2626),
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "$typeLabel: $itemToDisplay",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = violationPillText,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // ==========================================
            // Bento Card 3: Awakening & Wisdom Platform (No Emojis)
            // ==========================================
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (SaffahPenaltyQuotes.ALL_QUOTES.isNotEmpty()) {
                            currentQuoteIndex = (currentQuoteIndex + 1) % SaffahPenaltyQuotes.ALL_QUOTES.size
                        }
                    },
                shape = RoundedCornerShape(20.dp),
                color = cardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, quoteBorder),
                shadowElevation = if (isDark) 0.dp else 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    // Category Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = quoteCategoryBg,
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, quoteBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = getCategoryIcon(currentQuote.category),
                                    contentDescription = null,
                                    tint = quoteCategoryText,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = currentQuote.category.title,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = quoteCategoryText
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Autorenew,
                                contentDescription = "تغيير العبارة",
                                tint = textMuted,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "${currentQuoteIndex + 1}/${SaffahPenaltyQuotes.ALL_QUOTES.size}",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = textMuted
                            )
                        }
                    }

                    // Animated Quote Content
                    AnimatedContent(
                        targetState = currentQuote,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(350)) togetherWith fadeOut(animationSpec = tween(250))
                        },
                        label = "QuoteTransition"
                    ) { quote ->
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = quote.text,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 13.5.sp,
                                    lineHeight = 20.sp,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = textPrimary,
                                textAlign = TextAlign.Right
                            )

                            if (quote.subText.isNotBlank()) {
                                Text(
                                    text = quote.subText,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        lineHeight = 16.sp
                                    ),
                                    color = textSecondary,
                                    textAlign = TextAlign.Right
                                )
                            }
                        }
                    }

                    Text(
                        text = "انقر فوق البطاقة لتغيير العبارة يدوياً",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                        color = textMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}
