package com.example.ui.screens

import android.graphics.drawable.Drawable
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.rememberFastDrawablePainter
import com.example.model.BlockLogEntry
import com.example.model.InstalledApp
import com.example.ui.components.GlassBentoCard
import com.example.ui.components.featureTitleHint
import com.example.ui.theme.*
import com.example.util.AppListHelper
import com.example.viewmodel.MainViewModel

enum class BlockLogFilterType {
    ALL, KEYWORDS, SITES, IMAGES
}

@Composable
fun BlockLogsScreen(viewModel: MainViewModel) {
    LaunchedEffect(Unit) {
        viewModel.refreshBlockLogs()
    }

    val logs by viewModel.blockLogs.collectAsState()
    val detectedKeywordsCount by viewModel.detectedKeywordsCount.collectAsState()
    val detectedSitesCount by viewModel.detectedSitesCount.collectAsState()
    val detectedImagesCount by viewModel.detectedImagesCount.collectAsState()
    val totalBlockEventsCount by viewModel.totalBlockEventsCount.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()

    var selectedFilter by remember { mutableStateOf(BlockLogFilterType.ALL) }
    var showClearLogConfirmDialog by remember { mutableStateOf(false) }

    // Filter logs for Keywords, Websites, and Images
    val relevantLogs = remember(logs) {
        logs.filter { it.type.contains("كلمة") || it.type.contains("موقع") || it.type.contains("صورة") || it.type.contains("صور") || it.type.contains("AI") || it.type.contains("الذكاء") }
    }

    val filteredLogs = remember(relevantLogs, selectedFilter) {
        when (selectedFilter) {
            BlockLogFilterType.ALL -> relevantLogs
            BlockLogFilterType.KEYWORDS -> relevantLogs.filter { it.type.contains("كلمة") }
            BlockLogFilterType.SITES -> relevantLogs.filter { it.type.contains("موقع") }
            BlockLogFilterType.IMAGES -> relevantLogs.filter { it.type.contains("صورة") || it.type.contains("صور") || it.type.contains("AI") || it.type.contains("الذكاء") }
        }
    }

    val actualTotalCount = maxOf(totalBlockEventsCount, relevantLogs.size)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "سجل الحظر والمنع",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "سجل الكلمات والمواقع والصور المحظورة والتطبيقات المكتشفة بها",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (relevantLogs.isNotEmpty()) {
                IconButton(
                    onClick = { showClearLogConfirmDialog = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteSweep,
                        contentDescription = "مسح السجل",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        if (showClearLogConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showClearLogConfirmDialog = false },
                icon = {
                    Icon(
                        imageVector = Icons.Outlined.DeleteSweep,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                },
                title = {
                    Text(
                        text = "تأكيد مسح السجل",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                text = {
                    Text(
                        text = "هل أنت متأكد من رغبتك في مسح سجل الكلمات والمواقع والصور المحظورة بالكامل؟ لا يمكن التراجع عن هذا الإجراء.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showClearLogConfirmDialog = false
                            viewModel.clearBlockLogs()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "مسح السجل",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onError
                        )
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { showClearLogConfirmDialog = false },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء")
                    }
                },
                shape = RoundedCornerShape(18.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Bento UI Stats Header Grid with interactive filter selection
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Stat 1: Detected Keywords Count
            BentoStatCard(
                modifier = Modifier.weight(1f),
                title = "الكلمات",
                count = "$detectedKeywordsCount",
                icon = Icons.Outlined.FormatQuote,
                isSelected = selectedFilter == BlockLogFilterType.KEYWORDS,
                onClick = {
                    selectedFilter = if (selectedFilter == BlockLogFilterType.KEYWORDS) {
                        BlockLogFilterType.ALL
                    } else {
                        BlockLogFilterType.KEYWORDS
                    }
                },
                hintKey = "keyword_blocking"
            )

            // Stat 2: Detected Websites Count
            BentoStatCard(
                modifier = Modifier.weight(1f),
                title = "المواقع",
                count = "$detectedSitesCount",
                icon = Icons.Outlined.Public,
                isSelected = selectedFilter == BlockLogFilterType.SITES,
                onClick = {
                    selectedFilter = if (selectedFilter == BlockLogFilterType.SITES) {
                        BlockLogFilterType.ALL
                    } else {
                        BlockLogFilterType.SITES
                    }
                },
                hintKey = "site_blocking"
            )

            // Stat 3: Detected Inappropriate Images Count
            BentoStatCard(
                modifier = Modifier.weight(1f),
                title = "الصور المحظورة",
                count = "$detectedImagesCount",
                icon = Icons.Outlined.Image,
                isSelected = selectedFilter == BlockLogFilterType.IMAGES,
                onClick = {
                    selectedFilter = if (selectedFilter == BlockLogFilterType.IMAGES) {
                        BlockLogFilterType.ALL
                    } else {
                        BlockLogFilterType.IMAGES
                    }
                },
                hintKey = "ai_protection"
            )

            // Stat 4: Total Block Events Count (Unlimited / Show All)
            BentoStatCard(
                modifier = Modifier.weight(1f),
                title = "إجمالي الحظر",
                count = "$actualTotalCount",
                icon = Icons.Outlined.Shield,
                isSelected = selectedFilter == BlockLogFilterType.ALL,
                onClick = {
                    selectedFilter = BlockLogFilterType.ALL
                },
                hintKey = "block_logs"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when (selectedFilter) {
                                    BlockLogFilterType.KEYWORDS -> Icons.Outlined.FormatQuote
                                    BlockLogFilterType.SITES -> Icons.Outlined.Public
                                    BlockLogFilterType.IMAGES -> Icons.Outlined.Image
                                    BlockLogFilterType.ALL -> Icons.Outlined.CheckCircleOutline
                                },
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = when (selectedFilter) {
                            BlockLogFilterType.KEYWORDS -> "لا توجد كلمات محظورة مسجلة"
                            BlockLogFilterType.SITES -> "لا توجد مواقع محظورة مسجلة"
                            BlockLogFilterType.IMAGES -> "لا توجد صور غير لائقة محظورة مسجلة"
                            BlockLogFilterType.ALL -> "لا توجد عمليات حظر مسجلة حالياً"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = when (selectedFilter) {
                            BlockLogFilterType.KEYWORDS -> "اضغط على البطاقة مرة أخرى أو على إجمالي الحظر لعرض الكل"
                            BlockLogFilterType.SITES -> "اضغط على البطاقة مرة أخرى أو على إجمالي الحظر لعرض الكل"
                            BlockLogFilterType.IMAGES -> "اضغط على البطاقة مرة أخرى أو على إجمالي الحظر لعرض الكل"
                            BlockLogFilterType.ALL -> "سيتم تسجيل أي كلمة أو موقع أو صورة محظورة عند اكتشافها فوراً"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            val appMap = remember(installedApps) {
                val map = HashMap<String, InstalledApp>(installedApps.size * 2)
                for (app in installedApps) {
                    map[app.packageName.lowercase()] = app
                    map[app.appName.lowercase()] = app
                }
                map
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredLogs, key = { it.id }) { log ->
                    Box(
                        modifier = Modifier.animateItem(
                            fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                            fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                            placementSpec = androidx.compose.animation.core.spring(
                                stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                dampingRatio = 0.8f
                            )
                        )
                    ) {
                        BlockLogItemCard(
                            log = log,
                            appMap = appMap
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BentoStatCard(
    modifier: Modifier = Modifier,
    title: String,
    count: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean = false,
    onClick: () -> Unit = {},
    hintKey: String? = null
) {
    val borderColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
        animationSpec = tween(220, easing = FastOutSlowInEasing),
        label = "BentoBorderColor"
    )
    val bgColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
        animationSpec = tween(220, easing = FastOutSlowInEasing),
        label = "BentoBgColor"
    )

    Surface(
        onClick = onClick,
        modifier = modifier.saffahPressMotion(),
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                if (isSelected) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(6.dp)
                            .saffahBreathingPulse(enabled = true, minScale = 0.95f, maxScale = 1.08f, durationMs = 2400)
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            AnimatedContent(
                targetState = count,
                transitionSpec = {
                    (slideInVertically { height -> height / 2 } + fadeIn(tween(160))) togetherWith
                    (slideOutVertically { height -> -height / 2 } + fadeOut(tween(120)))
                },
                label = "BentoStatCount"
            ) { targetCount ->
                Text(
                    text = targetCount,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = if (hintKey != null) Modifier.featureTitleHint(hintKey = hintKey, onClick = onClick) else Modifier
            )
        }
    }
}

@Composable
private fun BlockLogItemCard(
    log: BlockLogEntry,
    appMap: Map<String, InstalledApp>
) {
    val isWebsite = log.type.contains("موقع")
    val isImage = log.type.contains("صورة") || log.type.contains("صور") || log.type.contains("AI") || log.type.contains("الذكاء")
    val formattedTime = remember(log.id, log.timestamp) { formatFullDateTime24H(log.id, log.timestamp) }

    GlassBentoCard(
        modifier = Modifier.saffahPressMotion(),
        backgroundColor = MaterialTheme.colorScheme.surface,
        borderColor = MaterialTheme.colorScheme.outline
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Source App Real Icon
            RealAppSourceIcon(
                sourceApp = log.sourceApp,
                appMap = appMap,
                modifier = Modifier.size(42.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Main Info Column
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = log.blockedItem,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // 24h Time Tag
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AccessTime,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = formattedTime,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Type Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = if (isImage) "صورة محظورة" else if (isWebsite) "موقع محظور" else "كلمة محظورة",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }

                    // Source App Label
                    val displayAppName = remember(log.sourceApp, appMap) {
                        resolveAppNameFast(log.sourceApp, appMap)
                    }

                    Text(
                        text = displayAppName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun RealAppSourceIcon(
    sourceApp: String,
    appMap: Map<String, InstalledApp>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val appIconDrawable = remember(sourceApp, appMap) {
        resolveAppIconFast(context, sourceApp, appMap)
    }
    val painter = rememberFastDrawablePainter(appIconDrawable)

    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = modifier
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            if (painter != null) {
                Image(
                    painter = painter,
                    contentDescription = sourceApp,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                )
            } else {
                Icon(
                    imageVector = if (sourceApp.contains("browser", ignoreCase = true) || sourceApp.contains("chrome", ignoreCase = true)) {
                        Icons.Default.Language
                    } else {
                        Icons.Default.Apps
                    },
                    contentDescription = sourceApp,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

private fun resolveAppIconFast(
    context: android.content.Context,
    sourceApp: String,
    appMap: Map<String, InstalledApp>
): Drawable? {
    if (sourceApp.isBlank()) return null

    // 1. Fast in-memory cache lookup
    val cached = AppListHelper.getCachedIcon(sourceApp)
    if (cached != null) return cached

    // 2. Search appMap in O(1)
    val matched = appMap[sourceApp.lowercase()]
    if (matched?.iconDrawable != null) {
        AppListHelper.cacheIcon(sourceApp, matched.iconDrawable)
        return matched.iconDrawable
    }

    // 3. Fallback: Query system icon and cache it
    return AppListHelper.resolveIconFast(context, sourceApp)
}

private fun resolveAppNameFast(
    sourceApp: String,
    appMap: Map<String, InstalledApp>
): String {
    if (sourceApp.isBlank()) return "تطبيق غير معروف"
    val cachedName = AppListHelper.getCachedAppName(sourceApp)
    if (cachedName != null) return cachedName
    val matched = appMap[sourceApp.lowercase()]
    return matched?.appName ?: sourceApp
}

private val cachedDateFormatter = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.US)
private val cachedDateTimeFormatter = java.text.SimpleDateFormat("HH:mm • yyyy/MM/dd", java.util.Locale.US)
private val timeExtractionRegex = Regex("""(\d{1,2}):(\d{2})""")

private fun formatFullDateTime24H(id: Long, timestampStr: String): String {
    // 1. If we have a valid timestamp millisecond ID (after year 2020)
    if (id > 1577836800000L) {
        return synchronized(cachedDateTimeFormatter) {
            cachedDateTimeFormatter.format(java.util.Date(id))
        }
    }

    val trimmed = timestampStr.trim()
    if (trimmed.isBlank()) {
        return synchronized(cachedDateTimeFormatter) {
            cachedDateTimeFormatter.format(java.util.Date())
        }
    }

    // 2. Fast check if already formatted
    if (trimmed.contains("•")) {
        return trimmed
    }

    // 3. Fallback: Parse 12h/24h time and combine with full date
    val isPm = trimmed.contains("PM", ignoreCase = true) || trimmed.contains("م")
    val isAm = trimmed.contains("AM", ignoreCase = true) || trimmed.contains("ص")

    val match = timeExtractionRegex.find(trimmed)
    if (match != null) {
        var hour = match.groupValues[1].toIntOrNull() ?: 12
        val minute = match.groupValues[2]

        if (isPm && hour < 12) {
            hour += 12
        } else if (isAm && hour == 12) {
            hour = 0
        }

        val formattedTimePart = String.format(java.util.Locale.US, "%02d:%s", hour, minute)
        val todayDatePart = synchronized(cachedDateFormatter) {
            cachedDateFormatter.format(java.util.Date())
        }
        return "$formattedTimePart • $todayDatePart"
    }

    return trimmed
}

