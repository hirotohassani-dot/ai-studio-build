package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

object ImageBitmapCache {
    private val bitmapCache = ConcurrentHashMap<Int, ImageBitmap>(128)

    fun getOrConvert(drawable: Drawable?): ImageBitmap? {
        if (drawable == null) return null
        val key = System.identityHashCode(drawable)
        bitmapCache[key]?.let { return it }

        val imageBitmap = try {
            if (drawable is BitmapDrawable && drawable.bitmap != null && !drawable.bitmap.isRecycled) {
                drawable.bitmap.asImageBitmap()
            } else {
                val rawW = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
                val rawH = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
                val width = rawW.coerceIn(48, 144)
                val height = rawH.coerceIn(48, 144)
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bitmap.asImageBitmap()
            }
        } catch (e: Exception) {
            null
        }

        if (imageBitmap != null) {
            bitmapCache[key] = imageBitmap
        }
        return imageBitmap
    }
}

class FastDrawablePainter(val drawable: Drawable) : Painter() {

    init {
        if (drawable.intrinsicWidth >= 0 && drawable.intrinsicHeight >= 0) {
            drawable.setBounds(0, 0, drawable.intrinsicWidth, drawable.intrinsicHeight)
        }
    }

    override val intrinsicSize: Size
        get() = if (drawable.intrinsicWidth >= 0 && drawable.intrinsicHeight >= 0) {
            Size(drawable.intrinsicWidth.toFloat(), drawable.intrinsicHeight.toFloat())
        } else {
            Size.Unspecified
        }

    override fun DrawScope.onDraw() {
        drawIntoCanvas { canvas ->
            val width = size.width.roundToInt()
            val height = size.height.roundToInt()
            drawable.setBounds(0, 0, width, height)
            drawable.draw(canvas.nativeCanvas)
        }
    }
}

@Composable
fun rememberFastDrawablePainter(drawable: Drawable?): Painter? {
    if (drawable == null) return null
    return remember(drawable) {
        val imageBitmap = ImageBitmapCache.getOrConvert(drawable)
        if (imageBitmap != null) {
            BitmapPainter(imageBitmap)
        } else {
            FastDrawablePainter(drawable)
        }
    }
}

