package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.MediaStore
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.example.model.RecoveryPledgeData
import com.example.util.SaffahMediaCompressor
import com.example.util.SaffahRecoveryManager
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * قسم وثيقة تعهد التعافي (Parchment Scroll Recovery Pledge)
 * مصممة برمجياً بالكامل (Compose Canvas) على شكل لفافة ورق قديمة واقعية،
 * خفيفة وفائقة الأداء دون أي استهلاك للذاكرة أو المعالج (0% lag).
 */
@Composable
fun RecoveryPledgeDocumentSection(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val pledgeData by viewModel.recoveryPledge.collectAsState()
    val globalUserName by viewModel.userName.collectAsState()

    var isEditMode by remember(pledgeData.isSigned) { mutableStateOf(!pledgeData.isSigned) }
    var currentText by remember(pledgeData.pledgeText) { mutableStateOf(pledgeData.pledgeText) }
    var currentSignerName by remember(pledgeData.signerName, globalUserName) {
        mutableStateOf(
            if (pledgeData.signerName.isNotBlank()) pledgeData.signerName else globalUserName
        )
    }

    // إدارة التوقيع اليدوي
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var isSignatureLoaded by remember { mutableStateOf(false) }

    // تحميل التوقيع المخزن عند البدء أو التغيير
    LaunchedEffect(pledgeData.signaturePointsJson) {
        strokes.clear()
        if (pledgeData.signaturePointsJson.isNotBlank()) {
            strokes.addAll(parseStrokesFromJson(pledgeData.signaturePointsJson))
        }
        isSignatureLoaded = true
    }

    var showClearConfirmationDialog by remember { mutableStateOf(false) }
    var isProcessingVideo by remember { mutableStateOf(false) }

    // التقاط الفيديو بالكاميرا
    var tempVideoFile by remember { mutableStateOf<File?>(null) }
    val videoCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success ->
        if (success && tempVideoFile != null && tempVideoFile!!.exists() && tempVideoFile!!.length() > 0) {
            isProcessingVideo = true
            val uri = Uri.fromFile(tempVideoFile!!)
            viewModel.compressAndSavePledgeVideo(uri) {
                isProcessingVideo = false
            }
        } else {
            isProcessingVideo = false
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // بطاقة اللفافة الورقية القديمة
        ParchmentScrollCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // رأس الوثيقة الفخم
                ParchmentHeader()

                Spacer(modifier = Modifier.height(10.dp))

                // حقل إدخال اسم المتعافي في وضع التحرير أو عرضه في وضع التوثيق
                if (isEditMode) {
                    OutlinedTextField(
                        value = currentSignerName,
                        onValueChange = { currentSignerName = it },
                        label = { Text("اسم صاحب التعهد", fontSize = 11.sp, color = Color(0xFF6E5336)) },
                        placeholder = { Text("اكتب اسمك ليظهر في الختم الرسمي", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0166FF),
                            unfocusedBorderColor = Color(0xFFB59A72).copy(alpha = 0.5f),
                            focusedContainerColor = Color(0xFFFAF4E6).copy(alpha = 0.7f),
                            unfocusedContainerColor = Color(0xFFFAF4E6).copy(alpha = 0.4f),
                            focusedTextColor = Color(0xFF281B0E),
                            unfocusedTextColor = Color(0xFF281B0E)
                        ),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // مساحة نص التعهد
                if (isEditMode) {
                    OutlinedTextField(
                        value = currentText,
                        onValueChange = { currentText = it },
                        label = { Text("نص ميثاق التعهد (حر وقابل للتعديل)", fontSize = 11.sp, color = Color(0xFF6E5336)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 160.dp, max = 260.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0166FF),
                            unfocusedBorderColor = Color(0xFFB59A72).copy(alpha = 0.5f),
                            focusedContainerColor = Color(0xFFFAF4E6).copy(alpha = 0.8f),
                            unfocusedContainerColor = Color(0xFFFAF4E6).copy(alpha = 0.5f),
                            focusedTextColor = Color(0xFF24170B),
                            unfocusedTextColor = Color(0xFF24170B)
                        ),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 12.5.sp,
                            lineHeight = 20.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                } else {
                    // عرض نص التعهد الموثق بأناقة داخل الورقة القديمة
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color(0xFFF9F2E2).copy(alpha = 0.6f),
                                shape = RoundedCornerShape(6.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Text(
                            text = currentText.ifBlank { SaffahRecoveryManager.DEFAULT_PLEDGE_TEMPLATE },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 13.sp,
                                lineHeight = 21.sp,
                                color = Color(0xFF24170B),
                                fontWeight = FontWeight.Medium
                            ),
                            textAlign = TextAlign.Start
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // قسم الفيديو (تسجيل أو معاينة)
                ParchmentVideoSection(
                    videoPath = pledgeData.videoPath,
                    isProcessing = isProcessingVideo,
                    isEditMode = isEditMode,
                    onRecordClick = {
                        try {
                            val pledgeDir = File(context.filesDir, "recovery_pledge").apply {
                                if (!exists()) mkdirs()
                            }
                            val tempFile = File(pledgeDir, "temp_record_${System.currentTimeMillis()}.mp4")
                            tempVideoFile = tempFile
                            val uri = FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.fileprovider",
                                tempFile
                            )
                            videoCaptureLauncher.launch(uri)
                        } catch (e: Exception) {
                            viewModel.showFeedback("تعذر فتح مسجل الفيديو: ${e.message}")
                        }
                    },
                    onDeleteClick = { viewModel.removePledgeVideo() }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // قسم التوقيع والختم الرسمي وفق "الحالة رقم 1"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(148.dp)
                ) {
                    // 1. قسم الختم الرسمي وفق هيكل الختم في الصورة (على اليمين مع عنوان "الخاتم" أعلاه)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .align(AbsoluteAlignment.TopRight)
                            .padding(end = 4.dp)
                    ) {
                        Text(
                            text = "الخاتم",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4A341E),
                            modifier = Modifier.padding(bottom = 2.dp)
                        )

                        if (pledgeData.isSigned && !isEditMode) {
                            RecoveryOfficialStamp(
                                signerName = pledgeData.signerName.ifBlank { globalUserName.ifBlank { "المتعافي الصامد" } },
                                signedDate = pledgeData.signedDate,
                                signedTime = formatTimeTo24h(pledgeData.signedTime, pledgeData.signedTimestamp)
                            )
                        } else {
                            // أثناء وضع التحرير أو قبل الحفظ
                            Box(
                                modifier = Modifier
                                    .size(114.dp)
                                    .border(
                                        width = 1.dp,
                                        color = Color(0xFFB59A72).copy(alpha = 0.4f),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Verified,
                                        contentDescription = null,
                                        tint = Color(0xFF9E8058).copy(alpha = 0.5f),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "يُعتمد الختم\nعند الحفظ",
                                        fontSize = 8.5.sp,
                                        color = Color(0xFF7A6040),
                                        textAlign = TextAlign.Center,
                                        lineHeight = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    // 2. مستطيل الإمضاء المتداخل وفق "الحالة رقم 1" (يبدأ من أقصى اليسار ويتداخل طرفه الأيمن مع أسفل دائرة الختم)
                    ParchmentSignatureBox(
                        strokes = strokes,
                        isEditable = isEditMode,
                        onClearSignature = { strokes.clear() },
                        modifier = Modifier
                            .align(AbsoluteAlignment.BottomLeft)
                            .padding(start = 2.dp)
                            .fillMaxWidth(0.74f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // أزرار التحكم والعمليات
                if (isEditMode) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                val now = System.currentTimeMillis()
                                val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(now))
                                val timeStr = SimpleDateFormat("HH:mm", Locale.US).format(Date(now))
                                val savedJson = serializeStrokesToJson(strokes)

                                val updatedData = pledgeData.copy(
                                    pledgeText = currentText.ifBlank { SaffahRecoveryManager.DEFAULT_PLEDGE_TEMPLATE },
                                    isSigned = true,
                                    signedDate = if (pledgeData.signedDate.isNotBlank()) pledgeData.signedDate else dateStr,
                                    signedTime = if (pledgeData.signedTime.isNotBlank()) formatTimeTo24h(pledgeData.signedTime, pledgeData.signedTimestamp) else timeStr,
                                    signedTimestamp = if (pledgeData.signedTimestamp > 0) pledgeData.signedTimestamp else now,
                                    signaturePointsJson = savedJson,
                                    signerName = currentSignerName.trim()
                                )
                                viewModel.saveRecoveryPledge(updatedData)
                                isEditMode = false
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF6E4720),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "حفظ وتوثيق العهد",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }

                        if (pledgeData.isSigned) {
                            OutlinedButton(
                                onClick = {
                                    isEditMode = false
                                    currentText = pledgeData.pledgeText
                                    currentSignerName = pledgeData.signerName
                                },
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF9E8058)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFF4A341E)
                                )
                            ) {
                                Text("إلغاء", fontSize = 11.sp)
                            }
                        }
                    }
                } else {
                    // أقصى يسار الوثيقة: أيقونة التعديل بجانب أيقونة السلة بلون بني بدون حاويات أو نصوص
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.align(AbsoluteAlignment.CenterLeft),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { isEditMode = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Edit,
                                    contentDescription = "تعديل الوثيقة",
                                    tint = Color(0xFF6E4720),
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            IconButton(
                                onClick = { showClearConfirmationDialog = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.DeleteOutline,
                                    contentDescription = "تفريغ الوثيقة",
                                    tint = Color(0xFF6E4720),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // حوار تأكيد تفريغ الوثيقة
    if (showClearConfirmationDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmationDialog = false },
            title = {
                Text(
                    text = "تفريغ وثيقة التعهد",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من تفريغ نص الوثيقة ومسح التوقيع والختم والفيديو للبدء من جديد؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearRecoveryPledge()
                        strokes.clear()
                        currentText = SaffahRecoveryManager.DEFAULT_PLEDGE_TEMPLATE
                        isEditMode = true
                        showClearConfirmationDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("تأكيد التفريغ", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmationDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

/**
 * بطاقة الحاوية للورق القديم (Parchment Scroll)
 * مرسومة بنسبة 100% بالـ Canvas بدون أي ملفات خارجية،
 * محاكاة طبق الأصل للصورة المرفقة مع اللفائف الخشبية والأطراف المنحنية.
 */
@Composable
private fun ParchmentScrollCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // اللفافة الخشبية والورقية العلوية
        ParchmentTopRoller(modifier = Modifier.fillMaxWidth())

        // جسم الورقة القديمة مع الحواف الممزقة/المسننة
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .background(
                    brush = Brush.verticalGradient(
                        listOf(
                            Color(0xFFF9F3E3),
                            Color(0xFFF6EBD1),
                            Color(0xFFF2E2C0),
                            Color(0xFFF5E9CC),
                            Color(0xFFFBF6E8)
                        )
                    )
                )
        ) {
            // رسم حدود وتعتيق الورقة الممزقة والفريم الداخلي
            Canvas(modifier = Modifier.matchParentSize()) {
                val w = size.width
                val h = size.height

                // ظلال وتعتيق خفيف على الجانبين الأيمن والأيسر
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFFD4BD94).copy(alpha = 0.45f),
                            Color.Transparent
                        ),
                        startX = 0f,
                        endX = 14.dp.toPx()
                    ),
                    size = Size(14.dp.toPx(), h)
                )
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xFFD4BD94).copy(alpha = 0.45f)
                        ),
                        startX = w - 14.dp.toPx(),
                        endX = w
                    ),
                    topLeft = Offset(w - 14.dp.toPx(), 0f),
                    size = Size(14.dp.toPx(), h)
                )

                // إطار أثري مزدوج خفيف داخل الورقة
                val inset = 8.dp.toPx()
                drawRoundRect(
                    color = Color(0xFF9E8058).copy(alpha = 0.35f),
                    topLeft = Offset(inset, inset),
                    size = Size(w - inset * 2, h - inset * 2),
                    cornerRadius = CornerRadius(4.dp.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
                val innerInset = 11.dp.toPx()
                drawRoundRect(
                    color = Color(0xFFB89B72).copy(alpha = 0.25f),
                    topLeft = Offset(innerInset, innerInset),
                    size = Size(w - innerInset * 2, h - innerInset * 2),
                    cornerRadius = CornerRadius(3.dp.toPx()),
                    style = Stroke(width = 0.8f.dp.toPx())
                )

                // زركشات أثرية في أركان الإطار الداخلي
                val cornerLen = 8.dp.toPx()
                // Top-Left
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(innerInset, innerInset), Offset(innerInset + cornerLen, innerInset), 1.5f)
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(innerInset, innerInset), Offset(innerInset, innerInset + cornerLen), 1.5f)
                // Top-Right
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(w - innerInset, innerInset), Offset(w - innerInset - cornerLen, innerInset), 1.5f)
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(w - innerInset, innerInset), Offset(w - innerInset, innerInset + cornerLen), 1.5f)
                // Bottom-Left
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(innerInset, h - innerInset), Offset(innerInset + cornerLen, h - innerInset), 1.5f)
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(innerInset, h - innerInset), Offset(innerInset, h - innerInset - cornerLen), 1.5f)
                // Bottom-Right
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(w - innerInset, h - innerInset), Offset(w - innerInset - cornerLen, h - innerInset), 1.5f)
                drawLine(Color(0xFF7D5F3A).copy(alpha = 0.4f), Offset(w - innerInset, h - innerInset), Offset(w - innerInset, h - innerInset - cornerLen), 1.5f)
            }

            content()
        }

        // اللفافة الخشبية والورقية السفلية
        ParchmentBottomRoller(modifier = Modifier.fillMaxWidth())
    }
}

/**
 * اللفافة العلوية: مرسومة برمجياً بالكامل بمظهر أسطوانة خشبية ومقابض مخرطة مع ورقة ملفوفة
 */
@Composable
private fun ParchmentTopRoller(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(34.dp)
    ) {
        val w = size.width
        val h = size.height
        val knobWidth = 22.dp.toPx()
        val scrollBodyStartX = knobWidth
        val scrollBodyEndX = w - knobWidth

        // مقبض الخشب الأيسر (Left Wooden Finial)
        drawWoodenFinial(isLeft = true, width = knobWidth, height = h)

        // مقبض الخشب الأيمن (Right Wooden Finial)
        drawWoodenFinial(isLeft = false, width = knobWidth, height = h)

        // لفة الورقة الأسطوانية العلوية
        val rollHeight = h * 0.72f
        val rollTop = (h - rollHeight) / 2f
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFFBF6E9),
                    Color(0xFFF3E7CD),
                    Color(0xFFDECEA8),
                    Color(0xFFB89E73),
                    Color(0xFF8C6E45)
                ),
                startY = rollTop,
                endY = rollTop + rollHeight
            ),
            topLeft = Offset(scrollBodyStartX - 2.dp.toPx(), rollTop),
            size = Size(scrollBodyEndX - scrollBodyStartX + 4.dp.toPx(), rollHeight),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )

        // خط طيات وأثر شق الورقة عند الالتفاف
        drawLine(
            color = Color(0xFF6B4E29).copy(alpha = 0.35f),
            start = Offset(scrollBodyStartX + 4.dp.toPx(), rollTop + rollHeight * 0.82f),
            end = Offset(scrollBodyEndX - 4.dp.toPx(), rollTop + rollHeight * 0.82f),
            strokeWidth = 1.dp.toPx()
        )
    }
}

/**
 * اللفافة السفلية: مرسومة برمجياً بالكامل بمظهر أسطوانة خشبية ومقابض مخرطة مع ورقة ملفوفة لأعلى
 */
@Composable
private fun ParchmentBottomRoller(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(34.dp)
    ) {
        val w = size.width
        val h = size.height
        val knobWidth = 22.dp.toPx()
        val scrollBodyStartX = knobWidth
        val scrollBodyEndX = w - knobWidth

        // مقبض الخشب الأيسر
        drawWoodenFinial(isLeft = true, width = knobWidth, height = h)

        // مقبض الخشب الأيمن
        drawWoodenFinial(isLeft = false, width = knobWidth, height = h)

        // لفة الورقة الأسطوانية السفلية الملتفة لأعلى
        val rollHeight = h * 0.72f
        val rollTop = (h - rollHeight) / 2f
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF8C6E45),
                    Color(0xFFB89E73),
                    Color(0xFFDECEA8),
                    Color(0xFFF3E7CD),
                    Color(0xFFFBF6E9)
                ),
                startY = rollTop,
                endY = rollTop + rollHeight
            ),
            topLeft = Offset(scrollBodyStartX - 2.dp.toPx(), rollTop),
            size = Size(scrollBodyEndX - scrollBodyStartX + 4.dp.toPx(), rollHeight),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )

        // خط طيات الورقة في اللفافة السفلية
        drawLine(
            color = Color(0xFF6B4E29).copy(alpha = 0.35f),
            start = Offset(scrollBodyStartX + 4.dp.toPx(), rollTop + rollHeight * 0.2f),
            end = Offset(scrollBodyEndX - 4.dp.toPx(), rollTop + rollHeight * 0.2f),
            strokeWidth = 1.dp.toPx()
        )
    }
}

/**
 * رسم المقبض الخشبي المخرط للّفافة (Wooden Finial Knob) بتدرجات الخشب الأصيل
 */
private fun DrawScope.drawWoodenFinial(isLeft: Boolean, width: Float, height: Float) {
    val centerY = height / 2f
    val knobColors = listOf(
        Color(0xFF381F0D),
        Color(0xFF6E4324),
        Color(0xFF9E653C),
        Color(0xFF5A3319),
        Color(0xFF2E1708)
    )

    if (isLeft) {
        // الطرف الدائري الخارجي
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF9E653C), Color(0xFF381F0D)),
                center = Offset(width * 0.22f, centerY - 2.dp.toPx()),
                radius = width * 0.25f
            ),
            radius = width * 0.22f,
            center = Offset(width * 0.22f, centerY)
        )
        // العنق المخرط
        drawRoundRect(
            brush = Brush.verticalGradient(knobColors, startY = centerY - height * 0.3f, endY = centerY + height * 0.3f),
            topLeft = Offset(width * 0.38f, centerY - height * 0.35f),
            size = Size(width * 0.3f, height * 0.7f),
            cornerRadius = CornerRadius(3.dp.toPx())
        )
        // الحلقة القاعدة الملتصقة بالأسطوانة
        drawRoundRect(
            brush = Brush.verticalGradient(knobColors, startY = centerY - height * 0.4f, endY = centerY + height * 0.4f),
            topLeft = Offset(width * 0.68f, centerY - height * 0.42f),
            size = Size(width * 0.32f, height * 0.84f),
            cornerRadius = CornerRadius(2.dp.toPx())
        )
    } else {
        val startX = size.width - width
        // الحلقة القاعدة الملتصقة بالأسطوانة
        drawRoundRect(
            brush = Brush.verticalGradient(knobColors, startY = centerY - height * 0.4f, endY = centerY + height * 0.4f),
            topLeft = Offset(startX, centerY - height * 0.42f),
            size = Size(width * 0.32f, height * 0.84f),
            cornerRadius = CornerRadius(2.dp.toPx())
        )
        // العنق المخرط
        drawRoundRect(
            brush = Brush.verticalGradient(knobColors, startY = centerY - height * 0.3f, endY = centerY + height * 0.3f),
            topLeft = Offset(startX + width * 0.32f, centerY - height * 0.35f),
            size = Size(width * 0.3f, height * 0.7f),
            cornerRadius = CornerRadius(3.dp.toPx())
        )
        // الطرف الدائري الخارجي
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF9E653C), Color(0xFF381F0D)),
                center = Offset(startX + width * 0.78f, centerY - 2.dp.toPx()),
                radius = width * 0.25f
            ),
            radius = width * 0.22f,
            center = Offset(startX + width * 0.78f, centerY)
        )
    }
}

/**
 * رأس الوثيقة الأثري
 */
@Composable
private fun ParchmentHeader() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Shield,
            contentDescription = null,
            tint = Color(0xFF634726),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "وثيقة عهد وميثاق التعافي",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF332010),
                letterSpacing = 0.5.sp
            ),
            textAlign = TextAlign.Center
        )
        Text(
            text = "عهد شرف مغلظ وميثاق ناصع للحرية والكرامة",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                color = Color(0xFF6E5132),
                fontWeight = FontWeight.Normal
            ),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        // خط فاصل أثري
        Canvas(modifier = Modifier.fillMaxWidth().height(4.dp)) {
            val cx = size.width / 2f
            val len = size.width * 0.42f
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, Color(0xFF8C6E45).copy(alpha = 0.6f), Color.Transparent)
                ),
                start = Offset(cx - len, size.height / 2f),
                end = Offset(cx + len, size.height / 2f),
                strokeWidth = 1.dp.toPx()
            )
            drawCircle(
                color = Color(0xFF7A5C34),
                radius = 1.8.dp.toPx(),
                center = Offset(cx, size.height / 2f)
            )
        }
    }
}

/**
 * قسم تسجيل وعرض فيديو التعهد مع الضغط الفائق
 * في المكان الفارغ (المستطيل الأخضر سابقاً): في مركزه نص تسجيل فيديو مع أيقونة تسجيل.
 * عند الضغط عليه يتم تسجيل فيديو، وبعد التسجيل يظهر thumbnail الفيديو بشكل مستطيل وحواف دائرية
 * في داخله أيقونة تشغيل الفيديو، وعند الضغط عليه يشتغل مباشرة في مكانه (in-place) بدون ملء الشاشة.
 * بالإضافة لأيقونة صغيرة لحذف أو إعادة تسجيل الفيديو.
 */
@Composable
private fun ParchmentVideoSection(
    videoPath: String,
    isProcessing: Boolean,
    isEditMode: Boolean,
    onRecordClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPlayingInPlace by remember { mutableStateOf(false) }

    // إعادة ضبط التشغيل إذا تغير مسار الفيديو
    LaunchedEffect(videoPath) {
        isPlayingInPlace = false
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        if (videoPath.isNotBlank()) {
            val context = LocalContext.current
            val thumbnail = remember(videoPath) {
                try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(videoPath)
                    val frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    retriever.release()
                    frame
                } catch (_: Exception) {
                    null
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(130.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1F1710))
                    .border(1.dp, Color(0xFF8C7150).copy(alpha = 0.45f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (isPlayingInPlace) {
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                val mediaController = MediaController(ctx)
                                mediaController.setAnchorView(this)
                                setMediaController(mediaController)
                                setVideoPath(videoPath)
                                setOnPreparedListener { mp ->
                                    mp.isLooping = false
                                    start()
                                }
                                setOnCompletionListener {
                                    isPlayingInPlace = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // زر إيقاف العرض والعودة للمعاينة
                    IconButton(
                        onClick = { isPlayingInPlace = false },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(4.dp)
                            .size(26.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إيقاف",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                } else {
                    // عرض الصورة المصغرة (Thumbnail)
                    if (thumbnail != null) {
                        Image(
                            bitmap = thumbnail.asImageBitmap(),
                            contentDescription = "معاينة الفيديو",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        // طبقة تظليل خفيفة لإبراز أيقونة التشغيل
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.28f))
                        )
                    }

                    // زر وأيقونة تشغيل الفيديو في الوسط
                    Surface(
                        onClick = { isPlayingInPlace = true },
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.65f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "تشغيل الفيديو",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    // عناصر التحكم الإضافية (حذف / إعادة تسجيل)
                    if (isEditMode) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp),
                            shape = RoundedCornerShape(20.dp),
                            color = Color.Black.copy(alpha = 0.65f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // إعادة التسجيل
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .clickable { onRecordClick() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = "إعادة التسجيل",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // فاصل عمودي دقيق
                                Box(
                                    modifier = Modifier
                                        .width(1.dp)
                                        .height(14.dp)
                                        .background(Color.White.copy(alpha = 0.3f))
                                )

                                // حذف الفيديو
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .clickable { onDeleteClick() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Delete,
                                        contentDescription = "حذف الفيديو",
                                        tint = Color(0xFFFF6B6B),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // لا يوجد فيديو: نص "تسجيل فيديو" مع أيقونة تسجيل في مركز الحاوية
            Surface(
                onClick = onRecordClick,
                enabled = !isProcessing,
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF6E4720),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF8C7150).copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                        Text(
                            text = "جاري الحفظ...",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(17.dp)
                        )
                        Text(
                            text = "تسجيل فيديو",
                            color = Color.White,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

/**
 * منطقة التوقيع
 * منطقة مخفية مسموحة للإمضاء تحت نص "الإمضاء:" مباشرة دون تلميح أو إطار أو مربعات
 * حتى يكون الإمضاء نقياً وحقيقياً تماماً على ورق البردي.
 */
@Composable
private fun ParchmentSignatureBox(
    strokes: MutableList<List<Offset>>,
    isEditable: Boolean,
    onClearSignature: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentStroke by remember { mutableStateOf<List<Offset>>(emptyList()) }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.Start
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الإمضاء:",
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4A341E)
            )

            if (isEditable && (strokes.isNotEmpty() || currentStroke.isNotEmpty())) {
                Text(
                    text = "مسح الإمضاء",
                    fontSize = 9.sp,
                    color = Color(0xFFB3261E),
                    modifier = Modifier
                        .clickable {
                            currentStroke = emptyList()
                            onClearSignature()
                        }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(3.dp))

        // منطقة إمضاء مخفية بدون أي إطار أو خلفية أو تلميح أو خطوط
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(86.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clipToBounds()
                    .then(
                        if (isEditable) {
                            Modifier.pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        val clamped = Offset(
                                            offset.x.coerceIn(0f, size.width.toFloat()),
                                            offset.y.coerceIn(0f, size.height.toFloat())
                                        )
                                        currentStroke = listOf(clamped)
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        val clamped = Offset(
                                            change.position.x.coerceIn(0f, size.width.toFloat()),
                                            change.position.y.coerceIn(0f, size.height.toFloat())
                                        )
                                        currentStroke = currentStroke + clamped
                                    },
                                    onDragEnd = {
                                        if (currentStroke.isNotEmpty()) {
                                            strokes.add(currentStroke)
                                            currentStroke = emptyList()
                                        }
                                    },
                                    onDragCancel = {
                                        currentStroke = emptyList()
                                    }
                                )
                            }
                        } else Modifier
                    )
            ) {
                val inkColor = Color(0xFF0166FF)
                val strokeWidthPx = 2.8.dp.toPx()

                // رسم الخطوط المحفوظة
                for (stroke in strokes) {
                    if (stroke.size > 1) {
                        val path = Path()
                        path.moveTo(stroke.first().x, stroke.first().y)
                        for (i in 1 until stroke.size) {
                            path.lineTo(stroke[i].x, stroke[i].y)
                        }
                        drawPath(
                            path = path,
                            color = inkColor,
                            style = Stroke(
                                width = strokeWidthPx,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    } else if (stroke.size == 1) {
                        drawCircle(
                            color = inkColor,
                            radius = strokeWidthPx / 2f,
                            center = stroke.first()
                        )
                    }
                }

                // رسم الخط الحالي تحت أصبع المستخدم
                if (currentStroke.size > 1) {
                    val path = Path()
                    path.moveTo(currentStroke.first().x, currentStroke.first().y)
                    for (i in 1 until currentStroke.size) {
                        path.lineTo(currentStroke[i].x, currentStroke[i].y)
                    }
                    drawPath(
                        path = path,
                        color = inkColor,
                        style = Stroke(
                            width = strokeWidthPx,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                } else if (currentStroke.size == 1) {
                    drawCircle(
                        color = inkColor,
                        radius = strokeWidthPx / 2f,
                        center = currentStroke.first()
                    )
                }
            }
        }
    }
}

/**
 * ختم التعافي الرسمي (Official Recovery Stamp)
 * تم حذف الهلال وأشعة الشمس وأغصان الغار بناءً على طلب المستخدم،
 * مع الإبقاء على الدوائر والنصوص والنجوم التوثيقية الرسمية.
 */
@Composable
private fun RecoveryOfficialStamp(
    signerName: String,
    signedDate: String,
    signedTime: String,
    modifier: Modifier = Modifier
) {
    val stampRed = Color(0xFFB71C1C)

    var isStamped by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isStamped = true
    }
    val stampScale by animateFloatAsState(
        targetValue = if (isStamped) 1f else 1.25f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "StampScale"
    )
    val stampAlpha by animateFloatAsState(
        targetValue = if (isStamped) 1f else 0f,
        animationSpec = tween(durationMillis = 200),
        label = "StampAlpha"
    )

    Box(
        modifier = modifier
            .size(114.dp)
            .graphicsLayer {
                scaleX = stampScale
                scaleY = stampScale
                alpha = stampAlpha
                rotationZ = -5f
            },
        contentAlignment = Alignment.Center
    ) {
        // رسم هيكل الختم المطابق للوثائق الرسمية بالكامل
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.minDimension / 2f - 2.dp.toPx()

            // 1. الدائرة الخارجية العريضة
            drawCircle(
                color = stampRed,
                radius = radius,
                center = center,
                style = Stroke(width = 1.8.dp.toPx())
            )

            // 2. الدائرة الخارجية المزدوجة المرافقة
            drawCircle(
                color = stampRed.copy(alpha = 0.85f),
                radius = radius - 3.2.dp.toPx(),
                center = center,
                style = Stroke(width = 0.8.dp.toPx())
            )

            // 3. الدائرة الفاصلة للإطار الحلقي
            val innerRingRadius = radius - 17.5.dp.toPx()
            drawCircle(
                color = stampRed,
                radius = innerRingRadius,
                center = center,
                style = Stroke(width = 1.0.dp.toPx())
            )

            // 4. الدائرة الزخرفية المنقطة داخل النواة
            drawCircle(
                color = stampRed.copy(alpha = 0.6f),
                radius = innerRingRadius - 2.5.dp.toPx(),
                center = center,
                style = Stroke(
                    width = 0.7.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(3f, 3f), 0f)
                )
            )

            // 5. رسم النصوص المقوسة والنجوم في الإطار الحلقي
            drawIntoCanvas { composeCanvas ->
                val nativeCanvas = composeCanvas.nativeCanvas
                val stampRedInt = stampRed.toArgb()

                val textPaint = android.graphics.Paint().apply {
                    color = stampRedInt
                    textSize = 7.5.sp.toPx()
                    isAntiAlias = true
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                }

                val rAnnularMid = radius - 9.2.dp.toPx()
                val rect = android.graphics.RectF(
                    center.x - rAnnularMid,
                    center.y - rAnnularMid,
                    center.x + rAnnularMid,
                    center.y + rAnnularMid
                )

                // النص المقوس العلوي (من اليسار للأعلى لليمين)
                val topPath = android.graphics.Path()
                topPath.addArc(rect, 205f, 130f)
                val topText = "وثيقة تعهد وميثاق التعافي"
                val topTextWidth = textPaint.measureText(topText)
                val topArcLen = (Math.PI * rAnnularMid * (130.0 / 180.0)).toFloat()
                val topOffset = ((topArcLen - topTextWidth) / 2f).coerceAtLeast(0f)
                nativeCanvas.drawTextOnPath(topText, topPath, topOffset, 0f, textPaint)

                // النص المقوس السفلي
                // لرسم العربية بشكل صحيح بدون تشوه وتراكب أحرف مع addArc السالب:
                // نستخدم مساراً مقوساً بزاوية موجبة أو محسوبة بدقة مع hOffset دقيق
                val bottomPath = android.graphics.Path()
                bottomPath.addArc(rect, 25f, 130f)
                val bottomText = "ميثاق الشرف والسيادة"
                val bottomTextWidth = textPaint.measureText(bottomText)
                val bottomArcLen = (Math.PI * rAnnularMid * (130.0 / 180.0)).toFloat()
                val bottomOffset = ((bottomArcLen - bottomTextWidth) / 2f).coerceAtLeast(0f)
                nativeCanvas.drawTextOnPath(bottomText, bottomPath, bottomOffset, 0f, textPaint)

                // النجوم الجانبية بدقة
                val starPaint = android.graphics.Paint().apply {
                    color = stampRedInt
                    textSize = 7.5.sp.toPx()
                    isAntiAlias = true
                    textAlign = android.graphics.Paint.Align.CENTER
                }
                nativeCanvas.drawText("★", center.x - rAnnularMid, center.y + 2.5.dp.toPx(), starPaint)
                nativeCanvas.drawText("★", center.x + rAnnularMid, center.y + 2.5.dp.toPx(), starPaint)
            }
        }

        // النصوص الرسمية في قلب النواة
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = signerName.ifBlank { "المتعافي الصامد" },
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Black,
                color = stampRed,
                textAlign = TextAlign.Center,
                maxLines = 1,
                letterSpacing = (-0.1).sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "$signedDate • $signedTime",
                fontSize = 6.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = stampRed,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "النقاء التام • لا رجعة",
                fontSize = 6.sp,
                fontWeight = FontWeight.Bold,
                color = stampRed,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * تحويل خطوط التوقيع إلى نص JSON للحفظ والتخزين الفائق
 */
private fun serializeStrokesToJson(strokes: List<List<Offset>>): String {
    return try {
        val root = JSONArray()
        for (stroke in strokes) {
            val strokeArr = JSONArray()
            for (pt in stroke) {
                val obj = JSONObject()
                obj.put("x", pt.x)
                obj.put("y", pt.y)
                strokeArr.put(obj)
            }
            root.put(strokeArr)
        }
        root.toString()
    } catch (e: Exception) {
        ""
    }
}

/**
 * استعادة خطوط التوقيع من نص JSON
 */
private fun parseStrokesFromJson(json: String): List<List<Offset>> {
    val result = mutableListOf<List<Offset>>()
    if (json.isBlank()) return result
    try {
        val root = JSONArray(json)
        for (i in 0 until root.length()) {
            val strokeArr = root.getJSONArray(i)
            val stroke = mutableListOf<Offset>()
            for (j in 0 until strokeArr.length()) {
                val obj = strokeArr.getJSONObject(j)
                val x = obj.getDouble("x").toFloat()
                val y = obj.getDouble("y").toFloat()
                stroke.add(Offset(x, y))
            }
            if (stroke.isNotEmpty()) {
                result.add(stroke)
            }
        }
    } catch (_: Exception) {}
    return result
}

/**
 * تحويل صيغة الوقت إلى نظام 24 ساعة (HH:mm) والتخلص من am و pm
 */
private fun formatTimeTo24h(timeStr: String, timestamp: Long = 0L): String {
    if (timeStr.isBlank()) {
        return if (timestamp > 0) {
            SimpleDateFormat("HH:mm", Locale.US).format(Date(timestamp))
        } else ""
    }

    // إذا كان التوقيت الزمني متاحاً وموثوقاً نستخدمه مباشرة لضمان الدقة
    if (timestamp > 0) {
        try {
            return SimpleDateFormat("HH:mm", Locale.US).format(Date(timestamp))
        } catch (_: Exception) {}
    }

    // محاولة تحليل الوقت من السلسلة النصية الحالية بصيغ متعددة
    val patterns = listOf(
        "hh:mm a",
        "h:mm a",
        "hh:mma",
        "h:mma",
        "HH:mm",
        "H:mm"
    )
    for (pat in patterns) {
        try {
            val parser = SimpleDateFormat(pat, Locale.US)
            parser.isLenient = true
            val date = parser.parse(timeStr.trim())
            if (date != null) {
                return SimpleDateFormat("HH:mm", Locale.US).format(date)
            }
        } catch (_: Exception) {}
    }

    // إزالة يدوية لأي بقايا am أو pm أو ص/م إذا تعذر التحليل
    return timeStr.replace("(?i)am|pm|ص|م".toRegex(), "").trim()
}
