package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.RecoveryStats
import com.example.model.RecoveryStreakRecord
import com.example.model.RelapseRecord
import com.example.ui.theme.SaffahTheme
import com.example.ui.theme.SaffahMotion
import com.example.ui.theme.saffahPressMotion
import com.example.ui.theme.isAppInDarkTheme
import androidx.compose.animation.core.tween
import com.example.util.SaffahRecoveryManager
import java.text.SimpleDateFormat
import java.util.*

// Visual Identity Colors: PURE WHITE / DARK SURFACE + #0166FF + NEUTRAL GRAYS
private val AccentBlue = Color(0xFF0166FF)

/**
 * نافذة أطول سلاسل التعافي بالتصميم الحديث الخاص بتطبيق السفاح:
 * - متوافقة بالكامل مع الوضع الفاتح والوضع الليلي (Dark Mode) بسلاسة وأناقة.
 * - النمط البصري: أسطح عصرية متناسقة مع الثيم + لون التمييز الأساسي #0166FF + رماديات محايدة هادئة.
 * - أيقونات خطية عصرية واضحة وموحدة (Monoline Rounded Outline).
 * - خلو تام من أي Emojis أو ألوان برتقالية/صفراء متفرقة.
 * - أرقام إنجليزية حصرية وعرض ذكي ومختصر للمدد الزمنية.
 */
@Composable
fun LongestRecoveryStreaksDialog(
    recoveryStats: RecoveryStats,
    currentTimeMs: Long,
    relapseHistory: List<RelapseRecord>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isDark = isAppInDarkTheme()

    val dialogBg = MaterialTheme.colorScheme.surface
    val dialogBorder = MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.3f else 0.2f)
    val headerIconBg = AccentBlue.copy(alpha = if (isDark) 0.22f else 0.08f)
    val textPrimary = MaterialTheme.colorScheme.onSurface
    val textSecondary = MaterialTheme.colorScheme.onSurfaceVariant
    val dividerColor = MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.2f else 0.12f)
    val emptyBg = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else Color(0xFFF8FAFC)

    val streaks = remember(recoveryStats, relapseHistory, currentTimeMs) {
        SaffahRecoveryManager.buildRecoveryStreaks(
            stats = recoveryStats,
            history = relapseHistory,
            firstEverStartTime = SaffahRecoveryManager.getFirstEverStartTime(context),
            currentTimeMs = currentTimeMs
        )
    }

    val longestStreak = streaks.firstOrNull()
    val ongoingStreak = streaks.find { it.isOngoing }

    val dateFormat = remember {
        SimpleDateFormat("yyyy-MM-dd • HH:mm", Locale.US)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false
            )
        ) {
            SaffahTheme(darkTheme = isDark) {
                BackHandler(onBack = onDismiss)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 16.dp, vertical = 24.dp)
                    .systemBarsPadding(),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.86f)
                        .clip(RoundedCornerShape(24.dp))
                        .border(
                            1.dp,
                            dialogBorder,
                            RoundedCornerShape(24.dp)
                        ),
                    color = dialogBg,
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // 1. الشريط العلوي (Header)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = headerIconBg,
                                    shape = CircleShape,
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Outlined.EmojiEvents,
                                            contentDescription = null,
                                            tint = AccentBlue,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "أطول سلاسل التعافي",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary,
                                    fontSize = 17.sp
                                )
                            }

                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        HorizontalDivider(
                            color = dividerColor,
                            thickness = 1.dp
                        )

                        // 2. المحتوى التمريري
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // ملخص Bento الإحصائي العلوي
                            item(key = "streaks_bento_summary") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // الرقم القياسي
                                    StreakBentoStatCard(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Outlined.EmojiEvents,
                                        iconTint = AccentBlue,
                                        title = "الرقم القياسي",
                                        value = formatStreakCompact(longestStreak),
                                        isAccentValue = true
                                    )

                                    // السلسلة الحالية
                                    StreakBentoStatCard(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Outlined.PlayArrow,
                                        iconTint = AccentBlue,
                                        title = "السلسلة الحالية",
                                        value = formatStreakCompact(ongoingStreak),
                                        isAccentValue = true
                                    )

                                    // إجمالي السلاسل
                                    StreakBentoStatCard(
                                        modifier = Modifier.weight(1f),
                                        icon = Icons.Outlined.FormatListNumbered,
                                        iconTint = textSecondary,
                                        title = "إجمالي السلاسل",
                                        value = "${streaks.size}",
                                        isAccentValue = false
                                    )
                                }
                            }

                            // عنوان القائمة
                            item(key = "streaks_list_header") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp, bottom = 2.dp)
                                ) {
                                    Text(
                                        text = "السلاسل المسجلة",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = textPrimary,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            // قائمة السلاسل
                            if (streaks.isEmpty()) {
                                item(key = "streaks_empty") {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = emptyBg,
                                        border = BorderStroke(1.dp, dividerColor),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(28.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.HistoryToggleOff,
                                                contentDescription = null,
                                                tint = textSecondary.copy(alpha = 0.6f),
                                                modifier = Modifier.size(32.dp)
                                            )
                                            Text(
                                                text = "لا توجد سلاسل مسجلة بعد",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = textSecondary
                                            )
                                        }
                                    }
                                }
                            } else {
                                items(
                                    items = streaks,
                                    key = { it.id }
                                ) { streak ->
                                    Box(
                                        modifier = Modifier.animateItem(
                                            fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                                            fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                                            placementSpec = androidx.compose.animation.core.spring(
                                                stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                                dampingRatio = 0.8f
                                            )
                                        )
                                    ) {
                                        ModernStreakCard(
                                            streak = streak,
                                            dateFormat = dateFormat
                                        )
                                    }
                                }
                            }
                        }

                        HorizontalDivider(
                            color = dividerColor,
                            thickness = 1.dp
                        )

                        // 3. زر الإغلاق الأساسي باللون الأزرق #0166FF
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            Button(
                                onClick = onDismiss,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AccentBlue,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                            ) {
                                Text(
                                    text = "إغلاق",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
}

/**
 * بطاقة إحصائية مدمجة لشبكة Bento العلوية
 */
@Composable
private fun StreakBentoStatCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    value: String,
    isAccentValue: Boolean = false
) {
    val isDark = isAppInDarkTheme()
    val bgColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else Color(0xFFF8FAFC)
    val borderColor = MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.25f else 0.15f)

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier.saffahPressMotion(targetScale = 0.97f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (isAccentValue) AccentBlue else MaterialTheme.colorScheme.onSurface,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * بطاقة عرض سلسلة التعافي بتصميم ناصع وهادئ ومتوافق مع الوضع الليلي
 */
@Composable
private fun ModernStreakCard(
    streak: RecoveryStreakRecord,
    dateFormat: SimpleDateFormat
) {
    val isDark = isAppInDarkTheme()
    val cardBg = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f) else Color(0xFFFFFFFF)
    val cardBorder = if (streak.isAllTimeRecord) {
        if (isDark) AccentBlue.copy(alpha = 0.6f) else AccentBlue.copy(alpha = 0.25f)
    } else {
        MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.25f else 0.18f)
    }
    val rankBadgeBg = if (streak.isAllTimeRecord) {
        AccentBlue.copy(alpha = if (isDark) 0.22f else 0.08f)
    } else {
        if (isDark) MaterialTheme.colorScheme.surface.copy(alpha = 0.7f) else Color(0xFFF8FAFC)
    }
    val rankBadgeBorder = if (streak.isAllTimeRecord) {
        AccentBlue.copy(alpha = if (isDark) 0.45f else 0.25f)
    } else {
        MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.2f else 0.12f)
    }
    val recordBadgeBg = AccentBlue.copy(alpha = if (isDark) 0.22f else 0.08f)
    val recordBadgeBorder = AccentBlue.copy(alpha = if (isDark) 0.45f else 0.25f)
    val ongoingBg = AccentBlue.copy(alpha = if (isDark) 0.22f else 0.08f)
    val completedBg = if (isDark) MaterialTheme.colorScheme.surface.copy(alpha = 0.7f) else Color(0xFFF8FAFC)
    val dateBoxBg = if (isDark) MaterialTheme.colorScheme.surface.copy(alpha = 0.65f) else Color(0xFFF8FAFC)
    val dateBoxBorder = MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.22f else 0.12f)
    val dividerColor = MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.2f else 0.12f)
    val textPrimary = MaterialTheme.colorScheme.onSurface
    val textSecondary = MaterialTheme.colorScheme.onSurfaceVariant

    val formattedStart = remember(streak.startTimestamp) {
        dateFormat.format(Date(streak.startTimestamp))
    }

    val formattedEnd = remember(streak.endTimestamp, streak.isOngoing) {
        if (streak.isOngoing) {
            "مستمرة حتى الآن"
        } else {
            dateFormat.format(Date(streak.endTimestamp))
        }
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .saffahPressMotion(targetScale = 0.985f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. الشريط العلوي: الترتيب والشارات
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // الترتيب وشارة الرقم القياسي
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = rankBadgeBg,
                        border = BorderStroke(0.5.dp, rankBadgeBorder)
                    ) {
                        Text(
                            text = "#${streak.rank}",
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (streak.isAllTimeRecord) AccentBlue else textSecondary,
                            fontSize = 11.5.sp
                        )
                    }

                    if (streak.isAllTimeRecord) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = recordBadgeBg,
                            border = BorderStroke(0.5.dp, recordBadgeBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.EmojiEvents,
                                    contentDescription = null,
                                    tint = AccentBlue,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "الرقم القياسي",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentBlue,
                                    fontSize = 10.5.sp
                                )
                            }
                        }
                    }
                }

                // حالة السلسلة (مستمرة / مكتملة)
                if (streak.isOngoing) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = ongoingBg
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(AccentBlue, CircleShape)
                            )
                            Text(
                                text = "مستمرة الآن",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = AccentBlue,
                                fontSize = 10.5.sp
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = completedBg,
                        border = BorderStroke(0.5.dp, dateBoxBorder)
                    ) {
                        Text(
                            text = "مكتملة",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = textSecondary,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }

            // 2. عرض المدة الزمنية بخط واضح وتباين قوي
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (streak.days > 0) {
                    Text(
                        text = "${streak.days}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (streak.isAllTimeRecord) AccentBlue else textPrimary,
                        fontSize = 24.sp
                    )
                    Text(
                        text = "يوم",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = textSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                    if (streak.hours > 0 || streak.minutes > 0) {
                        Text(
                            text = "• ${streak.hours} س ${streak.minutes} د",
                            style = MaterialTheme.typography.bodySmall,
                            color = textSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                } else {
                    // إذا كانت المدة أقل من يوم واحد: عرض الساعات والدقائق مباشرة كقيمة رئيسية
                    if (streak.hours > 0) {
                        Text(
                            text = "${streak.hours}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (streak.isAllTimeRecord) AccentBlue else textPrimary,
                            fontSize = 24.sp
                        )
                        Text(
                            text = "ساعة",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = textSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                        if (streak.minutes > 0) {
                            Text(
                                text = "• ${streak.minutes} دقيقة",
                                style = MaterialTheme.typography.bodySmall,
                                color = textSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    } else {
                        Text(
                            text = "${streak.minutes}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (streak.isAllTimeRecord) AccentBlue else textPrimary,
                            fontSize = 24.sp
                        )
                        Text(
                            text = "دقيقة",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = textSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
            }

            // 3. تواريخ البداية والنهاية بخلفية محايدة ناصعة وهادئة
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = dateBoxBg,
                border = BorderStroke(1.dp, dateBoxBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // البداية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.PlayCircleOutline,
                                contentDescription = null,
                                tint = AccentBlue,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "البداية:",
                                style = MaterialTheme.typography.labelSmall,
                                color = textSecondary,
                                fontSize = 11.5.sp
                            )
                        }

                        Text(
                            text = formattedStart,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = textPrimary,
                            fontSize = 11.5.sp
                        )
                    }

                    HorizontalDivider(
                        color = dividerColor,
                        thickness = 1.dp
                    )

                    // النهاية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = if (streak.isOngoing) Icons.Outlined.Update else Icons.Outlined.CheckCircleOutline,
                                contentDescription = null,
                                tint = if (streak.isOngoing) AccentBlue else textSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "النهاية:",
                                style = MaterialTheme.typography.labelSmall,
                                color = textSecondary,
                                fontSize = 11.5.sp
                            )
                        }

                        Text(
                            text = formattedEnd,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (streak.isOngoing) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (streak.isOngoing) AccentBlue else textPrimary,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * تنسيق مدة مدمج للبطاقات الإحصائية العلوية
 */
private fun formatStreakCompact(streak: RecoveryStreakRecord?): String {
    if (streak == null) return "0 س"
    return if (streak.days > 0) {
        "${streak.days} يوم"
    } else if (streak.hours > 0) {
        "${streak.hours} س"
    } else {
        "${streak.minutes} د"
    }
}
