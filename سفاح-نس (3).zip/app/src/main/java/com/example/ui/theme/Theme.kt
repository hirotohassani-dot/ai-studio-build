package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat

val LocalIsDarkTheme = compositionLocalOf { false }

/**
 * دالة موحدة ودقيقة لفحص ما إذا كان التطبيق في الوضع الليلي:
 * تعتمد على الثيم الفعلي للتطبيق سواء تم اختياره من الإعدادات أو من النظام،
 * مع فحص سطوع السطح كضمان نهائي لأي نوافذ أو حوارات فرعية.
 */
@Composable
fun isAppInDarkTheme(): Boolean {
    val isLocallyDark = LocalIsDarkTheme.current
    val isSurfaceDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    return isLocallyDark || isSurfaceDark
}

private val SaffahLightColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = OnPrimaryWhite,
    primaryContainer = PrimaryBlueLight,
    onPrimaryContainer = PrimaryBlue,
    secondary = PrimaryBlueDark,
    onSecondary = OnPrimaryWhite,
    secondaryContainer = PrimaryBlueLight,
    onSecondaryContainer = PrimaryBlue,
    background = BackgroundNeutral,
    onBackground = TextPrimaryDark,
    surface = SurfaceNeutral,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantNeutral,
    onSurfaceVariant = TextSecondaryMuted,
    outline = CardBorder,
    outlineVariant = Color(0xFFE4E4E7),
    error = ErrorRed,
    onError = Color.White
)

private val SaffahDarkColorScheme = darkColorScheme(
    primary = PrimaryBlueDarkTheme,
    onPrimary = Color.White,
    primaryContainer = PrimaryBlueDarkContainer,
    onPrimaryContainer = OnPrimaryBlueDarkContainer,
    secondary = PrimaryBlueDarkTheme,
    onSecondary = Color.White,
    secondaryContainer = PrimaryBlueDarkContainer,
    onSecondaryContainer = OnPrimaryBlueDarkContainer,
    background = BackgroundDark,
    onBackground = TextPrimaryLight,
    surface = SurfaceDark,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryLightMuted,
    outline = CardBorderDark,
    outlineVariant = Color(0xFF333338),
    error = ErrorRedDark,
    onError = Color.White
)

@Composable
fun SaffahTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SaffahDarkColorScheme else SaffahLightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = !darkTheme
                insetsController.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalIsDarkTheme provides darkTheme
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography
        ) {
            CompositionLocalProvider(
                androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = IBMPlexSansArabic),
                content = content
            )
        }
    }
}

@Composable
fun saffahSwitchColors(
    checkedTrackColor: Color? = null
): androidx.compose.material3.SwitchColors {
    val isDark = isAppInDarkTheme()
    val activeTrack = checkedTrackColor ?: (if (isDark) PrimaryBlueDarkTheme else PrimaryBlue)
    return androidx.compose.material3.SwitchDefaults.colors(
        // Checked (Active / مفعل)
        checkedThumbColor = Color.White,
        checkedTrackColor = activeTrack,
        checkedBorderColor = Color.Transparent,
        // Unchecked (Off / غير مفعل - واضح المعالم بتباين ممتاز في الوضعين)
        uncheckedThumbColor = if (isDark) Color(0xFFE4E4E7) else Color.White,
        uncheckedTrackColor = if (isDark) Color(0xFF333338) else Color(0xFFE2E4E8),
        uncheckedBorderColor = if (isDark) Color(0xFF71717A) else Color(0xFFCBD5E1),
        // Disabled & Checked (معطل وهو مفعل - واضح ومميز)
        disabledCheckedThumbColor = Color.White.copy(alpha = 0.85f),
        disabledCheckedTrackColor = activeTrack.copy(alpha = 0.45f),
        disabledCheckedBorderColor = Color.Transparent,
        // Disabled & Unchecked (معطل وهو غير مفعل - واضح المعالم بدون بهتان أو اختفاء)
        disabledUncheckedThumbColor = if (isDark) Color(0xFFA1A1AA) else Color(0xFF94A3B8),
        disabledUncheckedTrackColor = if (isDark) Color(0xFF27272A) else Color(0xFFE2E8F0),
        disabledUncheckedBorderColor = if (isDark) Color(0xFF52525B) else Color(0xFFCBD5E1)
    )
}

@Composable
fun SaffahSwitch(
    checked: Boolean,
    onCheckedChange: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: androidx.compose.material3.SwitchColors = saffahSwitchColors()
) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current

    val switchScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (checked) 0.82f else 0.78f,
        animationSpec = androidx.compose.animation.core.spring(
            stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
            dampingRatio = 0.65f
        ),
        label = "SwitchSpringScale"
    )

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        androidx.compose.material3.Switch(
            checked = checked,
            onCheckedChange = { newValue ->
                try {
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                } catch (_: Exception) {}
                onCheckedChange?.invoke(newValue)
            },
            modifier = modifier
                .saffahPressMotion(targetScale = 0.96f)
                .graphicsLayer {
                    scaleX = switchScale
                    scaleY = switchScale
                },
            enabled = enabled,
            colors = colors
        )
    }
}

/**
 * نص آلة كاتبة سريع جداً (Lightning Typewriter Text):
 * عند تفعيل الـ Switch، يعيد كتابة اسم الميزة أحادي الأحرف بسرعة البرق (~8 مللي ثانية لكل حرف)،
 * بحيث تظهر الأحرف بسرعة ودون أي تأخير ملحوظ أو Lag.
 */
@Composable
fun LightningTypewriterText(
    text: String,
    triggerState: Boolean,
    modifier: Modifier = Modifier,
    style: androidx.compose.ui.text.TextStyle = androidx.compose.material3.LocalTextStyle.current,
    fontWeight: FontWeight? = null,
    color: Color = Color.Unspecified,
    fontSize: androidx.compose.ui.unit.TextUnit = androidx.compose.ui.unit.TextUnit.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip
) {
    var visibleCharCount by androidx.compose.runtime.remember(text) { androidx.compose.runtime.mutableIntStateOf(text.length) }

    androidx.compose.runtime.LaunchedEffect(triggerState, text) {
        if (triggerState) {
            visibleCharCount = 1
            val totalLength = text.length
            val stepDelayMs = 8L // 8ms per character = lightning fast
            for (i in 1..totalLength) {
                visibleCharCount = i
                kotlinx.coroutines.delay(stepDelayMs)
            }
        } else {
            visibleCharCount = text.length
        }
    }

    androidx.compose.material3.Text(
        text = text.take(visibleCharCount),
        modifier = modifier,
        style = style,
        fontWeight = fontWeight,
        color = color,
        fontSize = fontSize,
        maxLines = maxLines,
        overflow = overflow
    )
}

/**
 * شريحة تحديد أيام سريان الحظر (Saffah Day Selection Chip):
 * تمنح تفاعلاً حركياً ناعماً وارتقائياً بفيزياء زنبركية ومؤشر لمسي ناعم وتنقلاً لونياً فورياً.
 */
@Composable
fun SaffahDaySelectionChip(
    dayLabel: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color = MaterialTheme.colorScheme.primary,
    activeTextColor: Color = MaterialTheme.colorScheme.onPrimary,
    inactiveColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    inactiveTextColor: Color = MaterialTheme.colorScheme.onSurfaceVariant
) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current

    val animScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isSelected) 1.05f else 1.0f,
        animationSpec = androidx.compose.animation.core.spring(
            stiffness = androidx.compose.animation.core.Spring.StiffnessMedium,
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioNoBouncy
        ),
        label = "DayChipScale"
    )

    val animatedBgColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (isSelected) activeColor else inactiveColor,
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 140),
        label = "DayChipBg"
    )

    androidx.compose.material3.Surface(
        onClick = {
            try {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
            } catch (_: Exception) {}
            onClick()
        },
        modifier = modifier
            .saffahPressMotion(targetScale = 0.96f)
            .graphicsLayer {
                scaleX = animScale
                scaleY = animScale
            },
        shape = CircleShape,
        color = animatedBgColor,
        border = BorderStroke(
            1.dp,
            if (isSelected) activeColor else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        androidx.compose.foundation.layout.Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
            androidx.compose.material3.Text(
                text = dayLabel,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) activeTextColor else inactiveTextColor,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}
