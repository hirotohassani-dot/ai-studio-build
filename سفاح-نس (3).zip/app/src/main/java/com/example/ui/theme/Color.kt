package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// SAFFAH PALETTE (#0166FF ACCENT & MINIMALIST DESIGN)
// ==========================================
// Primary Accent Color (#0166FF) & Subtle Tints (Light Mode)
val PrimaryBlue = Color(0xFF0166FF)               // Main Primary Accent
val PrimaryBlueDark = Color(0xFF0052CC)           // Slightly darker accent for pressed states
val PrimaryBlueLight = Color(0xFFEBF3FF)          // Very light subtle tint for soft selections / highlights
val PrimaryBlueSubtle = Color(0xFFF2F7FF)         // Ultra soft tint
val OnPrimaryWhite = Color(0xFFFFFFFF)            // Pure white on primary

// Dark Mode Primary Accent & Tints
val PrimaryBlueDarkTheme = Color(0xFF3B82F6)      // Crisp vibrant blue accent for Dark Mode
val PrimaryBlueDarkContainer = Color(0xFF1E293B)  // Dark slate-blue container for Dark Mode
val OnPrimaryBlueDarkContainer = Color(0xFF93C5FD)// Light blue text on dark container

// Neutral Light Theme Surface & Background tones
val BackgroundNeutral = Color(0xFFFAFAFA)         // Crisp clean off-white / light background
val SurfaceNeutral = Color(0xFFFFFFFF)            // Pure white for Bento cards and primary surfaces
val SurfaceVariantNeutral = Color(0xFFF4F4F5)     // Soft neutral gray (Zinc 100)
val SurfaceVariantSubtle = Color(0xFFF8F9FA)

// Neutral Dark Theme Surface & Background tones (Calm, Modern, Clean Dark)
val BackgroundDark = Color(0xFF09090B)            // Zinc 950 deep calm background
val SurfaceDark = Color(0xFF18181B)               // Zinc 900 for Bento cards and primary surfaces
val SurfaceVariantDark = Color(0xFF27272A)        // Zinc 800 for secondary cards/elements
val SurfaceVariantDarkSubtle = Color(0xFF222225)

// Typography & Icon Neutral tones
val TextPrimaryDark = Color(0xFF18181B)           // High-contrast primary near-black (Zinc 900) - Light Mode
val TextSecondaryMuted = Color(0xFF52525B)        // Balanced calm charcoal/slate (Zinc 600) - Light Mode
val TextTertiaryMuted = Color(0xFF71717A)         // Soft neutral muted gray (Zinc 500) - Light Mode
val IconToneCleanLight = Color(0xFF18181B)        // Natural black line-icon tone (High-contrast, unmuted)

val TextPrimaryLight = Color(0xFFF4F4F5)          // High-contrast primary near-white (Zinc 100) - Dark Mode
val TextSecondaryLightMuted = Color(0xFFA1A1AA)   // Balanced neutral light gray (Zinc 400) - Dark Mode
val TextTertiaryLightMuted = Color(0xFF71717A)    // Soft neutral muted dark gray (Zinc 500) - Dark Mode
val IconToneCleanDark = Color(0xFFA1A1AA)         // Softened clean slate line-icon tone for Dark Mode

// Borders & Outlines
val CardBorder = Color(0xFFE4E4E7)                // Minimalist subtle neutral border (Zinc 200) - Light Mode
val CardBorderDark = Color(0xFF27272A)            // Minimalist subtle dark border (Zinc 800) - Dark Mode
val CardBorderSubtle = Color(0xFFF4F4F5)
val DividerColor = Color(0xFFE4E4E7)
val DividerColorDark = Color(0xFF27272A)
val GlassBorder = Color(0x1F0166FF)               // Subtle accent tint border when active
val GlassBorderDark = Color(0x333B82F6)

// Legacy/Compatibility references pointing to clean theme tokens
val PrimaryBlack = TextPrimaryDark
val PrimaryBlackDarker = Color(0xFF09090B)

// Functional indicators (Restrained for security, warnings, and lock banners)
val SuccessGreen = Color(0xFF16A34A)              // Functional success / security status
val SuccessGreenDark = Color(0xFF22C55E)          // Functional success in Dark Mode
val WarningAmber = Color(0xFFD97706)              // Functional warning
val WarningAmberDark = Color(0xFFF59E0B)          // Functional warning in Dark Mode
val ErrorRed = Color(0xFFDC2626)                  // Functional error / lock banner
val ErrorRedDark = Color(0xFFEF4444)              // Functional error in Dark Mode
