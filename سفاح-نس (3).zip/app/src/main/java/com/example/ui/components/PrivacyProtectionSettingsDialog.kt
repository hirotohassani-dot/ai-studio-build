package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.util.SaffahPrivacyManager
import com.example.viewmodel.MainViewModel

private val PrimaryBlue = Color(0xFF0166FF)

@Composable
fun PrivacyProtectionSettingsDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val privacyConfig by viewModel.privacyConfig.collectAsState()

    var showSetupPinDialog by remember { mutableStateOf(false) }
    var isChangePinMode by remember { mutableStateOf(false) }
    var showVerifyPinForRemoveDialog by remember { mutableStateOf(false) }
    var sectionPendingRemoval by remember { mutableStateOf<SaffahPrivacyManager.PrivacySectionInfo?>(null) }
    var pendingSectionToEnableAfterPinSetup by remember { mutableStateOf<String?>(null) }

    // Dialog for Setting or Changing PIN
    if (showSetupPinDialog) {
        PrivacyPinSetupDialog(
            isChangeMode = isChangePinMode,
            onDismiss = {
                showSetupPinDialog = false
                isChangePinMode = false
                pendingSectionToEnableAfterPinSetup = null
            },
            onSuccess = {
                viewModel.refreshPrivacyConfig()
                pendingSectionToEnableAfterPinSetup?.let { sectionKey ->
                    viewModel.protectPrivacySection(sectionKey)
                    pendingSectionToEnableAfterPinSetup = null
                }
                Toast.makeText(
                    context,
                    if (isChangePinMode) "تم تغيير رمز PIN بنجاح" else "تم تعيين وتفعيل رمز PIN بنجاح",
                    Toast.LENGTH_SHORT
                ).show()
                showSetupPinDialog = false
                isChangePinMode = false
            }
        )
    }

    // Dialog for Verifying PIN before Removing a Protected Section
    if (sectionPendingRemoval != null) {
        val section = sectionPendingRemoval!!
        PrivacyPinVerificationDialog(
            title = "تأكيد إزالة الحماية",
            subtitle = "أدخل رمز PIN لتأكيد إزالة الحماية عن ${section.title}",
            onDismiss = { sectionPendingRemoval = null },
            onSuccess = {
                viewModel.unprotectPrivacySection(section.key)
                sectionPendingRemoval = null
                Toast.makeText(context, "تمت إزالة الحماية عن ${section.title}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Dialog for Verifying PIN before Completely Removing PIN
    if (showVerifyPinForRemoveDialog) {
        PrivacyPinVerificationDialog(
            title = "إلغاء رمز PIN",
            subtitle = "أدخل رمز PIN الحالي لتأكيد حذف الرمز وإلغاء الحماية عن الأقسام",
            onDismiss = { showVerifyPinForRemoveDialog = false },
            onSuccess = {
                viewModel.removePrivacyPin()
                showVerifyPinForRemoveDialog = false
                Toast.makeText(context, "تم حذف رمز PIN وإلغاء قفل الأقسام", Toast.LENGTH_SHORT).show()
            }
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.88f)
                    .widthIn(max = 500.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                shadowElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = PrimaryBlue.copy(alpha = 0.08f),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.Security,
                                        contentDescription = null,
                                        tint = PrimaryBlue,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "حماية الخصوصية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(14.dp))

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. PIN Status Card
                        item(key = "pin_status_card") {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                color = if (privacyConfig.isPinSet) PrimaryBlue.copy(alpha = 0.04f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = BorderStroke(
                                    1.dp,
                                    if (privacyConfig.isPinSet) PrimaryBlue.copy(alpha = 0.25f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = if (privacyConfig.isPinSet) PrimaryBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = if (privacyConfig.isPinSet) Icons.Default.Lock else Icons.Outlined.LockOpen,
                                                    contentDescription = null,
                                                    tint = if (privacyConfig.isPinSet) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (privacyConfig.isPinSet) "رمز PIN مفعل" else "رمز PIN غير معين",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }

                                    // Action buttons
                                    if (!privacyConfig.isPinSet) {
                                        Button(
                                            onClick = {
                                                isChangePinMode = false
                                                showSetupPinDialog = true
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(42.dp),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Key,
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("تعيين رمز PIN", fontWeight = FontWeight.SemiBold)
                                        }
                                    } else {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    isChangePinMode = true
                                                    showSetupPinDialog = true
                                                },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(40.dp),
                                                shape = RoundedCornerShape(12.dp),
                                                border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.5f))
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Edit,
                                                    contentDescription = null,
                                                    tint = PrimaryBlue,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("تغيير الرمز", color = PrimaryBlue, style = MaterialTheme.typography.labelMedium)
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    showVerifyPinForRemoveDialog = true
                                                },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(40.dp),
                                                shape = RoundedCornerShape(12.dp),
                                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f))
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Delete,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("إلغاء الرمز", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // 2. Sections Selection Header
                        item(key = "sections_header") {
                            Text(
                                text = "الأقسام المحمية",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                            )
                        }

                        // 3. Protected Sections
                        items(
                            items = SaffahPrivacyManager.ALL_SECTIONS,
                            key = { it.key }
                        ) { section ->
                            val isProtected = privacyConfig.protectedSections.contains(section.key)
                            val sectionIcon = when (section.key) {
                                SaffahPrivacyManager.SECTION_RECOVERY_PLEDGE -> Icons.Outlined.HistoryEdu
                                SaffahPrivacyManager.SECTION_RECOVERY_COUNTER -> Icons.Outlined.Shield
                                SaffahPrivacyManager.SECTION_RECOVERY_DIARIES -> Icons.Outlined.EditNote
                                SaffahPrivacyManager.SECTION_RECOVERY_STATS -> Icons.Outlined.Analytics
                                SaffahPrivacyManager.SECTION_RECOVERY_MAP -> Icons.Outlined.Map
                                SaffahPrivacyManager.SECTION_BLOCK_KEYWORDS_AND_SITES -> Icons.Outlined.Block
                                SaffahPrivacyManager.SECTION_BLOCK_LOGS -> Icons.Outlined.History
                                SaffahPrivacyManager.SECTION_ENTIRE_APP -> Icons.Outlined.PhoneAndroid
                                else -> Icons.Outlined.Lock
                            }

                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                color = if (isProtected) PrimaryBlue.copy(alpha = 0.03f) else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.dp,
                                    if (isProtected) PrimaryBlue.copy(alpha = 0.25f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = sectionIcon,
                                            contentDescription = null,
                                            tint = if (isProtected) PrimaryBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(22.dp)
                                        )

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Text(
                                            text = section.title,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    com.example.ui.theme.SaffahSwitch(
                                        checked = isProtected,
                                        onCheckedChange = { willCheck ->
                                            if (willCheck) {
                                                // If PIN is not configured, prompt setup first!
                                                if (!privacyConfig.isPinSet) {
                                                    pendingSectionToEnableAfterPinSetup = section.key
                                                    isChangePinMode = false
                                                    showSetupPinDialog = true
                                                } else {
                                                    viewModel.protectPrivacySection(section.key)
                                                }
                                            } else {
                                                // User requested: "يمنع ازالة قسم محدد محمي بكود pin الا بعد ادخال كود pin الذي تم انشائه من قبل المستخدم"
                                                sectionPendingRemoval = section
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Text("تم", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
