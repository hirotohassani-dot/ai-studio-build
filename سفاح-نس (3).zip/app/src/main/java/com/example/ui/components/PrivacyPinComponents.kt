package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import com.example.util.SaffahPrivacyManager
import kotlinx.coroutines.delay

private val PrimaryBlue = Color(0xFF0166FF)

/**
 * مؤشر الدوائر الأربعة لكود PIN
 */
@Composable
fun PrivacyPinDotsIndicator(
    pinLength: Int,
    isError: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.saffahShake(isError),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until 4) {
            val isFilled = i < pinLength
            val targetColor = when {
                isError -> MaterialTheme.colorScheme.error
                isFilled -> PrimaryBlue
                else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            }
            val dotColor by animateColorAsState(
                targetValue = targetColor,
                animationSpec = tween(durationMillis = 180),
                label = "PinDotColor"
            )
            val dotScale by animateFloatAsState(
                targetValue = if (isFilled) 1.25f else 1.0f,
                animationSpec = SaffahMotion.bouncySpring<Float>(),
                label = "PinDotScale"
            )
            val dotBorder = if (isFilled || isError) null else BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            Surface(
                modifier = Modifier
                    .size(18.dp)
                    .scale(dotScale),
                shape = CircleShape,
                color = dotColor,
                border = dotBorder
            ) {}
        }
    }
}

/**
 * لوحة مفاتيح أرقام إنجليزية نظيفة ومينيمالية (1-9، 0، ومفتاح الحذف)
 */
@Composable
fun PrivacyNumericKeypad(
    onDigitClick: (Char) -> Unit,
    onDeleteClick: () -> Unit,
    onClearClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("CLEAR", "0", "DEL")
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        rows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                row.forEach { item ->
                    when (item) {
                        "DEL" -> {
                            Surface(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .saffahPressMotion(enabled = enabled)
                                    .clickable(enabled = enabled) { onDeleteClick() },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                                        contentDescription = "حذف رقم",
                                        tint = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                        "CLEAR" -> {
                            Surface(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .saffahPressMotion(enabled = enabled)
                                    .clickable(enabled = enabled) { onClearClick() },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "C",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        else -> {
                            val digitChar = item[0]
                            Surface(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .saffahPressMotion(enabled = enabled)
                                    .clickable(enabled = enabled) { onDigitClick(digitChar) },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
                                shadowElevation = 0.dp
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = item,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * نافذة تأكيد رمز PIN قبل تنفيذ إجراء حساس (إلغاء حماية قسم، حذف الرمز، إلخ)
 */
@Composable
fun PrivacyPinVerificationDialog(
    title: String = "تأكيد رمز PIN",
    subtitle: String = "أدخل رمز PIN للمتابعة",
    sectionKey: String? = null,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    var isFrozen by remember {
        mutableStateOf(if (sectionKey == SaffahPrivacyManager.SECTION_RECOVERY_DIARIES) SaffahPrivacyManager.isDiaryFrozen(context) else false)
    }
    var remainingMillis by remember {
        mutableLongStateOf(if (sectionKey == SaffahPrivacyManager.SECTION_RECOVERY_DIARIES) SaffahPrivacyManager.getDiaryFrozenRemainingMillis(context) else 0L)
    }
    var currentInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(isFrozen) {
        while (isFrozen) {
            val rem = SaffahPrivacyManager.getDiaryFrozenRemainingMillis(context)
            if (rem <= 0L) {
                isFrozen = false
                break
            }
            remainingMillis = rem
            delay(1000L)
        }
    }

    fun processDigit(digit: Char) {
        if (isFrozen) return
        if (currentInput.length < 4) {
            val updated = currentInput + digit
            currentInput = updated
            errorMessage = null

            if (updated.length == 4) {
                when (val result = SaffahPrivacyManager.verifyPinWithSecurity(context, updated, sectionKey)) {
                    is SaffahPrivacyManager.VerifyPinResult.Success -> {
                        onSuccess()
                        onDismiss()
                    }
                    is SaffahPrivacyManager.VerifyPinResult.WrongPin -> {
                        errorMessage = result.message
                        currentInput = ""
                    }
                    is SaffahPrivacyManager.VerifyPinResult.Frozen -> {
                        isFrozen = true
                        remainingMillis = result.remainingMillis
                        errorMessage = result.message
                        currentInput = ""
                    }
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 400.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(26.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isFrozen) {
                        Text(
                            text = "تحذير أمني",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = SaffahPrivacyManager.SECURITY_FREEZE_MESSAGE,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "الوقت المتبقي لفك التجميد",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = SaffahPrivacyManager.formatRemainingHoursAndMinutes(remainingMillis),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryBlue
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        PrivacyPinDotsIndicator(
                            pinLength = currentInput.length,
                            isError = errorMessage != null
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = errorMessage ?: "",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        PrivacyNumericKeypad(
                            onDigitClick = { processDigit(it) },
                            onDeleteClick = {
                                if (currentInput.isNotEmpty()) {
                                    currentInput = currentInput.dropLast(1)
                                    errorMessage = null
                                }
                            },
                            onClearClick = {
                                currentInput = ""
                                errorMessage = null
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * نافذة تسجيل أو تغيير رمز PIN جديد (4 أرقام)
 */
@Composable
fun PrivacyPinSetupDialog(
    isChangeMode: Boolean = false,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current

    // Steps:
    // If changeMode: 0 = verify old, 1 = enter new, 2 = confirm new
    // If newMode: 1 = enter new, 2 = confirm new
    var step by remember { mutableIntStateOf(if (isChangeMode) 0 else 1) }
    var currentInput by remember { mutableStateOf("") }
    var newPinDraft by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val stepTitle = when (step) {
        0 -> "أدخل رمز PIN الحالي"
        1 -> if (isChangeMode) "أدخل رمز PIN الجديد (4 أرقام)" else "تعيين رمز PIN جديد (4 أرقام)"
        2 -> "أعد إدخال رمز PIN للتأكيد"
        else -> ""
    }

    val stepSubtitle = when (step) {
        0 -> "تحقق من هويتك للمتابعة وتغيير الرمز"
        1 -> "اختر رمزاً مكوناً من 4 أرقام يسهل تذكره"
        2 -> "أدخل نفس الرمز للتأكد من صحته"
        else -> ""
    }

    fun processDigit(digit: Char) {
        if (currentInput.length < 4) {
            val updated = currentInput + digit
            currentInput = updated
            errorMessage = null

            if (updated.length == 4) {
                when (step) {
                    0 -> {
                        // Verify old PIN
                        if (SaffahPrivacyManager.verifyPin(context, updated)) {
                            currentInput = ""
                            step = 1
                        } else {
                            errorMessage = "رمز PIN الحالي غير صحيح"
                            currentInput = ""
                        }
                    }
                    1 -> {
                        // Save draft of new PIN
                        newPinDraft = updated
                        currentInput = ""
                        step = 2
                    }
                    2 -> {
                        // Confirm matching
                        if (updated == newPinDraft) {
                            SaffahPrivacyManager.setPin(context, updated)
                            onSuccess()
                            onDismiss()
                        } else {
                            errorMessage = "رمز PIN غير متطابق، أعد المحاولة"
                            currentInput = ""
                            step = 1
                        }
                    }
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 400.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(26.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stepTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = stepSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    PrivacyPinDotsIndicator(
                        pinLength = currentInput.length,
                        isError = errorMessage != null
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(22.dp))

                    PrivacyNumericKeypad(
                        onDigitClick = { processDigit(it) },
                        onDeleteClick = {
                            if (currentInput.isNotEmpty()) {
                                currentInput = currentInput.dropLast(1)
                                errorMessage = null
                            }
                        },
                        onClearClick = {
                            currentInput = ""
                            errorMessage = null
                        }
                    )
                }
            }
        }
    }
}

/**
 * واجهة القفل الكاملة المخصصة للقسم أو التطبيق المقفل
 */
@Composable
fun PrivacyLockedScreenView(
    title: String,
    subtitle: String = "أدخل رمز PIN المكون من 4 أرقام لعرض المحتوى",
    icon: ImageVector = Icons.Outlined.Lock,
    sectionKey: String? = null,
    onBack: (() -> Unit)? = null,
    onUnlocked: () -> Unit
) {
    val context = LocalContext.current
    var isFrozen by remember {
        mutableStateOf(if (sectionKey == SaffahPrivacyManager.SECTION_RECOVERY_DIARIES) SaffahPrivacyManager.isDiaryFrozen(context) else false)
    }
    var remainingMillis by remember {
        mutableLongStateOf(if (sectionKey == SaffahPrivacyManager.SECTION_RECOVERY_DIARIES) SaffahPrivacyManager.getDiaryFrozenRemainingMillis(context) else 0L)
    }
    var currentInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(isFrozen) {
        while (isFrozen) {
            val rem = SaffahPrivacyManager.getDiaryFrozenRemainingMillis(context)
            if (rem <= 0L) {
                isFrozen = false
                break
            }
            remainingMillis = rem
            delay(1000L)
        }
    }

    fun processDigit(digit: Char) {
        if (isFrozen) return
        if (currentInput.length < 4) {
            val updated = currentInput + digit
            currentInput = updated
            errorMessage = null

            if (updated.length == 4) {
                when (val result = SaffahPrivacyManager.verifyPinWithSecurity(context, updated, sectionKey)) {
                    is SaffahPrivacyManager.VerifyPinResult.Success -> {
                        if (sectionKey != null) {
                            SaffahPrivacyManager.unlockSection(sectionKey)
                        }
                        onUnlocked()
                    }
                    is SaffahPrivacyManager.VerifyPinResult.WrongPin -> {
                        errorMessage = result.message
                        currentInput = ""
                    }
                    is SaffahPrivacyManager.VerifyPinResult.Frozen -> {
                        isFrozen = true
                        remainingMillis = result.remainingMillis
                        errorMessage = result.message
                        currentInput = ""
                    }
                }
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                                contentDescription = "رجوع",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                if (isFrozen) {
                    // Security Warning Frozen State UI
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .padding(vertical = 16.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.25f)),
                            modifier = Modifier.size(76.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Outlined.Shield,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = "تحذير أمني",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = SaffahPrivacyManager.SECURITY_FREEZE_MESSAGE,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center,
                            lineHeight = 24.sp
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 400.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 16.dp, horizontal = 20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "الوقت المتبقي لفك التجميد",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = SaffahPrivacyManager.formatRemainingHoursAndMinutes(remainingMillis),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryBlue
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "تم تجميد محاولات إدخال الرمز مؤقتاً لحماية خصوصية وسرية مذكراتك الشخصية.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (onBack != null) {
                        OutlinedButton(
                            onClick = onBack,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text("العودة", fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                } else {
                    // Middle: Icon, Title, Dots, Error
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = PrimaryBlue.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.2f)),
                            modifier = Modifier.size(76.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = PrimaryBlue,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(28.dp))

                        PrivacyPinDotsIndicator(
                            pinLength = currentInput.length,
                            isError = errorMessage != null
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        if (errorMessage != null) {
                            Text(
                                text = errorMessage ?: "",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            // Empty placeholder for height stability
                            Text(
                                text = " ",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }

                    // Keypad
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PrivacyNumericKeypad(
                            onDigitClick = { processDigit(it) },
                            onDeleteClick = {
                                if (currentInput.isNotEmpty()) {
                                    currentInput = currentInput.dropLast(1)
                                    errorMessage = null
                                }
                            },
                            onClearClick = {
                                currentInput = ""
                                errorMessage = null
                            }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}
