package com.example.ui.screens

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material3.HorizontalDivider

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import com.example.ui.components.rememberFastDrawablePainter
import com.example.ui.dialogs.AiIncludedAppsDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRow
import androidx.compose.material3.Tab
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import com.example.R
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.MainActivity
import com.example.model.PermissionStatus
import com.example.receiver.SaffahDeviceAdminReceiver
import com.example.util.SaffahProtectionManager
import com.example.ui.components.ExcludedAppsBox
import com.example.ui.components.GlassBentoCard
import com.example.ui.components.featureTitleHint
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.*
import com.example.util.SaffahLockTaskManager
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val permissionStatus by viewModel.permissionStatus.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val isAiProtectionEnabled by viewModel.isAiProtectionEnabled.collectAsState()
    val isAiNudeNetEnabled by viewModel.isAiNudeNetEnabled.collectAsState()
    val isAiAnimeEnabled by viewModel.isAiAnimeEnabled.collectAsState()
    val isAiDryRunEnabled by viewModel.isAiDryRunEnabled.collectAsState()
    val animeConfig by viewModel.animeConfig.collectAsState()
    val animeDebugState by viewModel.animeDebugState.collectAsState()
    val nudeConfig by viewModel.nudeConfig.collectAsState()
    val nudeDebugState by viewModel.nudeDebugState.collectAsState()
    val schedulerDebugState by viewModel.schedulerDebugState.collectAsState()
    var showAiDebugDialog by remember { mutableStateOf(false) }
    val aiProtectionIncludedApps by viewModel.aiProtectionIncludedApps.collectAsState()

    var showAppExclusionDialog by remember { mutableStateOf(false) }
    var showAiIncludedAppsDialog by remember { mutableStateOf(false) }
    var showProductivityEditDialog by remember { mutableStateOf(false) }
    var showProductivityInfoDialog by remember { mutableStateOf(false) }
    var showProductivityAddTargetDialog by remember { mutableStateOf(false) }
    var showProductivityAllowedAppsDialog by remember { mutableStateOf(false) }
    var editingTargetApp by remember { mutableStateOf<com.example.model.ProductivityTargetApp?>(null) }
    var deletingTargetApp by remember { mutableStateOf<com.example.model.ProductivityTargetApp?>(null) }

    val showUrgeVictoryDialog by viewModel.showUrgeVictoryDialog.collectAsState()

    if (showUrgeVictoryDialog) {
        UrgeVictoryDialog(
            onDismiss = { viewModel.closeUrgeVictoryDialog() }
        )
    }

    val productivityRule by viewModel.productivityRule.collectAsState()
    val isProductivityActiveNow by viewModel.isProductivityActiveNow.collectAsState()
    val productivityAppUsageMap by viewModel.productivityAppUsageMap.collectAsState()

    // Re-check permissions dynamically whenever user returns to the screen
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                viewModel.checkPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val vpnPrepareLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            viewModel.toggleVpn(true)
        } else {
            Toast.makeText(context, "تم إلغاء تفعيل الـ VPN", Toast.LENGTH_SHORT).show()
        }
    }

    val isVpnActive by com.example.service.SaffahVpnService.isVpnActive.collectAsState()
    val excludedVpnCount = remember(installedApps) { installedApps.count { it.isExcludedFromVpn } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Official Saffah App Brand Header
        item(key = "home_saffah_brand_header") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(id = R.drawable.ic_saffah_brand_logo),
                        contentDescription = "شعار السفاح",
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "السفّاح",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (isAiProtectionEnabled) "درع الحماية نشط" else "نظام الحماية والمراقبة",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isAiProtectionEnabled) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = (if (isAiProtectionEnabled) SuccessGreen else MaterialTheme.colorScheme.primary).copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, (if (isAiProtectionEnabled) SuccessGreen else MaterialTheme.colorScheme.primary).copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isAiProtectionEnabled) SuccessGreen else ErrorRed)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAiProtectionEnabled) "محمي" else "غير محمي",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isAiProtectionEnabled) SuccessGreen else ErrorRed
                        )
                    }
                }
            }
        }

        // AI Protection Bento Card (حجب الصور والفيديوهات الإباحية الواقعية)
        item(key = "home_ai_protection_toggle") {
            var showAiHintDialog by remember { mutableStateOf(false) }
            val haptic = LocalHapticFeedback.current

            if (showAiHintDialog) {
                Dialog(
                    onDismissRequest = { showAiHintDialog = false },
                    properties = DialogProperties(
                        usePlatformDefaultWidth = false,
                        dismissOnBackPress = true,
                        dismissOnClickOutside = true
                    )
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .widthIn(max = 380.dp)
                                .wrapContentHeight(),
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            shadowElevation = 8.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.AutoAwesome,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "درع الحجب البصري بالذكاء الاصطناعي (واقعي + أنمي/هينتاي)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    IconButton(
                                        onClick = { showAiHintDialog = false },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "إغلاق",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "• محركات ونماذج الذكاء الاصطناعي المدمجة:\n1. نموذج NudeNet ONNX: لرصد العري واللقطات الإباحية الواقعية والملابس الفاضحة في الصور والفيديوهات.\n2. نموذج MobileNetV3 (mobilenetv3_sce_dist.onnx): فحص وتصنيف رسومات الأنمي والهينتاي والمحتوى الكرتوني المثير (R15 و R18) محلياً على جهازك بسرعة فائقة.\n\n• كيفية العمل والأهمية:\nفحص مستمر للإطارات في التطبيقات المحددة وإغلاق المحتوى فوراً أو العودة للرئيسية عند اكتشاف أي مخالفة، دون إرسال أي لقطة أو بيانات لخارج هاتفك (أوفلاين 100%).",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 22.sp,
                                    fontSize = 13.5.sp
                                )
                            }
                        }
                    }
                }
            }

            GlassBentoCard(
                borderColor = if (isAiProtectionEnabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                modifier = Modifier.saffahGleam(enabled = isAiProtectionEnabled)
            ) {
                // Header / Info row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .combinedClickable(
                            onClick = {},
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                showAiHintDialog = true
                            }
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AutoAwesome,
                            contentDescription = null,
                            tint = if (isAiProtectionEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .size(24.dp)
                                .saffahBreathingPulse(enabled = isAiProtectionEnabled)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "درع الحجب البصري بالذكاء الاصطناعي",
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                softWrap = false
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isAiNudeNetEnabled && isAiAnimeEnabled) "النموذجان نشطان (واقعي + أنمي)"
                                else if (isAiNudeNetEnabled) "نموذج NudeNet فقط نشط (الواقعي)"
                                else if (isAiAnimeEnabled) "نموذج MobileNetV3 فقط نشط (الأنمي)"
                                else "النماذج معطلة",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = if (isAiProtectionEnabled) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                        if (isAiProtectionEnabled) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .saffahLiveDot(enabled = true, dotColor = Color(0xFF10B981), radiusDp = 3.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), thickness = 0.8.dp)
                Spacer(modifier = Modifier.height(12.dp))

                // Model 1: NudeNet (Real-world nudity)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "1. نموذج NudeNet (المحتوى الواقعي)",
                            style = MaterialTheme.typography.titleSmall.copy(fontSize = 13.5.sp),
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "حجب العري واللقطات الإباحية الواقعية والملابس الفاضحة",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    SaffahSwitch(
                        checked = isAiNudeNetEnabled,
                        onCheckedChange = { enable ->
                            viewModel.toggleAiNudeNet(enable)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Model 2: MobileNetV3 (Anime & Hentai)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "2. نموذج MobileNetV3 (الأنمي والهينتاي)",
                            style = MaterialTheme.typography.titleSmall.copy(fontSize = 13.5.sp),
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "فحص وتصنيف رسومات الأنمي والهينتاي (R15 و R18) محلياً",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    SaffahSwitch(
                        checked = isAiAnimeEnabled,
                        onCheckedChange = { enable ->
                            viewModel.toggleAiAnime(enable)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Switch 3: Dry Run Mode
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "3. وضع التجربة (Dry Run)",
                            style = MaterialTheme.typography.titleSmall.copy(fontSize = 13.5.sp),
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "عرض تنبيه بالقيم ونسبة المخالفة دون إغلاق الشاشة أو الرجوع",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    SaffahSwitch(
                        checked = isAiDryRunEnabled,
                        onCheckedChange = { enable ->
                            viewModel.toggleAiDryRun(enable)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Debug Panel & Live Values Button
                OutlinedButton(
                    onClick = { showAiDebugDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "لوحة فحص القيم الحية وضبط عتبات الذكاء الاصطناعي (Debug Panel)",
                        fontSize = 12.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                val aiIncludedAppsList = remember(installedApps, aiProtectionIncludedApps) {
                    installedApps.filter { aiProtectionIncludedApps.contains(it.packageName) }
                        .map { it.packageName to it.iconDrawable }
                }

                ExcludedAppsBox(
                    title = if (aiProtectionIncludedApps.isEmpty()) "التطبيقات المشمولة بالحجب البصري" else "التطبيقات المشمولة بالحجب البصري (${aiProtectionIncludedApps.size})",
                    apps = aiIncludedAppsList,
                    onClick = { showAiIncludedAppsDialog = true },
                    onLongClickItem = { pkg -> viewModel.toggleAiProtectionIncludedApp(pkg) },
                    hintKey = "ai_protection_apps"
                )
            }
        }

        // Main VPN Toggle Bento
        item(key = "home_vpn_toggle") {
            var showVpnHintDialog by remember { mutableStateOf(false) }
            val haptic = LocalHapticFeedback.current

            if (showVpnHintDialog) {
                Dialog(
                    onDismissRequest = { showVpnHintDialog = false },
                    properties = DialogProperties(
                        usePlatformDefaultWidth = false,
                        dismissOnBackPress = true,
                        dismissOnClickOutside = true
                    )
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .widthIn(max = 380.dp)
                                .wrapContentHeight(),
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            shadowElevation = 8.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "حماية الـ VPN",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { showVpnHintDialog = false },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "إغلاق",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "مرشح شبكي محلي لحظر المواقع الضارة ومنصات القمار والمحتوى الإباحي فورياً على مستوى الجهاز دون إرسال بياناتك للخارج.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 22.sp,
                                    fontSize = 13.5.sp
                                )
                            }
                        }
                    }
                }
            }

            GlassBentoCard(
                modifier = Modifier.saffahGleam(enabled = permissionStatus.isVpnActive)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .combinedClickable(
                            onClick = {},
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                showVpnHintDialog = true
                            }
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.VpnLock,
                            contentDescription = null,
                            tint = if (permissionStatus.isVpnActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .size(24.dp)
                                .saffahBreathingPulse(enabled = permissionStatus.isVpnActive)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "تفعيل طبقة الحماية VPN",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.featureTitleHint("vpn_protection")
                        )
                        if (permissionStatus.isVpnActive) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .saffahLiveDot(enabled = true, dotColor = Color(0xFF10B981), radiusDp = 3.dp)
                            )
                        }
                    }

                    SaffahSwitch(
                        checked = permissionStatus.isVpnActive,
                        onCheckedChange = { enable ->
                            if (enable) {
                                val vpnIntent = VpnService.prepare(context)
                                if (vpnIntent != null) {
                                    vpnPrepareLauncher.launch(vpnIntent)
                                } else {
                                    viewModel.toggleVpn(true)
                                }
                            } else {
                                viewModel.toggleVpn(false)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val excludedVpnApps = remember(installedApps) {
                    installedApps.filter { it.isExcludedFromVpn }.map { it.packageName to it.iconDrawable }
                }

                ExcludedAppsBox(
                    title = if (excludedVpnCount == 0) "استثناء تطبيقات من الـ VPN" else "استثناء تطبيقات من الـ VPN ($excludedVpnCount)",
                    apps = excludedVpnApps,
                    onClick = { showAppExclusionDialog = true },
                    onLongClickItem = { pkg -> viewModel.toggleAppVpnExclusion(pkg) },
                    hintKey = "vpn_exclusion"
                )
            }
        }

        // Locked Penalty Screen Bento Card
        item(key = "home_penalty_screen") {
            val isPenaltyEnabled by viewModel.isPenaltyEnabled.collectAsState()
            val penaltyMinutes by viewModel.penaltyDurationMinutes.collectAsState()
            val isPenaltyActive by viewModel.isPenaltyActive.collectAsState()
            val remainingMs by viewModel.remainingPenaltyMs.collectAsState()

            GlassBentoCard {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Row with Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .featureTitleHint("penalty_screen")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.LockClock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "شاشة العقوبة المقفلة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        SaffahSwitch(
                            checked = isPenaltyEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.togglePenaltyEnabled(enabled)
                            }
                        )
                    }

                    if (isPenaltyEnabled) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                        // Compact, elegant Duration Row with mini stepper
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "المدة المحددة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                // Clean Compact Stepper Pill
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.dp)
                                    ) {
                                        IconButton(
                                            onClick = {
                                                if (penaltyMinutes > 1) {
                                                    viewModel.setPenaltyDuration(penaltyMinutes - 1)
                                                }
                                            },
                                            enabled = penaltyMinutes > 1,
                                            modifier = Modifier
                                                .size(28.dp)
                                                .saffahMicroPress(enabled = penaltyMinutes > 1)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Remove,
                                                contentDescription = "إنقاص الدقائق",
                                                tint = if (penaltyMinutes > 1) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }

                                        Text(
                                            text = "$penaltyMinutes د",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )

                                        IconButton(
                                            onClick = {
                                                if (penaltyMinutes < 15) {
                                                    viewModel.setPenaltyDuration(penaltyMinutes + 1)
                                                }
                                            },
                                            enabled = penaltyMinutes < 15,
                                            modifier = Modifier
                                                .size(28.dp)
                                                .saffahMicroPress(enabled = penaltyMinutes < 15)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "زيادة الدقائق",
                                                tint = if (penaltyMinutes < 15) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Informative smart rule note
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "قاعدة التفعيل اليومية: يتم الحظر فورياً في كل مرة، وتُقفل شاشة العقوبة عند تكرار نفس الكلمة 3 مرات، أو نفس الموقع مرتين خلال اليوم (تُصفّر العدادات يومياً).",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Start
                            )
                        }

                        // Status pill if currently active
                        if (isPenaltyActive) {
                            val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
                            val remMinutes = totalSeconds / 60
                            val remSeconds = totalSeconds % 60
                            val formatted = String.format(java.util.Locale.ENGLISH, "%02d:%02d", remMinutes, remSeconds)

                            Surface(
                                color = ErrorRed.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .saffahLiveDot(enabled = true, dotColor = ErrorRed, radiusDp = 3.5.dp)
                                    )
                                    Icon(
                                        imageVector = Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = ErrorRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "العقوبة نشطة حالياً (متبقي $formatted)",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = ErrorRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 15-Minute Urge Suppression Bento Card (قاعدة 15د لدحر الرغبة)
        item(key = "home_urge_suppression_card") {
            val isUrgeEnabled by viewModel.isUrgeFeatureEnabled.collectAsState()
            val isUrgeActive by viewModel.isUrgeSessionActive.collectAsState()
            val remainingUrgeMs by viewModel.remainingUrgeSessionMs.collectAsState()

            var showUrgeTips by remember { mutableStateOf(false) }
            var tapCount by remember { mutableStateOf(0) }
            var lastTapTime by remember { mutableStateOf(0L) }

            GlassBentoCard(
                modifier = Modifier.saffahNeonBorderTrace(
                    enabled = isUrgeActive,
                    neonColor = MaterialTheme.colorScheme.primary,
                    cornerRadius = 16.dp
                )
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Row with Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .pointerInput(isUrgeEnabled, isUrgeActive) {
                                    detectTapGestures(
                                        onLongPress = {
                                            if (isUrgeEnabled) {
                                                showUrgeTips = !showUrgeTips
                                            }
                                        },
                                        onTap = {
                                            if (isUrgeEnabled && !isUrgeActive) {
                                                val now = System.currentTimeMillis()
                                                if (now - lastTapTime > 1500L) {
                                                    tapCount = 1
                                                } else {
                                                    tapCount++
                                                }
                                                lastTapTime = now

                                                if (tapCount >= 5) {
                                                    tapCount = 0
                                                    viewModel.startUrgeSessionManually(15)
                                                }
                                            }
                                        }
                                    )
                                }
                                .padding(vertical = 4.dp, horizontal = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.HourglassTop,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "قاعدة 15د لدحر الرغبة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.featureTitleHint("urge_suppression_15")
                            )
                        }

                        SaffahSwitch(
                            checked = isUrgeEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.toggleUrgeFeature(enabled)
                            }
                        )
                    }

                    if (isUrgeEnabled) {
                        // Toggled Tips & Guidelines on Long Press
                        if (showUrgeTips) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                            Text(
                                text = "تمنحك 15 دقيقة من الحماية وقفل الشاشة للتنفس واستعادة السيطرة حتى تنكسر موجة الرغبة بيولوجياً.\nاضغط 5 ضغطات متتالية على عنوان أو أيقونة الميزة لبدء جلسة فورية.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 20.sp
                            )

                            // Home Widget & Quick Settings Tile Tip Banner
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Widgets,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "يمكنك تشغيل النافذة العائمة فوراً بلمسة واحدة عبر الويدجت (Widget) بالشاشة الرئيسية أو من خلال بلاطة الإعدادات السريعة (Tile) بشريط الإشعارات فوق أي تطبيق.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        if (!isUrgeActive) {
                            Button(
                                onClick = {
                                    viewModel.startUrgeSessionManually(15)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .saffahHeartbeatPulse(enabled = isUrgeEnabled && !isUrgeActive)
                                    .saffahMicroPress(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "بدء جلسة 15 دقيقة لدحر الرغبة الآن",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Active Urge Session Status Card
                        if (isUrgeActive) {
                            val totalSeconds = (remainingUrgeMs / 1000L).coerceAtLeast(0L)
                            val remMinutes = totalSeconds / 60
                            val remSeconds = totalSeconds % 60
                            val formattedTime = String.format(java.util.Locale.ENGLISH, "%02d:%02d", remMinutes, remSeconds)

                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Timer,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(22.dp)
                                            )
                                            Text(
                                                text = "جلسة دحر الرغبة نشطة الآن",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        Surface(
                                            color = MaterialTheme.colorScheme.primary,
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = formattedTime,
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                SaffahLockTaskManager.launchLockTaskApp(context, SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                        ) {
                                            Icon(imageVector = Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("فتح شاشة القفل والتنفس", style = MaterialTheme.typography.labelSmall)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                viewModel.stopUrgeSessionManually()
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text("إيقاف مبكر (محمي)", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bedtime Mode (ضبط وقت النوم) Bento Card
        item(key = "home_bedtime_card") {
            val isBedtimeEnabled by viewModel.isBedtimeEnabled.collectAsState()
            val startHour by viewModel.bedtimeStartHour.collectAsState()
            val startMinute by viewModel.bedtimeStartMinute.collectAsState()
            val endHour by viewModel.bedtimeEndHour.collectAsState()
            val endMinute by viewModel.bedtimeEndMinute.collectAsState()
            val allowedApps by viewModel.bedtimeAllowedApps.collectAsState()
            val bedtimeDays by viewModel.bedtimeDays.collectAsState()
            val isBedtimeGrayscaleEnabled by viewModel.isBedtimeGrayscaleEnabled.collectAsState()
            val isBedtimeEyeComfortEnabled by viewModel.isBedtimeEyeComfortEnabled.collectAsState()
            val isCurrentlyBedtime by viewModel.isCurrentlyBedtime.collectAsState()
            val isHardwareGrayscaleGranted by viewModel.isHardwareGrayscaleGranted.collectAsState()

            var showStartTimePicker by remember { mutableStateOf(false) }
            var showEndTimePicker by remember { mutableStateOf(false) }
            var showBedtimeAppsDialog by remember { mutableStateOf(false) }
            var isBedtimeFeaturesExpanded by rememberSaveable { mutableStateOf(false) }

            val startTimeFormatted = String.format(java.util.Locale.ENGLISH, "%02d:%02d", startHour, startMinute)
            val endTimeFormatted = String.format(java.util.Locale.ENGLISH, "%02d:%02d", endHour, endMinute)

            if (showStartTimePicker) {
                BedtimeTimePickerDialog(
                    initialHour = startHour,
                    initialMinute = startMinute,
                    title = "تحديد وقت بداية النوم",
                    onDismiss = { showStartTimePicker = false },
                    onTimeSelected = { h, m ->
                        viewModel.updateBedtimeSchedule(h, m, endHour, endMinute)
                        showStartTimePicker = false
                    }
                )
            }

            if (showEndTimePicker) {
                BedtimeTimePickerDialog(
                    initialHour = endHour,
                    initialMinute = endMinute,
                    title = "تحديد وقت نهاية النوم",
                    onDismiss = { showEndTimePicker = false },
                    onTimeSelected = { h, m ->
                        viewModel.updateBedtimeSchedule(startHour, startMinute, h, m)
                        showEndTimePicker = false
                    }
                )
            }

            if (showBedtimeAppsDialog) {
                BedtimeAllowedAppsDialog(
                    viewModel = viewModel,
                    onDismiss = { showBedtimeAppsDialog = false }
                )
            }

            GlassBentoCard {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header with Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .featureTitleHint("bedtime_mode")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Bedtime,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "ضبط وقت النوم",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        SaffahSwitch(
                            checked = isBedtimeEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.setBedtimeEnabled(enabled)
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                    // Time Schedule Selector - Modern Elegant Connected Bar
                    Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Start Time Tab
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { showStartTimePicker = true },
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "بداية النوم",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = startTimeFormatted,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                // Elegant Arrow Divider
                                Box(
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.ArrowBack,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }

                                // End Time Tab
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { showEndTimePicker = true },
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "نهاية النوم",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = endTimeFormatted,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }

                        // Days of Week Selector
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "أيام التفعيل التلقائي",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            val weekDays = remember {
                                listOf(
                                    Pair(java.util.Calendar.SATURDAY, "س"),
                                    Pair(java.util.Calendar.SUNDAY, "ح"),
                                    Pair(java.util.Calendar.MONDAY, "ن"),
                                    Pair(java.util.Calendar.TUESDAY, "ث"),
                                    Pair(java.util.Calendar.WEDNESDAY, "ر"),
                                    Pair(java.util.Calendar.THURSDAY, "خ"),
                                    Pair(java.util.Calendar.FRIDAY, "ج")
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                weekDays.forEach { (dayInt, dayLetter) ->
                                    val isSelected = bedtimeDays.contains(dayInt)
                                    Surface(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                viewModel.toggleBedtimeDay(dayInt)
                                            },
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        shape = CircleShape
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = dayLetter,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // App Selection Button
                        val bedtimeSelectedApps = remember(installedApps, allowedApps) {
                            allowedApps.map { pkg ->
                                pkg to (installedApps.find { it.packageName == pkg }?.iconDrawable
                                    ?: com.example.util.AppListHelper.resolveIconFast(context, pkg))
                            }
                        }

                        ExcludedAppsBox(
                            title = if (allowedApps.isEmpty()) "تحديد التطبيقات المسموحة" else "تحديد التطبيقات المسموحة (${allowedApps.size} تطبيقات)",
                            apps = bedtimeSelectedApps,
                            onClick = { showBedtimeAppsDialog = true },
                            onLongClickItem = { pkg -> viewModel.toggleBedtimeAllowedApp(pkg) }
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                        // زر عرض / طي باقي ميزات وقت النوم
                        val chevronRotation by animateFloatAsState(
                            targetValue = if (isBedtimeFeaturesExpanded) 180f else 0f,
                            label = "bedtime_chevron_rotation"
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { isBedtimeFeaturesExpanded = !isBedtimeFeaturesExpanded }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isBedtimeFeaturesExpanded) "إخفاء الميزات" else "عرض كل الميزات",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isBedtimeFeaturesExpanded) "إخفاء الميزات" else "عرض كل الميزات",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(20.dp)
                                    .rotate(chevronRotation)
                            )
                        }

                        // باقي ميزات ضبط وقت النوم مطوية بشكل افتراضي
                        AnimatedVisibility(
                            visible = isBedtimeFeaturesExpanded,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                                // Grayscale Switch (تحويل الشاشة إلى أبيض وأسود)
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .weight(1f)
                                                .featureTitleHint("hardware_grayscale")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.InvertColors,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = "تحويل الشاشة إلى أبيض وأسود",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "يبدأ تلقائياً قبل 30 دقيقة من موعد النوم",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        SaffahSwitch(
                                            checked = isBedtimeGrayscaleEnabled,
                                            onCheckedChange = { viewModel.setBedtimeGrayscaleEnabled(it) }
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                                // Eye Comfort Switch (تفعيل وضع راحة العين)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .weight(1f)
                                            .featureTitleHint("bedtime_eye_comfort")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Visibility,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "تفعيل وضع راحة العين",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "يبدأ تلقائياً قبل 30 دقيقة من موعد النوم",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    SaffahSwitch(
                                        checked = isBedtimeEyeComfortEnabled,
                                        onCheckedChange = { viewModel.setBedtimeEyeComfortEnabled(it) }
                                    )
                                }
                            }
                        }
                    }
                }
        }

        // Trigger Blocking Section Title
        item(key = "home_trigger_blocking_title") {
            Text(
                text = "حظر المحفزات",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        // Trigger Blocking (حظر المحفزات) Bento Card
        item(key = "home_trigger_blocking") {
            val isTelegramSearchBlocked by viewModel.isTelegramSearchBlocked.collectAsState()
            val isWhatsAppChannelsBlocked by viewModel.isWhatsAppChannelsBlocked.collectAsState()
            val isYouTubeShortsBlocked by viewModel.isYouTubeShortsBlocked.collectAsState()
            val isFacebookLiteReelsBlocked by viewModel.isFacebookLiteReelsBlocked.collectAsState()
            val isInstagramReelsBlocked by viewModel.isInstagramReelsBlocked.collectAsState()

            GlassBentoCard {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Feature: Block Telegram Global Search
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_logo_telegram),
                                contentDescription = "Telegram",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(25.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "حظر البحث في تلغرام",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        SaffahSwitch(
                            checked = isTelegramSearchBlocked,
                            onCheckedChange = { enabled ->
                                viewModel.toggleTelegramSearchBlocked(enabled)
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                    // Feature: Block WhatsApp Channels & Exploration
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_logo_whatsapp),
                                contentDescription = "WhatsApp",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(25.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "حظر استكشاف وقنوات واتساب",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        SaffahSwitch(
                            checked = isWhatsAppChannelsBlocked,
                            onCheckedChange = { enabled ->
                                viewModel.toggleWhatsAppChannelsBlocked(enabled)
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                    // Feature: Block YouTube Shorts
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_logo_youtube),
                                contentDescription = "YouTube",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(25.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "حظر شورتس يوتيوب",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        SaffahSwitch(
                            checked = isYouTubeShortsBlocked,
                            onCheckedChange = { enabled ->
                                viewModel.toggleYouTubeShortsBlocked(enabled)
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                    // Feature: Block Facebook Lite Reels
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_logo_facebook),
                                contentDescription = "Facebook Lite",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(25.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "حظر ريلز فيسبوك لايت",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        SaffahSwitch(
                            checked = isFacebookLiteReelsBlocked,
                            onCheckedChange = { enabled ->
                                viewModel.toggleFacebookLiteReelsBlocked(enabled)
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                    // Feature: Block Instagram Reels
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_logo_instagram),
                                contentDescription = "Instagram",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(25.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "حظر ريلز انستغرام",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        SaffahSwitch(
                            checked = isInstagramReelsBlocked,
                            onCheckedChange = { enabled ->
                                viewModel.toggleInstagramReelsBlocked(enabled)
                            }
                        )
                    }
                }
            }
        }

        // Productivity & Discipline Section Title (تحسين الإنتاجية والإنظباط)
        item(key = "home_productivity_title") {
            Text(
                text = "تحسين الإنتاجية والإنظباط",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            )
        }

        // Productivity & Discipline Card
        item(key = "home_productivity_card") {
            val rule = productivityRule ?: com.example.model.ProductivityDisciplineRule()
            GlassBentoCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Header row: Title on start side, Action buttons (Edit, Switch) on end side
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.TrendingUp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = rule.name.ifBlank { "تحسين الإنتاجية والإنظباط" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    showProductivityEditDialog = true
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "تعديل العملية",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            SaffahSwitch(
                                checked = rule.isEnabled,
                                onCheckedChange = { isChecked ->
                                    viewModel.toggleProductivityRuleEnabled(isChecked)
                                }
                            )
                        }
                    }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Status Badge Row
                        val hasTargets = rule.targetApps.isNotEmpty()
                        val allTargetsDone = hasTargets && com.example.util.SaffahBlockRepository.isProductivityAllTargetsCompleted(context, rule)
                        val isHighlightState = isProductivityActiveNow || allTargetsDone

                        val statusText = when {
                            !rule.isEnabled -> "معطل"
                            !hasTargets -> "لم تُحدد أهداف بعد"
                            isProductivityActiveNow -> "نشط حالياً • من 06:00 إلى 22:00"
                            allTargetsDone -> "تم إنجاز الأهداف • رُفِع الحظر"
                            else -> "في الانتظار • يبدأ 06:00"
                        }

                        val dotColor = when {
                            !rule.isEnabled || !hasTargets -> MaterialTheme.colorScheme.outline
                            isProductivityActiveNow -> SuccessGreen
                            allTargetsDone -> SuccessGreen
                            else -> WarningAmber
                        }

                        Surface(
                            color = if (isHighlightState) SuccessGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(
                                1.dp,
                                if (isHighlightState) SuccessGreen.copy(alpha = 0.3f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = dotColor,
                                    modifier = Modifier.size(6.dp)
                                ) {}
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isHighlightState) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Active Days with Circular Arabic Letters (س، أ، ن، ث، ع، خ، ج)
                        Text(
                            text = "أيام السريان:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val prodDays = listOf(
                            java.util.Calendar.SATURDAY to "س",
                            java.util.Calendar.SUNDAY to "أ",
                            java.util.Calendar.MONDAY to "ن",
                            java.util.Calendar.TUESDAY to "ث",
                            java.util.Calendar.WEDNESDAY to "ع",
                            java.util.Calendar.THURSDAY to "خ",
                            java.util.Calendar.FRIDAY to "ج"
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            prodDays.forEach { (dayIndex, letter) ->
                                val isSelected = rule.activeDays.contains(dayIndex)
                                Surface(
                                    shape = CircleShape,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = letter,
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Target Apps & Progress Bars
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "تطبيقات الهدف وسقف الوقت اليومي (${rule.targetApps.size}):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            TextButton(
                                onClick = { showProductivityAddTargetDialog = true },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إضافة تطبيق", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (rule.targetApps.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "لم يتم تحديد أي تطبيق هدف بعد. اضغط على (+ إضافة تطبيق) لتحديد التطبيقات وسقف الوقت المطلوب.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rule.targetApps.forEach { targetApp ->
                                    val appItem = installedApps.find { it.packageName == targetApp.packageName }
                                    val appLabel = appItem?.appName ?: targetApp.packageName
                                    val spentMinutes = productivityAppUsageMap[targetApp.packageName] ?: 0
                                    val targetMinutes = targetApp.targetMinutes
                                    val rawProgress = if (targetMinutes > 0) (spentMinutes.toFloat() / targetMinutes.toFloat()).coerceIn(0f, 1f) else 0f
                                    val animatedProgress by androidx.compose.animation.core.animateFloatAsState(
                                        targetValue = rawProgress,
                                        animationSpec = androidx.compose.animation.core.tween(durationMillis = 400),
                                        label = "productivity_progress"
                                    )
                                    val isCompleted = spentMinutes >= targetMinutes

                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                        shape = RoundedCornerShape(14.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .combinedClickable(
                                                onClick = {
                                                    editingTargetApp = targetApp
                                                },
                                                onLongClick = {
                                                    val isRestricted = com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)
                                                    if (isRestricted) {
                                                        viewModel.showFeedback("لا يمكن حذف تطبيقات الهدف أثناء سريان التأخير الزمني (يُسمح بالتعديل والحذف بين 22:00 و 06:00).")
                                                    } else {
                                                        deletingTargetApp = targetApp
                                                    }
                                                }
                                            )
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(
                                                    modifier = Modifier.weight(1f),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    val iconPainter = rememberFastDrawablePainter(appItem?.iconDrawable)
                                                    if (iconPainter != null) {
                                                        Image(
                                                            painter = iconPainter,
                                                            contentDescription = null,
                                                            modifier = Modifier
                                                                .size(32.dp)
                                                                .clip(RoundedCornerShape(8.dp))
                                                        )
                                                    } else {
                                                        Surface(
                                                            color = MaterialTheme.colorScheme.primaryContainer,
                                                            shape = RoundedCornerShape(8.dp),
                                                            modifier = Modifier.size(32.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Apps,
                                                                contentDescription = null,
                                                                tint = MaterialTheme.colorScheme.primary,
                                                                modifier = Modifier.padding(5.dp)
                                                            )
                                                        }
                                                    }
                                                    Spacer(modifier = Modifier.width(10.dp))
                                                    Column {
                                                        Text(
                                                            text = appLabel,
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onSurface,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }
                                                }

                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            editingTargetApp = targetApp
                                                        }
                                                        .padding(horizontal = 6.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = com.example.util.SaffahBlockRepository.formatUsagePair(spentMinutes, targetMinutes),
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isCompleted) SuccessGreen else MaterialTheme.colorScheme.primary
                                                    )
                                                    if (isCompleted) {
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Icon(
                                                            imageVector = Icons.Default.CheckCircle,
                                                            contentDescription = "مكتمل",
                                                            tint = SuccessGreen,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            LinearProgressIndicator(
                                                progress = { animatedProgress },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(6.dp)
                                                    .clip(RoundedCornerShape(3.dp)),
                                                color = if (isCompleted) SuccessGreen else MaterialTheme.colorScheme.primary,
                                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Allowed Apps count & Edit Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "التطبيقات المسموحة للاستخدام الحر:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${rule.allowedApps.size} تطبيق مستثنى من الحظر",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }

                            OutlinedButton(
                                onClick = { showProductivityAllowedAppsDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Checklist, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تعديل", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
        }

        // Permissions Section Bento
        item(key = "home_permissions_title") {
            Text(
                text = "الأذونات والصلاحيات",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        // Accessibility Permission Item
        item(key = "home_perm_accessibility") {
            PermissionCardItem(
                title = "Accessibility",
                isEnabled = permissionStatus.isAccessibilityEnabled,
                isPermanentlyLocked = false,
                onClick = {
                    try {
                        SaffahProtectionManager.ensureAccessibilityServiceEnabled(context)
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "تعذر فتح إعدادات الوصول", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        // Exact alarms Item
        item(key = "home_perm_alarms") {
            PermissionCardItem(
                title = "Exact Alarms",
                isEnabled = permissionStatus.isExactAlarmEnabled,
                onClick = {
                    try {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                            try {
                                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:${context.packageName}"))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                            }
                        } else {
                            Toast.makeText(context, "مفعلة تلقائياً في نظامك", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "مفعلة في النظام", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        // Notification Access Item
        item(key = "home_perm_notif") {
            PermissionCardItem(
                title = "Notification Access",
                isEnabled = permissionStatus.isNotificationAccessEnabled,
                onClick = {
                    try {
                        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "تعذر فتح إعدادات الإشعارات", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    // Dialog for Excluding Apps from VPN
    if (showAppExclusionDialog) {
        var searchQuery by remember { mutableStateOf("") }
        var filterCategory by remember { mutableStateOf("ALL") }

        LaunchedEffect(Unit) {
            viewModel.loadRealInstalledApps()
        }

        val context = androidx.compose.ui.platform.LocalContext.current
        val currentlyExcludedSet = remember(installedApps) {
            com.example.util.SaffahBlockRepository.getExcludedVpnApps(context)
        }
        val completeAppsList = remember(installedApps, currentlyExcludedSet) {
            val existingPkgSet = installedApps.map { it.packageName }.toSet()
            val missingPkgs = currentlyExcludedSet.filter { !existingPkgSet.contains(it) }
            if (missingPkgs.isEmpty()) {
                installedApps
            } else {
                val synthesized = missingPkgs.map { pkg ->
                    val label = com.example.util.AppListHelper.resolveAppLabelFast(context, pkg)
                    val icon = com.example.util.AppListHelper.resolveIconFast(context, pkg)
                    com.example.model.InstalledApp(
                        packageName = pkg,
                        appName = label,
                        isExcludedFromVpn = true,
                        isBlocked = false,
                        isSystemApp = false,
                        iconDrawable = icon
                    )
                }
                installedApps + synthesized
            }
        }

        val filteredApps = remember(completeAppsList, searchQuery, filterCategory) {
            completeAppsList.filter { app ->
                val matchesSearch = searchQuery.isBlank() ||
                        app.appName.contains(searchQuery, ignoreCase = true) ||
                        app.packageName.contains(searchQuery, ignoreCase = true)

                val matchesCategory = when (filterCategory) {
                    "USER" -> !app.isSystemApp
                    "SYSTEM" -> app.isSystemApp
                    "EXCLUDED" -> app.isExcludedFromVpn
                    else -> true
                }

                matchesSearch && matchesCategory
            }
        }

        Dialog(
            onDismissRequest = {
                showAppExclusionDialog = false
                if (permissionStatus.isVpnActive) {
                    viewModel.toggleVpn(true)
                }
            },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding(),
                    color = MaterialTheme.colorScheme.surface
                ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    // Clean Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "استثناء تطبيقات من VPN (${installedApps.count { it.isExcludedFromVpn }})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(
                            onClick = {
                                showAppExclusionDialog = false
                                if (permissionStatus.isVpnActive) {
                                    viewModel.toggleVpn(true)
                                }
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Search input field
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("بحث باسم التطبيق أو اسم الحزمة...", style = MaterialTheme.typography.bodySmall) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Search, contentDescription = "بحث", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                    Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Category Filter Tabs (Spanning 100% width cleanly with no clipped edges)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val categories = listOf(
                            "ALL" to "الكل (${completeAppsList.size})",
                            "USER" to "المثبتة (${completeAppsList.count { !it.isSystemApp }})",
                            "SYSTEM" to "النظام (${completeAppsList.count { it.isSystemApp }})",
                            "EXCLUDED" to "المستثناة (${completeAppsList.count { it.isExcludedFromVpn }})"
                        )
                        categories.forEach { (key, label) ->
                            val isSelected = filterCategory == key
                            Surface(
                                onClick = { filterCategory = key },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 2.dp)
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // List of apps expanding cleanly to fill all available vertical space
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        if (filteredApps.isEmpty()) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SearchOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "لم يتم العثور على أي تطبيق مطابق",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredApps, key = { it.packageName }) { app ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (app.isExcludedFromVpn) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant,
                                        border = if (app.isExcludedFromVpn) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)) else null,
                                        onClick = { viewModel.toggleAppVpnExclusion(app.packageName) }
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            // App Icon
                                            val iconPainter = rememberFastDrawablePainter(app.iconDrawable)
                                            if (iconPainter != null) {
                                                Image(
                                                    painter = iconPainter,
                                                    contentDescription = app.appName,
                                                    modifier = Modifier
                                                        .size(40.dp)
                                                        .clip(RoundedCornerShape(10.dp))
                                                )
                                            } else {
                                                Surface(
                                                    modifier = Modifier.size(40.dp),
                                                    shape = RoundedCornerShape(10.dp),
                                                    color = MaterialTheme.colorScheme.primaryContainer
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Icon(
                                                            imageVector = Icons.Default.Android,
                                                            contentDescription = null,
                                                            tint = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.size(22.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(12.dp))

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = app.appName,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = app.packageName,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            Spacer(modifier = Modifier.width(8.dp))

                                            Checkbox(
                                                checked = app.isExcludedFromVpn,
                                                onCheckedChange = {
                                                    viewModel.toggleAppVpnExclusion(app.packageName)
                                                },
                                                colors = CheckboxDefaults.colors(
                                                    checkedColor = MaterialTheme.colorScheme.primary,
                                                    checkmarkColor = MaterialTheme.colorScheme.onPrimary
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

    // --- Productivity and Discipline Dialogs ---

    if (showProductivityInfoDialog) {
        ProductivityInfoDialog(
            onDismiss = { showProductivityInfoDialog = false }
        )
    }

    if (showProductivityEditDialog) {
        val isRestricted = com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)
        ProductivityRuleEditDialog(
            initialRule = productivityRule,
            isRestrictedByTimeDelay = isRestricted,
            onDismiss = { showProductivityEditDialog = false },
            onSave = { updatedRule ->
                viewModel.saveProductivityRule(updatedRule)
                showProductivityEditDialog = false
            }
        )
    }

    if (showProductivityAddTargetDialog) {
        LaunchedEffect(Unit) {
            viewModel.loadRealInstalledApps()
        }
        ProductivityAddTargetAppDialog(
            installedApps = installedApps,
            existingTargetApps = productivityRule?.targetApps ?: emptyList(),
            onDismiss = { showProductivityAddTargetDialog = false },
            onAddTarget = { newTargetApp ->
                val current = productivityRule ?: com.example.model.ProductivityDisciplineRule(
                    name = "تحسين الإنتاجية والإنظباط",
                    isEnabled = true,
                    targetApps = emptyList(),
                    allowedApps = emptySet()
                )
                val currentDaily = com.example.util.SaffahBlockRepository.getDailyForegroundTimeMillis(context, newTargetApp.packageName)
                val targetWithBaseline = newTargetApp.copy(
                    baselineMillis = currentDaily,
                    addedAt = System.currentTimeMillis()
                )
                val updatedTargets = current.targetApps.filter { it.packageName != targetWithBaseline.packageName } + targetWithBaseline
                com.example.util.SaffahNotificationManager.resetProductivityGoalNotificationState(context, newTargetApp.packageName)
                viewModel.saveProductivityRule(current.copy(isEnabled = true, targetApps = updatedTargets))
                showProductivityAddTargetDialog = false
            }
        )
    }

    if (showAiIncludedAppsDialog) {
        LaunchedEffect(Unit) {
            viewModel.loadRealInstalledApps()
        }
        AiIncludedAppsDialog(
            installedApps = installedApps,
            includedApps = aiProtectionIncludedApps,
            onDismiss = { showAiIncludedAppsDialog = false },
            onSaveIncludedApps = { newIncluded ->
                viewModel.setAiProtectionIncludedApps(newIncluded)
                showAiIncludedAppsDialog = false
            }
        )
    }

    if (showProductivityAllowedAppsDialog) {
        LaunchedEffect(Unit) {
            viewModel.loadRealInstalledApps()
        }
        val isRestricted = com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)
        ProductivityAllowedAppsDialog(
            installedApps = installedApps,
            allowedApps = productivityRule?.allowedApps ?: emptySet(),
            isRestrictedByTimeDelay = isRestricted,
            onDismiss = { showProductivityAllowedAppsDialog = false },
            onSaveAllowedApps = { newAllowed ->
                val current = productivityRule ?: com.example.model.ProductivityDisciplineRule(
                    name = "تحسين الإنتاجية والإنظباط",
                    isEnabled = false,
                    targetApps = emptyList(),
                    allowedApps = emptySet()
                )
                viewModel.saveProductivityRule(current.copy(allowedApps = newAllowed))
                showProductivityAllowedAppsDialog = false
            }
        )
    }

    val activeEditingApp = editingTargetApp
    if (activeEditingApp != null) {
        val appItem = installedApps.find { it.packageName == activeEditingApp.packageName }
        val appLabel = appItem?.appName ?: activeEditingApp.packageName
        val isRestricted = com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)
        ProductivityEditTargetAppDialog(
            targetApp = activeEditingApp,
            appName = appLabel,
            iconDrawable = appItem?.iconDrawable,
            isRestrictedByTimeDelay = isRestricted,
            onDismiss = { editingTargetApp = null },
            onSaveMinutes = { newMinutes ->
                viewModel.updateProductivityTargetMinutes(activeEditingApp.packageName, newMinutes)
                editingTargetApp = null
            }
        )
    }

    val activeDeletingApp = deletingTargetApp
    if (activeDeletingApp != null) {
        val appItem = installedApps.find { it.packageName == activeDeletingApp.packageName }
        val appLabel = appItem?.appName ?: activeDeletingApp.packageName
        ProductivityDeleteTargetConfirmDialog(
            targetApp = activeDeletingApp,
            appName = appLabel,
            onDismiss = { deletingTargetApp = null },
            onConfirmDelete = {
                viewModel.deleteProductivityTargetApp(activeDeletingApp.packageName)
                deletingTargetApp = null
            }
        )
    }
    if (showAiDebugDialog) {
        var selectedTab by remember { mutableStateOf(0) }

        // Anime inputs
        var tr18Input by remember(animeConfig) { mutableStateOf(animeConfig.tR18.toString()) }
        var tr15Input by remember(animeConfig) { mutableStateOf(animeConfig.tR15.toString()) }
        var tSumInput by remember(animeConfig) { mutableStateOf(animeConfig.tSum.toString()) }
        var animeConfirmInput by remember(animeConfig) { mutableStateOf(animeConfig.confirm.toString()) }

        // Nude inputs
        var tFemaleGenExpInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tFemaleGenExp.toString()) }
        var tMaleGenExpInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tMaleGenExp.toString()) }
        var tAnusExpInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tAnusExp.toString()) }
        var tFemaleBreastExpInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tFemaleBreastExp.toString()) }
        var tButtExpInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tButtExp.toString()) }
        var tButtIsolatedInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tButtIsolated.toString()) }
        var strongInput by remember(nudeConfig) { mutableStateOf(nudeConfig.strong.toString()) }
        var strongButtInput by remember(nudeConfig) { mutableStateOf(nudeConfig.strongButt.toString()) }
        var sexyEnabledState by remember(nudeConfig) { mutableStateOf(nudeConfig.sexyEnabled) }
        var tBreastCovInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tBreastCov.toString()) }
        var tLowerCovInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tLowerCov.toString()) }
        var tBellyExpInput by remember(nudeConfig) { mutableStateOf(nudeConfig.tBellyExp.toString()) }
        var nudeConfirmInput by remember(nudeConfig) { mutableStateOf(nudeConfig.confirm.toString()) }

        AlertDialog(
            onDismissRequest = { showAiDebugDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BugReport, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("لوحة فحص وضبط الذكاء الاصطناعي", style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TabRow(selectedTabIndex = selectedTab) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("المجدول", fontSize = 11.sp) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("NudeNet", fontSize = 11.sp) }
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = { Text("الأنمي", fontSize = 11.sp) }
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    when (selectedTab) {
                        0 -> {
                            // Scheduler Tab
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("حالة المجدول المشترك (FrameScheduler):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("وضع العمل: ${schedulerDebugState.mode}", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                    Text("زمن دورة المعالجة الأخيرة: ${schedulerDebugState.lastWorkMs} ms", fontSize = 11.5.sp)
                                    Text("التأخير حتى الإطار القادم: ${schedulerDebugState.nextDelayMs} ms", fontSize = 11.5.sp)
                                    Text("إطارات متطابقة دون تغيير: ${schedulerDebugState.unchangedTicks}", fontSize = 11.5.sp)
                                    Text("طلقات الاشتباه المتبقية: ${schedulerDebugState.suspectLeft}", fontSize = 11.5.sp)
                                    Text("تبريد الاشتباه: ${schedulerDebugState.burstCooldown}", fontSize = 11.5.sp)
                                    Text("الإطارات الإجبارية بعد الحظر: ${schedulerDebugState.forceTicks}", fontSize = 11.5.sp)
                                    Text("مسح البلاطات معلق (Sweep): ${if (schedulerDebugState.sweepPending) "نعم" else "لا"}", fontSize = 11.5.sp)
                                }
                            }
                        }
                        1 -> {
                            // NudeNet Tab
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("القيم الحية لنموذج NudeNet (الواقعي):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("زمن الاستدلال: ${nudeDebugState.ms} ms", fontSize = 11.5.sp)
                                    Text("عدد استدلالات الإطار (Runs): ${nudeDebugState.inferences}", fontSize = 11.5.sp)
                                    Text("سجل التأكيد الزمني: ${nudeDebugState.historyCount}/${nudeDebugState.historyTotal} (المطلوب: ${nudeConfig.confirm})", fontSize = 11.5.sp)
                                    Text("تقدم مسح البلاطات: ${nudeDebugState.tilesDone} بلاطة", fontSize = 11.5.sp)
                                    Text("إشارة شبكة الصور المصغرة (Cue): ${if (nudeDebugState.cueActive) "نشطة" else "خاملة"}", fontSize = 11.5.sp)
                                    Text("إيجابي الإطار: ${if (nudeDebugState.framePositive) "نعم" else "لا"} | تفعيل الحظر: ${if (nudeDebugState.trigger) "نعم" else "لا"}", fontSize = 11.5.sp)
                                    if (nudeDebugState.summary.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("أعلى الرصدات والمخالفات:", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                        nudeDebugState.summary.take(8).forEach { s ->
                                            Text("• $s", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    } else {
                                        Text("لم ترصد أي مخالفات أو احتمالات تتجاوز 0.20", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }

                            HorizontalDivider()
                            Text("عتبات NudeNet الصريحة والفاضحة:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            OutlinedTextField(
                                value = tFemaleGenExpInput,
                                onValueChange = { tFemaleGenExpInput = it },
                                label = { Text("عورة أنثى صريحة FEMALE_GEN (0.45)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tMaleGenExpInput,
                                onValueChange = { tMaleGenExpInput = it },
                                label = { Text("عورة ذكر صريحة MALE_GEN (0.45)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tFemaleBreastExpInput,
                                onValueChange = { tFemaleBreastExpInput = it },
                                label = { Text("صدر أنثى عارٍ BREAST_EXPOSED (0.50)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tAnusExpInput,
                                onValueChange = { tAnusExpInput = it },
                                label = { Text("دبر مكشوف ANUS_EXPOSED (0.50)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tButtExpInput,
                                onValueChange = { tButtExpInput = it },
                                label = { Text("مؤخرة مكشوفة مع جسم BUTTOCKS (0.60)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tButtIsolatedInput,
                                onValueChange = { tButtIsolatedInput = it },
                                label = { Text("مؤخرة معزولة بدون مؤشرات بشرية (0.80)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = strongInput,
                                onValueChange = { strongInput = it },
                                label = { Text("عتبة الحظر الفوري بلقطة واحدة (0.75)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = strongButtInput,
                                onValueChange = { strongButtInput = it },
                                label = { Text("حظر فوري مؤخرة صريحة (0.85)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("تفعيل قاعدة البيكيني والملابس الفاضحة (S1)", fontSize = 11.5.sp)
                                Switch(
                                    checked = sexyEnabledState,
                                    onCheckedChange = { sexyEnabledState = it }
                                )
                            }
                            OutlinedTextField(
                                value = tBreastCovInput,
                                onValueChange = { tBreastCovInput = it },
                                label = { Text("بيكيني/ملابس داخلية علوية (0.55)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tLowerCovInput,
                                onValueChange = { tLowerCovInput = it },
                                label = { Text("بيكيني/ملابس داخلية سفلية (0.55)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tBellyExpInput,
                                onValueChange = { tBellyExpInput = it },
                                label = { Text("بطن عارٍ مقترن بالبيكيني (0.45)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = nudeConfirmInput,
                                onValueChange = { nudeConfirmInput = it },
                                label = { Text("إطارات التأكيد من آخر 3 (2)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.resetNudeConfigToDefaults()
                                        showAiDebugDialog = false
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("استعادة الافتراضيات", fontSize = 11.sp)
                                }
                                Button(
                                    onClick = {
                                        val newCfg = nudeConfig.copy(
                                            tFemaleGenExp = tFemaleGenExpInput.toFloatOrNull() ?: nudeConfig.tFemaleGenExp,
                                            tMaleGenExp = tMaleGenExpInput.toFloatOrNull() ?: nudeConfig.tMaleGenExp,
                                            tAnusExp = tAnusExpInput.toFloatOrNull() ?: nudeConfig.tAnusExp,
                                            tFemaleBreastExp = tFemaleBreastExpInput.toFloatOrNull() ?: nudeConfig.tFemaleBreastExp,
                                            tButtExp = tButtExpInput.toFloatOrNull() ?: nudeConfig.tButtExp,
                                            tButtIsolated = tButtIsolatedInput.toFloatOrNull() ?: nudeConfig.tButtIsolated,
                                            strong = strongInput.toFloatOrNull() ?: nudeConfig.strong,
                                            strongButt = strongButtInput.toFloatOrNull() ?: nudeConfig.strongButt,
                                            sexyEnabled = sexyEnabledState,
                                            tBreastCov = tBreastCovInput.toFloatOrNull() ?: nudeConfig.tBreastCov,
                                            tLowerCov = tLowerCovInput.toFloatOrNull() ?: nudeConfig.tLowerCov,
                                            tBellyExp = tBellyExpInput.toFloatOrNull() ?: nudeConfig.tBellyExp,
                                            confirm = nudeConfirmInput.toIntOrNull() ?: nudeConfig.confirm
                                        )
                                        viewModel.updateNudeConfig(newCfg)
                                        showAiDebugDialog = false
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("حفظ NudeNet", fontSize = 11.sp)
                                }
                            }
                        }
                        2 -> {
                            // Anime Tab
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("القيم الحية لنموذج الأنمي MobileNetV3:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("زمن الاستدلال: ${animeDebugState.inferenceMs} ms", fontSize = 11.5.sp)
                                    Text("عدد النوافذ المفحوصة: ${animeDebugState.windowCount}", fontSize = 11.5.sp)
                                    Text("سجل التأكيد الزمني: ${animeDebugState.historyCount}/${animeDebugState.historyTotal} (المطلوب: ${animeConfig.confirm})", fontSize = 11.5.sp)
                                    Text("مخالفة الإطار: ${if (animeDebugState.framePositive) "نعم" else "لا"} | تفعيل الحظر: ${if (animeDebugState.trigger) "نعم" else "لا"}", fontSize = 11.5.sp)
                                    if (animeDebugState.probs.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("احتمالات النوافذ [Safe, R15, R18]:", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                        for (idx in animeDebugState.probs.indices) {
                                            val p = animeDebugState.probs[idx]
                                            val safe = (p.getOrElse(0) { 0f } * 100).toInt()
                                            val r15 = (p.getOrElse(1) { 0f } * 100).toInt()
                                            val r18 = (p.getOrElse(2) { 0f } * 100).toInt()
                                            Text("نافذة #${idx + 1}: آمن=${safe}% | r15=${r15}% | r18=${r18}%", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    } else {
                                        Text("لم يتم فحص إطارات أنمي بعد أو الإطار الحالي متطابق/فارغ", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }

                            HorizontalDivider()
                            Text("عتبات الأنمي في وقت التشغيل (Runtime):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            OutlinedTextField(
                                value = tr18Input,
                                onValueChange = { tr18Input = it },
                                label = { Text("عتبة r18 هينتاي وعري (0.90)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tr15Input,
                                onValueChange = { tr15Input = it },
                                label = { Text("عتبة r15 أنمي كاشف ومثير (0.88)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = tSumInput,
                                onValueChange = { tSumInput = it },
                                label = { Text("عتبة المجموع r15+r18 (0.95)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = animeConfirmInput,
                                onValueChange = { animeConfirmInput = it },
                                label = { Text("إطارات التأكيد من آخر 3 (2)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.resetAnimeConfigToDefaults()
                                        showAiDebugDialog = false
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("استعادة الافتراضيات", fontSize = 11.sp)
                                }
                                Button(
                                    onClick = {
                                        val newCfg = animeConfig.copy(
                                            tR18 = tr18Input.toFloatOrNull() ?: animeConfig.tR18,
                                            tR15 = tr15Input.toFloatOrNull() ?: animeConfig.tR15,
                                            tSum = tSumInput.toFloatOrNull() ?: animeConfig.tSum,
                                            confirm = animeConfirmInput.toIntOrNull() ?: animeConfig.confirm
                                        )
                                        viewModel.updateAnimeConfig(newCfg)
                                        showAiDebugDialog = false
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("حفظ الأنمي", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAiDebugDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

}

@Composable
private fun PermissionCardItem(
    title: String,
    isEnabled: Boolean,
    isPermanentlyLocked: Boolean = false,
    onClick: () -> Unit
) {
    GlassBentoCard(
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            val isDark = isSystemInDarkTheme()
            val primaryBlue = Color(0xFF0166FF)

            val badgeBgColor = when {
                isEnabled -> primaryBlue
                isPermanentlyLocked -> if (isDark) Color(0xFF2A2E39) else Color(0xFFF1F5F9)
                else -> if (isDark) Color(0xFF2A2D33) else Color.White
            }
            val badgeTextColor = when {
                isEnabled -> Color.White
                isPermanentlyLocked -> if (isDark) Color(0xFF94A3B8) else Color(0xFF475569)
                else -> if (isDark) Color(0xFFE5E7EB) else Color(0xFF1E2024)
            }
            val badgeBorder = when {
                isEnabled -> null
                isPermanentlyLocked -> BorderStroke(1.dp, if (isDark) Color(0xFF3F444E) else Color(0xFFE2E8F0))
                else -> BorderStroke(1.dp, if (isDark) Color(0xFF3F444E) else Color(0xFFD1D5DB))
            }

            Surface(
                color = badgeBgColor,
                shape = RoundedCornerShape(20.dp),
                border = badgeBorder
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    if (isPermanentlyLocked) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Locked",
                            modifier = Modifier.size(12.dp),
                            tint = badgeTextColor
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = if (isEnabled) "Active" else "Grant",
                        style = MaterialTheme.typography.labelSmall,
                        color = badgeTextColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BedtimeTimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    title: String,
    onDismiss: () -> Unit,
    onTimeSelected: (hour: Int, minute: Int) -> Unit
) {
    val timePickerState = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = true
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .wrapContentWidth()
                    .wrapContentHeight()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    TimePicker(
                        state = timePickerState,
                        colors = TimePickerDefaults.colors(
                            clockDialColor = MaterialTheme.colorScheme.surfaceVariant,
                            clockDialSelectedContentColor = MaterialTheme.colorScheme.onPrimary,
                            clockDialUnselectedContentColor = MaterialTheme.colorScheme.onSurface,
                            selectorColor = MaterialTheme.colorScheme.primary,
                            periodSelectorBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            periodSelectorSelectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            periodSelectorSelectedContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            periodSelectorUnselectedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            periodSelectorUnselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            timeSelectorSelectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            timeSelectorSelectedContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            timeSelectorUnselectedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            timeSelectorUnselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                onTimeSelected(timePickerState.hour, timePickerState.minute)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("تأكيد", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BedtimeAllowedAppsDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    LaunchedEffect(Unit) {
        viewModel.loadFilteredAppsForBedtime()
    }

    val filteredApps by viewModel.filteredAppsForBedtime.collectAsState()
    val allowedApps by viewModel.bedtimeAllowedApps.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var filterCategory by remember { mutableStateOf("ALL") }

    val context = androidx.compose.ui.platform.LocalContext.current
    val completeAppsList = remember(filteredApps, allowedApps) {
        val existingPkgSet = filteredApps.map { it.packageName }.toSet()
        val missingPkgs = allowedApps.filter { !existingPkgSet.contains(it) }
        if (missingPkgs.isEmpty()) {
            filteredApps
        } else {
            val synthesized = missingPkgs.map { pkg ->
                val label = com.example.util.AppListHelper.resolveAppLabelFast(context, pkg)
                val icon = com.example.util.AppListHelper.resolveIconFast(context, pkg)
                com.example.util.AppInfoItem(
                    packageName = pkg,
                    appName = label,
                    icon = icon,
                    isSystemApp = false,
                    isAllowed = true
                )
            }
            filteredApps + synthesized
        }
    }

    val displayedList = remember(completeAppsList, searchQuery, filterCategory, allowedApps) {
        val searchFiltered = completeAppsList.filter { app ->
            val matchesSearch = searchQuery.isBlank() ||
                    app.appName.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)
            val matchesCategory = when (filterCategory) {
                "USER" -> !app.isSystemApp
                "SYSTEM" -> app.isSystemApp
                "ALLOWED" -> allowedApps.contains(app.packageName)
                else -> true
            }
            matchesSearch && matchesCategory
        }
        // Selected / Allowed apps ALWAYS come first, then user apps, then system apps, then alphabetical
        searchFiltered.sortedWith(
            compareByDescending<com.example.util.AppInfoItem> { allowedApps.contains(it.packageName) }
                .thenBy { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Clean Header with Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "التطبيقات المسموحة أثناء النوم (${allowedApps.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن تطبيق أو حزمة...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "مسح",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Filter Tabs (Spanning 100% width cleanly with no clipped edges)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val categories = listOf(
                        "ALL" to "الكل (${completeAppsList.size})",
                        "USER" to "المثبتة (${completeAppsList.count { !it.isSystemApp }})",
                        "SYSTEM" to "النظام (${completeAppsList.count { it.isSystemApp }})",
                        "ALLOWED" to "المسموحة (${allowedApps.size})"
                    )
                    categories.forEach { (key, label) ->
                        val isSelected = filterCategory == key
                        Surface(
                            onClick = { filterCategory = key },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 2.dp)
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // App List
                if (displayedList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.SearchOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "لا توجد نتائج مطابقة",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(displayedList, key = { it.packageName }) { appItem ->
                            val isChecked = allowedApps.contains(appItem.packageName)
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                border = if (isChecked) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)) else null,
                                onClick = {
                                    viewModel.toggleBedtimeAllowedApp(appItem.packageName)
                                }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // App Icon
                                    val bedtimeIconPainter = rememberFastDrawablePainter(appItem.icon)
                                    if (bedtimeIconPainter != null) {
                                        Image(
                                            painter = bedtimeIconPainter,
                                            contentDescription = null,
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                        )
                                    } else {
                                        Surface(
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.size(40.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Default.Apps,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = appItem.appName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = appItem.packageName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = {
                                            viewModel.toggleBedtimeAllowedApp(appItem.packageName)
                                        },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = MaterialTheme.colorScheme.primary,
                                            checkmarkColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KeywordExemptionAppsDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    LaunchedEffect(Unit) {
        viewModel.loadFilteredAppsForKeywordExemption()
    }

    val filteredApps by viewModel.filteredAppsForKeywordExemption.collectAsState()
    val exemptedApps by viewModel.keywordExemptedApps.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var filterCategory by remember { mutableStateOf("ALL") }

    val context = androidx.compose.ui.platform.LocalContext.current
    val completeAppsList = remember(filteredApps, exemptedApps) {
        val existingPkgSet = filteredApps.map { it.packageName }.toSet()
        val missingPkgs = exemptedApps.filter { !existingPkgSet.contains(it) }
        if (missingPkgs.isEmpty()) {
            filteredApps
        } else {
            val synthesized = missingPkgs.map { pkg ->
                val label = com.example.util.AppListHelper.resolveAppLabelFast(context, pkg)
                val icon = com.example.util.AppListHelper.resolveIconFast(context, pkg)
                com.example.util.AppInfoItem(
                    packageName = pkg,
                    appName = label,
                    icon = icon,
                    isSystemApp = false,
                    isAllowed = false
                )
            }
            filteredApps + synthesized
        }
    }

    val displayedList = remember(completeAppsList, searchQuery, filterCategory, exemptedApps) {
        val searchFiltered = completeAppsList.filter { app ->
            val matchesSearch = searchQuery.isBlank() ||
                    app.appName.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)
            val matchesCategory = when (filterCategory) {
                "USER" -> !app.isSystemApp
                "SYSTEM" -> app.isSystemApp
                "EXEMPTED" -> exemptedApps.contains(app.packageName)
                else -> true
            }
            matchesSearch && matchesCategory
        }
        searchFiltered.sortedWith(
            compareByDescending<com.example.util.AppInfoItem> { exemptedApps.contains(it.packageName) }
                .thenBy { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    // Clean Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "استثناء التطبيقات من الكلمات المحظورة (${exemptedApps.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Search Box
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("بحث عن تطبيق أو حزمة...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "مسح",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Category Filter Tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val categories = listOf(
                            "ALL" to "الكل (${completeAppsList.size})",
                            "USER" to "المثبتة (${completeAppsList.count { !it.isSystemApp }})",
                            "SYSTEM" to "النظام (${completeAppsList.count { it.isSystemApp }})",
                            "EXEMPTED" to "المستثناة (${exemptedApps.size})"
                        )
                        categories.forEach { (key, label) ->
                            val isSelected = filterCategory == key
                            Surface(
                                onClick = { filterCategory = key },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 2.dp)
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        textAlign = TextAlign.Center,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Action Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = ErrorRed.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(20.dp),
                            onClick = {
                                if (filterCategory == "ALL" && searchQuery.isBlank()) {
                                    viewModel.clearAllKeywordExemptedApps()
                                } else {
                                    val currentDisplayedPkgs = displayedList.map { it.packageName }.toSet()
                                    viewModel.setKeywordExemptedApps(exemptedApps - currentDisplayedPkgs)
                                }
                            }
                        ) {
                            Text(
                                text = "إلغاء المعروض",
                                color = ErrorRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(20.dp),
                            onClick = {
                                val displayedPkgSet = displayedList.map { it.packageName }.toSet()
                                viewModel.setKeywordExemptedApps(exemptedApps + displayedPkgSet)
                            }
                        ) {
                            Text(
                                text = "تحديد المعروض (${displayedList.size})",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // App List
                    if (displayedList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.SearchOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "لا توجد نتائج مطابقة",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(displayedList, key = { it.packageName }) { appItem ->
                                val isChecked = exemptedApps.contains(appItem.packageName)
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(12.dp),
                                    onClick = {
                                        viewModel.toggleKeywordExemptedApp(appItem.packageName)
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // App Icon
                                        val iconPainter = rememberFastDrawablePainter(appItem.icon)
                                        if (iconPainter != null) {
                                            Image(
                                                painter = iconPainter,
                                                contentDescription = null,
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                            )
                                        } else {
                                            Surface(
                                                color = MaterialTheme.colorScheme.primaryContainer,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.size(40.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        imageVector = Icons.Default.Apps,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = appItem.appName,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = appItem.packageName,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = {
                                                viewModel.toggleKeywordExemptedApp(appItem.packageName)
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = MaterialTheme.colorScheme.primary,
                                                checkmarkColor = MaterialTheme.colorScheme.onPrimary
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GrayscaleHardwareSetupDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isHardwareGranted by viewModel.isHardwareGrayscaleGranted.collectAsState()
    val adbCommand = remember { viewModel.getAdbCommandForGrayscale() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header Icon
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            if (isHardwareGranted) SuccessGreen.copy(alpha = 0.12f)
                            else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isHardwareGranted) Icons.Default.CheckCircle else Icons.Default.InvertColors,
                        contentDescription = null,
                        tint = if (isHardwareGranted) SuccessGreen else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Text(
                    text = "عتاد تحويل الشاشة (Realme 10 / Android 14)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                // Current Status Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = if (isHardwareGranted) SuccessGreen.copy(alpha = 0.1f)
                    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (isHardwareGranted) Icons.Default.Verified else Icons.Default.Info,
                            contentDescription = null,
                            tint = if (isHardwareGranted) SuccessGreen else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isHardwareGranted) "صلاحية عتاد النظام مفعّلة بالكامل"
                                else "طبقة العرض الذكية تعمل تلقائياً",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isHardwareGranted) "يتم تحويل كل بكسل في الشاشة إلى أبيض وأسود عبر معالج الرسوميات (GPU)."
                                else "الشاشة تتحول للأبيض والأسود بدون أي متطلبات. ولتحويل عتاد النظام كاملاً يمكنك استخدام كود ADB أدناه.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Guide for Realme / Android 14
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "خطوات تفعيل عتاد النظام لهاتف Realme 10:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "1. من الإعدادات > خيارات المطور > فعّل (تصحيح أخطاء USB) و (تصحيح أخطاء USB - إعدادات الأمان).\n2. نفّذ الأمر التالي عبر الكمبيوتر أو تطبيق Shizuku:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )

                    // ADB Command Box
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = adbCommand,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    val clip = android.content.ClipData.newPlainText("ADB Command", adbCommand)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "تم نسخ أمر ADB بنجاح", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "نسخ",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            viewModel.refreshGrayscalePermissionState()
                            Toast.makeText(context, "تم تحديث حالة الفحص", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إعادة فحص", style = MaterialTheme.typography.labelMedium)
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("حسناً", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}