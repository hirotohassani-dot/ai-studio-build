package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.model.DiaryMediaItem
import com.example.model.DiaryMediaSource
import com.example.model.DiaryMediaType
import com.example.model.RecoveryJourneyMilestone
import com.example.util.SaffahMediaCompressor
import com.example.util.SaffahMilestoneMediaRepository
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import java.util.UUID

/**
 * نافذة تفاصيل محطة التعافي بتصميم Bento UI دافئ واحترافي خالٍ تماماً من الإيموجيات
 * تتيح تسجيل وتشغيل وإعادة تسمية وحذف تسجيلات الصوت والفيديو فائقة النقاء وعالية الضغط للمحطات المفتوحة
 */
@Composable
fun MilestoneDetailsDialog(
    milestone: RecoveryJourneyMilestone,
    userName: String,
    currentStreakDays: Int,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val isAchieved = currentStreakDays >= milestone.day
    val isLocked = !isAchieved

    // تجهيز اسم المستخدم أو اللقب الافتراضي
    val effectiveName = if (userName.isNotBlank()) userName else "يا بطل"
    val personalizedMotivation = milestone.motivationalQuoteTemplate.replace("%s", effectiveName)

    val biomeColor = Color(milestone.biome.primaryColorHex)
    val biomeSecondary = Color(milestone.biome.secondaryColorHex)

    // قائمة وسائط المحطة المحفوظة
    var milestoneMediaList by remember {
        mutableStateOf(SaffahMilestoneMediaRepository.getMediaForMilestone(context, milestone.day))
    }

    // Audio recording state
    var isAudioRecording by remember { mutableStateOf(false) }
    var recordingDurationSec by remember { mutableIntStateOf(0) }
    var recordingFile by remember { mutableStateOf<File?>(null) }

    // Video recording state
    var tempVideoFile by remember { mutableStateOf<File?>(null) }
    var tempVideoUri by remember { mutableStateOf<Uri?>(null) }

    // Dialog state for renaming, video playing, and deletion confirmation
    var mediaItemToRename by remember { mutableStateOf<DiaryMediaItem?>(null) }
    var selectedVideoForPlay by remember { mutableStateOf<DiaryMediaItem?>(null) }
    var mediaItemToDelete by remember { mutableStateOf<DiaryMediaItem?>(null) }

    // Audio recording timer loop
    LaunchedEffect(isAudioRecording) {
        if (isAudioRecording) {
            recordingDurationSec = 0
            while (isActive && isAudioRecording) {
                delay(1000L)
                recordingDurationSec++
            }
        }
    }

    // Launchers
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val audioFile = SaffahMilestoneMediaRepository.createMilestoneAudioFile(context, milestone.day)
            recordingFile = audioFile
            if (viewModel.audioRecorder.startRecording(audioFile)) {
                isAudioRecording = true
                recordingDurationSec = 0
            } else {
                viewModel.showFeedback("تعذر بدء التسجيل الصوتي")
            }
        } else {
            viewModel.showFeedback("يرجى منح صلاحية الميكروفون لتسجيل الصوت")
        }
    }

    val videoCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { isSuccess ->
        if (isSuccess && tempVideoFile != null && tempVideoFile!!.exists() && tempVideoFile!!.length() > 0) {
            coroutineScope.launch(Dispatchers.IO) {
                withContext(Dispatchers.Main) {
                    viewModel.showFeedback("جاري معالجة وتأمين الفيديو...")
                }
                val compressedVideo = SaffahMediaCompressor.compressVideoFile(tempVideoFile!!)
                var durationSec = 0
                try {
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(compressedVideo.absolutePath)
                    val durStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                    retriever.release()
                    durationSec = ((durStr?.toLongOrNull() ?: 0L) / 1000L).toInt()
                } catch (_: Exception) {}

                val videoItem = DiaryMediaItem(
                    id = UUID.randomUUID().toString(),
                    type = DiaryMediaType.VIDEO,
                    source = DiaryMediaSource.RECORDED_IN_APP,
                    filePath = compressedVideo.absolutePath,
                    fileName = "فيديو المحطة ${milestone.stationNumber}",
                    durationSeconds = durationSec,
                    fileSizeBytes = compressedVideo.length(),
                    createdAt = System.currentTimeMillis()
                )
                SaffahMilestoneMediaRepository.addMediaToMilestone(context, milestone.day, videoItem)
                withContext(Dispatchers.Main) {
                    milestoneMediaList = SaffahMilestoneMediaRepository.getMediaForMilestone(context, milestone.day)
                    viewModel.showFeedback("تم تأمين وحفظ الفيديو بنجاح")
                }
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val vFile = SaffahMilestoneMediaRepository.createMilestoneVideoFile(context, milestone.day)
            tempVideoFile = vFile
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", vFile)
            tempVideoUri = uri
            videoCaptureLauncher.launch(uri)
        } else {
            viewModel.showFeedback("يرجى منح صلاحية الكاميرا لتسجيل الفيديو")
        }
    }

    var isDialogVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isDialogVisible = true
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = {
                if (isAudioRecording) {
                    viewModel.audioRecorder.stopRecording()
                    isAudioRecording = false
                }
                viewModel.audioPlayer.stopAudio()
                onDismiss()
            },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            AnimatedVisibility(
                visible = isDialogVisible,
                enter = SaffahMotion.dialogPopEntrance(initialScale = 0.90f)
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.94f)
                        .fillMaxHeight(0.90f),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.5.dp, biomeColor.copy(alpha = 0.6f)),
                    shadowElevation = 12.dp
                ) {
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // ==========================================
                    // 1. TOP HEADER BANNER WITH BIOME GRADIENT
                    // ==========================================
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        biomeColor.copy(alpha = 0.95f),
                                        biomeSecondary.copy(alpha = 0.85f)
                                    )
                                )
                            )
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    color = Color.White.copy(alpha = 0.22f),
                                    shape = CircleShape,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isAchieved) Icons.Default.WorkspacePremium else Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier
                                            .padding(9.dp)
                                            .size(24.dp)
                                    )
                                }

                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "المحطة ${milestone.stationNumber}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Surface(
                                            color = if (isAchieved) Color.White else Color.Black.copy(alpha = 0.25f),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = if (isAchieved) "تم الإنجاز" else "مقفلة",
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isAchieved) biomeSecondary else Color.White
                                            )
                                        }
                                    }

                                    Text(
                                        text = "${milestone.day} يوماً • ${milestone.durationLabel}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                }
                            }

                            IconButton(
                                onClick = {
                                    if (isAudioRecording) {
                                        viewModel.audioRecorder.stopRecording()
                                        isAudioRecording = false
                                    }
                                    viewModel.audioPlayer.stopAudio()
                                    onDismiss()
                                },
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                    .size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // ==========================================
                    // 2. SCROLLABLE DETAILS CONTENT
                    // ==========================================
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Title Card
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = milestone.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "البيئة: ${milestone.biome.arabicName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = biomeColor,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // ==========================================
                        // MEDIA RECORDING & PLAYBACK SECTION (Bento UI)
                        // يظهر للمحطات المنجزة والمفتوحة
                        // ==========================================
                        if (isAchieved) {
                            val audioList = remember(milestoneMediaList) {
                                milestoneMediaList.filter { it.type == DiaryMediaType.AUDIO }
                            }
                            val videoList = remember(milestoneMediaList) {
                                milestoneMediaList.filter { it.type == DiaryMediaType.VIDEO }
                            }

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Header
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Mic,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Text(
                                                text = "توثيق المحطة (صوت وفيديو)",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }

                                        if (milestoneMediaList.isNotEmpty()) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                            ) {
                                                Text(
                                                    text = "${milestoneMediaList.size} تسجيل",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    // Action Bar: Record Audio & Record Video Buttons
                                    if (isAudioRecording) {
                                        // Recording in progress banner
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = Color(0xFFDC2626).copy(alpha = 0.10f),
                                            border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.35f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(10.dp)
                                                            .background(Color(0xFFDC2626), CircleShape)
                                                    )
                                                    Text(
                                                        text = "جاري التسجيل: ${formatDuration(recordingDurationSec)}",
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFDC2626)
                                                    )
                                                }

                                                Button(
                                                    onClick = {
                                                        val file = viewModel.audioRecorder.stopRecording()
                                                        isAudioRecording = false
                                                        if (file != null && file.exists() && file.length() > 0) {
                                                            val audioItem = DiaryMediaItem(
                                                                id = UUID.randomUUID().toString(),
                                                                type = DiaryMediaType.AUDIO,
                                                                source = DiaryMediaSource.RECORDED_IN_APP,
                                                                filePath = file.absolutePath,
                                                                fileName = "تسجيل صوتي للمحطة ${milestone.stationNumber}",
                                                                durationSeconds = recordingDurationSec,
                                                                fileSizeBytes = file.length(),
                                                                createdAt = System.currentTimeMillis()
                                                            )
                                                            SaffahMilestoneMediaRepository.addMediaToMilestone(context, milestone.day, audioItem)
                                                            milestoneMediaList = SaffahMilestoneMediaRepository.getMediaForMilestone(context, milestone.day)
                                                            viewModel.showFeedback("تم حفظ التسجيل الصوتي بنجاح")
                                                        }
                                                    },
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = Color(0xFFDC2626),
                                                        contentColor = Color.White
                                                    ),
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Stop,
                                                        contentDescription = "إنهاء التسجيل",
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "حفظ التسجيل",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    } else {
                                        // Two action chips: Record Audio & Record Video
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // زر تسجيل صوت فائق النقاء
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .clickable {
                                                        val hasPerm = ContextCompat.checkSelfPermission(
                                                            context,
                                                            Manifest.permission.RECORD_AUDIO
                                                        ) == PackageManager.PERMISSION_GRANTED

                                                        if (hasPerm) {
                                                            val audioFile = SaffahMilestoneMediaRepository.createMilestoneAudioFile(context, milestone.day)
                                                            recordingFile = audioFile
                                                            if (viewModel.audioRecorder.startRecording(audioFile)) {
                                                                isAudioRecording = true
                                                                recordingDurationSec = 0
                                                            } else {
                                                                viewModel.showFeedback("تعذر بدء التسجيل الصوتي")
                                                            }
                                                        } else {
                                                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                        }
                                                    },
                                                shape = RoundedCornerShape(12.dp),
                                                color = Color(0xFF16A34A).copy(alpha = 0.10f),
                                                border = BorderStroke(1.dp, Color(0xFF16A34A).copy(alpha = 0.30f))
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Mic,
                                                        contentDescription = null,
                                                        tint = Color(0xFF16A34A),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "تسجيل صوت",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF16A34A),
                                                        fontSize = 12.sp
                                                    )
                                                }
                                            }

                                            // زر تسجيل فيديو مضغوط وعالي الدقة
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .clickable {
                                                        val hasPerm = ContextCompat.checkSelfPermission(
                                                            context,
                                                            Manifest.permission.CAMERA
                                                        ) == PackageManager.PERMISSION_GRANTED

                                                        if (hasPerm) {
                                                            val vFile = SaffahMilestoneMediaRepository.createMilestoneVideoFile(context, milestone.day)
                                                            tempVideoFile = vFile
                                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", vFile)
                                                            tempVideoUri = uri
                                                            videoCaptureLauncher.launch(uri)
                                                        } else {
                                                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                                        }
                                                    },
                                                shape = RoundedCornerShape(12.dp),
                                                color = Color(0xFFEA580C).copy(alpha = 0.10f),
                                                border = BorderStroke(1.dp, Color(0xFFEA580C).copy(alpha = 0.30f))
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Videocam,
                                                        contentDescription = null,
                                                        tint = Color(0xFFEA580C),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "تسجيل فيديو",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFEA580C),
                                                        fontSize = 12.sp
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // Display Audio Capsules
                                    if (audioList.isNotEmpty()) {
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "التسجيلات الصوتية (${audioList.size}):",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )

                                            audioList.forEach { media ->
                                                MilestoneAudioItemCapsule(
                                                    viewModel = viewModel,
                                                    media = media,
                                                    onRename = { mediaItemToRename = media },
                                                    onDelete = { mediaItemToDelete = media }
                                                )
                                            }
                                        }
                                    }

                                    // Display Video Cards
                                    if (videoList.isNotEmpty()) {
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "مقاطع الفيديو (${videoList.size}):",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )

                                            videoList.forEach { video ->
                                                MilestoneVideoItemCard(
                                                    video = video,
                                                    onPlay = { selectedVideoForPlay = video },
                                                    onRename = { mediaItemToRename = video },
                                                    onDelete = { mediaItemToDelete = video }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Personalized Motivational Message
                        Surface(
                            color = biomeColor.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, biomeColor.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FormatQuote,
                                    contentDescription = null,
                                    tint = biomeColor,
                                    modifier = Modifier.size(28.dp)
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "رسالة المحطة",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = biomeColor
                                    )
                                    Text(
                                        text = personalizedMotivation,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }

                        // Positive Changes Section (التغيرات الإيجابية)
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoGraph,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "التغيرات الإيجابية والفسيولوجية",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            milestone.positiveChanges.forEach { change ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.Top,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Surface(
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = change.category,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        Text(
                                            text = change.details,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }

                        // Symptoms and Adaptation Challenges (الأعراض الحقيقية والتحديات)
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WarningAmber,
                                    contentDescription = null,
                                    tint = Color(0xFFF59E0B),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "الأعراض والتحديات المتوقعة في هذه المرحلة",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            milestone.symptomsAndWithdrawal.forEach { symptom ->
                                Surface(
                                    color = Color(0xFFF59E0B).copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.2f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(Color(0xFFF59E0B), CircleShape)
                                        )
                                        Text(
                                            text = symptom,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        // Scientific Note Section
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = "إضاءة عصبية وعلمية",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = milestone.scientificNote,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }

                    // ==========================================
                    // 3. BOTTOM CLOSE ACTION BUTTON
                    // ==========================================
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shadowElevation = 4.dp
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (isAudioRecording) {
                                        viewModel.audioRecorder.stopRecording()
                                        isAudioRecording = false
                                    }
                                    viewModel.audioPlayer.stopAudio()
                                    onDismiss()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = biomeColor,
                                    contentColor = Color.White
                                )
                            ) {
                                Text(
                                    text = "فهمت واستمر في الثبات",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

    // نافذة تعديل اسم ملف الصوت أو الفيديو
    mediaItemToRename?.let { item ->
        RenameMilestoneMediaDialog(
            initialName = item.fileName,
            onDismiss = { mediaItemToRename = null },
            onConfirm = { updatedName ->
                SaffahMilestoneMediaRepository.renameMediaInMilestone(context, milestone.day, item.id, updatedName)
                milestoneMediaList = SaffahMilestoneMediaRepository.getMediaForMilestone(context, milestone.day)
                mediaItemToRename = null
                viewModel.showFeedback("تم تحديث اسم الملف بنجاح")
            }
        )
    }

    // نافذة تأكيد حذف التسجيل
    mediaItemToDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { mediaItemToDelete = null },
            title = {
                Text(
                    text = "حذف التسجيل",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف \"${item.fileName.ifBlank { "هذا التسجيل" }}\"؟ يمكنك تسجيل مقطع جديد بعد الحذف.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (viewModel.audioPlayer.playbackState.value.currentFilePath == item.filePath) {
                            viewModel.audioPlayer.stopAudio()
                        }
                        SaffahMilestoneMediaRepository.deleteMediaFromMilestone(context, milestone.day, item.id)
                        milestoneMediaList = SaffahMilestoneMediaRepository.getMediaForMilestone(context, milestone.day)
                        mediaItemToDelete = null
                        viewModel.showFeedback("تم حذف التسجيل بنجاح")
                    },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("حذف نهائي", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { mediaItemToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة مشغل الفيديو المنبثق
    selectedVideoForPlay?.let { videoItem ->
        MilestoneVideoPlayerDialog(
            videoItem = videoItem,
            onDismiss = { selectedVideoForPlay = null }
        )
    }
}

/**
 * كبسولة مشغل صوتي أنيقة ومضغوطة بتصميم مذكرات التعافي مع أزرار التشغيل، التمرير، تعديل الاسم، والحذف
 */
@Composable
private fun MilestoneAudioItemCapsule(
    viewModel: MainViewModel,
    media: DiaryMediaItem,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val playbackState by viewModel.audioPlayer.playbackState.collectAsState()
    val isPlayingThis = playbackState.isPlaying && playbackState.currentFilePath == media.filePath
    val isLoadedThis = playbackState.currentFilePath == media.filePath
    val sourceTint = Color(0xFF16A34A)

    LaunchedEffect(isPlayingThis) {
        if (isPlayingThis) {
            while (isActive) {
                delay(250L)
                viewModel.audioPlayer.updateProgress()
            }
        }
    }

    val currentMs = if (isLoadedThis) playbackState.currentPositionMs else 0
    val totalMs = if (isLoadedThis && playbackState.durationMs > 0) playbackState.durationMs else (media.durationSeconds * 1000)
    val progress = if (totalMs > 0) (currentMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f

    var isSeeking by remember { mutableStateOf(false) }
    var seekProgress by remember { mutableFloatStateOf(0f) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, sourceTint.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            // السطر العلوي: اسم الملف + الحجم + تعديل + حذف
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = media.fileName.ifBlank { "تسجيل صوتي للمحطة" },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val sizeStr = formatFileSize(media.fileSizeBytes)
                    if (sizeStr.isNotBlank()) {
                        Text(
                            text = sizeStr,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                    }

                    // زر تعديل الاسم
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                            .clickable { onRename() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = "تعديل الاسم",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(13.dp)
                        )
                    }

                    // زر الحذف
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f))
                            .clickable { onDelete() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Delete,
                            contentDescription = "حذف التسجيل",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // السطر السفلي: زر التشغيل + شريط التمرير + العداد
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(sourceTint)
                        .clickable { viewModel.audioPlayer.playAudio(media.filePath) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlayingThis) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlayingThis) "إيقاف مؤقت" else "تشغيل",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                MilestoneAudioProgressBar(
                    progress = if (isSeeking) seekProgress else progress,
                    onSeek = {
                        isSeeking = true
                        seekProgress = it
                    },
                    onSeekFinished = { finalFraction ->
                        isSeeking = false
                        if (totalMs > 0) {
                            val targetMs = (finalFraction * totalMs).toInt()
                            if (isLoadedThis) {
                                viewModel.audioPlayer.seekTo(targetMs)
                            } else {
                                viewModel.audioPlayer.playAudio(media.filePath)
                                viewModel.audioPlayer.seekTo(targetMs)
                            }
                        }
                    },
                    activeColor = sourceTint,
                    inactiveColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                val displayCurrentSec = if (isSeeking) (seekProgress * totalMs / 1000).toInt() else (currentMs / 1000)
                Text(
                    text = "${formatDuration(displayCurrentSec)} / ${formatDuration(totalMs / 1000)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
            }
        }
    }
}

/**
 * شريط تقدم صوتي تفاعلي متطابق مع تصميم مذكرات التعافي
 */
@Composable
private fun MilestoneAudioProgressBar(
    progress: Float,
    onSeek: (Float) -> Unit,
    onSeekFinished: (Float) -> Unit,
    activeColor: Color,
    inactiveColor: Color,
    modifier: Modifier = Modifier
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragProgress by remember { mutableFloatStateOf(0f) }
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl

    val currentProgress = if (isDragging) dragProgress else progress.coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .pointerInput(isRtl) {
                detectTapGestures(
                    onPress = { offset ->
                        val w = size.width.toFloat()
                        if (w > 0) {
                            val rawFraction = (offset.x / w).coerceIn(0f, 1f)
                            val fraction = if (isRtl) (1f - rawFraction) else rawFraction
                            isDragging = true
                            dragProgress = fraction
                            onSeek(fraction)
                            val released = tryAwaitRelease()
                            isDragging = false
                            if (released) {
                                onSeekFinished(dragProgress)
                            }
                        }
                    }
                )
            }
            .pointerInput(isRtl) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        val w = size.width.toFloat()
                        if (w > 0) {
                            val rawFraction = (offset.x / w).coerceIn(0f, 1f)
                            val fraction = if (isRtl) (1f - rawFraction) else rawFraction
                            isDragging = true
                            dragProgress = fraction
                            onSeek(fraction)
                        }
                    },
                    onDragEnd = {
                        isDragging = false
                        onSeekFinished(dragProgress)
                    },
                    onDragCancel = {
                        isDragging = false
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val w = size.width.toFloat()
                        if (w > 0) {
                            val rawFraction = (change.position.x / w).coerceIn(0f, 1f)
                            val fraction = if (isRtl) (1f - rawFraction) else rawFraction
                            dragProgress = fraction
                            onSeek(fraction)
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(16.dp)) {
            val canvasW = size.width
            val canvasH = size.height
            val centerY = canvasH / 2f
            val trackH = 4.dp.toPx()
            val thumbRadius = 6.dp.toPx()

            val startX = thumbRadius
            val endX = canvasW - thumbRadius
            val availableW = (endX - startX).coerceAtLeast(1f)

            val thumbX = if (isRtl) {
                endX - (availableW * currentProgress)
            } else {
                startX + (availableW * currentProgress)
            }

            drawRoundRect(
                color = inactiveColor,
                topLeft = Offset(startX, centerY - (trackH / 2f)),
                size = Size(availableW, trackH),
                cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
            )

            if (currentProgress > 0f) {
                if (isRtl) {
                    val activeW = endX - thumbX
                    if (activeW > 0) {
                        drawRoundRect(
                            color = activeColor,
                            topLeft = Offset(thumbX, centerY - (trackH / 2f)),
                            size = Size(activeW, trackH),
                            cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
                        )
                    }
                } else {
                    val activeW = thumbX - startX
                    if (activeW > 0) {
                        drawRoundRect(
                            color = activeColor,
                            topLeft = Offset(startX, centerY - (trackH / 2f)),
                            size = Size(activeW, trackH),
                            cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
                        )
                    }
                }
            }

            drawCircle(
                color = activeColor,
                radius = thumbRadius,
                center = Offset(thumbX, centerY)
            )
            drawCircle(
                color = Color.White,
                radius = 1.8.dp.toPx(),
                center = Offset(thumbX, centerY)
            )
        }
    }
}

/**
 * بطاقة فيديو مدمجة بتصميم مذكرات التعافي مع إمكانية التشغيل، تعديل الاسم، والحذف
 */
@Composable
private fun MilestoneVideoItemCard(
    video: DiaryMediaItem,
    onPlay: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val sourceTint = Color(0xFFEA580C)
    val sizeStr = formatFileSize(video.fileSizeBytes)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, sourceTint.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val context = LocalContext.current
            val thumbFile = remember(video.filePath) {
                SaffahMediaCompressor.getThumbnailFile(context, video.filePath)
            }
            Surface(
                color = sourceTint.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .size(36.dp)
                    .clickable { onPlay() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (thumbFile.exists() && thumbFile.name.endsWith("_thumb.jpg")) {
                        AsyncImage(
                            model = thumbFile,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.35f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            tint = sourceTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onPlay() }
            ) {
                Text(
                    text = video.fileName.ifBlank { "مقطع فيديو للمحطة" },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (sizeStr.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = sizeStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp
                    )
                }
            }

            // زر تعديل اسم الفيديو
            IconButton(
                onClick = onRename,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Edit,
                    contentDescription = "تعديل الاسم",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }

            // زر حذف الفيديو
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Delete,
                    contentDescription = "حذف الفيديو",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            Button(
                onClick = onPlay,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = sourceTint,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(
                    text = "تشغيل",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * نافذة مشغل الفيديو المنبثق
 */
@Composable
private fun MilestoneVideoPlayerDialog(
    videoItem: DiaryMediaItem,
    onDismiss: () -> Unit
) {
    val file = remember(videoItem.filePath) { File(videoItem.filePath) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            if (file.exists()) {
                AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            setVideoPath(file.absolutePath)
                            val mediaController = MediaController(ctx)
                            mediaController.setAnchorView(this)
                            setMediaController(mediaController)
                            setOnPreparedListener { mp ->
                                mp.start()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "ملف الفيديو غير موجود",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق",
                    tint = Color.White
                )
            }
        }
    }
}

/**
 * نافذة تعديل اسم الملف
 */
@Composable
private fun RenameMilestoneMediaDialog(
    initialName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newName by remember { mutableStateOf(initialName) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 400.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "تعديل اسم التسجيل",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("اسم التسجيل") },
                        placeholder = { Text("أدخل اسماً للتسجيل...") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.8f),
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        ),
                        trailingIcon = if (newName.isNotBlank()) {
                            {
                                IconButton(onClick = { newName = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "مسح",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        } else null,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.8f))
                        ) {
                            Text(
                                text = "إلغاء",
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = {
                                if (newName.isNotBlank()) {
                                    onConfirm(newName.trim())
                                }
                            },
                            enabled = newName.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "حفظ",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatDuration(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format(Locale.US, "%02d:%02d", m, s)
}

private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return ""
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return if (mb >= 1.0) {
        String.format(Locale.US, "%.1f MB", mb)
    } else {
        String.format(Locale.US, "%d KB", kb.toLong())
    }
}
