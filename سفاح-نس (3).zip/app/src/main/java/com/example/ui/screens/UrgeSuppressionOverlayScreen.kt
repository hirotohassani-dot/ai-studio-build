package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassBentoCard
import com.example.ui.theme.*
import com.example.util.SaffahUrgeManager
import com.example.util.UrgeMotivationalMessage
import kotlinx.coroutines.delay
import java.util.Locale

/**
 * شاشة القفل والنافذة العائمة لجلسة "قاعدة الـ 15 دقيقة لدحر الرغبة"
 * - تصميم هادئ ومظلم ومريح يساعد على الاسترخاء والتنفس والتركيز.
 * - عداد تنازلي دقيق يبدأ من 15:00.
 * - رسائل تحفيزية إيمانية وسلوكية متناوبة بدقة وهدوء.
 * - تمرين تنفس تفاعلي بدائرة نبضية هادئة (شهيق 4 ثوانٍ، حبس 4 ثوانٍ، زفير 6 ثوانٍ).
 * - خالية تماماً من أي إيموجيات التزاماً بمعايير التصميم.
 */
@Composable
fun UrgeSuppressionOverlayScreen(
    onFinished: () -> Unit
) {
    val context = LocalContext.current

    var remainingMs by remember {
        val currentRem = SaffahUrgeManager.getUrgeSessionRemainingMs(context)
        mutableLongStateOf(if (currentRem > 0L) currentRem else 15 * 60 * 1000L)
    }
    var currentMessageIndex by remember { mutableIntStateOf(0) }

    val messages = SaffahUrgeManager.motivationalMessages

    // Ticker for countdown timer (500ms interval)
    LaunchedEffect(Unit) {
        delay(150L)
        while (true) {
            val isActive = SaffahUrgeManager.isUrgeSessionActive(context)
            val rem = SaffahUrgeManager.getUrgeSessionRemainingMs(context)
            remainingMs = rem
            if (!isActive || rem <= 0L) {
                SaffahUrgeManager.completeUrgeSession(context)
                onFinished()
                break
            }
            delay(500L)
        }
    }

    // Message cycler (every 12 seconds)
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            while (true) {
                delay(12000L)
                currentMessageIndex = (currentMessageIndex + 1) % messages.size
            }
        }
    }

    val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val timeFormatted = String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds)

    val sessionTotalDurationMs = 15 * 60 * 1000f
    val progress = ((sessionTotalDurationMs - remainingMs) / sessionTotalDurationMs).coerceIn(0f, 1f)

    // Breathing Animation Cycle (4s Inhale, 4s Hold, 6s Exhale = 14s total cycle)
    val breathingTransition = rememberInfiniteTransition(label = "BreathingGuide")
    val breathingPhaseProgress by breathingTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "BreathingPhase"
    )

    // Calculate breathing state from phase: 0..0.285 (Inhale), 0.285..0.571 (Hold), 0.571..1.0 (Exhale)
    val (breathingLabel, breathingScale) = remember(breathingPhaseProgress) {
        when {
            breathingPhaseProgress < 0.285f -> {
                // Inhale: 0 -> 1 scale
                val fraction = breathingPhaseProgress / 0.285f
                Pair("شهيق هادئ وعميق", 0.85f + 0.35f * fraction)
            }
            breathingPhaseProgress < 0.571f -> {
                // Hold
                Pair("احبس النفس بهدوء", 1.20f)
            }
            else -> {
                // Exhale
                val fraction = (breathingPhaseProgress - 0.571f) / (1f - 0.571f)
                Pair("زفير بطيء ومريح", 1.20f - 0.35f * fraction)
            }
        }
    }

    val primaryWarm = Color(0xFFD97706) // Warm Amber
    val emeraldColor = Color(0xFF059669) // Calming Emerald
    val darkCanvas = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF0F172A), // Deep Night Navy
            Color(0xFF1E1B2E), // Subtle Warm Midnight
            Color(0xFF0B1120)  // Solid Dark Foundation
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(darkCanvas)
            .padding(horizontal = 20.dp, vertical = 28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Header Pill
            Surface(
                color = primaryWarm.copy(alpha = 0.15f),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, primaryWarm.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = primaryWarm,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "قاعدة الـ 15 دقيقة لدحر الرغبة",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = primaryWarm
                    )
                }
            }

            // Big Circular Countdown & Breathing Hub
            Box(
                modifier = Modifier
                    .size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                // Expanding Breathing Ring
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .scale(breathingScale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    emeraldColor.copy(alpha = 0.20f),
                                    emeraldColor.copy(alpha = 0.05f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Background Circular Progress
                CircularProgressIndicator(
                    progress = { 1f },
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White.copy(alpha = 0.08f),
                    strokeWidth = 10.dp,
                    strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                )

                // Active Circular Progress Indicator
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxSize(),
                    color = emeraldColor,
                    strokeWidth = 10.dp,
                    strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                )

                // Center Display: Time & Breathing Instruction
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = timeFormatted,
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 2.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = breathingLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = emeraldColor,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Motivational & Spiritual Bento Card
            val currentMessage = messages.getOrNull(currentMessageIndex) ?: messages.first()

            AnimatedContent(
                targetState = currentMessage,
                transitionSpec = {
                    (fadeIn(animationSpec = tween(400, easing = SaffahMotion.EmphasizedDecelerate)) +
                            scaleIn(initialScale = 0.95f, animationSpec = tween(400, easing = SaffahMotion.EmphasizedDecelerate)))
                        .togetherWith(
                            fadeOut(animationSpec = tween(280, easing = SaffahMotion.EmphasizedAccelerate)) +
                                    scaleOut(targetScale = 1.03f, animationSpec = tween(280, easing = SaffahMotion.EmphasizedAccelerate))
                        )
                },
                label = "MotivationalMessageChange"
            ) { msg ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF1E293B).copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = msg.category,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = primaryWarm,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = msg.text,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            lineHeight = 26.sp
                        )

                        if (msg.subtext.isNotBlank()) {
                            Text(
                                text = msg.subtext,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.LightGray.copy(alpha = 0.85f),
                                textAlign = TextAlign.Center,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }

            // Personalized Defense Suggestion (Top historically successful technique)
            val recommendedTechniqueText = remember {
                com.example.util.SaffahRecoveryManager.getTopUrgeDefenseRecommendation(context)
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF0166FF).copy(alpha = 0.15f),
                border = BorderStroke(1.dp, Color(0xFF0166FF).copy(alpha = 0.40f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = Color(0xFF60A5FA),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = recommendedTechniqueText,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 18.sp
                    )
                }
            }

            // Calming Guidelines & Neuro Affirmation Pill
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = Color.White.copy(alpha = 0.05f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SelfImprovement,
                        contentDescription = null,
                        tint = emeraldColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "موجة الرغبة تنكسر خلال 15 دقيقة فقط. تنفس ببطء واستحضر قوة الإرادة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
