package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.RelapseTrigger
import com.example.ui.theme.*

/**
 * حوار توثيق وتدوين دحر الرغبة (Urge Logging Dialog)
 * يفتح تلقائياً بعد انتهاء جلسة الـ 15 دقيقة بنجاح أو عند التوثيق المباشر.
 * يسجل: الشدة، المحفز، المشاعر والملاحظات، ويضيفها لسجل التعافي.
 * تصميم Minimalist بألوان دافئة وبدون إيموجيات.
 */
@Composable
fun UrgeLogDialog(
    initialIntensity: Int = 4,
    onDismiss: () -> Unit,
    onSaveUrgeLog: (intensity: Int, trigger: String, emotion: String, notes: String) -> Unit
) {
    var intensity by remember { mutableIntStateOf(initialIntensity) }
    var selectedTrigger by remember { mutableStateOf("ملل وفراغ") }
    var customTrigger by remember { mutableStateOf("") }
    var selectedEmotion by remember { mutableStateOf("قلق وتوتر") }
    var customEmotion by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val triggersList = listOf(
        "ملل وفراغ",
        "ضغط نفسي وتوتر",
        "تعب وإرهاق جسدي",
        "محتوى بصري عابر",
        "تفكير عشوائي وسرحان",
        "وحدة وانعزال",
        "محفز مخصص"
    )

    val emotionsList = listOf(
        "قلق وتوتر",
        "إجهاد وضغط",
        "فضول عابر",
        "شعور بالعزلة",
        "رتابة وملل",
        "حالة نفسية مخصصة"
    )

    val isDark = isAppInDarkTheme()
    val emeraldColor = if (isDark) SuccessGreenDark else SuccessGreen
    val amberColor = if (isDark) WarningAmberDark else WarningAmber

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .wrapContentHeight()
                    .padding(vertical = 24.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header: Victory Announcement
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            color = emeraldColor.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = emeraldColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "انتصار سلوكي وتجاوز الرغبة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "تم كسر الموجة بنجاح! وثّق التجربة لترسيخ الوعي السلوكي.",
                                style = MaterialTheme.typography.bodySmall,
                                color = emeraldColor,
                                fontSize = 11.5.sp
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    // 1. Intensity (1 to 5)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "شدة الرغبة التي تم دحرها:",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Surface(
                                color = amberColor.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "$intensity من 5",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = amberColor
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            for (i in 1..5) {
                                val isSelected = intensity == i
                                Surface(
                                    onClick = { intensity = i },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) amberColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) amberColor else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    )
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = i.toString(),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2. Trigger
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "المحفز أو الشرارة المبدئية:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            triggersList.forEach { trig ->
                                val isSel = selectedTrigger == trig
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) emeraldColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSel) emeraldColor else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedTrigger = trig }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = trig,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) emeraldColor else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (isSel) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = emeraldColor,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (selectedTrigger == "محفز مخصص") {
                            OutlinedTextField(
                                value = customTrigger,
                                onValueChange = { customTrigger = it },
                                placeholder = { Text("اكتب المحفز بالتفصيل..", fontSize = 11.5.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    // 3. Emotion / Mental state
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "الحالة النفسية والمشاعر المرافقة:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            emotionsList.forEach { emo ->
                                val isSel = selectedEmotion == emo
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedEmotion = emo }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = emo,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (isSel) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (selectedEmotion == "حالة نفسية مخصصة") {
                            OutlinedTextField(
                                value = customEmotion,
                                onValueChange = { customEmotion = it },
                                placeholder = { Text("اكتب مشاعرك والحالة النفسية..", fontSize = 11.5.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    // 4. Notes
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "ملاحظات وتجربة الصمود (اختياري):",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            placeholder = { Text("ما الذي ساعدك على تجاوز الرغبة؟ (مثال: التنفس، الذكر، ترك الهاتف..)", fontSize = 11.5.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3,
                            textStyle = MaterialTheme.typography.bodySmall
                        )
                    }

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إغلاق", style = MaterialTheme.typography.labelMedium)
                        }

                        Button(
                            onClick = {
                                val finalTrigger = if (selectedTrigger == "محفز مخصص" && customTrigger.isNotBlank()) customTrigger else selectedTrigger
                                val finalEmotion = if (selectedEmotion == "حالة نفسية مخصصة" && customEmotion.isNotBlank()) customEmotion else selectedEmotion
                                onSaveUrgeLog(intensity, finalTrigger, finalEmotion, notes)
                                onDismiss()
                            },
                            modifier = Modifier.weight(1.5f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = emeraldColor
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "حفظ وتوثيق الانتصار",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
