package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * نافذة عائمة أنيقة تظهر عند تسجيل "ربحت المعركة"
 * تهنئ المتعافي وتشجعه وتُبجله وتحفزه، مع تأثيرات احتفالية (Celebration Effects) متزامنة
 * ملتزمة بالقواعد الصارمة: بدون إيموجي، أرقام إنجليزية فقط، وألوان راقية تعتمد على #0166FF
 */
@Composable
fun VictoryCelebrationDialog(
    streakDays: Int,
    onDismiss: () -> Unit
) {
    val haptic = LocalHapticFeedback.current

    // اهتزاز لمسي تأكيدي واحتفالي عند فتح النافذة
    LaunchedEffect(Unit) {
        try {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            delay(120)
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        } catch (_: Exception) {}
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f))
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            // ==========================================
            // تأثيرات الاحتفال الحركية المتزامنة (Celebration Particles)
            // ==========================================
            CelebrationEffectsOverlay(
                modifier = Modifier.fillMaxSize()
            )

            // ==========================================
            // البطاقة العائمة الأنيقة
            // ==========================================
            var isVisible by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                isVisible = true
            }

            AnimatedVisibility(
                visible = isVisible,
                enter = SaffahMotion.dialogPopEntrance(initialScale = 0.88f)
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .widthIn(max = 410.dp)
                        .padding(horizontal = 16.dp)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) { /* منع إغلاق البطاقة عند الضغط داخلها */ },
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shadowElevation = 16.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 22.dp, vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // الأيقونة المركزية: درع النصر والفخار
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(76.dp)
                        ) {
                            // هالة دائرية نابضة خفيفة بلون الهوية
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF0166FF).copy(alpha = 0.1f),
                                modifier = Modifier.size(76.dp)
                            ) {}

                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF0166FF).copy(alpha = 0.18f),
                                modifier = Modifier.size(58.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.Shield,
                                        contentDescription = null,
                                        tint = Color(0xFF0166FF),
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                        }

                        // شارة الإنجاز العلوية
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFF0166FF).copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, Color(0xFF0166FF).copy(alpha = 0.25f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.WorkspacePremium,
                                    contentDescription = null,
                                    tint = Color(0xFF0166FF),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "انتصار بطولي موثق",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0166FF)
                                )
                            }
                        }

                        // عنوان التهنئة والتبجيل
                        Text(
                            text = "مبارك لك الانتصار يا بطل!",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF111827),
                            textAlign = TextAlign.Center
                        )

                        // بطاقة إحصائية العداد وسلسلة النصر (أرقام إنجليزية حصراً)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "سلسلة الصمود الحالية:",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF4B5563)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF10B981).copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "$streakDays يوماً",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF059669),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        // نص التبجيل والتشجيع والتحفيز
                        Text(
                            text = "لقد أثبتَّ اليوم مجدداً أن إرادتك الفولاذية أصلب من كل النزوات العابرة. الرجال الأحرار هم من يروّضون رغباتهم ويصنعون هيبتهم بكرامة وعزة، وأنت اليوم وقفت وقفة بطل حقيقي انتصر في أشرس معارك النفس.\n\nكل يوم صمود تدونه هو لبنة متينة في بناء مستقبلك النقي وحريتك الكاملة.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF374151),
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp,
                            fontSize = 13.5.sp
                        )

                        // رسالة تحفيزية ختامية
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF0166FF).copy(alpha = 0.05f),
                            border = BorderStroke(1.dp, Color(0xFF0166FF).copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "«معركة اليوم حُسمت بفوزك، وغداً انتصار جديد تصنعه بعزيمتك وثباتك»",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF0166FF),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // زر المتابعة والانطلاق
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0166FF),
                                contentColor = Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                        ) {
                            Text(
                                text = "مواصلة الصمود بثقة",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * تأثيرات الاحتفال الحركية المتزامنة
 * تقوم بتوليد جزيئات هندسية ملونة تطير وتسقط بفيزياء ناعمة
 */
@Composable
private fun CelebrationEffectsOverlay(
    modifier: Modifier = Modifier
) {
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 3200, easing = LinearEasing)
        )
    }

    val particleCount = 85
    val particles = remember {
        val colorsList = listOf(
            Color(0xFF0166FF), // Primary Blue
            Color(0xFF10B981), // Emerald Success
            Color(0xFFF59E0B), // Golden Victory
            Color(0xFF6366F1), // Royal Indigo
            Color(0xFF06B6D4), // Cyan Glow
            Color(0xFF8B5CF6), // Violet Honor
            Color(0xFFE2E8F0)  // Soft Silver
        )

        val shapes = ParticleShape.values()

        List(particleCount) { index ->
            // انطلاق الجزيئات من الجزء العلوي والأوسط بنمط نافورة احتفالية
            val startXRatio = Random.nextFloat()
            val startYRatio = Random.nextFloat() * 0.35f
            val angle = Random.nextFloat() * 360f
            val speed = Random.nextFloat() * 550f + 180f
            val rad = Math.toRadians(angle.toDouble())

            CelebrationParticleItem(
                initialXRatio = startXRatio,
                initialYRatio = startYRatio,
                velocityX = (Math.cos(rad) * speed).toFloat(),
                velocityY = (Math.sin(rad) * speed).toFloat() - 250f, // قوة دفع علوية
                size = Random.nextFloat() * 8f + 6f,
                color = colorsList[index % colorsList.size],
                rotationSpeed = (Random.nextFloat() - 0.5f) * 720f,
                initialRotation = Random.nextFloat() * 360f,
                shape = shapes[index % shapes.size],
                gravity = Random.nextFloat() * 350f + 650f
            )
        }
    }

    val t = progress.value * 3.2f // مدة الثواني المنقضية

    Canvas(modifier = modifier) {
        val canvasWidth = size.width
        val canvasHeight = size.height

        for (p in particles) {
            val posX = (p.initialXRatio * canvasWidth) + p.velocityX * t
            val posY = (p.initialYRatio * canvasHeight) + p.velocityY * t + 0.5f * p.gravity * t * t
            val currentRotation = p.initialRotation + p.rotationSpeed * t

            // حساب التلاشي التدريجي في الثواني الأخيرة
            val alpha = when {
                t < 2.0f -> 1f
                t < 3.2f -> (1f - (t - 2.0f) / 1.2f).coerceIn(0f, 1f)
                else -> 0f
            }

            if (alpha <= 0.01f || posY > canvasHeight + 80f || posY < -120f) {
                continue
            }

            val particleColor = p.color.copy(alpha = alpha)

            when (p.shape) {
                ParticleShape.CIRCLE -> {
                    drawCircle(
                        color = particleColor,
                        radius = p.size / 2f,
                        center = Offset(posX, posY)
                    )
                }
                ParticleShape.RECTANGLE -> {
                    rotate(currentRotation, pivot = Offset(posX, posY)) {
                        drawRoundRect(
                            color = particleColor,
                            topLeft = Offset(posX - p.size, posY - p.size / 2.5f),
                            size = Size(p.size * 2f, p.size),
                            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                        )
                    }
                }
                ParticleShape.RING -> {
                    drawCircle(
                        color = particleColor,
                        radius = p.size / 2f,
                        center = Offset(posX, posY),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
                ParticleShape.DIAMOND -> {
                    rotate(currentRotation, pivot = Offset(posX, posY)) {
                        val path = Path().apply {
                            moveTo(posX, posY - p.size)
                            lineTo(posX + p.size * 0.7f, posY)
                            lineTo(posX, posY + p.size)
                            lineTo(posX - p.size * 0.7f, posY)
                            close()
                        }
                        drawPath(path = path, color = particleColor)
                    }
                }
            }
        }
    }
}

private enum class ParticleShape {
    CIRCLE,
    RECTANGLE,
    RING,
    DIAMOND
}

private data class CelebrationParticleItem(
    val initialXRatio: Float,
    val initialYRatio: Float,
    val velocityX: Float,
    val velocityY: Float,
    val size: Float,
    val color: Color,
    val rotationSpeed: Float,
    val initialRotation: Float,
    val shape: ParticleShape,
    val gravity: Float
)
