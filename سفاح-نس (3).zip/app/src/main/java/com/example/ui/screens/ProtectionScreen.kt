package com.example.ui.screens

import android.widget.Toast
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassBentoCard
import com.example.ui.components.featureTitleHint
import com.example.ui.components.QrKeyInstructionsDialog
import com.example.ui.components.QrKeySetupDialog
import com.example.ui.components.QrKeyVerificationDialog
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProtectionScreen(
    viewModel: MainViewModel,
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current

    val isTimeDelayActive by viewModel.isTimeDelayActive.collectAsState()
    val isDisallowSafeBoot by viewModel.isDisallowSafeBoot.collectAsState()
    val isDisallowConfigDateTime by viewModel.isDisallowConfigDateTime.collectAsState()
    val isDisallowConfigPrivateDns by viewModel.isDisallowConfigPrivateDns.collectAsState()
    val isDisallowDebuggingFeatures by viewModel.isDisallowDebuggingFeatures.collectAsState()
    val isBlockUnsupportedBrowsers by viewModel.isBlockUnsupportedBrowsers.collectAsState()
    val isBlockInAppBrowsers by viewModel.isBlockInAppBrowsers.collectAsState()
    val isHideVpnNotification by viewModel.isHideVpnNotification.collectAsState()
    val isKeeperServiceEnabled by viewModel.isKeeperServiceEnabled.collectAsState()
    val permissionStatus by viewModel.permissionStatus.collectAsState()
    val remainingTimeDelayMs by viewModel.remainingTimeDelayMs.collectAsState()
    val timeDelayUntilTimestamp by viewModel.timeDelayUntilTimestamp.collectAsState()
    val configuredTimeDelayHours by viewModel.configuredTimeDelayHours.collectAsState()

    val qrKeyConfig by viewModel.qrKeyConfig.collectAsState()
    val isQrKeyActive by viewModel.isQrKeyActive.collectAsState()
    val showQrKeyVerificationDialog by viewModel.showQrKeyVerificationDialog.collectAsState()

    var inputHoursText by remember { mutableStateOf("1") }
    var extendHoursText by remember { mutableStateOf("1") }
    var showStartConfirmDialog by remember { mutableStateOf(false) }
    var showExtendConfirmDialog by remember { mutableStateOf(false) }
    var showNotificationPermissionDialog by remember { mutableStateOf(false) }
    var showQrKeySetupDialog by remember { mutableStateOf(false) }
    var qrKeySetupInitialScanningMode by remember { mutableStateOf(false) }
    var showQrKeyInfoDialog by remember { mutableStateOf(false) }
    val view = LocalView.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header
        item(key = "protection_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "رجوع",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Column {
                    Text(
                        text = "مركز الحماية",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.featureTitleHint("protection_center")
                    )
                    Text(
                        text = "اختيار طريقة حماية واحدة (قفل QR المادي أو التأخير الزمني)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Physical QR / Barcode Key Bento Card (نظام مفتاح الباركود / QR المادي)
        item(key = "protection_qr_barcode_key") {
            GlassBentoCard(
                borderColor = if (isQrKeyActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Top Row: Icon + Title/Badge (with Long-press trigger) + Info Icon
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isQrKeyActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Outlined.QrCodeScanner,
                                    contentDescription = null,
                                    tint = if (isQrKeyActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .pointerInput(isTimeDelayActive) {
                                    detectTapGestures(
                                        onTap = {
                                            if (isTimeDelayActive && !isQrKeyActive) {
                                                Toast.makeText(context, "ميزة التأخير الزمني نشطة حالياً. لا يُسمح باختيار قفل QR إلا بعد انتهاء مدة التأخير الزمني.", Toast.LENGTH_SHORT).show()
                                            } else {
                                                qrKeySetupInitialScanningMode = false
                                                showQrKeySetupDialog = true
                                            }
                                        },
                                        onLongPress = {
                                            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                            showQrKeyInfoDialog = true
                                        }
                                    )
                                },
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "قفل مفتاح QR المادي",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.featureTitleHint(
                                        hintKey = "protection_qr_barcode",
                                        onClick = {
                                            if (isTimeDelayActive && !isQrKeyActive) {
                                                Toast.makeText(context, "ميزة التأخير الزمني نشطة حالياً. لا يُسمح باختيار قفل QR إلا بعد انتهاء مدة التأخير الزمني.", Toast.LENGTH_SHORT).show()
                                            } else {
                                                qrKeySetupInitialScanningMode = false
                                                showQrKeySetupDialog = true
                                            }
                                        }
                                    )
                                )
                                if (isQrKeyActive) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "مفعل (${qrKeyConfig.totalKeysCount} ${if (qrKeyConfig.totalKeysCount == 1) "كود" else "أكواد"})",
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Notice if Time Delay is active and blocking QR key
                    if (isTimeDelayActive && !isQrKeyActive) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.LockClock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "ميزة التأخير الزمني نشطة حالياً. لا يُسمح باختيار قفل QR كحماية إلا بعد انتهاء الحماية عبر ميزة التأخير الزمني.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Compact Actions Row
                    if (isQrKeyActive) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    viewModel.executeProtectedAction(
                                        actionType = "ADD_ADDITIONAL_QR_KEY",
                                        actionDescription = "إضافة كود حماية QR إضافي (يلزم مسح الكود الأساسي الأول)",
                                        requirePrimaryOnly = true
                                    ) {
                                        qrKeySetupInitialScanningMode = true
                                        showQrKeySetupDialog = true
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إضافة كود", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    qrKeySetupInitialScanningMode = false
                                    showQrKeySetupDialog = true
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                            ) {
                                Icon(Icons.Outlined.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إدارة الأكواد", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                if (isTimeDelayActive) {
                                    Toast.makeText(context, "ميزة التأخير الزمني نشطة حالياً. لا يُسمح باختيار قفل QR إلا بعد انتهاء مدة التأخير الزمني.", Toast.LENGTH_SHORT).show()
                                } else {
                                    qrKeySetupInitialScanningMode = true
                                    showQrKeySetupDialog = true
                                }
                            },
                            enabled = !isTimeDelayActive,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Outlined.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isTimeDelayActive) "غير متاح (التأخير الزمني نشط)" else "مسح وإضافة كود الحماية (تفعيل)",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Main Time Delay (ميزة التأخير الزمني) Bento Card
        item(key = "protection_time_delay") {
            GlassBentoCard(
                borderColor = if (isTimeDelayActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isTimeDelayActive) Icons.Outlined.LockClock else Icons.Outlined.HourglassBottom,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "ميزة التأخير الزمني",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.featureTitleHint("time_delay")
                                )
                                Surface(
                                    color = if (isTimeDelayActive) {
                                        SuccessGreen.copy(alpha = 0.12f)
                                    } else if (isQrKeyActive) {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                    ) {
                                        if (isTimeDelayActive) {
                                            val infiniteTransition = rememberInfiniteTransition(label = "pulse_green_dot")
                                            val dotAlpha by infiniteTransition.animateFloat(
                                                initialValue = 0.35f,
                                                targetValue = 1f,
                                                animationSpec = infiniteRepeatable(
                                                    animation = tween(750, easing = FastOutSlowInEasing),
                                                    repeatMode = RepeatMode.Reverse
                                                ),
                                                label = "dotAlpha"
                                            )
                                            val dotScale by infiniteTransition.animateFloat(
                                                initialValue = 0.8f,
                                                targetValue = 1.2f,
                                                animationSpec = infiniteRepeatable(
                                                    animation = tween(750, easing = FastOutSlowInEasing),
                                                    repeatMode = RepeatMode.Reverse
                                                ),
                                                label = "dotScale"
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .graphicsLayer {
                                                        scaleX = dotScale
                                                        scaleY = dotScale
                                                        alpha = dotAlpha
                                                    }
                                                    .background(SuccessGreen, CircleShape)
                                            )
                                            Text(
                                                text = "نشط",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = SuccessGreen
                                            )
                                        } else {
                                            Text(
                                                text = if (isQrKeyActive) {
                                                    "غير متاح (قفل QR نشط)"
                                                } else {
                                                    "غير مفعلة"
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "قفل زمني يمنع تعطيل الحماية أو تخفيف أي قيود حتى انتهاء المدة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (isTimeDelayActive) {
                        // Active Countdown and Details
                        val totalSec = (remainingTimeDelayMs / 1000).coerceAtLeast(0L)
                        val hours = totalSec / 3600
                        val minutes = (totalSec % 3600) / 60
                        val seconds = totalSec % 60

                        val countdownStr = if (hours < 100) {
                            String.format(Locale.US, "%02dh : %02dm : %02ds", hours, minutes, seconds)
                        } else {
                            String.format(Locale.US, "%dh : %02dm : %02ds", hours, minutes, seconds)
                        }
                        val endDateStr = remember(timeDelayUntilTimestamp) {
                            val sdf = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.US)
                            sdf.format(Date(timeDelayUntilTimestamp))
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp, horizontal = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "الوقت المتبقي لانتهاء القفل الحامي",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Timer,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = countdownStr,
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontSize = if (hours >= 100_000) 18.sp else if (hours >= 10_000) 20.sp else if (hours >= 1_000) 22.sp else 25.sp,
                                                fontWeight = FontWeight.Black
                                            ),
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                                Text(
                                    text = "ينتهي القفل في: $endDateStr",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Extend Time Delay Section
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                        Text(
                            text = "تمديد مدة التأخير الزمني",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Quick Preset Add Bento Pills
                        val extendPresets = listOf(1L to "+1h", 3L to "+3h", 24L to "+24h", 72L to "+72h", 168L to "+168h")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            extendPresets.forEach { (h, label) ->
                                Surface(
                                    onClick = {
                                        extendHoursText = h.toString()
                                        showExtendConfirmDialog = true
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .saffahPressMotion()
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        // Custom Extend Input
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = extendHoursText,
                                onValueChange = { str ->
                                    if (str.all { it.isDigit() }) {
                                        if (str.isEmpty() || (str.toLongOrNull() ?: 0L) <= 900_000L) {
                                            extendHoursText = str
                                        }
                                    }
                                },
                                label = { Text("عدد الساعات المضافة (H)") },
                                placeholder = { Text("مثال: 50 أو 1000 أو 900000") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Button(
                                onClick = {
                                    val parsed = (extendHoursText.toLongOrNull() ?: 1L).coerceIn(1L, 900_000L)
                                    if (parsed > 0) {
                                        showExtendConfirmDialog = true
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تمديد", fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // Inactive Setup State
                        if (isQrKeyActive) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.QrCodeScanner,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "قفل مفتاح QR المادي مفعّل حالياً كطريقة الحماية الوحيدة. لتفعيل الحماية عبر التأخير الزمني، يجب أولاً تعطيل قفل QR من الأعلى (حذف الأكواد).",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Text(
                            text = "اختر مدة التأخير الزمني السريعة بالساعات:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Preset Hours Bento Grid (2 rows of 4 pills spanning 100% width with no cutoffs)
                        val quickPresetsRow1 = listOf(
                            1L to "1h",
                            3L to "3h",
                            12L to "12h",
                            24L to "24h"
                        )
                        val quickPresetsRow2 = listOf(
                            48L to "48h",
                            72L to "72h",
                            168L to "168h",
                            720L to "720h"
                        )

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                quickPresetsRow1.forEach { (h, label) ->
                                    val isSelected = inputHoursText == h.toString()
                                    Surface(
                                        onClick = { inputHoursText = h.toString() },
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp)
                                            .saffahPressMotion()
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier.fillMaxSize()
                                        ) {
                                            Text(
                                                text = label,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                quickPresetsRow2.forEach { (h, label) ->
                                    val isSelected = inputHoursText == h.toString()
                                    Surface(
                                        onClick = { inputHoursText = h.toString() },
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp)
                                            .saffahPressMotion()
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier.fillMaxSize()
                                        ) {
                                            Text(
                                                text = label,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Manual Custom Hours Input
                        OutlinedTextField(
                            value = inputHoursText,
                            onValueChange = { str ->
                                if (str.all { it.isDigit() }) {
                                    if (str.isEmpty() || (str.toLongOrNull() ?: 0L) <= 900_000L) {
                                        inputHoursText = str
                                    }
                                }
                            },
                            label = { Text("تحديد عدد الساعات يدوياً (H)") },
                            placeholder = { Text("أدخل أي رقم حتى 900000 ساعة") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            trailingIcon = {
                                Text(
                                    text = "hours",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(end = 12.dp)
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Start Protection Button
                        Button(
                            onClick = {
                                if (isQrKeyActive) {
                                    Toast.makeText(context, "قفل QR المادي مفعّل حالياً. يجب حذف وتعطيل قفل QR أولاً.", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val parsed = (inputHoursText.toLongOrNull() ?: 1L).coerceIn(1L, 900_000L)
                                if (parsed > 0) {
                                    showStartConfirmDialog = true
                                } else {
                                    Toast.makeText(context, "يرجى إدخال عدد ساعات صحيح (1 أو أكثر)", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = !isQrKeyActive,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            val formattedHours = inputHoursText.ifBlank { "1" }
                            Text(
                                text = if (isQrKeyActive) "غير متاح (قفل QR مفعّل)" else "بدء الحماية وقفل الإعدادات ($formattedHours ساعة)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Safe Boot Restriction Bento Card (منع تشغيل الوضع الآمن)
        item(key = "protection_safeboot") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        LightningTypewriterText(
                            text = "منع تشغيل الوضع الآمن",
                            triggerState = isDisallowSafeBoot,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.featureTitleHint("disallow_safe_boot")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isDisallowSafeBoot,
                        onCheckedChange = { enabled ->
                            viewModel.toggleDisallowSafeBoot(enabled)
                        }
                    )
                }
            }
        }

        // Prevent Date/Time Manipulation Bento Card (منع التلاعب بالوقت)
        item(key = "protection_datetime_restriction") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Schedule,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        LightningTypewriterText(
                            text = "منع التلاعب بالوقت",
                            triggerState = isDisallowConfigDateTime,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.featureTitleHint("disallow_datetime_change")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isDisallowConfigDateTime,
                        onCheckedChange = { enabled ->
                            viewModel.toggleDisallowConfigDateTime(enabled)
                        }
                    )
                }
            }
        }

        // Disable Private DNS Configuration Bento Card (تعطيل إعدادات DNS)
        item(key = "protection_dns_restriction") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Dns,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "تعطيل إعدادات DNS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.featureTitleHint("disallow_private_dns")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isDisallowConfigPrivateDns,
                        onCheckedChange = { enabled ->
                            viewModel.toggleDisallowConfigPrivateDns(enabled)
                        }
                    )
                }
            }
        }

        // Disable Debugging Features Bento Card (منع خيارات وتصحيح المطورين)
        item(key = "protection_debugging_features") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DeveloperMode,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "حظر خيارات وتصحيح المطورين",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.featureTitleHint("disallow_debugging")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isDisallowDebuggingFeatures,
                        onCheckedChange = { enabled ->
                            viewModel.toggleDisallowDebuggingFeatures(enabled)
                        }
                    )
                }
            }
        }

        // Block Unsupported Browsers Bento Card (حظر المتصفحات غير المدعومة)
        item(key = "protection_block_unsupported_browsers") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PublicOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "حظر المتصفحات غير المدعومة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.featureTitleHint("block_unsupported_browsers")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isBlockUnsupportedBrowsers,
                        onCheckedChange = { enabled ->
                            viewModel.toggleBlockUnsupportedBrowsers(enabled)
                        }
                    )
                }
            }
        }

        // Block In-App Browsers & WebViews (حظر المتصفح داخل التطبيق)
        item(key = "protection_block_in_app_browsers") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.OpenInBrowser,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "حظر المتصفح داخل التطبيق",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.featureTitleHint("block_in_app_browsers")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isBlockInAppBrowsers,
                        onCheckedChange = { enabled ->
                            viewModel.toggleBlockInAppBrowsers(enabled)
                        }
                    )
                }
            }
        }

        // Hide VPN Notification Bento Card (إخفاء إشعار الـ VPN)
        item(key = "protection_hide_vpn_notification") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.NotificationsOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "إخفاء إشعار الـ VPN",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.featureTitleHint("hide_vpn_notification")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isHideVpnNotification,
                        onCheckedChange = { enabled ->
                            if (enabled && !permissionStatus.isNotificationAccessEnabled) {
                                showNotificationPermissionDialog = true
                            }
                            viewModel.toggleHideVpnNotification(enabled) {
                                showNotificationPermissionDialog = true
                            }
                        }
                    )
                }
            }
        }

        // Continuous Keeper Service Bento Card (خدمة الحماية الدائمة)
        item(key = "protection_keeper_service") {
            GlassBentoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "خدمة الحماية الدائمة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.featureTitleHint("keeper_foreground_service")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    SaffahSwitch(
                        checked = isKeeperServiceEnabled,
                        onCheckedChange = { enabled ->
                            viewModel.toggleKeeperService(enabled)
                        }
                    )
                }
            }
        }
    }

    if (showNotificationPermissionDialog) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showNotificationPermissionDialog = false },
                shape = RoundedCornerShape(24.dp),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp,
                title = {
                    Text(
                        text = "صلاحية الوصول إلى الإشعارات",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "لإخفاء إشعار الـ VPN النشط في شريط الحالة ولوحة إشعارات النظام، يحتاج تطبيق السَّفاح إلى منح صلاحية 'الوصول إلى الإشعارات' (Notification Access).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "يرجى الضغط على زر المتابعة وتفعيل الخيار لتطبيق السَّفاح في قائمة إعدادات النظام.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showNotificationPermissionDialog = false },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                        ) {
                            Text("لاحقاً", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = {
                                showNotificationPermissionDialog = false
                                viewModel.openNotificationAccessSettings()
                            },
                            modifier = Modifier.weight(1.2f).height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("فتح الإعدادات", fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = null
            )
        }
    }

    if (showStartConfirmDialog) {
        val hoursToStart = (inputHoursText.toLongOrNull() ?: 1L).coerceIn(1L, 900_000L)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showStartConfirmDialog = false },
                shape = RoundedCornerShape(24.dp),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp,
                title = {
                    Text(
                        text = "تأكيد بدء قفل التأخير الزمني",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Duration Badge
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HourglassTop,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تفعيل الحماية لمدة $hoursToStart ساعة",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        // Restrictions List Card
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                Text(
                                    text = "القيود المطبقة طوال فترة القفل:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                val restrictions = listOf(
                                    "منع تعطيل الـ VPN أو تعديل استثناءات التطبيقات",
                                    "منع تعطيل أو تقليل مدة شاشة العقوبة وفترة الهدوء",
                                    "منع حذف الكلمات والمواقع المحظورة أو تصفير السجل",
                                    "منع إزالة التطبيقات من الحظر المؤبد أو تعديل الجداول",
                                    "منع تعطيل حماية النظام (الوضع الآمن، تصحيح USB، DNS)",
                                    "منع التلاعب بالوقت والتاريخ أو تغيير المنطقة الزمنية",
                                    "منع إيقاف التطبيق إجبارياً أو مسح بياناته أو حذفه",
                                    "منع فتح المتصفحات غير المدعومة أو التصفح المدمج",
                                    "منع تقليل الساعات أو الإيقاف حتى انتهاء الوقت كاملاً"
                                )

                                restrictions.forEach { item ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(5.dp)
                                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                                        )
                                        Text(
                                            text = item,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        Text(
                            text = "ملاحظة: يُسمح فقط بزيادة القيود وتمديد الوقت.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showStartConfirmDialog = false },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                        ) {
                            Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = {
                                if (isQrKeyActive) {
                                    Toast.makeText(context, "قفل QR المادي مفعّل حالياً. يجب حذف وتعطيل قفل QR أولاً.", Toast.LENGTH_SHORT).show()
                                    showStartConfirmDialog = false
                                } else {
                                    viewModel.startTimeDelay(hoursToStart)
                                    showStartConfirmDialog = false
                                }
                            },
                            modifier = Modifier.weight(1.3f).height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("بدء القفل", fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = null
            )
        }
    }

    if (showExtendConfirmDialog) {
        val hoursToAdd = (extendHoursText.toLongOrNull() ?: 1L).coerceIn(1L, 900_000L)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showExtendConfirmDialog = false },
                shape = RoundedCornerShape(24.dp),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp,
                title = {
                    Text(
                        text = "تمديد مدة التأخير الزمني",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "إضافة $hoursToAdd ساعة إضافية",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "سيتم تمديد وقت القفل الحالي ولن يمكن تقليله حتى انتهاء المدة الممددة. هل تريد بالتأكيد الاستمرار؟",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                },
                confirmButton = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showExtendConfirmDialog = false },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                        ) {
                            Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = {
                                viewModel.extendTimeDelay(hoursToAdd)
                                showExtendConfirmDialog = false
                            },
                            modifier = Modifier.weight(1.2f).height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("تأكيد التمديد", fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = null
            )
        }
    }

    if (showQrKeySetupDialog) {
        QrKeySetupDialog(
            viewModel = viewModel,
            onDismiss = { showQrKeySetupDialog = false },
            initialScanningMode = qrKeySetupInitialScanningMode
        )
    }

    if (showQrKeyInfoDialog) {
        QrKeyInstructionsDialog(
            onDismiss = { showQrKeyInfoDialog = false }
        )
    }
}
