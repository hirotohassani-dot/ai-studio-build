package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.LockClock
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.util.SaffahQrKeyManager
import com.example.viewmodel.MainViewModel

/**
 * حوار إدارة وتسجيل مفاتيح الـ QR Code المادية
 * يتيح مسح وإضافة أكثر من كود مادي وإدارتها بكل سلاسة وأناقة
 */
@Composable
fun QrKeySetupDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    initialScanningMode: Boolean = false
) {
    val context = LocalContext.current
    val qrConfig by viewModel.qrKeyConfig.collectAsState()
    val isQrActive by viewModel.isQrKeyActive.collectAsState()
    val isTimeDelayActive by viewModel.isTimeDelayActive.collectAsState()

    var isScanningMode by remember(qrConfig.keys.isEmpty(), initialScanningMode) {
        mutableStateOf(!isQrActive || qrConfig.keys.isEmpty() || initialScanningMode)
    }
    var scannedCodeCandidate by remember { mutableStateOf<String?>(null) }
    var customLabelInput by remember { mutableStateOf("") }
    var keyToDeleteCandidate by remember { mutableStateOf<SaffahQrKeyManager.QrKeyItem?>(null) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(24.dp)
                    ),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Icon
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Outlined.QrCodeScanner,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // Title
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = if (isScanningMode) {
                                if (qrConfig.keys.isEmpty()) "تسجيل كود الحماية المادي" else "إضافة كود حماية جديد"
                            } else {
                                "إدارة أكواد الحماية المادية (${qrConfig.totalKeysCount})"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isScanningMode) {
                                "امسح الرمز الورقي بالكاميرا لاعتماده كأحد مفاتيح فك القيود"
                            } else {
                                "أي كود مضاف يمنح صلاحية فك الحظر وتعطيل الصلاحيات"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (isTimeDelayActive && !isQrActive) {
                        // حالة حظر تفعيل قفل QR بسبب سريان ميزة التأخير الزمني (حماية واحدة فقط)
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.LockClock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(32.dp)
                                )
                                Text(
                                    text = "ميزة التأخير الزمني نشطة حالياً",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "يجب اختيار طريقة حماية واحدة فقط. لا يُسمح باختيار أو تفعيل قفل QR المادي إلا بعد انتهاء الحماية عبر ميزة التأخير الزمني الحالية.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Button(
                                    onClick = onDismiss,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("حسناً")
                                }
                            }
                        }
                    } else if (isScanningMode) {
                        // Scanner View Mode
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Live Camera Scanner Box
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(230.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(
                                        width = 1.dp,
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                            ) {
                                QrBarcodeScannerSurface(
                                    modifier = Modifier.fillMaxSize(),
                                    onCodeScanned = { rawScanned ->
                                        if (scannedCodeCandidate != rawScanned) {
                                            scannedCodeCandidate = rawScanned
                                            if (customLabelInput.isBlank()) {
                                                customLabelInput = "كود الحماية ${qrConfig.totalKeysCount + 1}"
                                            }
                                        }
                                    }
                                )
                            }

                            // Scanned Confirmation preview & Naming / Deletion
                            scannedCodeCandidate?.let { code ->
                                val existingKey = viewModel.findKeyByRawCode(code)
                                if (existingKey != null) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Info,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Text(
                                                    text = "هذا الرمز مسجل مسبقاً (${existingKey.label})",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onErrorContainer
                                                )
                                            }

                                            Text(
                                                text = if (qrConfig.totalKeysCount <= 1) {
                                                    "حذف هذا الرمز سيؤدي إلى تعطيل قفل الـ QR المادي كلياً."
                                                } else {
                                                    "يمكنك حذف هذا الرمز المسجل فوراً من قاعدة البيانات."
                                                },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.9f)
                                            )

                                            Button(
                                                onClick = {
                                                    scannedCodeCandidate = null
                                                    onDismiss()
                                                    viewModel.deleteQrKey(existingKey.id, existingKey.label)
                                                },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(42.dp),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = MaterialTheme.colorScheme.error
                                                )
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("حذف هذا الكود المسجل نهائياً", fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                } else {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    text = "تم التقاط الرمز بنجاح",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                            }

                                            // Name Input
                                            OutlinedTextField(
                                                value = customLabelInput,
                                                onValueChange = { customLabelInput = it },
                                                label = { Text("اسم الكود (اختياري)") },
                                                singleLine = true,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            )

                                            Button(
                                                onClick = {
                                                    if (isTimeDelayActive) {
                                                        Toast.makeText(context, "ميزة التأخير الزمني نشطة حالياً. لا يُسمح بتفعيل قفل QR.", Toast.LENGTH_SHORT).show()
                                                        return@Button
                                                    }
                                                    val success = viewModel.registerQrKey(code, customLabelInput)
                                                    if (success) {
                                                        Toast.makeText(context, "تم حفظ كود الحماية بنجاح.", Toast.LENGTH_SHORT).show()
                                                        scannedCodeCandidate = null
                                                        customLabelInput = ""
                                                        isScanningMode = false
                                                    }
                                                },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(42.dp)
                                                    .testTag("confirm_register_qr_button"),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = MaterialTheme.colorScheme.primary
                                                )
                                            ) {
                                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("اعتماد وحفظ هذا الكود", fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }

                            // Return to list button if keys exist
                            if (qrConfig.keys.isNotEmpty()) {
                                OutlinedButton(
                                    onClick = {
                                        isScanningMode = false
                                        scannedCodeCandidate = null
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("الرجوع إلى قائمة الأكواد المسجلة")
                                }
                            }
                        }
                    } else {
                        // Overview & List of Registered Keys
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Top Action Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "الأكواد الصالحة للاستخدام (${qrConfig.totalKeysCount}):",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                FilledTonalButton(
                                    onClick = {
                                        viewModel.executeProtectedAction(
                                            actionType = "ADD_ADDITIONAL_QR_KEY",
                                            actionDescription = "إضافة كود حماية QR إضافي (يلزم مسح الكود الأساسي الأول)",
                                            requirePrimaryOnly = true
                                        ) {
                                            isScanningMode = true
                                            scannedCodeCandidate = null
                                            customLabelInput = "كود الحماية ${qrConfig.totalKeysCount + 1}"
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إضافة كود", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Keys List
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 240.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                itemsIndexed(qrConfig.keys, key = { _, keyItem -> keyItem.id }) { index, keyItem ->
                                    val isPrimary = (index == 0)
                                    Surface(
                                        color = if (isPrimary) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(
                                            1.dp,
                                            if (isPrimary) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Surface(
                                                shape = CircleShape,
                                                color = if (isPrimary) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.size(34.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        imageVector = if (isPrimary) Icons.Default.Shield else Icons.Outlined.VpnKey,
                                                        contentDescription = null,
                                                        tint = if (isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }

                                            Column(
                                                modifier = Modifier.weight(1f),
                                                verticalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Text(
                                                        text = keyItem.label,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Surface(
                                                        color = if (isPrimary) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text(
                                                            text = if (isPrimary) "الأساسي" else "إضافي",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = if (isPrimary) FontWeight.Bold else FontWeight.Normal,
                                                            color = if (isPrimary) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = "البصمة: ${SaffahQrKeyManager.formatMaskedPreview(keyItem.preview)}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            IconButton(
                                                onClick = {
                                                    keyToDeleteCandidate = keyItem
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Delete,
                                                    contentDescription = "حذف الكود",
                                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Bottom Management Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        onDismiss()
                                        viewModel.clearQrKey()
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("حذف كافة الأكواد", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Bottom Dismiss Button
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "إغلاق",
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Single Key Delete Confirmation
        keyToDeleteCandidate?.let { keyItem ->
            val isPrimary = (keyItem.id == qrConfig.primaryKey?.id || qrConfig.keys.firstOrNull()?.id == keyItem.id)
            AlertDialog(
                onDismissRequest = { keyToDeleteCandidate = null },
                shape = RoundedCornerShape(20.dp),
                title = {
                    Text(
                        text = "تأكيد حذف كود الحماية",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (isPrimary && qrConfig.totalKeysCount > 1) {
                                "أنت على وشك حذف '${keyItem.label}' (الكود الأساسي الأول).\n\nعند الحذف، سيصبح الكود التالي تلقائياً هو الكود الأساسي الأول المعتمد لإدارة باقي الأكواد."
                            } else if (qrConfig.totalKeysCount > 1) {
                                "هل أنت متأكد من رغبتك في حذف '${keyItem.label}'؟ ستبقى بقية الأكواد المسجلة فعالة لحماية التطبيق."
                            } else {
                                "هذا هو كود الحماية الوحيد المتبقي. حذفه سيؤدي إلى تعطيل قفل الـ QR المادي كلياً."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "يلزم مسح الكود الأساسي الأول لتأكيد عملية الحذف.",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val candidate = keyToDeleteCandidate
                            keyToDeleteCandidate = null
                            if (candidate != null) {
                                onDismiss()
                                viewModel.deleteQrKey(candidate.id, candidate.label)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("حذف الكود", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { keyToDeleteCandidate = null },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}
