package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.model.RecoveryBackupSummary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

/**
 * نافذة النسخ الاحتياطي الشامل لمركز التعافي (Full Backup Sheet)
 * تتيح تصدير واستيراد كافة بيانات ونصوص وصور وفيديوهات وتسجيلات التعافي بصيغة ZIP مضغوطة وآمنة
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecoveryBackupSheet(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val backupSummary by viewModel.recoveryBackupSummary.collectAsState()
    val isBackupInProgress by viewModel.isRecoveryBackupInProgress.collectAsState()
    val isRestoreInProgress by viewModel.isRecoveryRestoreInProgress.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.refreshRecoveryBackupSummary()
    }

    // Export ZIP Launcher
    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        uri?.let { viewModel.exportRecoveryBackupToFile(it) }
    }

    // Import ZIP / JSON Launcher
    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.importRecoveryBackupFromFile(it) }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            dragHandle = {
                Surface(
                    modifier = Modifier
                        .padding(top = 12.dp, bottom = 8.dp)
                        .size(width = 36.dp, height = 4.dp),
                    shape = RoundedCornerShape(2.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                ) {}
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 32.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Outlined.SaveAlt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "النسخ الاحتياطي لمركز التعافي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "تصدير واستيراد شامل للبيانات والصور والفيديوهات والأصوات",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Last backup timestamp indicator
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.History,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "حالة آخر حفظ:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = backupSummary.lastBackupFormatted ?: "لم يتم حفظ نسخة شاملة بعد",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = if (backupSummary.lastBackupFormatted != null) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Detailed Contents Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "المحتويات المشمولة في النسخة الشاملة:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 0.5.dp)

                        BackupDataRow(
                            title = "الأيام الصافية ومسار التعافي:",
                            value = "${formatCount(backupSummary.currentStreakDays, "يوم", "أيام", "يومان")} (${formatCount(backupSummary.totalPureDays, "يوم نقي", "أيام نقية", "يومان نقيان")})"
                        )

                        BackupDataRow(
                            title = "أيام تقويم تتبع التعافي:",
                            value = formatCount(backupSummary.calendarDaysCount, "يوم موثق", "أيام موثقة", "يومان موثقان")
                        )

                        BackupDataRow(
                            title = "يوميات وتأملات التعافي:",
                            value = formatCount(backupSummary.diariesCount, "مذكرة مسجلة", "مذكرات مسجلة", "مذكرتان مسجلتان")
                        )

                        BackupDataRow(
                            title = "الصور والمرفقات:",
                            value = formatCount(backupSummary.imagesCount, "صورة", "صور", "صورتان")
                        )

                        BackupDataRow(
                            title = "مقاطع الفيديو (مذكرات، ميثاق، محطات):",
                            value = formatCount(backupSummary.videosCount, "فيديو", "فيديوهات", "فيديو")
                        )

                        BackupDataRow(
                            title = "التسجيلات الصوتية (مذكرات، إلحاح، محطات):",
                            value = formatCount(backupSummary.audiosCount, "تسجيل صوتي", "تسجيلات صوتية", "تسجيلان صوتيان")
                        )

                        BackupDataRow(
                            title = "سجلات الانتكاسات والتشريح السلوكي:",
                            value = formatCount(backupSummary.relapsesCount, "حدث مسجل", "أحداث مسجلة", "حدثان مسجلان")
                        )

                        BackupDataRow(
                            title = "نوبات الشوق ومقاومة الإلحاح:",
                            value = formatCount(backupSummary.urgesCount, "نوبة مسجلة", "نوبات مسجلة", "نوبتان مسجلتان")
                        )

                        BackupDataRow(
                            title = "تسجيلات خريطة رحلة التعافي:",
                            value = formatCount(backupSummary.milestoneMediaCount, "تسجيل محطة", "تسجيلات محطات", "تسجيلان لمحطات")
                        )

                        BackupDataRow(
                            title = "وثيقة وميثاق التعافي:",
                            value = if (backupSummary.isPledgeSigned) "موقع وموثق" else "مسودة غير موقعة"
                        )

                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 0.5.dp)

                        val mediaMb = String.format(Locale.US, "%.1f", backupSummary.totalMediaSizeBytes / (1024.0 * 1024.0))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "الحجم التقديري لملفات الوسائط:",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "$mediaMb MB",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons
                // 1. Export Button
                Button(
                    onClick = {
                        val timestampStr = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                        exportFileLauncher.launch("saffah_recovery_full_backup_$timestampStr.zip")
                    },
                    enabled = !isBackupInProgress && !isRestoreInProgress,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    if (isBackupInProgress) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "جاري تجميع وضغط النسخة الشاملة...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.FileDownload,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تصدير نسخة احتياطية شاملة",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 2. Import Button
                OutlinedButton(
                    onClick = {
                        importFileLauncher.launch(
                            arrayOf(
                                "application/zip",
                                "application/x-zip-compressed",
                                "application/octet-stream",
                                "application/json",
                                "*/*"
                            )
                        )
                    },
                    enabled = !isBackupInProgress && !isRestoreInProgress,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    if (isRestoreInProgress) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "جاري استخراج واستعادة البيانات...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.FileUpload,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "استيراد نسخة احتياطية واستعادة البيانات",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Note
                Text(
                    text = "يتم حفظ كافة الصور والتسجيلات والمذكرات في ملف ZIP مشفر محلياً على الهاتف لسهولة نقله واستعادته في أي وقت بدون فقدان أي تفاصيل.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun BackupDataRow(
    title: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun formatCount(
    count: Int,
    singular: String,
    plural: String,
    dual: String,
    singularAfterTen: String = singular
): String {
    return when {
        count == 0 -> "0 $singularAfterTen"
        count == 1 -> "1 $singular"
        count == 2 -> "2 $dual"
        count in 3..10 -> "$count $plural"
        else -> "$count $singularAfterTen"
    }
}
