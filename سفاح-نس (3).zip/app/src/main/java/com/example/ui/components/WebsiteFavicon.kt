package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.ui.theme.ErrorRed
import kotlinx.coroutines.Dispatchers

/**
 * Extracts and cleans the hostname/domain from a website string or URL.
 */
fun cleanDomainForFavicon(rawDomain: String): String {
    return rawDomain.trim()
        .removePrefix("http://")
        .removePrefix("https://")
        .removePrefix("www.")
        .removePrefix("*.")
        .removePrefix("*")
        .substringBefore("/")
        .substringBefore(":")
        .substringBefore("?")
        .trim()
        .lowercase()
}

/**
 * Highly optimized, battery-efficient Website Favicon loader.
 * Uses Coil with disk and memory caching and Google's high-resolution favicon CDN.
 * Gracefully falls back to a clean Language icon when offline or on error.
 */
@Composable
fun WebsiteFavicon(
    domain: String,
    modifier: Modifier = Modifier,
    size: Dp = 38.dp,
    iconSize: Dp = 20.dp,
    containerColor: Color = ErrorRed.copy(alpha = 0.12f),
    iconTint: Color = ErrorRed
) {
    val context = LocalContext.current
    val cleanDomain = remember(domain) { cleanDomainForFavicon(domain) }
    val faviconUrl = remember(cleanDomain) {
        if (cleanDomain.isNotEmpty()) {
            "https://www.google.com/s2/favicons?domain=$cleanDomain&sz=128"
        } else {
            ""
        }
    }

    val imageRequest = remember(faviconUrl) {
        ImageRequest.Builder(context)
            .data(faviconUrl)
            .crossfade(true)
            .dispatcher(Dispatchers.IO)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .networkCachePolicy(CachePolicy.ENABLED)
            .build()
    }

    Surface(
        color = containerColor,
        shape = CircleShape,
        modifier = modifier.size(size)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            if (cleanDomain.isNotEmpty()) {
                SubcomposeAsyncImage(
                    model = imageRequest,
                    contentDescription = domain,
                    modifier = Modifier
                        .size(size * 0.65f)
                        .clip(RoundedCornerShape(4.dp)),
                    contentScale = ContentScale.Fit,
                    loading = {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = iconTint.copy(alpha = 0.5f),
                            modifier = Modifier.size(iconSize)
                        )
                    },
                    error = {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(iconSize)
                        )
                    }
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(iconSize)
                )
            }
        }
    }
}
