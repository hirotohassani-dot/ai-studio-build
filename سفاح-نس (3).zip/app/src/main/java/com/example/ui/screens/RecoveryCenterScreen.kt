package com.example.ui.screens

import androidx.activity.compose.BackHandler
import com.example.ui.theme.isAppInDarkTheme
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BiomeType
import com.example.model.DailyCalendarStatus
import com.example.model.RelapseTrigger
import com.example.ui.components.GlassBentoCard
import com.example.ui.components.featureTitleHint
import com.example.ui.components.LongestRecoveryStreaksDialog
import com.example.ui.components.RecoveryStartDateDialog
import com.example.ui.components.RecoveryTrackingCalendarCard
import com.example.ui.theme.*
import com.example.util.SaffahRecoveryManager
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

/**
 * شاشة قسم عداد التعافي المباشر (Recovery Counter Screen)
 * - عداد التعافي المباشر بصيغة: الأيام - الساعات - الدقائق (أرقام إنجليزية)
 * - تحديد تاريخ ووقت البداية بدقة (سنة، شهر، يوم، ساعة، دقيقة)
 * - إحصائيات: أطول مدة، تاريخ البداية، عدد الانتكاسات
 * - زر "انتكست" لتشريح الانتكاسة وتصفير العداد الصارم (فلسفة النقاء 100%)
 * - مؤشر فسيولوجي علمي لمرحلة ترميم الدوبامين والفص الجبهي
 * - شريط تقدم أنيق بلون مشبع محفز يمتلئ تدريجياً كل 5 أيام مع تحديات (5، 10، 15...)
 * - الوصول إلى خريطة مسار التعافي التفاعلية
 */
@Composable
fun RecoveryCenterScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToMap: () -> Unit = {},
    onNavigateToStats: (initialTab: Int) -> Unit = {}
) {
    val context = LocalContext.current
    val recoveryStats by viewModel.recoveryStats.collectAsState()
    val currentTimeMs by viewModel.recoveryCurrentTimeMs.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val dailyBaselineHistory by viewModel.dailyBaselineHistory.collectAsState()
    val recoveryCalendarHistory by viewModel.recoveryCalendarHistory.collectAsState()
    val urgeDatesSet by viewModel.urgeDatesSet.collectAsState()

    val todayKey = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val todayBaselineCheckIn = remember(dailyBaselineHistory, todayKey) {
        dailyBaselineHistory.find { it.dateKey == todayKey }
    }

    var showDatePickerDialog by remember { mutableStateOf(false) }
    var showRelapseAutopsyDialog by remember { mutableStateOf(false) }
    var showLongestStreaksDialog by remember { mutableStateOf(false) }

    // حساب المدة الحالية بدقة بالثواني والأيام والساعات والدقائق
    val elapsedSec = remember(recoveryStats.startTimestamp, currentTimeMs) {
        ((currentTimeMs - recoveryStats.startTimestamp) / 1000L).coerceAtLeast(0L)
    }

    val days = (elapsedSec / 86400L).toInt()
    val hours = ((elapsedSec % 86400L) / 3600L).toInt()
    val minutes = ((elapsedSec % 3600L) / 60L).toInt()
    val seconds = (elapsedSec % 60L).toInt()

    // حساب أطول مدة
    val longestDays = recoveryStats.longestStreakDays.coerceAtLeast(days)

    // تنسيق تاريخ البداية
    val formattedStartDate = remember(recoveryStats.startTimestamp) {
        val sdf = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.US)
        sdf.format(Date(recoveryStats.startTimestamp))
    }

    // حساب شريط التقدم والمحطة التالية (كل 5 أيام)
    val (nextMilestoneDay, progressToNext) = remember(days) {
        SaffahRecoveryManager.getNextMilestone(days)
    }

    val motivationalQuote = remember(days) {
        SaffahRecoveryManager.getMotivationalQuote(days)
    }

    // المرحلة العلمية لترميم الدوبامين
    val neuroStage = remember(days) {
        SaffahRecoveryManager.getNeuroRecoveryStage(days)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AnimatedContent(
            targetState = showRelapseAutopsyDialog,
            transitionSpec = {
                (fadeIn(animationSpec = tween(220, easing = FastOutSlowInEasing)) +
                 scaleIn(initialScale = 0.98f, animationSpec = tween(220, easing = FastOutSlowInEasing))) togetherWith
                 fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing))
            },
            label = "AutopsyScreenTransition"
        ) { isAutopsyOpen ->
            if (isAutopsyOpen) {
                BackHandler {
                    showRelapseAutopsyDialog = false
                }
                RelapseAutopsyScreen(
                    installedApps = installedApps,
                    onDismiss = { showRelapseAutopsyDialog = false },
                    onConfirm = { initialSpark, loopholeType, haltMoodState, preventiveDecision, note, triggerId, saveToDiaries, newBlockedKeyword, blockAppPackage ->
                        showRelapseAutopsyDialog = false
                        viewModel.recordRecoveryRelapse(
                            note = note,
                            triggerId = triggerId,
                            defenseAction = preventiveDecision,
                            initialSpark = initialSpark,
                            loopholeType = loopholeType,
                            haltMoodState = haltMoodState,
                            preventiveDecision = preventiveDecision,
                            saveToDiaries = saveToDiaries,
                            newBlockedKeyword = newBlockedKeyword,
                            blockAppPackage = blockAppPackage
                        )
                    }
                )
            } else {
                Scaffold(
                    topBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    shadowElevation = 0.5.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(40.dp)
                                .saffahPressMotion()
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "رجوع",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "مركز التعافي المباشر",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (userName.isNotBlank()) "مسار القوة والسيادة: $userName" else "عداد النقاء والانضباط التام",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(
                            onClick = { onNavigateToStats(0) },
                            modifier = Modifier
                                .size(40.dp)
                                .saffahPressMotion()
                        ) {
                            Icon(
                                imageVector = Icons.Default.BarChart,
                                contentDescription = "الإحصائيات والأنماط",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        IconButton(
                            onClick = { showDatePickerDialog = true },
                            modifier = Modifier
                                .size(40.dp)
                                .saffahPressMotion()
                        ) {
                            Icon(
                                imageVector = Icons.Default.EditCalendar,
                                contentDescription = "تعديل وقت البداية",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ==========================================
                // 1. HERO RECOVERY COUNTER (عداد التعافي الرئيسي)
                // ==========================================
                item(key = "recovery_hero_card") {
                    GlassBentoCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 24.dp
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Top Badge: Current Station & Location
                            val currentBiome = remember(days) { BiomeType.getBiomeForDay(days) }
                            val currentStation = remember(days) { ((days / 7) + 1).coerceAtMost(105) }

                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { onNavigateToMap() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "عرض في الخريطة",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "المحطة $currentStation: ${currentBiome.arabicName}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ChevronLeft,
                                        contentDescription = "الانتقال للخريطة",
                                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // Live Counter (Days - Hours - Minutes - Seconds) with Time-based Progress Indicators
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CounterDigitUnit(
                                    value = String.format(Locale.US, "%d", days),
                                    label = "يوم",
                                    progress = progressToNext.coerceIn(0f, 1f),
                                    isHighlighted = true,
                                    modifier = Modifier.weight(1f)
                                )

                                CounterDigitUnit(
                                    value = String.format(Locale.US, "%02d", hours),
                                    label = "ساعة",
                                    progress = (hours.toFloat() / 24f).coerceIn(0f, 1f),
                                    modifier = Modifier.weight(1f)
                                )

                                CounterDigitUnit(
                                    value = String.format(Locale.US, "%02d", minutes),
                                    label = "دقيقة",
                                    progress = (minutes.toFloat() / 60f).coerceIn(0f, 1f),
                                    modifier = Modifier.weight(1f)
                                )

                                CounterDigitUnit(
                                    value = String.format(Locale.US, "%02d", seconds),
                                    label = "ثانية",
                                    progress = (seconds.toFloat() / 60f).coerceIn(0f, 1f),
                                    progressColor = Color(0xFF10B981),
                                    showLiveIndicator = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            // Integrated Challenge Section
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Flag,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Text(
                                                text = if (days >= 730) "ختام مسار السنتين" else "تحدي الـ $nextMilestoneDay يوماً",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }

                                        Surface(
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = "${(progressToNext * 100).toInt()}%",
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }

                                    LinearProgressIndicator(
                                        progress = { progressToNext },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    )

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Lightbulb,
                                            contentDescription = null,
                                            tint = WarningAmber,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = motivationalQuote,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.5.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 2.dp),
                                thickness = 0.5.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                            )

                            // Zero-Tolerance Reset Button (Cool Calm Red Card)
                            val isDarkTheme = isAppInDarkTheme()
                            val resetContainerColor = if (isDarkTheme) Color(0xFF241416) else Color(0xFFFFF1F2)
                            val resetBorderColor = if (isDarkTheme) Color(0xFF5A1E24) else Color(0xFFFECDD3)
                            val resetContentColor = if (isDarkTheme) Color(0xFFFB7185) else Color(0xFFE11D48)

                            Surface(
                                onClick = { showRelapseAutopsyDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                color = resetContainerColor,
                                border = BorderStroke(1.dp, resetBorderColor)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RestartAlt,
                                        contentDescription = null,
                                        tint = resetContentColor,
                                        modifier = Modifier.size(19.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "تصفير العداد والبدأ من الـ0",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = resetContentColor
                                    )
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // 2. STATS OVERVIEW BENTO (بطاقة إحصائيات المسار)
                // ==========================================
                item(key = "recovery_stats_bento") {
                    GlassBentoCard {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "إحصائيات المسار",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Longest Streak
                                StatMiniCard(
                                    icon = Icons.Default.EmojiEvents,
                                    title = "أطول مدة",
                                    value = "$longestDays يوم",
                                    iconTint = Color(0xFFF59E0B),
                                    modifier = Modifier.weight(1f),
                                    onClick = { showLongestStreaksDialog = true },
                                    hintKey = "longest_streak"
                                )

                                // Relapses Count
                                StatMiniCard(
                                    icon = Icons.Default.History,
                                    title = "عدد الانتكاسات",
                                    value = "${recoveryStats.relapseCount} مرات",
                                    iconTint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigateToStats(1) },
                                    hintKey = "relapses_count"
                                )
                            }

                            // Start Date row
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showDatePickerDialog = true }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CalendarToday,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Column {
                                            Text(
                                                text = "تاريخ بداية التعافي",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = formattedStartDate,
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }

                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "تعديل",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // تقويم تتبع التعافي (Recovery Tracking Calendar)
                // ==========================================
                item(key = "recovery_tracking_calendar_card") {
                    RecoveryTrackingCalendarCard(
                        calendarHistory = recoveryCalendarHistory,
                        urgeDatesSet = urgeDatesSet,
                        recoveryStartTimestamp = recoveryStats.startTimestamp,
                        currentStreakDays = days,
                        onSetDayStatus = { dateKey, status ->
                            viewModel.setCalendarDayStatus(dateKey, status)
                        },
                        onTodaySuccess = {
                            val todayKey = java.time.LocalDate.now().toString()
                            viewModel.setCalendarDayStatus(todayKey, DailyCalendarStatus.SUCCESS)
                        },
                        onRequestRelapseAutopsy = {
                            showRelapseAutopsyDialog = true
                        }
                    )
                }

                // ==========================================
                // 3. NEUROPLASTICITY & DOPAMINE STAGE CARD (الحالة البيولوجية للدماغ)
                // ==========================================
                item(key = "recovery_neuro_stage_card") {
                    val cyanColor = PrimaryBlue
                    GlassBentoCard {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Psychology,
                                        contentDescription = null,
                                        tint = cyanColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "الحالة البيولوجية للدماغ",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.featureTitleHint("brain_neuroplasticity")
                                    )
                                }

                                Surface(
                                    color = cyanColor.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = neuroStage.dayRange,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = cyanColor
                                    )
                                }
                            }

                            Text(
                                text = "المرحلة ${neuroStage.stageNumber}: ${neuroStage.stageName}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = neuroStage.biologicalExplanation,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )

                            LinearProgressIndicator(
                                progress = { neuroStage.progressPercent },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(2.5.dp)),
                                color = cyanColor,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = neuroStage.keyActionableTip,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // ==========================================
                // 4. RECOVERY INDEX (مؤشر التعافي)
                // ==========================================
                item(key = "recovery_daily_baseline_card") {
                    val currentBaselineScore = remember(dailyBaselineHistory) {
                        com.example.util.SaffahRecoveryManager.calculateCumulativeRecoveryScores(dailyBaselineHistory).lastOrNull() ?: 0
                    }

                    DailyBaselineQuickCheckCard(
                        todayCheckIn = todayBaselineCheckIn,
                        currentBaselineScore = currentBaselineScore,
                        onSaveCheckIn = { clarity, mood, sleep, energy ->
                            viewModel.saveDailyBaselineCheckIn(clarity, mood, sleep, energy)
                        },
                        onNavigateToStats = { onNavigateToStats(0) }
                    )
                }
            }
        }

        // ==========================================
        // DIALOGS: START DATE & RELAPSE AUTOPSY & LONGEST STREAKS
        // ==========================================
        if (showLongestStreaksDialog) {
            val analytics by viewModel.recoveryAnalytics.collectAsState()
            LongestRecoveryStreaksDialog(
                recoveryStats = recoveryStats,
                currentTimeMs = currentTimeMs,
                relapseHistory = analytics.history,
                onDismiss = { showLongestStreaksDialog = false }
            )
        }

        if (showDatePickerDialog) {
            RecoveryStartDateDialog(
                initialTimestamp = recoveryStats.startTimestamp,
                onDismiss = { showDatePickerDialog = false },
                onConfirm = { y, m, d, h, min ->
                    viewModel.setRecoveryStartTime(y, m, d, h, min)
                }
            )
        }

            }
        }
    }
}

/**
 * استمارة تشريح الزلة وتصفير العداد الصارم (فلسفة النقاء 100%)
 * تتضمن الأركان الأربعة الإلزامية قبل السماح بإعادة ضبط التوقيت:
 * 1. التسلسل الزمني للزلة: أين بدأت الشرارة الأولى؟
 * 2. الثغرة التقنية/السلوكية: كيف تم الوصول للمحتوى رغم الحظر؟
 * 3. الحالة المزاجية قبل الزلة مباشرة: (HALT)
 * 4. القرار الوقائي الإلزامي: إضافة كلمة للحظر، تقييم النوم، أو حظر التطبيق
 */
@Composable
private fun RelapseAutopsyScreen(
    installedApps: List<com.example.model.InstalledApp> = emptyList(),
    onDismiss: () -> Unit,
    onConfirm: (
        initialSpark: String,
        loopholeType: String,
        haltMoodState: String,
        preventiveDecision: String,
        note: String,
        triggerId: String,
        saveToDiaries: Boolean,
        newBlockedKeyword: String?,
        blockAppPackage: String?
    ) -> Unit
) {
    // 1. التسلسل الزمني للزلة
    var selectedSparkType by remember { mutableStateOf("فيديو في يوتيوب / ريلز") }
    var customSparkDetails by remember { mutableStateOf("") }

    // 2. الثغرة التقنية / السلوكية
    var selectedLoopholeType by remember { mutableStateOf("استخدام تطبيق غير محظور") }
    var customLoopholeDetails by remember { mutableStateOf("") }

    // 3. الحالة المزاجية قبل الزلة مباشرة
    var selectedHaltMood by remember { mutableStateOf("إرهاق وسهر") }

    // 4. القرار الوقائي الإلزامي
    var selectedDecisionType by remember { mutableStateOf("إضافة كلمة جديدة لقائمة الحظر") }
    var newKeywordToBlock by remember { mutableStateOf("") }
    var selectedAppToBlock by remember { mutableStateOf("") }
    var customDecisionDetails by remember { mutableStateOf("") }

    // ملاحظات إضافية والمذكرات
    var additionalNotes by remember { mutableStateOf("") }
    var saveToDiaries by remember { mutableStateOf(true) }
    var showValidationError by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 0.5.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "استمارة تشريح الزلة وتصفير العداد الصارم",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "تحليل الأركان لسد الثغرة نهائياً قبل البدء من جديد",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.1f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Outlined.RestartAlt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "تحليل الزلة وتصفير العداد",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "يجب إكمال كافة أركان التشريح لسد الثغرة نهائياً قبل البدء من جديد.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
                // ==========================================
                // 1. التسلسل الزمني للزلة (أين بدأت الشرارة الأولى؟)
                // ==========================================
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Timeline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "التسلسل الزمني: أين بدأت الشرارة الأولى؟",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        val sparkOptions = listOf(
                            "فيديو في يوتيوب / ريلز",
                            "تصفح بدون هدف",
                            "تدوينة في فيسبوك / X",
                            "محادثة أو رسالة معينة",
                            "سهر وخلوة مع الهاتف",
                            "شرارة أخرى"
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            sparkOptions.chunked(2).forEach { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    rowItems.forEach { opt ->
                                        val isSel = selectedSparkType == opt
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { selectedSparkType = opt }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = opt,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                                if (isSel) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Check,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    if (rowItems.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = customSparkDetails,
                            onValueChange = { customSparkDetails = it },
                            placeholder = { Text("تفاصيل البداية (مثال: كنت أبحث عن موضوع فظهر مقترح..)", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)
                        )
                    }
                }

                // ==========================================
                // 2. الثغرة التقنية / السلوكية
                // ==========================================
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Security,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "الثغرة التقنية/السلوكية: كيف تم الوصول؟",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        val loopholeOptions = listOf(
                            "استخدام تطبيق غير محظور",
                            "البحث بطريقة التفافية",
                            "استخدام هاتف أو جهاز آخر",
                            "التلاعب بالإعدادات أو الوقت",
                            "سبب أو ثغرة أخرى"
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            loopholeOptions.chunked(2).forEach { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    rowItems.forEach { opt ->
                                        val isSel = selectedLoopholeType == opt
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { selectedLoopholeType = opt }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = opt,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                                if (isSel) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Check,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    if (rowItems.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = customLoopholeDetails,
                            onValueChange = { customLoopholeDetails = it },
                            placeholder = { Text("توضيح الثغرة (مثال: بحثت بكلمة مفتاحية غير محظورة..)", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)
                        )
                    }
                }

                // ==========================================
                // 3. الحالة المزاجية قبل الزلة مباشرة (HALT)
                // ==========================================
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Psychology,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "الحالة المزاجية قبل الزلة مباشرة:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        val haltOptions = listOf(
                            "إرهاق وسهر",
                            "فراغ وملل",
                            "ضغط وتوتر",
                            "وحدة وعزلة",
                            "غضب وإحباط",
                            "جوع واستنزاف"
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            haltOptions.chunked(2).forEach { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    rowItems.forEach { opt ->
                                        val isSel = selectedHaltMood == opt
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { selectedHaltMood = opt }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = opt,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                                if (isSel) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Check,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // 4. القرار الوقائي الإلزامي
                // ==========================================
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.GppGood,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "القرار الوقائي الإلزامي (إجراء عملي صارم):",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        val decisionOptions = listOf(
                            "إضافة كلمة جديدة لقائمة الحظر",
                            "حظر التطبيق الذي بدأت منه الشرارة",
                            "تقييم وضبط موعد النوم وإبعاد الهاتف",
                            "تفعيل التأخير الزمني وتشديد القفل",
                            "قرار وقائي مخصص"
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            decisionOptions.forEach { opt ->
                                val isSel = selectedDecisionType == opt
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedDecisionType = opt }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = opt,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (isSel) {
                                            Icon(
                                                imageVector = Icons.Outlined.Check,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // إذا كان القرار إضافة كلمة للحظر، نظهر حقل الكلمة لتنفيذها مباشرة
                        if (selectedDecisionType == "إضافة كلمة جديدة لقائمة الحظر") {
                            OutlinedTextField(
                                value = newKeywordToBlock,
                                onValueChange = { newKeywordToBlock = it },
                                label = { Text("الكلمة أو العبارة الجديدة لحظرها فوراً", fontSize = 11.sp) },
                                placeholder = { Text("أدخل الكلمة التي سهلت الوصول..", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)
                            )
                        }

                        // إذا كان القرار حظر تطبيق، نظهر حقل إدخال اسم التطبيق
                        if (selectedDecisionType == "حظر التطبيق الذي بدأت منه الشرارة") {
                            OutlinedTextField(
                                value = selectedAppToBlock,
                                onValueChange = { selectedAppToBlock = it },
                                label = { Text("اسم التطبيق المراد حظره", fontSize = 11.sp) },
                                placeholder = { Text("أدخل اسم التطبيق لتوثيقه وحظره..", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)
                            )
                        }

                        OutlinedTextField(
                            value = customDecisionDetails,
                            onValueChange = { customDecisionDetails = it },
                            placeholder = { Text("توضيح القرار الوقائي بالتفصيل (إلزامي للالتزام الصارم)..", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)
                        )
                    }
                }

                // ==========================================
                // مذكرات التعافي وتنبيه التحقق
                // ==========================================
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { saveToDiaries = !saveToDiaries }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = saveToDiaries,
                        onCheckedChange = { saveToDiaries = it }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "توثيق وحفظ استمارة التشريح في مذكرات التعافي",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 12.sp
                    )
                }

                if (showValidationError) {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "يجب تحديد كافة أركان الاستمارة (الشرارة، الثغرة، المزاج، والقرار الوقائي) قبل تصفير العداد.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // ==========================================
                // أزرار الإجراء: تأكيد التشريح وتصفير العداد + إلغاء
                // ==========================================
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            val finalSpark = if (customSparkDetails.isNotBlank()) "$selectedSparkType ($customSparkDetails)" else selectedSparkType
                            val finalLoophole = if (customLoopholeDetails.isNotBlank()) "$selectedLoopholeType ($customLoopholeDetails)" else selectedLoopholeType
                            val finalDecision = buildString {
                                append(selectedDecisionType)
                                if (newKeywordToBlock.isNotBlank()) {
                                    append(" (كلمة الحظر: $newKeywordToBlock)")
                                }
                                if (selectedAppToBlock.isNotBlank()) {
                                    append(" (تطبيق: $selectedAppToBlock)")
                                }
                                if (customDecisionDetails.isNotBlank()) {
                                    append(" - $customDecisionDetails")
                                }
                            }

                            // التحقق من استيفاء الأركان الإلزامية
                            val isFormComplete = finalSpark.isNotBlank() &&
                                    finalLoophole.isNotBlank() &&
                                    selectedHaltMood.isNotBlank() &&
                                    finalDecision.isNotBlank()

                            if (isFormComplete) {
                                showValidationError = false
                                val effectiveTriggerId = when {
                                    selectedHaltMood.contains("إرهاق") || selectedHaltMood.contains("Tired") -> RelapseTrigger.FATIGUE.id
                                    selectedHaltMood.contains("ملل") || selectedHaltMood.contains("Bored") -> RelapseTrigger.BOREDOM.id
                                    selectedHaltMood.contains("توتر") || selectedHaltMood.contains("ضغط") || selectedHaltMood.contains("Stressed") -> RelapseTrigger.STRESS.id
                                    selectedHaltMood.contains("عزلة") || selectedHaltMood.contains("وحدة") || selectedHaltMood.contains("Lonely") -> RelapseTrigger.LONELINESS.id
                                    selectedHaltMood.contains("غضب") || selectedHaltMood.contains("Angry") -> RelapseTrigger.ANGER.id
                                    selectedHaltMood.contains("جوع") || selectedHaltMood.contains("Hungry") -> RelapseTrigger.FATIGUE.id
                                    selectedSparkType.contains("سهر") -> RelapseTrigger.LATE_NIGHT.id
                                    selectedSparkType.contains("تصفح") -> RelapseTrigger.RANDOM_BROWSING.id
                                    else -> RelapseTrigger.OTHER.id
                                }

                                onConfirm(
                                    finalSpark,
                                    finalLoophole,
                                    selectedHaltMood,
                                    finalDecision,
                                    additionalNotes.trim(),
                                    effectiveTriggerId,
                                    saveToDiaries,
                                    newKeywordToBlock.takeIf { it.isNotBlank() },
                                    selectedAppToBlock.takeIf { it.isNotBlank() }
                                )
                            } else {
                                showValidationError = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(imageVector = Icons.Outlined.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تأكيد التشريح وتصفير العداد", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, softWrap = false)
                    }

                    Surface(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Box(
                            modifier = Modifier.padding(horizontal = 22.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "إلغاء",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

/**
 * خانة رقمية عصرية متكاملة لعرض الأيام / الساعات / الدقائق / الثواني مع مؤشر تقدم محيطي بمرور الوقت
 */
@Composable
private fun CounterDigitUnit(
    value: String,
    label: String,
    progress: Float = 0f,
    progressColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    isHighlighted: Boolean = false,
    showLiveIndicator: Boolean = false
) {
    val density = LocalDensity.current
    val strokeWidth = 2.5.dp
    val strokeWidthPx = with(density) { strokeWidth.toPx() }
    val inset = strokeWidthPx / 2f

    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = if (progress < 0.03f) snap() else tween(durationMillis = 350, easing = LinearEasing),
        label = "TimeProgressAnimation"
    )

    val trackColor = if (isHighlighted) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
    } else if (showLiveIndicator) {
        Color(0xFF10B981).copy(alpha = 0.18f)
    } else {
        MaterialTheme.colorScheme.outline.copy(alpha = 0.22f)
    }

    Surface(
        modifier = modifier
            .aspectRatio(1f)
            .drawWithContent {
                drawContent()
                val diameter = minOf(size.width, size.height) - strokeWidthPx
                val arcTopLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                val arcSize = Size(diameter, diameter)

                // 1. Draw background circle track
                drawArc(
                    color = trackColor,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = arcTopLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidthPx)
                )

                // 2. Draw active clockwise progress arc starting at 12 o'clock (270 degrees)
                if (animatedProgress > 0.001f) {
                    drawArc(
                        color = progressColor,
                        startAngle = 270f,
                        sweepAngle = 360f * animatedProgress.coerceIn(0f, 1f),
                        useCenter = false,
                        topLeft = arcTopLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
                    )
                }
            },
        color = if (isHighlighted) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        },
        shape = CircleShape
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center) {
                AnimatedContent(
                    targetState = value,
                    transitionSpec = { SaffahMotion.digitRollingTransition() },
                    label = "DigitRoll"
                ) { targetVal ->
                    Text(
                        text = targetVal,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isHighlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        fontSize = 21.sp,
                        lineHeight = 24.sp
                    )
                }
                if (showLiveIndicator) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-2).dp)
                            .size(6.dp)
                            .background(Color(0xFF10B981), CircleShape)
                            .saffahBreathingPulse(enabled = true, minScale = 0.8f, maxScale = 1.3f, durationMs = 1200)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = if (isHighlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}

/**
 * بطاقة إحصائية ميني
 */
@Composable
private fun StatMiniCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    iconTint: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    hintKey: String? = null
) {
    Surface(
        modifier = if (onClick != null) {
            modifier
                .clip(RoundedCornerShape(14.dp))
                .saffahCardFloat(targetScale = 0.96f, onClick = onClick)
        } else {
            modifier
        },
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                color = iconTint.copy(alpha = 0.15f),
                shape = CircleShape,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier
                        .padding(8.dp)
                        .size(20.dp)
                )
            }

            Column(modifier = Modifier.weight(1f, fill = false)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = if (hintKey != null) Modifier.featureTitleHint(hintKey = hintKey, onClick = onClick) else Modifier
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/**
 * بطاقة الفحص اليومي السريع لخط الأساس (Daily Baseline Index)
 * 4 مقاييس من 1 إلى 5:
 * 1. صفاء الذهن
 * 2. استقرار المزاج
 * 3. جودة النوم والنشاط الصباحي
 * 4. مستوى الطاقة والحافز للإنجاز
 */
@Composable
private fun DailyBaselineQuickCheckCard(
    todayCheckIn: com.example.model.DailyBaselineCheckIn?,
    currentBaselineScore: Int = 0,
    onSaveCheckIn: (clarity: Int, mood: Int, sleep: Int, energy: Int) -> Unit,
    onNavigateToStats: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    var isEditing by remember(todayCheckIn) { mutableStateOf(todayCheckIn == null) }

    var clarityRating by remember(todayCheckIn) { mutableIntStateOf(todayCheckIn?.clarityOfMind ?: 3) }
    var moodRating by remember(todayCheckIn) { mutableIntStateOf(todayCheckIn?.moodStability ?: 3) }
    var sleepRating by remember(todayCheckIn) { mutableIntStateOf(todayCheckIn?.sleepQuality ?: 3) }
    var energyRating by remember(todayCheckIn) { mutableIntStateOf(todayCheckIn?.energyAndMotivation ?: 3) }

    val rawAverage = remember(clarityRating, moodRating, sleepRating, energyRating) {
        (clarityRating + moodRating + sleepRating + energyRating) / 4.0
    }

    val indigoColor = PrimaryBlue

    val rotationAngle by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        label = "chevronRotation"
    )

    GlassBentoCard {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header (Clickable to expand/collapse)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { isExpanded = !isExpanded }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ShowChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                        modifier = Modifier.size(24.dp)
                    )

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "مؤشر التعافي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.featureTitleHint("daily_baseline", onClick = { isExpanded = !isExpanded })
                        )
                        Text(
                            text = "فحص سريع بنهاية اليوم (4 مقاييس)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = if (isExpanded) "طي" else "توسيع",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .size(18.dp)
                                .rotate(rotationAngle)
                        )
                    }
                }
            }

            // Animated Collapsible Content
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (todayCheckIn != null && !isEditing) {
                        // Completed View
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "مؤشر التعافي التراكمي",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "$currentBaselineScore%",
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = indigoColor
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "متوسط تقييم اليوم",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = String.format(Locale.ENGLISH, "%.2f من 5", todayCheckIn.averageScore),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                LinearProgressIndicator(
                                    progress = { (currentBaselineScore / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = indigoColor,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )

                                // 4 mini badges
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    BaselineMetricPill(
                                        title = "صفاء الذهن",
                                        score = todayCheckIn.clarityOfMind,
                                        modifier = Modifier.weight(1f)
                                    )
                                    BaselineMetricPill(
                                        title = "استقرار المزاج",
                                        score = todayCheckIn.moodStability,
                                        modifier = Modifier.weight(1f)
                                    )
                                    BaselineMetricPill(
                                        title = "جودة النوم",
                                        score = todayCheckIn.sleepQuality,
                                        modifier = Modifier.weight(1f)
                                    )
                                    BaselineMetricPill(
                                        title = "الطاقة والحافز",
                                        score = todayCheckIn.energyAndMotivation,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { isEditing = true },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تعديل الفحص",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = onNavigateToStats,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = indigoColor
                                ),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShowChart,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "عرض المخطط",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        // Interactive Check-In Form
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Metric 1: Mental Clarity
                            BaselineRatingInputRow(
                                title = "صفاء الذهن",
                                subHint = "التركيز، غياب الضبابية العقلية والتشوش",
                                selectedScore = clarityRating,
                                onScoreSelected = { clarityRating = it },
                                activeColor = indigoColor
                            )

                            // Metric 2: Mood Stability
                            BaselineRatingInputRow(
                                title = "استقرار المزاج",
                                subHint = "التوازن الانفعالي، الهدوء وغياب التوتر",
                                selectedScore = moodRating,
                                onScoreSelected = { moodRating = it },
                                activeColor = indigoColor
                            )

                            // Metric 3: Sleep Quality & Morning Vitality
                            BaselineRatingInputRow(
                                title = "جودة النوم والنشاط الصباحي",
                                subHint = "عمق النوم، سهولة الاستيقاظ والنشاط",
                                selectedScore = sleepRating,
                                onScoreSelected = { sleepRating = it },
                                activeColor = indigoColor
                            )

                            // Metric 4: Energy & Drive for Achievement
                            BaselineRatingInputRow(
                                title = "مستوى الطاقة والحافز للإنجاز",
                                subHint = "الدافع الداخلي، الإرادة والرغبة في الإنتاجية",
                                selectedScore = energyRating,
                                onScoreSelected = { energyRating = it },
                                activeColor = indigoColor
                            )

                            // Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (todayCheckIn != null) {
                                    OutlinedButton(
                                        onClick = { isEditing = false },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        contentPadding = PaddingValues(horizontal = 8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "إلغاء التعديل",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        onSaveCheckIn(clarityRating, moodRating, sleepRating, energyRating)
                                        isEditing = false
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = indigoColor
                                    ),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "توثيق الفحص",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * صف إدخال التقييم من 1 إلى 5 لمقياس خط الأساس
 */
@Composable
private fun BaselineRatingInputRow(
    title: String,
    subHint: String,
    selectedScore: Int,
    onScoreSelected: (Int) -> Unit,
    activeColor: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                shape = RoundedCornerShape(10.dp)
            )
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subHint,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }

        // 1..5 chips row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (score in 1..5) {
                val isSelected = selectedScore == score
                Surface(
                    onClick = { onScoreSelected(score) },
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) activeColor else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) activeColor else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = score.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

/**
 * بطاقة مصغرة لعرض نتيجة مقياس خط الأساس
 */
@Composable
private fun BaselineMetricPill(
    title: String,
    score: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "$score/5",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

