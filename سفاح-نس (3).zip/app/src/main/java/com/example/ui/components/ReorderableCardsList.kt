package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.launch

/**
 * مكون متطور وسلس لإعادة ترتيب بطاقات عمليات الحظر عبر السحب والإفلات (Fluid Reorderable Cards List).
 *
 * الخصائص والميزات الأساسية:
 * 1. السحب والانزلاق الحر: تظل البطاقة ممسوكة تحت إصبع المستخدم بسلاسة تامة دون فلتان تلقائي أو قفزات عشوائية.
 * 2. إفساح المجال التفاعلي (Slot Opening): تنزاح البطاقات الأخرى بانسيابية بفيزياء زنبركية لفتح مساحة للموضع الجديد.
 * 3. الفلتان الفيزيائي المستقر (Spring Glide Drop): عند رفع الإصبع، تنزلق البطاقة بنعومة فائقة إلى الموضع المختار وتستقر به.
 * 4. الحفاظ على أبعاد البطاقة الطبيعية بنسبة 100% دون أي فراغات داخلية أو تمددات غير مرغوبة.
 * 5. ردود فعل لمسية (Haptics) محسنة أثناء التحليق وتغيير الموضع والاستقرار.
 */
@Composable
fun <T> ReorderableCardsList(
    items: List<T>,
    key: (T) -> Any,
    onReorder: (List<T>) -> Unit,
    modifier: Modifier = Modifier,
    spacing: Dp = 10.dp,
    activeColor: Color = MaterialTheme.colorScheme.primary,
    hintText: String = "اضغط مطولاً على أي بطاقة واسحبها لتغيير الترتيب",
    itemContent: @Composable (item: T, isDragging: Boolean) -> Unit
) {
    val latestOnReorder by rememberUpdatedState(onReorder)
    var currentList by remember { mutableStateOf(items) }

    var draggingKey by remember { mutableStateOf<Any?>(null) }
    var draggingFromIndex by remember { mutableIntStateOf(-1) }
    var currentTargetIndex by remember { mutableIntStateOf(-1) }
    var isSettling by remember { mutableStateOf(false) }

    // Synchronize currentList immediately whenever items update and not actively dragging
    if (draggingKey == null && !isSettling && currentList != items) {
        currentList = items
    }

    LaunchedEffect(items) {
        if (draggingKey == null && !isSettling) {
            currentList = items
        }
    }

    val coroutineScope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val spacingPx = with(density) { spacing.toPx() }

    val itemHeights = remember { mutableStateMapOf<Any, Int>() }
    val dragAnimatableY = remember { Animatable(0f) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(spacing)
    ) {
        // تلميح أنيق يظهر فقط عند وجود بطاقتين أو أكثر
        if (currentList.size >= 2) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = activeColor.copy(alpha = 0.12f),
                    modifier = Modifier.size(20.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = null,
                            tint = activeColor,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Text(
                    text = hintText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        currentList.forEachIndexed { index, item ->
            val itemKey = key(item)
            androidx.compose.runtime.key(itemKey) {
                val isCurrentItemDragging = draggingKey == itemKey

            // حساب الإزاحة الانتقالية للبطاقات الأخرى لإفساح المجال
            val targetShiftY = remember(isCurrentItemDragging, draggingKey, draggingFromIndex, currentTargetIndex, index, itemHeights.toMap()) {
                if (draggingKey == null || isCurrentItemDragging || draggingFromIndex == -1 || currentTargetIndex == -1) {
                    0f
                } else {
                    val draggedItemHeight = (itemHeights[draggingKey] ?: 120) + spacingPx
                    when {
                        // إذا كان السحب للأسفل متجاوزاً هذا العنصر
                        draggingFromIndex < currentTargetIndex && index in (draggingFromIndex + 1)..currentTargetIndex -> {
                            -draggedItemHeight
                        }
                        // إذا كان السحب للأعلى متجاوزاً هذا العنصر
                        draggingFromIndex > currentTargetIndex && index in currentTargetIndex until draggingFromIndex -> {
                            draggedItemHeight
                        }
                        else -> 0f
                    }
                }
            }

            val animatedShiftY by animateFloatAsState(
                targetValue = targetShiftY,
                animationSpec = spring(
                    stiffness = Spring.StiffnessMediumLow,
                    dampingRatio = Spring.DampingRatioLowBouncy
                ),
                label = "CardShiftY_$itemKey"
            )

            val targetScale = if (isCurrentItemDragging) 1.025f else 1.0f
            val scale by animateFloatAsState(
                targetValue = targetScale,
                animationSpec = spring(
                    stiffness = Spring.StiffnessMediumLow,
                    dampingRatio = Spring.DampingRatioLowBouncy
                ),
                label = "CardDragScale_$itemKey"
            )

            val targetElevation = if (isCurrentItemDragging) 12.dp else 0.dp
            val elevation by animateDpAsState(
                targetValue = targetElevation,
                animationSpec = spring(
                    stiffness = Spring.StiffnessMediumLow,
                    dampingRatio = Spring.DampingRatioNoBouncy
                ),
                label = "CardDragElevation_$itemKey"
            )

            val targetAlpha = if (draggingKey != null && !isCurrentItemDragging) 0.86f else 1.0f
            val alpha by animateFloatAsState(
                targetValue = targetAlpha,
                animationSpec = spring(stiffness = Spring.StiffnessMedium),
                label = "CardOtherAlpha_$itemKey"
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .zIndex(if (isCurrentItemDragging) 100f else 1f)
                    .graphicsLayer {
                        translationY = if (isCurrentItemDragging) dragAnimatableY.value else animatedShiftY
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                        shadowElevation = elevation.toPx()
                    }
                    .onSizeChanged { size ->
                        itemHeights[itemKey] = size.height
                    }
                    .then(
                        if (currentList.size > 1) {
                            Modifier.pointerInput(itemKey, currentList) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = {
                                        val curIdx = currentList.indexOfFirst { key(it) == itemKey }
                                        if (curIdx != -1 && !isSettling) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            draggingKey = itemKey
                                            draggingFromIndex = curIdx
                                            currentTargetIndex = curIdx
                                            coroutineScope.launch {
                                                dragAnimatableY.snapTo(0f)
                                            }
                                        }
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        if (draggingKey == itemKey && draggingFromIndex != -1 && !isSettling) {
                                            val currentVal = dragAnimatableY.value + dragAmount.y
                                            coroutineScope.launch {
                                                dragAnimatableY.snapTo(currentVal)
                                            }

                                            // حساب مراكز العناصر لمعرفة أقرب موضع (Slot) مع deadzone لمنع التذبذب
                                            var cumulativeY = 0f
                                            val centers = currentList.mapIndexed { idx, itm ->
                                                val h = (itemHeights[key(itm)] ?: 120).toFloat()
                                                val center = cumulativeY + (h / 2f)
                                                cumulativeY += h + spacingPx
                                                idx to center
                                            }

                                            val fromCenter = centers.getOrNull(draggingFromIndex)?.second ?: 0f
                                            val currentDraggedCenter = fromCenter + currentVal

                                            val newTarget = centers.minByOrNull { kotlin.math.abs(it.second - currentDraggedCenter) }?.first ?: draggingFromIndex
                                            if (newTarget != currentTargetIndex) {
                                                currentTargetIndex = newTarget
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            }
                                        }
                                    },
                                    onDragEnd = {
                                        if (draggingKey == itemKey && draggingFromIndex != -1 && !isSettling) {
                                            val from = draggingFromIndex
                                            val to = currentTargetIndex

                                            isSettling = true
                                            coroutineScope.launch {
                                                // حساب الإزاحة الدقيقة للموضع الجديد حتى تنزلق البطاقة إليه بسلاسة تامة قبل التثبيت
                                                val expectedSlotOffset = when {
                                                    to > from -> {
                                                        (from + 1..to).sumOf { idx ->
                                                            ((itemHeights[key(currentList[idx])] ?: 120) + spacingPx).toDouble()
                                                        }.toFloat()
                                                    }
                                                    to < from -> {
                                                        -(to until from).sumOf { idx ->
                                                            ((itemHeights[key(currentList[idx])] ?: 120) + spacingPx).toDouble()
                                                        }.toFloat()
                                                    }
                                                    else -> 0f
                                                }

                                                // انزلاق البطاقة بنعومة إلى الفراغ المخصص
                                                dragAnimatableY.animateTo(
                                                    targetValue = expectedSlotOffset,
                                                    animationSpec = spring(
                                                        stiffness = Spring.StiffnessMedium,
                                                        dampingRatio = Spring.DampingRatioLowBouncy
                                                    )
                                                )

                                                if (from != to && from in currentList.indices && to in currentList.indices) {
                                                    val mutable = currentList.toMutableList()
                                                    val movedItem = mutable.removeAt(from)
                                                    mutable.add(to, movedItem)
                                                    currentList = mutable
                                                    latestOnReorder(mutable)
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                }

                                                dragAnimatableY.snapTo(0f)
                                                draggingKey = null
                                                draggingFromIndex = -1
                                                currentTargetIndex = -1
                                                isSettling = false
                                            }
                                        }
                                    },
                                    onDragCancel = {
                                        if (draggingKey == itemKey && !isSettling) {
                                            val from = draggingFromIndex
                                            val to = currentTargetIndex
                                            isSettling = true
                                            coroutineScope.launch {
                                                val expectedSlotOffset = when {
                                                    to > from -> {
                                                        (from + 1..to).sumOf { idx ->
                                                            ((itemHeights[key(currentList[idx])] ?: 120) + spacingPx).toDouble()
                                                        }.toFloat()
                                                    }
                                                    to < from -> {
                                                        -(to until from).sumOf { idx ->
                                                            ((itemHeights[key(currentList[idx])] ?: 120) + spacingPx).toDouble()
                                                        }.toFloat()
                                                    }
                                                    else -> 0f
                                                }

                                                dragAnimatableY.animateTo(
                                                    targetValue = expectedSlotOffset,
                                                    animationSpec = spring(
                                                        stiffness = Spring.StiffnessMedium,
                                                        dampingRatio = Spring.DampingRatioLowBouncy
                                                    )
                                                )

                                                if (from != -1 && to != -1 && from != to && from in currentList.indices && to in currentList.indices) {
                                                    val mutable = currentList.toMutableList()
                                                    val movedItem = mutable.removeAt(from)
                                                    mutable.add(to, movedItem)
                                                    currentList = mutable
                                                    latestOnReorder(mutable)
                                                }

                                                dragAnimatableY.snapTo(0f)
                                                draggingKey = null
                                                draggingFromIndex = -1
                                                currentTargetIndex = -1
                                                isSettling = false
                                            }
                                        }
                                    }
                                )
                            }
                        } else {
                            Modifier
                        }
                    )
            ) {
                itemContent(item, isCurrentItemDragging)
            }
            }
        }
    }
}
