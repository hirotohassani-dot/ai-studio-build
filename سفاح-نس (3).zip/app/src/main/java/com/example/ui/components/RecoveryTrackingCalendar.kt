package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.DailyCalendarStatus
import com.example.ui.theme.isAppInDarkTheme
import com.example.ui.theme.saffahPressMotion
import java.time.LocalDate
import java.time.YearMonth

private val ArabicMonthNames = listOf(
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
)

private val WeekDayNames = listOf(
    "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
)

data class CalendarDayItem(
    val date: LocalDate,
    val isCurrentMonth: Boolean,
    val isToday: Boolean,
    val isFuture: Boolean,
    val status: DailyCalendarStatus,
    val hasUrgeDefeated: Boolean
)

/**
 * لوحة ألوان متكاملة تدعم الوضع الليلي والوضع النهاري للتقويم والحوارات
 */
data class CalendarColors(
    val isDark: Boolean,
    val cardBackground: Color,
    val cardBorder: Color,
    val dividerColor: Color,
    val headerText: Color,
    val headerIconTint: Color,
    val weekdayText: Color,
    val dayNeutralFill: Color,
    val dayAdjacentFill: Color,
    val dayNeutralText: Color,
    val dayAdjacentText: Color,
    val todayBlue: Color,
    val successGreen: Color,
    val relapseRed: Color,
    val skippedYellow: Color,
    val urgeDot: Color,
    val urgeDotBorder: Color,
    val legendText: Color,
    val dialogSurface: Color,
    val dialogBorder: Color,
    val dialogTitleText: Color,
    val dialogSubtitleText: Color,
    val dialogCloseTint: Color,
    val relapseButtonContainer: Color,
    val relapseButtonBorder: Color,
    val relapseButtonText: Color,
    val skippedButtonContainer: Color,
    val skippedButtonBorder: Color,
    val skippedButtonText: Color,
    val unselectButtonText: Color,
    val secondaryDialogBtnContainer: Color,
    val secondaryDialogBtnBorder: Color,
    val secondaryDialogBtnText: Color,
    val urgeBannerBg: Color,
    val urgeBannerText: Color
)

@Composable
private fun rememberCalendarColors(): CalendarColors {
    val isDark = isAppInDarkTheme()
    return remember(isDark) {
        if (isDark) {
            CalendarColors(
                isDark = true,
                cardBackground = Color(0xFF18181B), // Zinc 900
                cardBorder = Color(0xFF27272A),     // Zinc 800
                dividerColor = Color(0xFF27272A),
                headerText = Color(0xFFF4F4F5),     // Zinc 100
                headerIconTint = Color(0xFFF4F4F5),
                weekdayText = Color(0xFFA1A1AA),    // Zinc 400
                dayNeutralFill = Color(0xFF27272A), // Zinc 800
                dayAdjacentFill = Color(0xFF1C1C20),
                dayNeutralText = Color(0xFFF4F4F5),
                dayAdjacentText = Color(0xFF52525B), // Zinc 600
                todayBlue = Color(0xFF3B82F6),      // Blue Dark Theme
                successGreen = Color(0xFF10B981),
                relapseRed = Color(0xFFEF4444),
                skippedYellow = Color(0xFFF59E0B),
                urgeDot = Color(0xFFA78BFA),
                urgeDotBorder = Color(0xFF18181B),
                legendText = Color(0xFFA1A1AA),
                dialogSurface = Color(0xFF18181B),
                dialogBorder = Color(0xFF27272A),
                dialogTitleText = Color(0xFFF4F4F5),
                dialogSubtitleText = Color(0xFFA1A1AA),
                dialogCloseTint = Color(0xFFA1A1AA),
                relapseButtonContainer = Color(0xFF201515),
                relapseButtonBorder = Color(0xFFEF4444),
                relapseButtonText = Color(0xFFF87171),
                skippedButtonContainer = Color(0xFF221C13),
                skippedButtonBorder = Color(0xFFF59E0B),
                skippedButtonText = Color(0xFFFBBF24),
                unselectButtonText = Color(0xFFA1A1AA),
                secondaryDialogBtnContainer = Color(0xFF27272A),
                secondaryDialogBtnBorder = Color(0xFF3F3F46),
                secondaryDialogBtnText = Color(0xFFF4F4F5),
                urgeBannerBg = Color(0xFF8B5CF6).copy(alpha = 0.2f),
                urgeBannerText = Color(0xFFDDD6FE)
            )
        } else {
            CalendarColors(
                isDark = false,
                cardBackground = Color.White,
                cardBorder = Color(0xFFE5E7EB),
                dividerColor = Color(0xFFF3F4F6),
                headerText = Color(0xFF1F2937),
                headerIconTint = Color(0xFF1F2937),
                weekdayText = Color(0xFF6B7280),
                dayNeutralFill = Color(0xFFF3F4F6),
                dayAdjacentFill = Color(0xFFF9FAFB),
                dayNeutralText = Color(0xFF1F2937),
                dayAdjacentText = Color(0xFFD1D5DB),
                todayBlue = Color(0xFF0166FF),
                successGreen = Color(0xFF10B981),
                relapseRed = Color(0xFFEF4444),
                skippedYellow = Color(0xFFF59E0B),
                urgeDot = Color(0xFF8B5CF6),
                urgeDotBorder = Color.White,
                legendText = Color(0xFF6B7280),
                dialogSurface = Color.White,
                dialogBorder = Color(0xFFE5E7EB),
                dialogTitleText = Color(0xFF1F2937),
                dialogSubtitleText = Color(0xFF6B7280),
                dialogCloseTint = Color(0xFF6B7280),
                relapseButtonContainer = Color.White,
                relapseButtonBorder = Color(0xFFEF4444),
                relapseButtonText = Color(0xFFEF4444),
                skippedButtonContainer = Color.White,
                skippedButtonBorder = Color(0xFFF59E0B),
                skippedButtonText = Color(0xFFF59E0B),
                unselectButtonText = Color(0xFF6B7280),
                secondaryDialogBtnContainer = Color.White,
                secondaryDialogBtnBorder = Color(0xFFE5E7EB),
                secondaryDialogBtnText = Color(0xFF1F2937),
                urgeBannerBg = Color(0xFF8B5CF6).copy(alpha = 0.1f),
                urgeBannerText = Color(0xFF7C3AED)
            )
        }
    }
}

/**
 * بناء شبكة الأيام لشهر محدد متضمنة أيام الأسابيع المكتملة
 */
private fun buildDaysListForMonth(
    targetMonth: YearMonth,
    calendarHistory: Map<String, DailyCalendarStatus>,
    urgeDatesSet: Set<String>,
    today: LocalDate,
    recoveryStartDate: LocalDate
): List<CalendarDayItem> {
    val list = mutableListOf<CalendarDayItem>()
    val firstDayOfMonth = targetMonth.atDay(1)
    val daysInMonth = targetMonth.lengthOfMonth()

    // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    val startOffset = firstDayOfMonth.dayOfWeek.value % 7

    // الأيام السابقة للشهر الحالي لتعبئة أول أسبوع
    val prevMonth = targetMonth.minusMonths(1)
    val daysInPrevMonth = prevMonth.lengthOfMonth()
    for (i in (daysInPrevMonth - startOffset + 1)..daysInPrevMonth) {
        val d = prevMonth.atDay(i)
        val dateKey = d.toString()
        val rawStatus = calendarHistory[dateKey]
        val effectiveStatus = when {
            rawStatus != null -> rawStatus
            d.isBefore(today) && !d.isBefore(recoveryStartDate) -> DailyCalendarStatus.SKIPPED
            else -> DailyCalendarStatus.NONE
        }
        list.add(
            CalendarDayItem(
                date = d,
                isCurrentMonth = false,
                isToday = d.isEqual(today),
                isFuture = d.isAfter(today),
                status = effectiveStatus,
                hasUrgeDefeated = urgeDatesSet.contains(dateKey)
            )
        )
    }

    // أيام الشهر الحالي
    for (day in 1..daysInMonth) {
        val d = targetMonth.atDay(day)
        val dateKey = d.toString()
        val rawStatus = calendarHistory[dateKey]
        val effectiveStatus = when {
            rawStatus != null -> rawStatus
            d.isBefore(today) && !d.isBefore(recoveryStartDate) -> DailyCalendarStatus.SKIPPED
            else -> DailyCalendarStatus.NONE
        }
        list.add(
            CalendarDayItem(
                date = d,
                isCurrentMonth = true,
                isToday = d.isEqual(today),
                isFuture = d.isAfter(today),
                status = effectiveStatus,
                hasUrgeDefeated = urgeDatesSet.contains(dateKey)
            )
        )
    }

    // الأيام اللاحقة من الشهر القادم لإكمال الصف الأخير
    val remainder = list.size % 7
    if (remainder != 0) {
        val daysToAdd = 7 - remainder
        val nextMonth = targetMonth.plusMonths(1)
        for (i in 1..daysToAdd) {
            val d = nextMonth.atDay(i)
            val dateKey = d.toString()
            val rawStatus = calendarHistory[dateKey]
            val effectiveStatus = when {
                rawStatus != null -> rawStatus
                d.isBefore(today) && !d.isBefore(recoveryStartDate) -> DailyCalendarStatus.SKIPPED
                else -> DailyCalendarStatus.NONE
            }
            list.add(
                CalendarDayItem(
                    date = d,
                    isCurrentMonth = false,
                    isToday = d.isEqual(today),
                    isFuture = d.isAfter(today),
                    status = effectiveStatus,
                    hasUrgeDefeated = urgeDatesSet.contains(dateKey)
                )
            )
        }
    }
    return list
}

/**
 * بطاقة تقويم تتبع التعافي (Recovery Tracking Calendar)
 * تدعم الوضع النهاري والوضع الليلي تلقائياً وبانسجام كامل
 */
@Composable
fun RecoveryTrackingCalendarCard(
    calendarHistory: Map<String, DailyCalendarStatus>,
    urgeDatesSet: Set<String>,
    recoveryStartTimestamp: Long,
    currentStreakDays: Int? = null,
    onSetDayStatus: (dateKey: String, status: DailyCalendarStatus) -> Unit,
    onTodaySuccess: () -> Unit,
    onRequestRelapseAutopsy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = rememberCalendarColors()
    val today = remember { LocalDate.now() }
    val minYearMonth = remember { YearMonth.of(2020, 1) }
    var currentYearMonth by remember { mutableStateOf(YearMonth.now()) }
    val canGoPrevious = currentYearMonth.isAfter(minYearMonth)
    var selectedDayForDialog by remember { mutableStateOf<CalendarDayItem?>(null) }
    var showRelapseConfirmationDialog by remember { mutableStateOf(false) }
    var showVictoryCelebrationDialog by remember { mutableStateOf(false) }
    var triggerTodayVictoryAnim by remember { mutableStateOf(false) }

    // حساب سلسلة الصمود بالأيام المحققة بدقة وبشكل متطابق تماماً مع عداد التعافي الرئيسي
    val actualStreakDays = remember(currentStreakDays, calendarHistory, recoveryStartTimestamp) {
        if (currentStreakDays != null) {
            currentStreakDays
        } else if (recoveryStartTimestamp > 0L) {
            val diffMs = System.currentTimeMillis() - recoveryStartTimestamp
            (diffMs / (1000L * 60 * 60 * 24)).toInt().coerceAtLeast(0)
        } else {
            var count = 0
            var checkDate = LocalDate.now()
            while (true) {
                val key = checkDate.toString()
                val status = calendarHistory[key]
                if (status == DailyCalendarStatus.SUCCESS || checkDate == LocalDate.now()) {
                    if (status == DailyCalendarStatus.SUCCESS) count++
                    checkDate = checkDate.minusDays(1)
                    if (count > 365) break
                } else {
                    break
                }
            }
            count.coerceAtLeast(0)
        }
    }

    val recoveryStartDate = remember(recoveryStartTimestamp) {
        if (recoveryStartTimestamp > 0L) {
            try {
                java.time.Instant.ofEpochMilli(recoveryStartTimestamp)
                    .atZone(java.time.ZoneId.systemDefault())
                    .toLocalDate()
            } catch (_: Exception) {
                today
            }
        } else {
            today
        }
    }

    // بطاقة الحاوية بتنسيق الوضع الليلي والنهاري
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = colors.cardBackground,
        border = BorderStroke(1.dp, colors.cardBorder),
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ==========================================
            // شريط العنوان والتنقل بين الأشهر
            // السهم الأيسر < يتقدم للمستقبل
            // السهم الأيمن > يعود للماضي
            // ==========================================
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // سهم لليسار (محدد بالأحمر سابقاً): يتقدم إلى المستقبل
                    IconButton(
                        onClick = { currentYearMonth = currentYearMonth.plusMonths(1) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "الشهر التالي",
                            tint = colors.headerIconTint,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // عنوان الشهر والسنة مع انتقال ناعم
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { currentYearMonth = YearMonth.now() }
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        AnimatedContent(
                            targetState = currentYearMonth,
                            transitionSpec = {
                                val isForward = targetState.isAfter(initialState)
                                val initialSlide = if (isForward) -35 else 35
                                val targetSlide = if (isForward) 35 else -35
                                (slideInHorizontally(
                                    initialOffsetX = { initialSlide },
                                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
                                ) + fadeIn(
                                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
                                )).togetherWith(
                                    slideOutHorizontally(
                                        targetOffsetX = { targetSlide },
                                        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
                                    ) + fadeOut(
                                        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
                                    )
                                )
                            },
                            label = "MonthTitleTransition"
                        ) { targetMonth ->
                            val monthName = ArabicMonthNames.getOrElse(targetMonth.monthValue - 1) { "" }
                            val yearStr = "${targetMonth.year}"
                            Text(
                                text = "$monthName $yearStr",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = colors.headerText
                            )
                        }
                    }

                    // سهم لليمين (محدد بالأسود سابقاً): يعود للماضي (لا يسمح بالرجوع تحت سنة 2020)
                    IconButton(
                        onClick = {
                            if (canGoPrevious) {
                                currentYearMonth = currentYearMonth.minusMonths(1)
                            }
                        },
                        enabled = canGoPrevious,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "الشهر السابق",
                            tint = if (canGoPrevious) colors.headerIconTint else colors.headerIconTint.copy(alpha = 0.25f),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = colors.dividerColor, thickness = 1.dp)

            // ==========================================
            // صف أسماء أيام الأسبوع (الأحد -> السبت RTL)
            // ==========================================
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WeekDayNames.forEach { dayName ->
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = dayName,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.weekdayText,
                                textAlign = TextAlign.Center,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // ==========================================
            // شبكة دوائر الأيام مع إيماءات السحب:
            // - سحب من اليسار إلى اليمين (> 0): تواريخ مستقبلية
            // - سحب من اليمين إلى اليسار (< 0): تواريخ قديمة (لا يسمح بالرجوع تحت سنة 2020)
            // ==========================================
            var accumulatedDrag by remember { mutableStateOf(0f) }
            val dragModifier = Modifier.pointerInput(currentYearMonth, canGoPrevious) {
                detectHorizontalDragGestures(
                    onDragStart = { accumulatedDrag = 0f },
                    onHorizontalDrag = { _, dragAmount ->
                        accumulatedDrag += dragAmount
                    },
                    onDragEnd = {
                        if (accumulatedDrag > 45f) {
                            currentYearMonth = currentYearMonth.plusMonths(1)
                        } else if (accumulatedDrag < -45f && canGoPrevious) {
                            currentYearMonth = currentYearMonth.minusMonths(1)
                        }
                        accumulatedDrag = 0f
                    }
                )
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                AnimatedContent(
                    targetState = currentYearMonth,
                    transitionSpec = {
                        val isForward = targetState.isAfter(initialState)
                        // سحب من اليسار إلى اليمين (المستقبل): يدخل من اليسار ويخرج لليمين بنعومة فائقة
                        // سحب من اليمين إلى اليسار (الماضي): يدخل من اليمين ويخرج لليسار بنعومة فائقة
                        (slideInHorizontally(
                            initialOffsetX = { fullWidth -> if (isForward) -fullWidth / 2 else fullWidth / 2 },
                            animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing)
                        ) + fadeIn(
                            animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing)
                        )).togetherWith(
                            slideOutHorizontally(
                                targetOffsetX = { fullWidth -> if (isForward) fullWidth / 2 else -fullWidth / 2 },
                                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing)
                            ) + fadeOut(
                                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing)
                            )
                        )
                    },
                    label = "CalendarDaysTransition",
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(dragModifier)
                ) { targetMonth ->
                    val targetDays = remember(targetMonth, calendarHistory, urgeDatesSet, today, recoveryStartDate) {
                        buildDaysListForMonth(
                            targetMonth = targetMonth,
                            calendarHistory = calendarHistory,
                            urgeDatesSet = urgeDatesSet,
                            today = today,
                            recoveryStartDate = recoveryStartDate
                        )
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val rows = targetDays.chunked(7)
                            rows.forEach { weekDays ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    weekDays.forEach { item ->
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CalendarDayCircle(
                                                item = item,
                                                colors = colors,
                                                triggerVictoryAnim = (item.isToday && triggerTodayVictoryAnim),
                                                onVictoryAnimDone = { triggerTodayVictoryAnim = false },
                                                onClick = {
                                                    if (!item.isFuture) {
                                                        selectedDayForDialog = item
                                                    }
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = colors.dividerColor, thickness = 1.dp)

            // ==========================================
            // زرا المتابعة المباشرة بجانب بعض بشكل متجاوب
            // ==========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. زر "ربحتُ المعركة اليوم"
                OutlinedButton(
                    onClick = {
                        onTodaySuccess()
                        showVictoryCelebrationDialog = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (colors.isDark) Color(0xFF13201A) else Color.White,
                        contentColor = colors.successGreen
                    ),
                    border = BorderStroke(1.5.dp, colors.successGreen),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = colors.successGreen
                        )
                        Text(
                            text = "ربحتُ المعركة اليوم",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.successGreen,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // 2. زر "خسرتُ المعركة اليوم"
                OutlinedButton(
                    onClick = { showRelapseConfirmationDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = colors.relapseButtonContainer,
                        contentColor = colors.relapseButtonText
                    ),
                    border = BorderStroke(1.5.dp, colors.relapseButtonBorder),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = colors.relapseButtonText
                        )
                        Text(
                            text = "خسرتُ المعركة اليوم",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.relapseButtonText,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }

    // ==========================================
    // نافذة اختيار / تعديل حالة اليوم المحدد (تدعم الثيم الليلي)
    // ==========================================
    selectedDayForDialog?.let { item ->
        DayStatusActionDialog(
            dayItem = item,
            colors = colors,
            onDismiss = { selectedDayForDialog = null },
            onSelectStatus = { newStatus ->
                onSetDayStatus(item.date.toString(), newStatus)
                if (newStatus == DailyCalendarStatus.SUCCESS && item.isToday) {
                    showVictoryCelebrationDialog = true
                }
                selectedDayForDialog = null
            }
        )
    }

    // ==========================================
    // نافذة الاحتفال بالانتصار (عند الضغط على ربحت المعركة)
    // ==========================================
    if (showVictoryCelebrationDialog) {
        VictoryCelebrationDialog(
            streakDays = actualStreakDays,
            onDismiss = {
                showVictoryCelebrationDialog = false
                triggerTodayVictoryAnim = true
            }
        )
    }

    // ==========================================
    // نافذة تأكيد الانتكاسة عند الضغط على زر الانتكاسة (تدعم الثيم الليلي)
    // ==========================================
    if (showRelapseConfirmationDialog) {
        RelapseActionConfirmationDialog(
            colors = colors,
            onDismiss = { showRelapseConfirmationDialog = false },
            onConfirmAutopsyAndReset = {
                showRelapseConfirmationDialog = false
                onRequestRelapseAutopsy()
            }
        )
    }
}

private enum class VictoryDayAnimPhase {
    IDLE,
    FILLING,
    CHECKMARK,
    NUMBER_RETURN
}

/**
 * دائرة اليوم في التقويم مع دعم كامل لتأثير الانتصار الهندسي
 */
@Composable
private fun CalendarDayCircle(
    item: CalendarDayItem,
    colors: CalendarColors,
    triggerVictoryAnim: Boolean = false,
    onVictoryAnimDone: () -> Unit = {},
    onClick: () -> Unit
) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val (circleBgColor, circleTextColor, isBold) = when {
        // اليوم الحالي
        item.isToday -> {
            when (item.status) {
                DailyCalendarStatus.SUCCESS -> Triple(colors.successGreen, Color.White, true)
                DailyCalendarStatus.RELAPSE -> Triple(colors.relapseRed, Color.White, true)
                else -> Triple(colors.todayBlue, Color.White, true)
            }
        }
        // أيام سابقة محددة بالحالات
        item.status == DailyCalendarStatus.SUCCESS -> Triple(colors.successGreen, Color.White, true)
        item.status == DailyCalendarStatus.RELAPSE -> Triple(colors.relapseRed, Color.White, true)
        item.status == DailyCalendarStatus.SKIPPED -> Triple(colors.skippedYellow, Color.White, true)
        // أيام عادية من الشهر الحالي
        item.isCurrentMonth -> {
            Triple(colors.dayNeutralFill, colors.dayNeutralText, true)
        }
        // أيام من الشهر السابق أو اللاحق
        else -> Triple(colors.dayAdjacentFill, colors.dayAdjacentText, false)
    }

    val isBelowMinYear = item.date.year < 2020

    // ==========================================
    // حزمة الحركة الخاصة بالانتصار في اليوم الحالي
    // ==========================================
    val fillProgress = remember { androidx.compose.animation.core.Animatable(0f) }
    var animPhase by remember { mutableStateOf(VictoryDayAnimPhase.IDLE) }

    LaunchedEffect(triggerVictoryAnim) {
        if (triggerVictoryAnim && item.isToday) {
            animPhase = VictoryDayAnimPhase.FILLING
            fillProgress.snapTo(0f)
            fillProgress.animateTo(
                targetValue = 1f,
                animationSpec = androidx.compose.animation.core.tween(320, easing = androidx.compose.animation.core.FastOutSlowInEasing)
            )
            animPhase = VictoryDayAnimPhase.CHECKMARK
            try {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
            } catch (_: Exception) {}
            kotlinx.coroutines.delay(500)
            animPhase = VictoryDayAnimPhase.NUMBER_RETURN
            kotlinx.coroutines.delay(280)
            animPhase = VictoryDayAnimPhase.IDLE
            onVictoryAnimDone()
        }
    }

    val isAnimActive = animPhase != VictoryDayAnimPhase.IDLE

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(enabled = !item.isFuture && !isBelowMinYear) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        // دائرة اليوم الأساسية (بنسبة 1:1 وهندسية دقيقة)
        Box(
            modifier = Modifier
                .fillMaxSize(0.85f)
                .aspectRatio(1f)
                .clip(CircleShape)
                .background(if (isAnimActive && animPhase == VictoryDayAnimPhase.FILLING) colors.todayBlue else circleBgColor),
            contentAlignment = Alignment.Center
        ) {
            // التعبئة الرأسية السريعة من الأسفل إلى الأعلى باللون الأخضر
            if (isAnimActive && animPhase == VictoryDayAnimPhase.FILLING) {
                androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                    val h = size.height
                    val w = size.width
                    val top = h * (1f - fillProgress.value)
                    clipRect(
                        left = 0f,
                        top = top,
                        right = w,
                        bottom = h
                    ) {
                        drawCircle(color = colors.successGreen)
                    }
                }
            }

            // المحتوى الداخلي: علامة الصح ثم رقم اليوم
            if (isAnimActive && animPhase == VictoryDayAnimPhase.CHECKMARK) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = true,
                    enter = androidx.compose.animation.scaleIn(
                        initialScale = 0.4f,
                        animationSpec = androidx.compose.animation.core.spring(
                            stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                            dampingRatio = 0.65f
                        )
                    ) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(120)),
                    exit = androidx.compose.animation.scaleOut(targetScale = 0.8f) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(150))
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "تم النصر",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            } else {
                // رقم اليوم بالإنجليزية
                Text(
                    text = "${item.date.dayOfMonth}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
                    color = circleTextColor,
                    textAlign = TextAlign.Center,
                    fontSize = 15.sp
                )
            }
        }

        // نقطة دحر الرغبة الملحة (Urge Surfing Dot)
        // توضع خارج قص الدائرة لتبقى دائرية كاملة 100% وظاهرة بكل وضوح دون أي اقتطاع
        if (item.hasUrgeDefeated) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 1.dp, end = 1.dp)
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(colors.urgeDot)
                    .border(1.5.dp, colors.urgeDotBorder, CircleShape)
            )
        }
    }
}

/**
 * عنصر مفتاح الألوان في التقويم
 */
@Composable
private fun CalendarLegendItem(
    color: Color,
    text: String,
    textColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * نافذة تحديد / تعديل حالة اليوم مع دعم الوضع الليلي والنهاري
 */
@Composable
private fun DayStatusActionDialog(
    dayItem: CalendarDayItem,
    colors: CalendarColors,
    onDismiss: () -> Unit,
    onSelectStatus: (DailyCalendarStatus) -> Unit
) {
    val monthName = ArabicMonthNames.getOrElse(dayItem.date.monthValue - 1) { "" }
    val formattedDate = "${dayItem.date.dayOfMonth} $monthName ${dayItem.date.year}"

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = colors.dialogSurface,
            border = BorderStroke(1.dp, colors.dialogBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // رأس النافذة
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "متابعة مسار اليوم",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.dialogTitleText
                        )
                        Text(
                            text = formattedDate,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.dialogSubtitleText
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = colors.dialogCloseTint
                        )
                    }
                }

                // تنبيه في حال وجود دحر رغبة في هذا اليوم
                if (dayItem.hasUrgeDefeated) {
                    Surface(
                        color = colors.urgeBannerBg,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(colors.urgeDot)
                            )
                            Text(
                                text = "تم تسجيل دحر رغبة ملحة بنجاح في هذا اليوم",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.urgeBannerText
                            )
                        }
                    }
                }

                HorizontalDivider(color = colors.dividerColor)

                // خيارات تعيين الحالة
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // خيار 1: تم سحق وحش الإباحية
                    Button(
                        onClick = { onSelectStatus(DailyCalendarStatus.SUCCESS) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .saffahPressMotion(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colors.successGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text(
                                text = "تم سحق وحش الإباحية بنجاح",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }

                    // خيار 2: انتكاسة
                    OutlinedButton(
                        onClick = { onSelectStatus(DailyCalendarStatus.RELAPSE) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .saffahPressMotion(),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = colors.relapseButtonContainer,
                            contentColor = colors.relapseButtonText
                        ),
                        border = BorderStroke(1.5.dp, colors.relapseButtonBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.WarningAmber, contentDescription = null, modifier = Modifier.size(18.dp), tint = colors.relapseButtonText)
                            Text(
                                text = "تسجيل انتكاسة لهذا اليوم",
                                fontWeight = FontWeight.Bold,
                                color = colors.relapseButtonText,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }

                    // خيار 3: تحديد كيوم تخطي
                    OutlinedButton(
                        onClick = { onSelectStatus(DailyCalendarStatus.SKIPPED) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .saffahPressMotion(),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = colors.skippedButtonContainer,
                            contentColor = colors.skippedButtonText
                        ),
                        border = BorderStroke(1.5.dp, colors.skippedButtonBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Flag, contentDescription = null, modifier = Modifier.size(18.dp), tint = colors.skippedButtonText)
                            Text(
                                text = "تحديد كيوم تخطي (لم تتم المتابعة)",
                                fontWeight = FontWeight.Bold,
                                color = colors.skippedButtonText,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }

                    // خيار 4: إلغاء التحديد (تفريغ)
                    if (dayItem.status != DailyCalendarStatus.NONE) {
                        TextButton(
                            onClick = { onSelectStatus(DailyCalendarStatus.NONE) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                        ) {
                            Text(
                                text = "إلغاء التحديد وتفريغ اليوم",
                                color = colors.unselectButtonText,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * نافذة تأكيد إجراء الانتكاسة مع دعم الوضع الليلي والنهاري
 */
@Composable
private fun RelapseActionConfirmationDialog(
    colors: CalendarColors,
    onDismiss: () -> Unit,
    onConfirmAutopsyAndReset: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = colors.dialogSurface,
            border = BorderStroke(1.dp, colors.dialogBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = null,
                        tint = colors.relapseRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "تسجيل انتكاسة وتصفير العداد الصارم",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = colors.dialogTitleText
                    )
                }

                Text(
                    text = "سيتم تسجيل اليوم كانتكاسة في التقويم وتصفير عداد التعافي لبدء مسار نقي جديد 100%. التعافي رحلة مستمرة والزلة درس عملي لسد الثغرات.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.dialogTitleText.copy(alpha = 0.85f),
                    lineHeight = 22.sp
                )

                HorizontalDivider(color = colors.dividerColor)

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // خيار تأكيد تصفير العداد والتشريح الصارم
                    Button(
                        onClick = onConfirmAutopsyAndReset,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colors.relapseRed,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "تأكيد والانتقال لتشريح الزلة الصارم",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    // خيار تراجع
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = colors.secondaryDialogBtnContainer,
                            contentColor = colors.secondaryDialogBtnText
                        ),
                        border = BorderStroke(1.dp, colors.secondaryDialogBtnBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "تراجع وإلغاء",
                            fontWeight = FontWeight.Medium,
                            color = colors.secondaryDialogBtnText,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
