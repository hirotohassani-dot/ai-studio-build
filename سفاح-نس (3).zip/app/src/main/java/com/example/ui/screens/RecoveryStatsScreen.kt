package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.*
import com.example.ui.theme.*
import com.example.util.SaffahRecoveryManager
import com.example.viewmodel.MainViewModel
import com.example.ui.components.UrgeSurfingStatsDialog
import com.example.ui.components.featureTitleHint
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.delay

/**
 * شاشة إحصائيات وأنماط التعافي (Recovery Statistics)
 * بتصميم مينيمليست بسيط ونظيف (Minimalist & Clean Bento UI)
 * دافئ، مضغوط، خالٍ من الحشو والتعقيد، ومبني على أسس علمية وسلوكية صارمة (100% Pure Days).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecoveryStatsScreen(
    viewModel: MainViewModel,
    initialTab: Int = 0,
    onBack: () -> Unit
) {
    val analytics by viewModel.recoveryAnalytics.collectAsState()
    val dailyBaselineHistory by viewModel.dailyBaselineHistory.collectAsState()
    val isFullScreenBaselineChart by viewModel.isFullScreenBaselineChart.collectAsState()

    var showLogUrgeDialog by remember { mutableStateOf(false) }
    var showBaselineCheckInDialog by remember { mutableStateOf(false) }
    var showUrgeStatsDialog by remember { mutableStateOf(false) }
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab) } // 0: الإحصائيات والمؤشرات، 1: سجل الأحداث

    val primaryAccent = PrimaryBlue

    DisposableEffect(Unit) {
        onDispose {
            viewModel.setFullScreenBaselineChart(false)
        }
    }

    if (isFullScreenBaselineChart) {
        BackHandler {
            viewModel.setFullScreenBaselineChart(false)
        }
        FullScreenBaselineScoreChartView(
            history = dailyBaselineHistory,
            onClose = { viewModel.setFullScreenBaselineChart(false) }
        )
    } else {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AnimatedContent(
                targetState = showLogUrgeDialog,
                transitionSpec = {
                    (fadeIn(animationSpec = tween(220, easing = FastOutSlowInEasing)) +
                     scaleIn(initialScale = 0.98f, animationSpec = tween(220, easing = FastOutSlowInEasing))) togetherWith
                     fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing))
                },
                label = "LogUrgeScreenTransition"
            ) { isLogUrgeOpen ->
                if (isLogUrgeOpen) {
                    BackHandler {
                        showLogUrgeDialog = false
                    }
                    LogUrgeScreen(
                        viewModel = viewModel,
                        onDismiss = { showLogUrgeDialog = false },
                        onConfirm = { intensity, trigger, technique, duration, resisted, note, customTech, customTrig, audioPath ->
                            viewModel.logUrge(intensity, trigger, technique, duration, resisted, note, customTech, customTrig, audioPath)
                            showLogUrgeDialog = false
                        }
                    )
                } else {
                    Scaffold(
                    topBar = {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            shadowElevation = 0.5.dp
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "رجوع",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "الإحصائيات والأنماط",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "تحليل سلوكي وعصبي صارم لنقاء المسار",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 14.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // تبويبات العرض البسيطة
                item(key = "stats_tab_selector") {
                    MinimalTabSelector(
                        selectedTab = selectedTab,
                        onTabSelected = { selectedTab = it }
                    )
                }

                if (selectedTab == 0) {
                    // 1. مؤشر خط الأساس اليومي التفاعلي (Interactive Daily Baseline Line Chart) - الأهم والأكثر استخداماً يومياً
                    item(key = "section_daily_baseline_chart") {
                        MinimalBaselineScoreChartCard(
                            history = dailyBaselineHistory,
                            onDeleteEntry = { id -> viewModel.deleteDailyBaselineCheckIn(id) },
                            onOpenCheckInDialog = { showBaselineCheckInDialog = true },
                            onExpandFullScreen = { viewModel.setFullScreenBaselineChart(true) }
                        )
                    }

                    // 2. بطاقة دحر ومقاومة الرغبات (Urge Surfing & Craving Defense) - استخدام تفاعلي مباشر عند هجوم الرغبات
                    item(key = "section_urge_surfing") {
                        MinimalUrgeSurfingCard(
                            analytics = analytics.urgeAnalytics,
                            onLogUrgeClick = { showLogUrgeDialog = true },
                            onOpenUrgeStatsClick = { showUrgeStatsDialog = true }
                        )
                    }

                    // 3. قسم أخطر الأوقات 24h (Minimal Times Risk Chart) - ساعات الذروة اليومية للحذر الفوري
                    item(key = "section_most_dangerous_times") {
                        MinimalTimesRiskCard(timeRiskStats = analytics.timeRiskStats)
                    }

                    // 4. تحليل المحفزات السلوكية ونموذج HALT - الأسباب السلوكية ونقاط الضعف
                    item(key = "section_triggers_breakdown") {
                        MinimalTriggersBreakdownCard(triggerStats = analytics.triggerStats)
                    }

                    // 5. قسم أخطر الأيام (Minimal Days Risk Chart) - توزيع الأيام الأسبوعية
                    item(key = "section_most_dangerous_days") {
                        MinimalDaysRiskCard(dayRiskStats = analytics.dayRiskStats)
                    }

                    // 6. مؤشر تتبع سرعة التعافي ومقارنة التحسن - تحليل تراكمي طويل المدى
                    item(key = "section_recovery_velocity_tracker") {
                        MinimalRecoveryVelocityCard(analytics = analytics)
                    }

                } else {
                    // سجل التواريخ وتشريح الانتكاسات
                    item(key = "relapse_history_header") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "سجل الأحداث والتشريح (${analytics.history.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.featureTitleHint("relapse_history_log")
                            )

                            if (analytics.history.isNotEmpty()) {
                                TextButton(
                                    onClick = { viewModel.clearAllRelapses() },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "مسح السجل",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }

                    if (analytics.history.isEmpty()) {
                        item(key = "empty_relapse_history") {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircleOutline,
                                        contentDescription = null,
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Text(
                                        text = "السجل نظيف تماماً بنقاء 100%",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "لم يتم تسجيل أي انتكاسات. استمر في الحفاظ على النقاء التام.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    } else {
                        items(
                            items = analytics.history,
                            key = { it.id }
                        ) { record ->
                            Box(
                                modifier = Modifier.animateItem(
                                    fadeInSpec = tween(220, easing = SaffahMotion.EmphasizedDecelerate),
                                    fadeOutSpec = tween(180, easing = SaffahMotion.EmphasizedAccelerate),
                                    placementSpec = androidx.compose.animation.core.spring(
                                        stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
                                        dampingRatio = 0.8f
                                    )
                                )
                            ) {
                                RelapseHistoryItemCard(
                                    record = record,
                                    onDelete = { viewModel.deleteRelapseRecord(record.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showUrgeStatsDialog) {
            UrgeSurfingStatsDialog(
                viewModel = viewModel,
                onDismiss = { showUrgeStatsDialog = false }
            )
        }

        if (showBaselineCheckInDialog) {
            BaselineCheckInDialog(
                onDismiss = { showBaselineCheckInDialog = false },
                onConfirm = { clarity, mood, sleep, energy ->
                    viewModel.saveDailyBaselineCheckIn(clarity, mood, sleep, energy)
                    showBaselineCheckInDialog = false
                }
            )
        }
    }
}
}
}
}

/**
 * محدد التبويبات البسيط النظيف
 */
@Composable
private fun MinimalTabSelector(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            val tabs = listOf("المؤشرات والتحليل العلمي", "سجل الأحداث والتشريح")
            tabs.forEachIndexed { index, title ->
                val isSelected = selectedTab == index
                Surface(
                    shape = RoundedCornerShape(9.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
                    shadowElevation = if (isSelected) 1.dp else 0.dp,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .clickable { onTabSelected(index) }
                ) {
                    Text(
                        text = title,
                        modifier = Modifier.padding(vertical = 9.dp),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * 2. بطاقة دحر ومقاومة الرغبات السلوكية (Urge Surfing & Craving Defense)
 */
@Composable
private fun MinimalUrgeSurfingCard(
    analytics: UrgeSurfingAnalytics,
    onLogUrgeClick: () -> Unit,
    onOpenUrgeStatsClick: () -> Unit
) {
    val primaryBlue = Color(0xFF0166FF)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 0.5.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Waves,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "دحر الرغبات",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.featureTitleHint("urge_defense_stats")
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = primaryBlue.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${(analytics.resistanceSuccessRate * 100).toInt()}% نسبة الصمود",
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                .featureTitleHint("urge_resistance_rate"),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = primaryBlue
                        )
                    }

                    // Raw black/line icon without text for clean visual balance and stats access
                    IconButton(
                        onClick = onOpenUrgeStatsClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.BarChart,
                            contentDescription = "إحصائيات وسجل دحر الرغبات",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // إحصائيات المقاومة المدمجة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "نوبات تم دحرها",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.5.sp,
                            modifier = Modifier.featureTitleHint("urge_surfing_victories")
                        )
                        Text(
                            text = "${analytics.totalUrgesDefeated} نوبة",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = primaryBlue
                        )
                    }
                }

                Surface(
                    modifier = Modifier.weight(1.4f),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "التقنية الأكثر فعالية",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.5.sp,
                            modifier = Modifier.featureTitleHint("urge_effective_technique")
                        )
                        Text(
                            text = analytics.mostEffectiveTechniqueTitle.split("(").first().trim(),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // زر تسجيل دحر رغبة فوري
            Button(
                onClick = onLogUrgeClick,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primaryBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تسجيل وتجاوز رغبة ملحة فورية",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * 3. تحليل المحفزات السلوكية ونموذج HALT
 */
@Composable
private fun MinimalTriggersBreakdownCard(triggerStats: List<TriggerStat>) {
    val hasData = triggerStats.any { it.count > 0 }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 0.5.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Insights,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "تشريح المحفزات السلوكية",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.featureTitleHint("triggers_breakdown_analysis")
                    )
                }

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "كشف الثغرة",
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.5.sp
                    )
                }
            }

            if (!hasData) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "لم يتم رصد أي محفزات حتى الآن. عند تسجيل أي تشريح سيتم ترتيب وتصنيف نقاط الضعف السلوكية تلقائياً.",
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            } else {
                val topTriggers = triggerStats.filter { it.count > 0 }.take(4)
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    topTriggers.forEachIndexed { index, item ->
                        val indicatorColor = when (index) {
                            0 -> Color(0xFF0166FF)
                            1 -> Color(0xFF2563EB)
                            2 -> Color(0xFF60A5FA)
                            else -> Color(0xFF93C5FD)
                        }
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.trigger.title,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (item.isPrimary) FontWeight.Bold else FontWeight.Medium,
                                    color = if (item.isPrimary) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.5.sp
                                )
                                Text(
                                    text = "${(item.percentage * 100).toInt()}% (${item.count} زلة)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = indicatorColor,
                                    fontSize = 11.5.sp
                                )
                            }

                            LinearProgressIndicator(
                                progress = { item.percentage },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = indicatorColor,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 4. مؤشر تتبع سرعة التعافي ومقارنة التحسن
 */
@Composable
private fun MinimalRecoveryVelocityCard(analytics: RecoveryAnalytics) {
    var selectedWindow by remember { mutableStateOf(VelocityTimeWindow.PAST_WEEK) }
    val metrics = analytics.velocityMetricsMap[selectedWindow] ?: return
    val primaryBlue = Color(0xFF0166FF)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 0.5.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Speed,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "تتبع سرعة التعافي",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.featureTitleHint("recovery_velocity_tracker")
                    )
                }

                Surface(
                    color = primaryBlue.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = metrics.velocityLevelTitle,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = primaryBlue
                    )
                }
            }

            // فلاتر الفترات الزمنية
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VelocityTimeWindow.values().forEach { window ->
                    val isSelected = window == selectedWindow
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) primaryBlue.copy(alpha = 0.08f) else Color.Transparent,
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) primaryBlue.copy(alpha = 0.35f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedWindow = window }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = window.shortLabel,
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) primaryBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // محتوى التحليل في إطار هادئ ومرتب
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = metrics.comparisonInsight,
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

/**
 * 5. قسم أخطر الأيام (أيام الأسبوع RTL من السبت للجمعة)
 */
@Composable
private fun MinimalDaysRiskCard(dayRiskStats: List<DayRiskStat>) {
    val peakDay = dayRiskStats.find { it.isPeak }
    val maxCount = dayRiskStats.maxOfOrNull { it.count } ?: 0
    val primaryBlue = Color(0xFF0166FF)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 0.5.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "أخطر الأيام",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.featureTitleHint("day_risk_analysis")
                    )
                }

                if (peakDay != null && peakDay.count > 0) {
                    Surface(
                        color = primaryBlue.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "الذروة: ${peakDay.arabicName}",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = primaryBlue
                        )
                    }
                }
            }

            // مخطط الأيام ذو المساحات المنظمة والمريحة للعين
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.20f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    dayRiskStats.forEach { dayStat ->
                        val heightFraction = if (maxCount > 0) (dayStat.count.toFloat() / maxCount.toFloat()).coerceIn(0.08f, 1f) else 0.08f
                        val barColor = when {
                            dayStat.isPeak && dayStat.count > 0 -> primaryBlue
                            dayStat.count > 0 -> Color(0xFF60A5FA)
                            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (dayStat.count > 0) "${dayStat.count}" else "-",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                                fontWeight = if (dayStat.count > 0) FontWeight.Bold else FontWeight.Normal,
                                color = when {
                                    dayStat.isPeak && dayStat.count > 0 -> primaryBlue
                                    dayStat.count > 0 -> Color(0xFF3B82F6)
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
                                }
                            )

                            Box(
                                modifier = Modifier
                                    .width(14.dp)
                                    .height((52 * heightFraction).dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(barColor)
                            )

                            Text(
                                text = dayStat.shortName,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                                fontWeight = if (dayStat.isPeak && dayStat.count > 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (dayStat.isPeak && dayStat.count > 0) primaryBlue else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 6. قسم أخطر الأوقات
 */
@Composable
private fun MinimalTimesRiskCard(timeRiskStats: List<TimeRiskStat>) {
    val peakTime = timeRiskStats.find { it.isPeak }
    val maxCount = timeRiskStats.maxOfOrNull { it.count } ?: 0
    val primaryBlue = Color(0xFF0166FF)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 0.5.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AccessTime,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "أخطر الأوقات",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.featureTitleHint("time_risk_analysis")
                    )
                }

                if (peakTime != null && peakTime.count > 0) {
                    Surface(
                        color = primaryBlue.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "الذروة: ${peakTime.rangeKey}",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = primaryBlue
                        )
                    }
                }
            }

            // قائمة النطاقات الزمنية بتصميم أفقي مريح مع مسافات متناسقة
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                timeRiskStats.forEach { timeStat ->
                    val barFraction = if (maxCount > 0) (timeStat.count.toFloat() / maxCount.toFloat()).coerceIn(0.04f, 1f) else 0.04f
                    val barColor = when {
                        timeStat.isPeak && timeStat.count > 0 -> primaryBlue
                        timeStat.count > 0 -> Color(0xFF60A5FA)
                        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = timeStat.rangeKey,
                            modifier = Modifier.width(96.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 11.5.sp,
                            fontWeight = if (timeStat.isPeak && timeStat.count > 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (timeStat.isPeak && timeStat.count > 0) primaryBlue else MaterialTheme.colorScheme.onSurface
                        )

                        LinearProgressIndicator(
                            progress = { barFraction },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = barColor,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )

                        Text(
                            text = if (timeStat.count > 0) "${timeStat.count}" else "-",
                            modifier = Modifier.width(28.dp),
                            textAlign = TextAlign.End,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (timeStat.count > 0) FontWeight.Bold else FontWeight.Normal,
                            color = when {
                                timeStat.isPeak && timeStat.count > 0 -> primaryBlue
                                timeStat.count > 0 -> Color(0xFF3B82F6)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * بطاقة عنصر سجل الانتكاسات مع المحفز وخطة الدفاع
 */
@Composable
private fun RelapseHistoryItemCard(
    record: RelapseRecord,
    onDelete: () -> Unit
) {
    val cal = remember(record.timestamp) {
        Calendar.getInstance().apply { timeInMillis = record.timestamp }
    }
    val formattedDate = remember(record.timestamp) {
        val sdf = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.US)
        sdf.format(Date(record.timestamp))
    }
    val dayName = remember(cal) {
        when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY -> "السبت"
            Calendar.SUNDAY -> "الأحد"
            Calendar.MONDAY -> "الإثنين"
            Calendar.TUESDAY -> "الثلاثاء"
            Calendar.WEDNESDAY -> "الأربعاء"
            Calendar.THURSDAY -> "الخميس"
            Calendar.FRIDAY -> "الجمعة"
            else -> ""
        }
    }

    val triggerObj = remember(record.triggerId) {
        RelapseTrigger.values().find { it.id == record.triggerId } ?: RelapseTrigger.OTHER
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)),
        shadowElevation = 0.5.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = dayName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "($formattedDate)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.10f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = triggerObj.title,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }

                if (record.initialSpark.isNotBlank()) {
                    Text(
                        text = "الشرارة: ${record.initialSpark}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (record.loopholeType.isNotBlank()) {
                    Text(
                        text = "الثغرة: ${record.loopholeType}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (record.haltMoodState.isNotBlank()) {
                    Text(
                        text = "الحالة المزاجية: ${record.haltMoodState}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (record.note.isNotBlank()) {
                    Text(
                        text = "الملاحظة: ${record.note}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                val effectiveDefense = record.preventiveDecision.ifBlank { record.defenseAction }
                if (effectiveDefense.isNotBlank()) {
                    Text(
                        text = "القرار الوقائي: $effectiveDefense",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF10B981),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(32.dp)
                    .saffahPressMotion()
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}


/**
 * شاشة توثيق الرغبات الملحة (Urge Surfing Log Screen)
 * شاشة كاملة بتصميم Bento UI مينيمليست أنيق ومريح للعين، خالٍ من التعقيد والحشو
 */
@Composable
private fun LogUrgeScreen(
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    onConfirm: (UrgeIntensity, RelapseTrigger, UrgeDefenseTechnique, Int, Boolean, String, String, String, String?) -> Unit
) {
    val context = LocalContext.current
    val customTechniquesList by viewModel.customDefenseTechniques.collectAsState()
    val customTriggersList by viewModel.customTriggers.collectAsState()

    var selectedIntensity by remember { mutableStateOf(UrgeIntensity.STRONG) }
    var selectedTrigger by remember { mutableStateOf<RelapseTrigger?>(RelapseTrigger.BOREDOM) }
    var selectedCustomTrigger by remember { mutableStateOf<String?>(null) }
    var isCustomTriggerSelected by remember { mutableStateOf(false) }
    var customTriggerText by remember { mutableStateOf("") }

    var selectedTechnique by remember { mutableStateOf<UrgeDefenseTechnique?>(UrgeDefenseTechnique.MINUTES_15_RULE) }
    var selectedCustomTechnique by remember { mutableStateOf<String?>(null) }
    var isCustomTechniqueSelected by remember { mutableStateOf(false) }
    var customTechniqueText by remember { mutableStateOf("") }

    var durationMinutes by remember { mutableIntStateOf(15) }
    var resistedSuccessfully by remember { mutableStateOf(true) }
    var noteText by remember { mutableStateOf("") }

    // Audio recording states
    val audioRecorder = remember { com.example.util.SaffahAudioRecorder(context) }
    var isRecording by remember { mutableStateOf(false) }
    var recordedAudioPath by remember { mutableStateOf<String?>(null) }
    var recordingSeconds by remember { mutableIntStateOf(0) }

    val playbackState by viewModel.audioPlayer.playbackState.collectAsState()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val file = File(context.filesDir, "urge_rec_${System.currentTimeMillis()}.m4a")
            if (audioRecorder.startRecording(file)) {
                isRecording = true
                recordedAudioPath = null
            } else {
                Toast.makeText(context, "تعذر بدء التسجيل الصوتي", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "يلزم منح إذن الميكروفون للتسجيل", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordingSeconds = 0
            while (isRecording) {
                delay(1000L)
                recordingSeconds++
            }
        }
    }

    LaunchedEffect(playbackState.isPlaying) {
        while (playbackState.isPlaying) {
            delay(200L)
            viewModel.audioPlayer.updateProgress()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            if (audioRecorder.isCurrentlyRecording()) {
                audioRecorder.stopRecording()
            }
            viewModel.audioPlayer.stopAudio()
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 0.5.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "توثيق الرغبات الملحة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "تسجيل تفاصيل الموجة لتعزيز استجابة الفص الجبهي وتجاوز الإلحاح",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. شدة الموجة (2x2 Grid)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "شدة الموجة",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            ) {
                                Text(
                                    text = "المستوى ${selectedIntensity.levelNumber} من 4",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        val intensityItems = listOf(
                            Triple(UrgeIntensity.MILD, "خفيفة", "تشتت عابر"),
                            Triple(UrgeIntensity.MODERATE, "متوسطة", "إلحاح متصاعد"),
                            Triple(UrgeIntensity.STRONG, "شديدة", "ضغط ذهني قوي"),
                            Triple(UrgeIntensity.CRITICAL, "حرجة", "ذروة النوبة")
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                intensityItems.take(2).forEach { (intensity, mainTitle, subTitle) ->
                                    val isSelected = selectedIntensity == intensity

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(
                                            1.dp,
                                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { selectedIntensity = intensity }
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Text(
                                                text = mainTitle,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = subTitle,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.sp,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                intensityItems.drop(2).forEach { (intensity, mainTitle, subTitle) ->
                                    val isSelected = selectedIntensity == intensity

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(
                                            1.dp,
                                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { selectedIntensity = intensity }
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Text(
                                                text = mainTitle,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = subTitle,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.sp,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. المحفز المباشر (خيارات + محفز يدوي)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "المحفز المباشر",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        val triggersList = listOf(
                            RelapseTrigger.BOREDOM to "الفراغ والملل",
                            RelapseTrigger.LATE_NIGHT to "السهر والخلوة",
                            RelapseTrigger.RANDOM_BROWSING to "التصفح العشوائي",
                            RelapseTrigger.STRESS to "الضغط والتوتر"
                        )
                        val builtInTriggerNames = triggersList.map { it.second }
                        val filteredCustomTriggers = customTriggersList.filter { custom ->
                            builtInTriggerNames.none { it.equals(custom, ignoreCase = true) }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                triggersList.take(2).forEach { (trigger, label) ->
                                    val isSelected = !isCustomTriggerSelected && selectedCustomTrigger == null && selectedTrigger == trigger
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(
                                            1.dp,
                                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable {
                                                isCustomTriggerSelected = false
                                                selectedCustomTrigger = null
                                                selectedTrigger = trigger
                                            }
                                    ) {
                                        Text(
                                            text = label,
                                            modifier = Modifier.padding(vertical = 9.dp, horizontal = 4.dp),
                                            textAlign = TextAlign.Center,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                triggersList.drop(2).forEach { (trigger, label) ->
                                    val isSelected = !isCustomTriggerSelected && selectedCustomTrigger == null && selectedTrigger == trigger
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(
                                            1.dp,
                                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable {
                                                isCustomTriggerSelected = false
                                                selectedCustomTrigger = null
                                                selectedTrigger = trigger
                                            }
                                    ) {
                                        Text(
                                            text = label,
                                            modifier = Modifier.padding(vertical = 9.dp, horizontal = 4.dp),
                                            textAlign = TextAlign.Center,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            // عرض المحفزات المخصصة المحفوظة سابقاً
                            filteredCustomTriggers.forEach { customTrig ->
                                val isSelected = !isCustomTriggerSelected && selectedCustomTrigger == customTrig
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            isCustomTriggerSelected = false
                                            selectedCustomTrigger = customTrig
                                            selectedTrigger = null
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = customTrig,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            if (isSelected) {
                                                Icon(
                                                    imageVector = Icons.Outlined.CheckCircle,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .clickable {
                                                        if (selectedCustomTrigger == customTrig) {
                                                            selectedCustomTrigger = null
                                                            selectedTrigger = RelapseTrigger.BOREDOM
                                                        }
                                                        viewModel.deleteCustomTrigger(customTrig)
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Close,
                                                    contentDescription = "حذف المحفز المحفوظ",
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // خيار إضافة محفز يدوي
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isCustomTriggerSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.dp,
                                    if (isCustomTriggerSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        isCustomTriggerSelected = true
                                        selectedCustomTrigger = null
                                        selectedTrigger = null
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Edit,
                                        contentDescription = null,
                                        tint = if (isCustomTriggerSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (customTriggerText.isNotBlank() && isCustomTriggerSelected) "محفز يدوي: $customTriggerText" else "إضافة محفز مباشر بشكل يدوي...",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (isCustomTriggerSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isCustomTriggerSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (isCustomTriggerSelected) {
                                OutlinedTextField(
                                    value = customTriggerText,
                                    onValueChange = { customTriggerText = it },
                                    placeholder = {
                                        Text(
                                            "اكتب المحفز المباشر يدوياً (مثال: محادثة مزعجة، مكان معين...)",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                        )
                                    },
                                    trailingIcon = {
                                        if (customTriggerText.isNotBlank()) {
                                            IconButton(
                                                onClick = {
                                                    val trimmed = customTriggerText.trim()
                                                    if (trimmed.isNotBlank()) {
                                                        viewModel.saveCustomTrigger(trimmed)
                                                        selectedCustomTrigger = trimmed
                                                        isCustomTriggerSelected = false
                                                        customTriggerText = ""
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "حفظ المحفز كخيار",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    )
                                )
                            }
                        }
                    }
                }

                // 3. التقنية الدفاعية المطبقة (خيارات + تقنية دفاعية يدوية)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "التقنية الدفاعية المطبقة",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        val techniques = listOf(
                            UrgeDefenseTechnique.MINUTES_15_RULE,
                            UrgeDefenseTechnique.COLD_WATER_RESET,
                            UrgeDefenseTechnique.BREATHING_478,
                            UrgeDefenseTechnique.PHONE_DISPLACEMENT
                        )
                        val builtInTitles = techniques.map { it.title }
                        val filteredCustomTechniques = customTechniquesList.filter { custom ->
                            builtInTitles.none { it.equals(custom, ignoreCase = true) }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            techniques.forEach { tech ->
                                val isSelected = !isCustomTechniqueSelected && selectedCustomTechnique == null && selectedTechnique == tech
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            isCustomTechniqueSelected = false
                                            selectedCustomTechnique = null
                                            selectedTechnique = tech
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = tech.title,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )

                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Outlined.CheckCircle,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // عرض التقنيات الدفاعية المخصصة المضافة والمحفوظة سابقاً
                            filteredCustomTechniques.forEach { customTech ->
                                val isSelected = !isCustomTechniqueSelected && selectedCustomTechnique == customTech
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            isCustomTechniqueSelected = false
                                            selectedCustomTechnique = customTech
                                            selectedTechnique = null
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = customTech,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            if (isSelected) {
                                                Icon(
                                                    imageVector = Icons.Outlined.CheckCircle,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .clickable {
                                                        if (selectedCustomTechnique == customTech) {
                                                            selectedCustomTechnique = null
                                                            selectedTechnique = UrgeDefenseTechnique.MINUTES_15_RULE
                                                        }
                                                        viewModel.deleteCustomDefenseTechnique(customTech)
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Close,
                                                    contentDescription = "حذف التقنية المحفوظة",
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // خيار إضافة تقنية دفاعية يدوية
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isCustomTechniqueSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.dp,
                                    if (isCustomTechniqueSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        isCustomTechniqueSelected = true
                                        selectedCustomTechnique = null
                                        selectedTechnique = null
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Add,
                                        contentDescription = null,
                                        tint = if (isCustomTechniqueSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (customTechniqueText.isNotBlank() && isCustomTechniqueSelected) "تقنية يدوية: $customTechniqueText" else "إضافة تقنية دفاعية مطبقة بشكل يدوي...",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (isCustomTechniqueSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isCustomTechniqueSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (isCustomTechniqueSelected) {
                                OutlinedTextField(
                                    value = customTechniqueText,
                                    onValueChange = { customTechniqueText = it },
                                    placeholder = {
                                        Text(
                                            "اكتب التقنية المطبقة يدوياً (مثال: الوضوء، المشي السريع، الاتصال بصديق...)",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                        )
                                    },
                                    trailingIcon = {
                                        if (customTechniqueText.isNotBlank()) {
                                            IconButton(
                                                onClick = {
                                                    val trimmed = customTechniqueText.trim()
                                                    if (trimmed.isNotBlank()) {
                                                        viewModel.saveCustomDefenseTechnique(trimmed)
                                                        selectedCustomTechnique = trimmed
                                                        isCustomTechniqueSelected = false
                                                        customTechniqueText = ""
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "حفظ التقنية كخيار",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    )
                                )
                            }
                        }
                    }
                }

                // 4. توثيق صوتي للنوبة (Audio Recording)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "توثيق صوتي للنوبة",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Icon(
                                imageVector = Icons.Outlined.Mic,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        when {
                            isRecording -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Surface(
                                                shape = CircleShape,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(10.dp)
                                            ) {}
                                            val minutes = recordingSeconds / 60
                                            val seconds = recordingSeconds % 60
                                            Text(
                                                text = String.format(Locale.ENGLISH, "جاري التسجيل: %02d:%02d", minutes, seconds),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                val finishedFile = audioRecorder.stopRecording()
                                                isRecording = false
                                                if (finishedFile != null && finishedFile.exists()) {
                                                    recordedAudioPath = finishedFile.absolutePath
                                                }
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Stop,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = Color.White
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("إيقاف وحفظ", fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }

                            recordedAudioPath != null -> {
                                val isPlaying = playbackState.isPlaying && playbackState.currentFilePath == recordedAudioPath
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            IconButton(
                                                onClick = {
                                                    val path = recordedAudioPath ?: return@IconButton
                                                    if (isPlaying) {
                                                        viewModel.audioPlayer.pauseAudio()
                                                    } else {
                                                        viewModel.audioPlayer.playAudio(path)
                                                    }
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (isPlaying) Icons.Outlined.PauseCircle else Icons.Outlined.PlayCircle,
                                                    contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل",
                                                    tint = MaterialTheme.colorScheme.onSurface,
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }

                                            Column {
                                                Text(
                                                    text = "تم توثيق المقطع بنجاح",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                val totalSeconds = (playbackState.durationMs / 1000).coerceAtLeast(0)
                                                val currentSeconds = (playbackState.currentPositionMs / 1000).coerceAtLeast(0)
                                                val timeText = if (isPlaying) {
                                                    String.format(Locale.ENGLISH, "%02d:%02d / %02d:%02d", currentSeconds / 60, currentSeconds % 60, totalSeconds / 60, totalSeconds % 60)
                                                } else {
                                                    "جاهز للحفظ مع السجل"
                                                }
                                                Text(
                                                    text = timeText,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        IconButton(
                                            onClick = {
                                                viewModel.audioPlayer.stopAudio()
                                                recordedAudioPath?.let { File(it).delete() }
                                                recordedAudioPath = null
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.DeleteOutline,
                                                contentDescription = "حذف التسجيل",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            else -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            val permission = android.Manifest.permission.RECORD_AUDIO
                                            val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                                                context,
                                                permission
                                            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                            if (hasPermission) {
                                                val file = File(context.filesDir, "urge_rec_${System.currentTimeMillis()}.m4a")
                                                if (audioRecorder.startRecording(file)) {
                                                    isRecording = true
                                                    recordedAudioPath = null
                                                } else {
                                                    Toast.makeText(context, "تعذر بدء التسجيل الصوتي", Toast.LENGTH_SHORT).show()
                                                }
                                            } else {
                                                micPermissionLauncher.launch(permission)
                                            }
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Mic,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "تسجيل مقطع صوتي لتوثيق النوبة",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. عنصرا الاختيار لنتيجة التعامل مع الرغبة (تم دحر الرغبة بنجاح / فشل دحر الرغبة)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // الخيار الأول: تم دحر الرغبة بنجاح
                    Surface(
                        onClick = { resistedSuccessfully = true },
                        shape = RoundedCornerShape(14.dp),
                        color = if (resistedSuccessfully) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            width = if (resistedSuccessfully) 1.5.dp else 1.dp,
                            color = if (resistedSuccessfully) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (resistedSuccessfully) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.CheckCircle,
                                        contentDescription = null,
                                        tint = if (resistedSuccessfully) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "تم دحر الرغبة بنجاح",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (resistedSuccessfully) FontWeight.Bold else FontWeight.SemiBold,
                                    color = if (resistedSuccessfully) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "ترسيخ المسار العصبي للفص الجبهي وتجاوز الموجة",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.5.sp
                                )
                            }
                        }
                    }

                    // الخيار الثاني: فشل دحر الرغبة
                    Surface(
                        onClick = { resistedSuccessfully = false },
                        shape = RoundedCornerShape(14.dp),
                        color = if (!resistedSuccessfully) MaterialTheme.colorScheme.error.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            width = if (!resistedSuccessfully) 1.5.dp else 1.dp,
                            color = if (!resistedSuccessfully) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (!resistedSuccessfully) MaterialTheme.colorScheme.error.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.Close,
                                        contentDescription = null,
                                        tint = if (!resistedSuccessfully) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "فشل دحر الرغبة",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (!resistedSuccessfully) FontWeight.Bold else FontWeight.SemiBold,
                                    color = if (!resistedSuccessfully) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "تسجيل النوبة لرصد المحفز والتعلم من التجربة",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.5.sp
                                )
                            }
                        }
                    }
                }

                // 6. حقل الملاحظة أو الدرس المستفاد
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    placeholder = {
                        Text(
                            "ملاحظة أو فكرة ساعدت في التجاوز (اختياري)",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                // أزرار الإجراء: تأكيد التوثيق وتثبيت التقدم + إلغاء
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            val effectiveTrigger = when {
                                isCustomTriggerSelected && customTriggerText.isNotBlank() -> RelapseTrigger.OTHER
                                selectedCustomTrigger != null -> RelapseTrigger.OTHER
                                else -> selectedTrigger ?: RelapseTrigger.BOREDOM
                            }
                            val effectiveTechnique = when {
                                isCustomTechniqueSelected && customTechniqueText.isNotBlank() -> UrgeDefenseTechnique.OTHER
                                selectedCustomTechnique != null -> UrgeDefenseTechnique.OTHER
                                else -> selectedTechnique ?: UrgeDefenseTechnique.MINUTES_15_RULE
                            }
                            val customTech = when {
                                isCustomTechniqueSelected && customTechniqueText.isNotBlank() -> customTechniqueText.trim()
                                selectedCustomTechnique != null -> selectedCustomTechnique?.trim().orEmpty()
                                else -> ""
                            }
                            val customTrig = when {
                                isCustomTriggerSelected && customTriggerText.isNotBlank() -> customTriggerText.trim()
                                selectedCustomTrigger != null -> selectedCustomTrigger?.trim().orEmpty()
                                else -> ""
                            }

                            onConfirm(
                                selectedIntensity,
                                effectiveTrigger,
                                effectiveTechnique,
                                durationMinutes,
                                resistedSuccessfully,
                                noteText.trim(),
                                customTech,
                                customTrig,
                                recordedAudioPath
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (resistedSuccessfully) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(
                            imageVector = if (resistedSuccessfully) Icons.Outlined.Check else Icons.Outlined.CheckCircleOutline,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (resistedSuccessfully) "توثيق الانتصار وتثبيت التقدم" else "توثيق النتيجة وتثبيت التقدم",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    Surface(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Box(
                            modifier = Modifier.padding(horizontal = 22.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "إلغاء",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
    }
}

// ==========================================
// مؤشر خط الأساس اليومي - المخطط الخطي التفاعلي
// ==========================================

/**
 * بطاقة مخطط مؤشر خط الأساس اليومي التفاعلي (Interactive Daily Baseline Score Chart Card)
 * تصميم مينيمليست مطابق للتصميم المطلوب:
 * - Score بالخط العريض في البداية مع محدد زمني في النهاية (Day / Week / Month)
 * - محور عمودي للنسب المئوية (100%, 80%, 60%, 40%, 20%) مع خطوط شبكة أفقية
 * - محور أفقي للأيام مع أسماء الشهور/الأعوام
 * - خط أزرق نيلي يربط النقاط الدائرية
 * - تفاعل باللمس لعرض تفاصيل المقاييس الأربعة
 * - يعتمد حصراً على السجلات الفعلية دون أي تقدير تلقائي للأيام المفقودة
 */
@Composable
fun MinimalBaselineScoreChartCard(
    history: List<DailyBaselineCheckIn>,
    onDeleteEntry: (String) -> Unit,
    onOpenCheckInDialog: () -> Unit,
    onExpandFullScreen: () -> Unit
) {
    val context = LocalContext.current
    var selectedPeriod by remember { mutableStateOf(BaselineChartPeriod.DAY) }
    var showPeriodDropdown by remember { mutableStateOf(false) }

    val dataPoints = remember(history, selectedPeriod) {
        SaffahRecoveryManager.getBaselineDataPoints(context, selectedPeriod)
    }

    var selectedPointIndex by remember(dataPoints) {
        mutableIntStateOf(if (dataPoints.isNotEmpty()) dataPoints.size - 1 else -1)
    }

    val selectedPoint = remember(dataPoints, selectedPointIndex) {
        if (selectedPointIndex in dataPoints.indices) dataPoints[selectedPointIndex] else dataPoints.lastOrNull()
    }

    val chartLineColor = Color(0xFF0166FF) // Primary accent blue #0166FF
    val gridLineColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
    val textLabelColor = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shadowElevation = 0.5.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header and Chart in LTR layout to strictly match the design specification
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. Header (Minimalist Line Expand Icon on Start/Left, Title, Dropdown Filter on End/Right)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Minimalist line expand icon (no text, no fill)
                            IconButton(
                                onClick = onExpandFullScreen,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fullscreen,
                                    contentDescription = "عرض المخطط بالشاشة الكاملة",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Text(
                                text = "مؤشر التعافي",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.featureTitleHint("daily_baseline_chart")
                            )
                        }

                        // Filter Dropdown / Selector
                        Box {
                            Surface(
                                onClick = { showPeriodDropdown = true },
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = selectedPeriod.titleAr,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "تغيير الفترة",
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showPeriodDropdown,
                                onDismissRequest = { showPeriodDropdown = false }
                            ) {
                                BaselineChartPeriod.values().forEach { period ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = period.titleAr,
                                                fontWeight = if (selectedPeriod == period) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        onClick = {
                                            selectedPeriod = period
                                            showPeriodDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // 2. Chart View
                    if (dataPoints.isEmpty()) {
                        // Empty state with clean grid outline
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .background(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShowChart,
                                    contentDescription = null,
                                    tint = chartLineColor.copy(alpha = 0.6f),
                                    modifier = Modifier.size(32.dp)
                                )
                                Text(
                                    text = "لا توجد سجلات فحص خط أساس بعد",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "قم بإجراء الفحص اليومي السريع من واجهة العداد لتبدأ في رسم المنحنى البياني بدقة.",
                                    style = MaterialTheme.typography.labelSmall,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = onOpenCheckInDialog,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = chartLineColor,
                                        contentColor = Color.White
                                    ),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "توثيق الفحص الآن",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    } else {
                        // Interactive Line Chart with Compact Step Spacing
                        val scrollState = rememberScrollState()
                        val chartHeight = 185.dp
                        val stepSpacing = 28.dp // Compact step distance between points (matching sample design)
                        val paddingStart = 20.dp
                        val paddingEnd = 24.dp

                        val totalContentWidth = paddingStart + paddingEnd + ((dataPoints.size - 1).coerceAtLeast(0) * 28).dp

                        LaunchedEffect(dataPoints.size) {
                            if (dataPoints.isNotEmpty()) {
                                scrollState.scrollTo(scrollState.maxValue)
                            }
                        }

                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(chartHeight)
                        ) {
                            val containerWidth = maxWidth
                            val finalCanvasWidth = maxOf(containerWidth - 40.dp, totalContentWidth)

                            Row(modifier = Modifier.fillMaxSize()) {
                                // Left Y-Axis Labels Column (aligned to Start to align with the evaluation card)
                                Column(
                                    modifier = Modifier
                                        .width(32.dp)
                                        .fillMaxHeight()
                                        .padding(bottom = 30.dp, top = 8.dp),
                                    verticalArrangement = Arrangement.SpaceBetween,
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    listOf("100%", "80%", "60%", "40%", "20%", "0%").forEach { label ->
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                            color = textLabelColor,
                                            maxLines = 1
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                // Scrollable Chart Canvas
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .horizontalScroll(scrollState)
                                ) {
                                    Canvas(
                                        modifier = Modifier
                                            .width(finalCanvasWidth)
                                            .fillMaxHeight()
                                            .pointerInput(dataPoints) {
                                                detectTapGestures { offset ->
                                                    val paddingStartPx = paddingStart.toPx()
                                                    val stepSpacingPx = stepSpacing.toPx()
                                                    val count = dataPoints.size
                                                    if (count == 0) return@detectTapGestures

                                                    var closestIndex = 0
                                                    var minDistance = Float.MAX_VALUE
                                                    for (i in 0 until count) {
                                                        val ptX = paddingStartPx + i * stepSpacingPx
                                                        val dist = kotlin.math.abs(offset.x - ptX)
                                                        if (dist < minDistance) {
                                                            minDistance = dist
                                                            closestIndex = i
                                                        }
                                                    }
                                                    selectedPointIndex = closestIndex
                                                }
                                            }
                                    ) {
                                        val paddingStartPx = paddingStart.toPx()
                                        val stepSpacingPx = stepSpacing.toPx()
                                        val paddingTopPx = 8.dp.toPx()
                                        val paddingBottomPx = 30.dp.toPx()

                                        val usableHeight = size.height - paddingTopPx - paddingBottomPx

                                        // 1. Draw horizontal grid lines (0%, 20%, 40%, 60%, 80%, 100%)
                                        val percentages = listOf(100, 80, 60, 40, 20, 0)
                                        percentages.forEach { pct ->
                                            val y = paddingTopPx + (1f - (pct / 100f)) * usableHeight
                                            drawLine(
                                                color = gridLineColor,
                                                start = Offset(0f, y),
                                                end = Offset(size.width, y),
                                                strokeWidth = 1.dp.toPx()
                                            )
                                        }

                                        // 2. Compute Point Coordinates
                                        val count = dataPoints.size
                                        val pointCoords = mutableListOf<Offset>()

                                        for (i in 0 until count) {
                                            val x = paddingStartPx + i * stepSpacingPx
                                            val y = paddingTopPx + (1f - (dataPoints[i].scorePercentage / 100f)) * usableHeight
                                            pointCoords.add(Offset(x, y))
                                        }

                                        // 3. Draw Connecting Line
                                        if (pointCoords.size > 1) {
                                            val linePath = Path().apply {
                                                moveTo(pointCoords.first().x, pointCoords.first().y)
                                                for (i in 1 until pointCoords.size) {
                                                    lineTo(pointCoords[i].x, pointCoords[i].y)
                                                }
                                            }

                                            drawPath(
                                                path = linePath,
                                                color = chartLineColor,
                                                style = Stroke(
                                                    width = 2.5.dp.toPx(),
                                                    cap = StrokeCap.Round,
                                                    join = StrokeJoin.Round
                                                )
                                            )
                                        }

                                        // 4. Draw Selected Indicator Guide Line
                                        if (selectedPointIndex in pointCoords.indices) {
                                            val selOffset = pointCoords[selectedPointIndex]
                                            drawLine(
                                                color = chartLineColor.copy(alpha = 0.35f),
                                                start = Offset(selOffset.x, paddingTopPx),
                                                end = Offset(selOffset.x, size.height - paddingBottomPx),
                                                strokeWidth = 1.5.dp.toPx(),
                                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                                            )
                                        }

                                        // 5. Draw Circular Dots
                                        pointCoords.forEachIndexed { index, coord ->
                                            val isSelected = index == selectedPointIndex
                                            if (isSelected) {
                                                // Outer halo ring
                                                drawCircle(
                                                    color = chartLineColor.copy(alpha = 0.22f),
                                                    radius = 9.dp.toPx(),
                                                    center = coord
                                                )
                                                // Inner solid dot
                                                drawCircle(
                                                    color = chartLineColor,
                                                    radius = 5.dp.toPx(),
                                                    center = coord
                                                )
                                                drawCircle(
                                                    color = Color.White,
                                                    radius = 2.dp.toPx(),
                                                    center = coord
                                                )
                                            } else {
                                                drawCircle(
                                                    color = chartLineColor,
                                                    radius = 4.5.dp.toPx(),
                                                    center = coord
                                                )
                                            }
                                        }

                                        // 6. Draw X-Axis Labels using Native Canvas
                                        val dayTextPaint = android.graphics.Paint().apply {
                                            color = android.graphics.Color.GRAY
                                            textSize = 10.sp.toPx()
                                            textAlign = android.graphics.Paint.Align.CENTER
                                            isAntiAlias = true
                                        }
                                        val monthTextPaint = android.graphics.Paint().apply {
                                            color = android.graphics.Color.DKGRAY
                                            textSize = 9.sp.toPx()
                                            isFakeBoldText = true
                                            textAlign = android.graphics.Paint.Align.CENTER
                                            isAntiAlias = true
                                        }

                                        pointCoords.forEachIndexed { index, coord ->
                                            val pt = dataPoints[index]
                                            val dayY = size.height - 4.dp.toPx()
                                            val monthY = size.height - 16.dp.toPx()

                                            if (pt.subLabel != null && selectedPeriod == BaselineChartPeriod.DAY) {
                                                drawContext.canvas.nativeCanvas.drawText(
                                                    pt.subLabel,
                                                    coord.x,
                                                    monthY,
                                                    monthTextPaint
                                                )
                                            }
                                            drawContext.canvas.nativeCanvas.drawText(
                                                pt.displayLabel,
                                                coord.x,
                                                dayY,
                                                dayTextPaint
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 3. Selected Point Breakdown Panel (Bento)
            if (selectedPoint != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    border = BorderStroke(1.dp, chartLineColor.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                val formattedDate = remember(selectedPoint.timestamp) {
                                    formatArabicDateWithEnglishDigits(selectedPoint.timestamp)
                                }
                                Text(
                                    text = formattedDate,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "مؤشر التعافي: ${selectedPoint.scorePercentage}% | تقييم اليوم: ${String.format(Locale.ENGLISH, "%.2f", selectedPoint.rawAverage)} من 5",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = chartLineColor,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.featureTitleHint("recovery_index_score")
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = chartLineColor.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = "${selectedPoint.scorePercentage}%",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = chartLineColor
                                )
                            }
                        }

                        // 4 metrics detail pills
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ChartMetricItemPill(
                                label = "صفاء الذهن",
                                score = String.format(Locale.ENGLISH, "%.1f", selectedPoint.clarity),
                                hintKey = "baseline_clarity",
                                modifier = Modifier.weight(1f)
                            )
                            ChartMetricItemPill(
                                label = "استقرار المزاج",
                                score = String.format(Locale.ENGLISH, "%.1f", selectedPoint.mood),
                                hintKey = "baseline_mood",
                                modifier = Modifier.weight(1f)
                            )
                            ChartMetricItemPill(
                                label = "جودة النوم",
                                score = String.format(Locale.ENGLISH, "%.1f", selectedPoint.sleep),
                                hintKey = "baseline_sleep",
                                modifier = Modifier.weight(1f)
                            )
                            ChartMetricItemPill(
                                label = "الطاقة والحافز",
                                score = String.format(Locale.ENGLISH, "%.1f", selectedPoint.energy),
                                hintKey = "baseline_energy",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * دالة مساعدة لتنسيق التاريخ بالعربية مع الحفاظ على الأرقام الإنجليزية (Western Arabic numerals)
 */
private fun formatArabicDateWithEnglishDigits(timestamp: Long): String {
    val dayName = SimpleDateFormat("EEEE", Locale("ar")).format(Date(timestamp))
    val monthName = SimpleDateFormat("MMMM", Locale("ar")).format(Date(timestamp))
    val cal = Calendar.getInstance().apply { timeInMillis = timestamp }
    val day = cal.get(Calendar.DAY_OF_MONTH)
    val year = cal.get(Calendar.YEAR)
    return "$dayName، $day $monthName $year"
}

/**
 * واجهة عرض مخطط مؤشر خط الأساس اليومي بالشاشة الكاملة (Full Screen Baseline Chart View)
 * مصممة بنمط مينيمليست أنيق وبأقصى مساحة ممكنة للمخطط البياني وتوزيع متجاوب للنقاط
 */
@Composable
fun FullScreenBaselineScoreChartView(
    history: List<DailyBaselineCheckIn>,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var selectedPeriod by remember { mutableStateOf(BaselineChartPeriod.DAY) }
    var showPeriodDropdown by remember { mutableStateOf(false) }

    val dataPoints = remember(history, selectedPeriod) {
        SaffahRecoveryManager.getBaselineDataPoints(context, selectedPeriod)
    }

    var selectedPointIndex by remember(dataPoints) {
        mutableIntStateOf(if (dataPoints.isNotEmpty()) dataPoints.size - 1 else -1)
    }

    val selectedPoint = remember(dataPoints, selectedPointIndex) {
        if (selectedPointIndex in dataPoints.indices) dataPoints[selectedPointIndex] else dataPoints.lastOrNull()
    }

    val chartLineColor = Color(0xFF0166FF)
    val gridLineColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
    val textLabelColor = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // 1. Sleek Compact Top Bar (Exit, Title, Selected Info Pill, Period Filter)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Right: Exit Icon + Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FullscreenExit,
                                contentDescription = "إغلاق الشاشة الكاملة",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Text(
                            text = "مؤشر التعافي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.featureTitleHint("daily_baseline_chart")
                        )
                    }

                    // Center: Compact Selected Point Information Pill
                    if (selectedPoint != null) {
                        val formattedDate = remember(selectedPoint.timestamp) {
                            formatArabicDateWithEnglishDigits(selectedPoint.timestamp)
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, chartLineColor.copy(alpha = 0.25f)),
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = formattedDate,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "المؤشر: ${selectedPoint.scorePercentage}% (${String.format(Locale.ENGLISH, "%.2f", selectedPoint.rawAverage)}/5)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = chartLineColor
                                )
                                Text(
                                    text = "صفاء ${String.format(Locale.ENGLISH, "%.1f", selectedPoint.clarity)} | مزاج ${String.format(Locale.ENGLISH, "%.1f", selectedPoint.mood)} | نوم ${String.format(Locale.ENGLISH, "%.1f", selectedPoint.sleep)} | طاقة ${String.format(Locale.ENGLISH, "%.1f", selectedPoint.energy)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Left: Period Selector Dropdown
                    Box {
                        Surface(
                            onClick = { showPeriodDropdown = true },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = selectedPeriod.titleAr,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = "تغيير الفترة",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showPeriodDropdown,
                            onDismissRequest = { showPeriodDropdown = false }
                        ) {
                            BaselineChartPeriod.values().forEach { period ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = period.titleAr,
                                            fontWeight = if (selectedPeriod == period) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        selectedPeriod = period
                                        showPeriodDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 2. Full-Height Responsive Chart Canvas Area
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                if (dataPoints.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد سجلات فحص لعرضها في المخطط",
                            style = MaterialTheme.typography.bodyMedium,
                            color = textLabelColor
                        )
                    }
                } else {
                    val scrollState = rememberScrollState()
                    val stepSpacing = 50.dp
                    val paddingStart = 32.dp
                    val paddingEnd = 40.dp
                    val totalContentWidth = paddingStart + paddingEnd + ((dataPoints.size - 1).coerceAtLeast(0) * 50).dp

                    LaunchedEffect(dataPoints.size) {
                        if (dataPoints.isNotEmpty()) {
                            scrollState.scrollTo(scrollState.maxValue)
                        }
                    }

                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        val containerWidth = maxWidth
                        val finalCanvasWidth = maxOf(containerWidth - 52.dp, totalContentWidth)

                        Row(modifier = Modifier.fillMaxSize()) {
                            // Left Y-Axis Labels Column
                            Column(
                                modifier = Modifier
                                    .width(42.dp)
                                    .fillMaxHeight()
                                    .padding(bottom = 36.dp, top = 14.dp),
                                verticalArrangement = Arrangement.SpaceBetween,
                                horizontalAlignment = Alignment.Start
                            ) {
                                listOf("100%", "80%", "60%", "40%", "20%", "0%").forEach { label ->
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                        color = textLabelColor,
                                        maxLines = 1
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            // Scrollable Chart Canvas
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .horizontalScroll(scrollState)
                            ) {
                                Canvas(
                                    modifier = Modifier
                                        .width(finalCanvasWidth)
                                        .fillMaxHeight()
                                        .pointerInput(dataPoints) {
                                            detectTapGestures { offset ->
                                                val paddingStartPx = paddingStart.toPx()
                                                val stepSpacingPx = stepSpacing.toPx()
                                                val count = dataPoints.size
                                                if (count == 0) return@detectTapGestures

                                                var closestIndex = 0
                                                var minDistance = Float.MAX_VALUE
                                                for (i in 0 until count) {
                                                    val ptX = paddingStartPx + i * stepSpacingPx
                                                    val dist = kotlin.math.abs(offset.x - ptX)
                                                    if (dist < minDistance) {
                                                        minDistance = dist
                                                        closestIndex = i
                                                    }
                                                }
                                                selectedPointIndex = closestIndex
                                            }
                                        }
                                ) {
                                    val paddingStartPx = paddingStart.toPx()
                                    val stepSpacingPx = stepSpacing.toPx()
                                    val paddingTopPx = 14.dp.toPx()
                                    val paddingBottomPx = 36.dp.toPx()

                                    val usableHeight = size.height - paddingTopPx - paddingBottomPx

                                    // 1. Draw horizontal grid lines
                                    val percentages = listOf(100, 80, 60, 40, 20, 0)
                                    percentages.forEach { pct ->
                                        val y = paddingTopPx + (1f - (pct / 100f)) * usableHeight
                                        drawLine(
                                            color = gridLineColor,
                                            start = Offset(0f, y),
                                            end = Offset(size.width, y),
                                            strokeWidth = 1.dp.toPx()
                                        )
                                    }

                                    // 2. Compute Point Coordinates
                                    val count = dataPoints.size
                                    val pointCoords = mutableListOf<Offset>()

                                    for (i in 0 until count) {
                                        val x = paddingStartPx + i * stepSpacingPx
                                        val y = paddingTopPx + (1f - (dataPoints[i].scorePercentage / 100f)) * usableHeight
                                        pointCoords.add(Offset(x, y))
                                    }

                                    // 3. Draw Connecting Line
                                    if (pointCoords.size > 1) {
                                        val linePath = Path().apply {
                                            moveTo(pointCoords.first().x, pointCoords.first().y)
                                            for (i in 1 until pointCoords.size) {
                                                lineTo(pointCoords[i].x, pointCoords[i].y)
                                            }
                                        }

                                        drawPath(
                                            path = linePath,
                                            color = chartLineColor,
                                            style = Stroke(
                                                width = 3.5.dp.toPx(),
                                                cap = StrokeCap.Round,
                                                join = StrokeJoin.Round
                                            )
                                        )
                                    }

                                    // 4. Draw Selected Indicator Guide Line
                                    if (selectedPointIndex in pointCoords.indices) {
                                        val selOffset = pointCoords[selectedPointIndex]
                                        drawLine(
                                            color = chartLineColor.copy(alpha = 0.45f),
                                            start = Offset(selOffset.x, paddingTopPx),
                                            end = Offset(selOffset.x, size.height - paddingBottomPx),
                                            strokeWidth = 2.dp.toPx(),
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                        )
                                    }

                                    // 5. Draw Circular Dots
                                    pointCoords.forEachIndexed { index, coord ->
                                        val isSelected = index == selectedPointIndex
                                        if (isSelected) {
                                            drawCircle(
                                                color = chartLineColor.copy(alpha = 0.25f),
                                                radius = 12.dp.toPx(),
                                                center = coord
                                            )
                                            drawCircle(
                                                color = chartLineColor,
                                                radius = 7.dp.toPx(),
                                                center = coord
                                            )
                                            drawCircle(
                                                color = Color.White,
                                                radius = 3.dp.toPx(),
                                                center = coord
                                            )
                                        } else {
                                            drawCircle(
                                                color = chartLineColor,
                                                radius = 6.dp.toPx(),
                                                center = coord
                                            )
                                        }
                                    }

                                    // 6. Draw X-Axis Labels using Native Canvas
                                    val dayTextPaint = android.graphics.Paint().apply {
                                        color = android.graphics.Color.GRAY
                                        textSize = 12.sp.toPx()
                                        textAlign = android.graphics.Paint.Align.CENTER
                                        isAntiAlias = true
                                    }
                                    val monthTextPaint = android.graphics.Paint().apply {
                                        color = android.graphics.Color.DKGRAY
                                        textSize = 11.sp.toPx()
                                        isFakeBoldText = true
                                        textAlign = android.graphics.Paint.Align.CENTER
                                        isAntiAlias = true
                                    }

                                    pointCoords.forEachIndexed { index, coord ->
                                        val pt = dataPoints[index]
                                        val dayY = size.height - 6.dp.toPx()
                                        val monthY = size.height - 20.dp.toPx()

                                        if (pt.subLabel != null && selectedPeriod == BaselineChartPeriod.DAY) {
                                            drawContext.canvas.nativeCanvas.drawText(
                                                pt.subLabel,
                                                coord.x,
                                                monthY,
                                                monthTextPaint
                                            )
                                        }
                                        drawContext.canvas.nativeCanvas.drawText(
                                            pt.displayLabel,
                                            coord.x,
                                            dayY,
                                            dayTextPaint
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * حبة مصغرة لعرض درجات المقياس داخل المخطط
 */
@Composable
private fun ChartMetricItemPill(
    label: String,
    score: String,
    modifier: Modifier = Modifier,
    hintKey: String? = null
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 6.dp, horizontal = 4.dp)
                .then(if (hintKey != null) Modifier.featureTitleHint(hintKey) else Modifier),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "$score/5",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * نافذة حوارية لتسجيل فحص خط الأساس من واجهة الإحصائيات
 */
@Composable
private fun BaselineCheckInDialog(
    onDismiss: () -> Unit,
    onConfirm: (clarity: Int, mood: Int, sleep: Int, energy: Int) -> Unit
) {
    var clarity by remember { mutableIntStateOf(3) }
    var mood by remember { mutableIntStateOf(3) }
    var sleep by remember { mutableIntStateOf(3) }
    var energy by remember { mutableIntStateOf(3) }

    val rawAverage = remember(clarity, mood, sleep, energy) { (clarity + mood + sleep + energy) / 4.0 }
    val percentage = remember(clarity, mood, sleep, energy) {
        (((clarity + mood + sleep + energy) / 20.0) * 100.0).toInt().coerceIn(0, 100)
    }

    val primaryColor = Color(0xFF0166FF)

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth(0.92f)
            .padding(vertical = 16.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QueryStats,
                    contentDescription = null,
                    tint = primaryColor,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "فحص مؤشر التعافي اليومي",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "قيّم حالتك اليومية عبر 4 مقاييس من 1 إلى 5:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // 1. صفاء الذهن
                MetricRatingRow(
                    title = "صفاء الذهن",
                    hint = "التركيز، التفكير الواضح وغياب الضبابية",
                    selectedScore = clarity,
                    onSelect = { clarity = it },
                    accentColor = primaryColor
                )

                // 2. استقرار المزاج
                MetricRatingRow(
                    title = "استقرار المزاج",
                    hint = "التوازن النفسي والهدوء وغياب التوتر",
                    selectedScore = mood,
                    onSelect = { mood = it },
                    accentColor = primaryColor
                )

                // 3. جودة النوم والنشاط
                MetricRatingRow(
                    title = "جودة النوم والنشاط الصباحي",
                    hint = "عمق النوم واليقظة بنشاط",
                    selectedScore = sleep,
                    onSelect = { sleep = it },
                    accentColor = primaryColor
                )

                // 4. مستوى الطاقة والحافز
                MetricRatingRow(
                    title = "مستوى الطاقة والحافز للإنجاز",
                    hint = "الدافع الداخلي والإنتاجية",
                    selectedScore = energy,
                    onSelect = { energy = it },
                    accentColor = primaryColor
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = primaryColor.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "المعدل: ${String.format(Locale.ENGLISH, "%.2f", rawAverage)} / 5",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "النسبة: $percentage%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(clarity, mood, sleep, energy) },
                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("حفظ وتوثيق الفحص ($percentage%)", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun MetricRatingRow(
    title: String,
    hint: String,
    selectedScore: Int,
    onSelect: (Int) -> Unit,
    accentColor: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = hint,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                color = accentColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "$selectedScore / 5",
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (score in 1..5) {
                val isSelected = selectedScore == score
                Surface(
                    onClick = { onSelect(score) },
                    modifier = Modifier
                        .weight(1f)
                        .height(30.dp),
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected) accentColor else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(0.5.dp, if (isSelected) accentColor else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = score.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

