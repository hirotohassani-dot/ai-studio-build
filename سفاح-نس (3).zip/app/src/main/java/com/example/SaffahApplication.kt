package com.example

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.util.SaffahMediaCompressor
import java.io.File
import java.util.Locale

class SaffahApplication : Application(), ImageLoaderFactory {

    companion object {
        // Arabic locale explicitly configured with Western/Latin (English) numerals 0-9
        val ARABIC_LATIN_LOCALE: Locale = Locale.forLanguageTag("ar-u-nu-latn")
    }

    override fun attachBaseContext(base: Context) {
        Locale.setDefault(ARABIC_LATIN_LOCALE)

        val config = Configuration(base.resources.configuration)
        config.setLocale(ARABIC_LATIN_LOCALE)
        config.setLayoutDirection(ARABIC_LATIN_LOCALE)

        val localizedContext = base.createConfigurationContext(config)
        super.attachBaseContext(localizedContext)
    }

    override fun onCreate() {
        super.onCreate()
        setupCrashProtection()
        enforceArabicRtl()

        val isUserUnlocked = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val um = getSystemService(Context.USER_SERVICE) as? android.os.UserManager
            um?.isUserUnlocked ?: true
        } else {
            true
        }

        if (isUserUnlocked) {
            // تأمين وعزل كافة مجلدات وسائط التطبيق لمنع تسربها لاستوديو الهاتف أو ماسح الوسائط
            try {
                SaffahMediaCompressor.initSecurity(this)
            } catch (e: Exception) {
                Log.e("SaffahApp", "Error initializing media security: ${e.message}")
            }
            // تهيئة قنوات الإشعارات وجدولة المنبهات بدقة لمنع أي تأخير أو فقدان
            try {
                com.example.util.SaffahNotificationManager.initChannels(this)
                com.example.util.SaffahNotificationManager.ensureNotificationPermissionGranted(this)
                com.example.util.SaffahNotificationManager.scheduleAlarms(this)
            } catch (e: Exception) {
                Log.e("SaffahApp", "Error initializing notifications: ${e.message}")
            }
        }

        // تطبيق التحصين الشامل للسفاح في النظام وإطلاق خدمة الحماية المستمرة (يعمل في Direct Boot وفي الوضع العادي)
        try {
            com.example.util.SaffahProtectionManager.startKeeperService(this)
            com.example.service.SaffahKeeperService.ensureKeeperNotification(this)
            com.example.util.SaffahProtectionManager.applyAllSystemImmunity(this)
        } catch (e: Exception) {
            Log.e("SaffahApp", "Error applying system immunity: ${e.message}")
        }

        if (isUserUnlocked) {
            // إلغاء أي إعدادات لنظام التشغيل تربط الشحن بتفعيل وضع عدم الإزعاج أو كتم الصوت
            try {
                com.example.util.SaffahChargingManager.disableOemChargingDndTriggers(this)
            } catch (e: Exception) {
                Log.e("SaffahApp", "Error disabling OEM charging triggers: ${e.message}")
            }
        }
    }

    private fun setupCrashProtection() {
        // Global Uncaught Exception Handler for all background threads and coroutines
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("SaffahCrashGuard", "CRASH INTERCEPTED on thread '${thread.name}': ${throwable.message}", throwable)
            try {
                if (isRecoverableException(throwable)) {
                    Log.w("SaffahCrashGuard", "Safely absorbed recoverable exception on thread '${thread.name}': ${throwable::class.java.simpleName}")
                    return@setDefaultUncaughtExceptionHandler
                }
            } catch (_: Throwable) {}

            // For any other unexpected background thread exception, absorb without crashing the app process
            if (thread.name != "main") {
                Log.w("SaffahCrashGuard", "Safely absorbed background thread exception on '${thread.name}' to prevent app kill")
                return@setDefaultUncaughtExceptionHandler
            }

            defaultHandler?.uncaughtException(thread, throwable)
        }
    }


    private fun isRecoverableException(throwable: Throwable?): Boolean {
        if (throwable == null) return false
        if (throwable is OutOfMemoryError || throwable is VirtualMachineError) return false

        val msg = throwable.message?.lowercase() ?: ""
        val className = throwable::class.java.name

        // NullPointer, Index, IllegalState, and JSON exceptions in background threads
        if (throwable is NullPointerException ||
            throwable is IndexOutOfBoundsException ||
            throwable is NoSuchElementException ||
            throwable is org.json.JSONException ||
            throwable is SecurityException ||
            throwable is java.io.IOException ||
            throwable is android.database.sqlite.SQLiteException
        ) return true

        // IPC / Binder dead objects and remote exceptions
        if (throwable is android.os.DeadObjectException ||
            throwable is android.os.RemoteException ||
            throwable is android.os.TransactionTooLargeException
        ) return true

        // WindowManager and UI glitches
        if (throwable is android.view.WindowManager.BadTokenException ||
            throwable is android.view.WindowManager.InvalidDisplayException ||
            (throwable is IllegalArgumentException && (msg.contains("not attached to window manager") || msg.contains("view="))) ||
            (throwable is IllegalStateException && (msg.contains("has already been added") || msg.contains("not-sealed") || msg.contains("recycled")))
        ) return true

        // Background service start restrictions on Android 12+ / 14
        if (className.contains("ForegroundServiceStartNotAllowedException")) return true

        // Concurrent collection modifications during quick sweeps
        if (throwable is java.util.ConcurrentModificationException) return true

        // Check nested causes
        val cause = throwable.cause
        if (cause != null && cause !== throwable) {
            return isRecoverableException(cause)
        }

        return false
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.20) // سقف الذاكرة العشوائية 20% كحد أقصى لمنع أي بطء أو استنزاف
                    .strongReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(cacheDir, "saffah_coil_cache"))
                    .maxSizeBytes(60L * 1024 * 1024) // 60MB كاش محلي
                    .build()
            }
            .respectCacheHeaders(false)
            .allowRgb565(true) // توفير 50% من استهلاك الذاكرة للصور
            .allowHardware(true) // استخدام عتاد كرت الشاشة لتسريع الرسم بدون بطء
            .crossfade(true)
            .build()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        try {
            coil.Coil.imageLoader(this).memoryCache?.clear()
            com.example.util.AppListHelper.clearMemoryCaches()
        } catch (_: Exception) {}
    }

    override fun onLowMemory() {
        super.onLowMemory()
        try {
            coil.Coil.imageLoader(this).memoryCache?.clear()
            com.example.util.AppListHelper.clearMemoryCaches()
        } catch (_: Exception) {}
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        enforceArabicRtl()
    }

    private fun enforceArabicRtl() {
        try {
            Locale.setDefault(ARABIC_LATIN_LOCALE)
            val config = resources.configuration
            config.setLocale(ARABIC_LATIN_LOCALE)
            config.setLayoutDirection(ARABIC_LATIN_LOCALE)
            @Suppress("DEPRECATION")
            resources.updateConfiguration(config, resources.displayMetrics)
        } catch (e: Exception) {
            Log.e("SaffahApp", "Error enforcing RTL: ${e.message}")
        }
    }
}

