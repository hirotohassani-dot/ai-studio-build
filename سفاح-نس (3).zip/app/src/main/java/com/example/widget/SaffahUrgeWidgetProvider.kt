package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.widget.RemoteViews
import android.widget.Toast
import com.example.R
import com.example.util.SaffahUrgeManager

/**
 * ويدجت الشاشة الرئيسية (Home Screen Widget) بحجم الأيقونة (1x1)
 * لتفعيل قاعدة الـ 15 دقيقة لدحر الرغبة فوراً بلمسة واحدة دون الحاجة للدخول للتطبيق.
 */
class SaffahUrgeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        if (intent.action == ACTION_TRIGGER_URGE) {
            Log.i(TAG, "Urge 15-Minute Widget tapped by user from Home Screen!")

            val isAlreadyActive = SaffahUrgeManager.isUrgeSessionActive(context)
            if (isAlreadyActive) {
                val remainingMs = SaffahUrgeManager.getUrgeSessionRemainingMs(context)
                val remainingMinutes = (remainingMs / 1000L / 60L).coerceAtLeast(1L)
                Toast.makeText(
                    context,
                    "جلسة دحر الرغبة نشطة بالفعل (متبقي $remainingMinutes دقيقة)",
                    Toast.LENGTH_SHORT
                ).show()
                com.example.util.SaffahLockTaskManager.launchLockTaskApp(context, com.example.util.SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
            } else {
                // Activate urge suppression rule immediately
                SaffahUrgeManager.setUrgeFeatureEnabled(context, true)
                SaffahUrgeManager.startUrgeSession(context, 15)

                Toast.makeText(
                    context,
                    "تم تفعيل قاعدة الـ 15 دقيقة لدحر الرغبة فوراً!",
                    Toast.LENGTH_SHORT
                ).show()
            }

            // Update all widgets on the home screen
            updateAllWidgets(context)
        }
    }

    companion object {
        private const val TAG = "SaffahUrgeWidget"
        const val ACTION_TRIGGER_URGE = "com.example.ACTION_TRIGGER_URGE"

        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_urge_button)
                val isActive = SaffahUrgeManager.isUrgeSessionActive(context)

                if (isActive) {
                    views.setInt(
                        R.id.widget_container,
                        "setBackgroundResource",
                        R.drawable.widget_bg_urge_active
                    )
                    views.setTextViewText(R.id.widget_status, "نشط الآن")
                } else {
                    views.setInt(
                        R.id.widget_container,
                        "setBackgroundResource",
                        R.drawable.widget_bg_urge_idle
                    )
                    views.setTextViewText(R.id.widget_status, "15 دقيقة")
                }

                // Setup explicit broadcast intent for click action
                val clickIntent = Intent(context, SaffahUrgeWidgetProvider::class.java).apply {
                    action = ACTION_TRIGGER_URGE
                }
                val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                } else {
                    PendingIntent.FLAG_UPDATE_CURRENT
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    appWidgetId,
                    clickIntent,
                    flags
                )

                views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                views.setOnClickPendingIntent(R.id.widget_container, pendingIntent)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (e: Exception) {
                Log.e(TAG, "Error updating app widget $appWidgetId: ${e.message}", e)
            }
        }

        /**
         * تحديث جميع ويدجت دحر الرغبة الموجودة على الشاشة الرئيسية للمستخدم
         */
        fun updateAllWidgets(context: Context) {
            try {
                val appWidgetManager = AppWidgetManager.getInstance(context)
                val componentName = ComponentName(context, SaffahUrgeWidgetProvider::class.java)
                val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
                if (appWidgetIds != null && appWidgetIds.isNotEmpty()) {
                    for (appWidgetId in appWidgetIds) {
                        updateAppWidget(context, appWidgetManager, appWidgetId)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating all widgets: ${e.message}")
            }
        }
    }
}
