package com.example.worker

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.util.SaffahLockTaskManager
import com.example.util.SaffahProtectionManager

class ServiceWatchdogWorker(
    context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    override fun doWork(): Result {
        return try {
            Log.i("SaffahWatchdog", "Heartbeat check running via WorkManager...")

            // Re-apply Device Owner protection settings and auto-heal critical services
            SaffahProtectionManager.applyAllSystemImmunity(applicationContext, force = true)
            SaffahProtectionManager.startKeeperService(applicationContext)
            SaffahProtectionManager.applyDeviceOwnerRestrictions(applicationContext)
            SaffahProtectionManager.ensureAccessibilityServiceEnabled(applicationContext)

            // Re-sync all package suspensions and limits (fallback in case accessibility was killed)
            com.example.util.SaffahBlockRepository.checkAndPerformMidnightReset(applicationContext)
            com.example.util.SaffahBlockRepository.applyPackageSuspensionIfNeeded(applicationContext)

            // Ensure LockTask mode if explicitly active or protection disabled
            val lockReason = SaffahLockTaskManager.updateStateAndCheck(applicationContext)
            if (lockReason != SaffahLockTaskManager.LockReason.NONE) {
                SaffahLockTaskManager.launchLockTaskAndSettings(applicationContext, lockReason)
            }

            Result.success()
        } catch (t: Throwable) {
            Log.e("SaffahWatchdog", "Error in Watchdog Worker: ${t.message}")
            Result.retry()
        }
    }
}
