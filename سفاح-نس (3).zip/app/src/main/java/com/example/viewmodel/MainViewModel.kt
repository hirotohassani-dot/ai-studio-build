package com.example.viewmodel

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.receiver.SaffahDeviceAdminReceiver
import com.example.service.SaffahVpnService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

import com.example.util.SaffahProtectionManager
import com.example.util.SaffahUrgeManager

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // App state
    private val _permissionStatus = MutableStateFlow(PermissionStatus())
    val permissionStatus: StateFlow<PermissionStatus> = _permissionStatus.asStateFlow()

    private val _selectedDnsServer = MutableStateFlow(DnsFilterServer.CLEAN_BROWSING)
    val selectedDnsServer: StateFlow<DnsFilterServer> = _selectedDnsServer.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val installedApps: StateFlow<List<InstalledApp>> = _installedApps.asStateFlow()

    private val _blockedKeywords = MutableStateFlow<List<BlockedKeyword>>(emptyList())
    val blockedKeywords: StateFlow<List<BlockedKeyword>> = _blockedKeywords.asStateFlow()

    private val _blockedSites = MutableStateFlow<List<BlockedSite>>(emptyList())
    val blockedSites: StateFlow<List<BlockedSite>> = _blockedSites.asStateFlow()

    private val _isImportingBlockedData = MutableStateFlow(false)
    val isImportingBlockedData: StateFlow<Boolean> = _isImportingBlockedData.asStateFlow()

    private val _blockLogs = MutableStateFlow<List<BlockLogEntry>>(emptyList())
    val blockLogs: StateFlow<List<BlockLogEntry>> = _blockLogs.asStateFlow()

    // Trigger Blocking State
    private val _isTelegramSearchBlocked = MutableStateFlow(false)
    val isTelegramSearchBlocked: StateFlow<Boolean> = _isTelegramSearchBlocked.asStateFlow()

    private val _isWhatsAppChannelsBlocked = MutableStateFlow(false)
    val isWhatsAppChannelsBlocked: StateFlow<Boolean> = _isWhatsAppChannelsBlocked.asStateFlow()

    private val _isYouTubeShortsBlocked = MutableStateFlow(false)
    val isYouTubeShortsBlocked: StateFlow<Boolean> = _isYouTubeShortsBlocked.asStateFlow()

    private val _isFacebookLiteReelsBlocked = MutableStateFlow(false)
    val isFacebookLiteReelsBlocked: StateFlow<Boolean> = _isFacebookLiteReelsBlocked.asStateFlow()

    private val _isInstagramReelsBlocked = MutableStateFlow(false)
    val isInstagramReelsBlocked: StateFlow<Boolean> = _isInstagramReelsBlocked.asStateFlow()

    private val _isBlockUnsupportedBrowsers = MutableStateFlow(false)
    val isBlockUnsupportedBrowsers: StateFlow<Boolean> = _isBlockUnsupportedBrowsers.asStateFlow()

    private val _isBlockInAppBrowsers = MutableStateFlow(false)
    val isBlockInAppBrowsers: StateFlow<Boolean> = _isBlockInAppBrowsers.asStateFlow()

    private val _isHideVpnNotification = MutableStateFlow(false)
    val isHideVpnNotification: StateFlow<Boolean> = _isHideVpnNotification.asStateFlow()

    private val _isAiProtectionEnabled = MutableStateFlow(false)
    val isAiProtectionEnabled: StateFlow<Boolean> = _isAiProtectionEnabled.asStateFlow()

    private val _isAiNudeNetEnabled = MutableStateFlow(false)
    val isAiNudeNetEnabled: StateFlow<Boolean> = _isAiNudeNetEnabled.asStateFlow()

    private val _isAiAnimeEnabled = MutableStateFlow(false)
    val isAiAnimeEnabled: StateFlow<Boolean> = _isAiAnimeEnabled.asStateFlow()

    private val _isAiDryRunEnabled = MutableStateFlow(false)
    val isAiDryRunEnabled: StateFlow<Boolean> = _isAiDryRunEnabled.asStateFlow()

    private val _animeConfig = MutableStateFlow(com.example.util.AnimeCfg())
    val animeConfig: StateFlow<com.example.util.AnimeCfg> = _animeConfig.asStateFlow()

    val animeDebugState = com.example.util.SaffahAnimeClassifier.debugState

    private val _nudeConfig = MutableStateFlow(com.example.util.NudeCfg())
    val nudeConfig: StateFlow<com.example.util.NudeCfg> = _nudeConfig.asStateFlow()

    val nudeDebugState = com.example.util.SaffahNudeNetClassifier.debugState
    val schedulerDebugState = com.example.util.FrameScheduler.globalDebugState

    private val _aiProtectionIncludedApps = MutableStateFlow<Set<String>>(emptySet())
    val aiProtectionIncludedApps: StateFlow<Set<String>> = _aiProtectionIncludedApps.asStateFlow()

    private val _isKeeperServiceEnabled = MutableStateFlow(true)
    val isKeeperServiceEnabled: StateFlow<Boolean> = _isKeeperServiceEnabled.asStateFlow()

    // App Schedule Rules State
    private val _isAppScheduleMasterEnabled = MutableStateFlow(false)
    val isAppScheduleMasterEnabled: StateFlow<Boolean> = _isAppScheduleMasterEnabled.asStateFlow()

    private val _appScheduleRules = MutableStateFlow<List<AppBlockScheduleRule>>(emptyList())
    val appScheduleRules: StateFlow<List<AppBlockScheduleRule>> = _appScheduleRules.asStateFlow()

    // Usage Block Rules State
    private val _isUsageMasterEnabled = MutableStateFlow(false)
    val isUsageMasterEnabled: StateFlow<Boolean> = _isUsageMasterEnabled.asStateFlow()

    private val _usageRules = MutableStateFlow<List<UsageBlockRule>>(emptyList())
    val usageRules: StateFlow<List<UsageBlockRule>> = _usageRules.asStateFlow()

    // Permanent Blocked Packages State (الحظر المؤبد)
    private val _permanentBlockedPackages = MutableStateFlow<Set<String>>(emptySet())
    val permanentBlockedPackages: StateFlow<Set<String>> = _permanentBlockedPackages.asStateFlow()

    // Uninstall Blocked Packages State (منع حذف التطبيقات - Device Owner)
    private val _uninstallBlockedPackages = MutableStateFlow<Set<String>>(emptySet())
    val uninstallBlockedPackages: StateFlow<Set<String>> = _uninstallBlockedPackages.asStateFlow()


    // Settings State
    private val _isFullScreenBaselineChart = MutableStateFlow(false)
    val isFullScreenBaselineChart: StateFlow<Boolean> = _isFullScreenBaselineChart.asStateFlow()

    fun setFullScreenBaselineChart(enabled: Boolean) {
        _isFullScreenBaselineChart.value = enabled
    }

    private val _isDarkMode = MutableStateFlow(
        context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE).getBoolean("dark_mode", false)
    )
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("العربية")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _backupStatusMessage = MutableStateFlow<String?>(null)
    val backupStatusMessage: StateFlow<String?> = _backupStatusMessage.asStateFlow()

    private val _backupSummary = MutableStateFlow(com.example.util.GoogleDriveBackupManager.getBackupSummary(context))
    val backupSummary: StateFlow<com.example.model.BackupSummary> = _backupSummary.asStateFlow()

    private val _isBackupInProgress = MutableStateFlow(false)
    val isBackupInProgress: StateFlow<Boolean> = _isBackupInProgress.asStateFlow()

    private val _isRestoreInProgress = MutableStateFlow(false)
    val isRestoreInProgress: StateFlow<Boolean> = _isRestoreInProgress.asStateFlow()

    private val _isDisallowSafeBoot = MutableStateFlow(false)
    val isDisallowSafeBoot: StateFlow<Boolean> = _isDisallowSafeBoot.asStateFlow()

    private val _isDisallowConfigDateTime = MutableStateFlow(false)
    val isDisallowConfigDateTime: StateFlow<Boolean> = _isDisallowConfigDateTime.asStateFlow()

    private val _isDisallowConfigPrivateDns = MutableStateFlow(false)
    val isDisallowConfigPrivateDns: StateFlow<Boolean> = _isDisallowConfigPrivateDns.asStateFlow()

    private val _isDisallowDebuggingFeatures = MutableStateFlow(false)
    val isDisallowDebuggingFeatures: StateFlow<Boolean> = _isDisallowDebuggingFeatures.asStateFlow()

    // Penalty Screen State
    private val _isPenaltyEnabled = MutableStateFlow(false)
    val isPenaltyEnabled: StateFlow<Boolean> = _isPenaltyEnabled.asStateFlow()

    private val _penaltyDurationMinutes = MutableStateFlow(5)
    val penaltyDurationMinutes: StateFlow<Int> = _penaltyDurationMinutes.asStateFlow()

    private val _isPenaltyActive = MutableStateFlow(false)
    val isPenaltyActive: StateFlow<Boolean> = _isPenaltyActive.asStateFlow()

    private val _remainingPenaltyMs = MutableStateFlow(0L)
    val remainingPenaltyMs: StateFlow<Long> = _remainingPenaltyMs.asStateFlow()

    // 15-Minute Urge Suppression State (قاعدة 15د لدحر الرغبة)
    private val _isUrgeFeatureEnabled = MutableStateFlow(SaffahUrgeManager.isUrgeFeatureEnabled(context))
    val isUrgeFeatureEnabled: StateFlow<Boolean> = _isUrgeFeatureEnabled.asStateFlow()

    private val _isUrgeSessionActive = MutableStateFlow(SaffahUrgeManager.isUrgeSessionActive(context))
    val isUrgeSessionActive: StateFlow<Boolean> = _isUrgeSessionActive.asStateFlow()

    private val _remainingUrgeSessionMs = MutableStateFlow(SaffahUrgeManager.getUrgeSessionRemainingMs(context))
    val remainingUrgeSessionMs: StateFlow<Long> = _remainingUrgeSessionMs.asStateFlow()

    private val _showUrgeLogDialog = MutableStateFlow(false)
    val showUrgeLogDialog: StateFlow<Boolean> = _showUrgeLogDialog.asStateFlow()

    private val _showUrgeVictoryDialog = MutableStateFlow(false)
    val showUrgeVictoryDialog: StateFlow<Boolean> = _showUrgeVictoryDialog.asStateFlow()

    // Time Delay State (ميزة التأخير الزمني)
    private val _isTimeDelayActive = MutableStateFlow(false)
    val isTimeDelayActive: StateFlow<Boolean> = _isTimeDelayActive.asStateFlow()

    private val _remainingTimeDelayMs = MutableStateFlow(0L)
    val remainingTimeDelayMs: StateFlow<Long> = _remainingTimeDelayMs.asStateFlow()

    private val _timeDelayUntilTimestamp = MutableStateFlow(0L)
    val timeDelayUntilTimestamp: StateFlow<Long> = _timeDelayUntilTimestamp.asStateFlow()

    private val _configuredTimeDelayHours = MutableStateFlow(1L)
    val configuredTimeDelayHours: StateFlow<Long> = _configuredTimeDelayHours.asStateFlow()

    private val _userFeedbackMessage = MutableStateFlow<String?>(null)
    val userFeedbackMessage: StateFlow<String?> = _userFeedbackMessage.asStateFlow()

    // Bedtime Mode State
    private val _isBedtimeEnabled = MutableStateFlow(false)
    val isBedtimeEnabled: StateFlow<Boolean> = _isBedtimeEnabled.asStateFlow()

    private val _bedtimeStartHour = MutableStateFlow(23)
    val bedtimeStartHour: StateFlow<Int> = _bedtimeStartHour.asStateFlow()

    private val _bedtimeStartMinute = MutableStateFlow(0)
    val bedtimeStartMinute: StateFlow<Int> = _bedtimeStartMinute.asStateFlow()

    private val _bedtimeEndHour = MutableStateFlow(5)
    val bedtimeEndHour: StateFlow<Int> = _bedtimeEndHour.asStateFlow()

    private val _bedtimeEndMinute = MutableStateFlow(0)
    val bedtimeEndMinute: StateFlow<Int> = _bedtimeEndMinute.asStateFlow()

    private val _bedtimeAllowedApps = MutableStateFlow<Set<String>>(emptySet())
    val bedtimeAllowedApps: StateFlow<Set<String>> = _bedtimeAllowedApps.asStateFlow()

    private val _bedtimeDays = MutableStateFlow<Set<Int>>(emptySet())
    val bedtimeDays: StateFlow<Set<Int>> = _bedtimeDays.asStateFlow()

    private val _isBedtimeGrayscaleEnabled = MutableStateFlow(false)
    val isBedtimeGrayscaleEnabled: StateFlow<Boolean> = _isBedtimeGrayscaleEnabled.asStateFlow()

    private val _isBedtimeEyeComfortEnabled = MutableStateFlow(false)
    val isBedtimeEyeComfortEnabled: StateFlow<Boolean> = _isBedtimeEyeComfortEnabled.asStateFlow()

    private val _isHardwareGrayscaleGranted = MutableStateFlow(false)
    val isHardwareGrayscaleGranted: StateFlow<Boolean> = _isHardwareGrayscaleGranted.asStateFlow()

    private val _isTestingGrayscale = MutableStateFlow(false)
    val isTestingGrayscale: StateFlow<Boolean> = _isTestingGrayscale.asStateFlow()

    private val _isCurrentlyBedtime = MutableStateFlow(false)
    val isCurrentlyBedtime: StateFlow<Boolean> = _isCurrentlyBedtime.asStateFlow()

    private val _filteredAppsForBedtime = MutableStateFlow<List<com.example.util.AppInfoItem>>(emptyList())
    val filteredAppsForBedtime: StateFlow<List<com.example.util.AppInfoItem>> = _filteredAppsForBedtime.asStateFlow()

    // Keyword Exempted Apps State (استثناء التطبيقات من الكلمات المحظورة)
    private val _keywordExemptedApps = MutableStateFlow<Set<String>>(emptySet())
    val keywordExemptedApps: StateFlow<Set<String>> = _keywordExemptedApps.asStateFlow()

    // Physical QR / Barcode Key Protection State (نظام قفل QR / الباركود المادي)
    private val _qrKeyConfig = MutableStateFlow(com.example.util.SaffahQrKeyManager.getQrKeyConfig(context))
    val qrKeyConfig: StateFlow<com.example.util.SaffahQrKeyManager.QrKeyConfig> = _qrKeyConfig.asStateFlow()

    private val _isQrKeyActive = MutableStateFlow(com.example.util.SaffahQrKeyManager.isQrKeyProtectionActive(context))
    val isQrKeyActive: StateFlow<Boolean> = _isQrKeyActive.asStateFlow()

    private val _showQrKeyVerificationDialog = MutableStateFlow(false)
    val showQrKeyVerificationDialog: StateFlow<Boolean> = _showQrKeyVerificationDialog.asStateFlow()

    private val _pendingProtectedActionDesc = MutableStateFlow("")
    val pendingProtectedActionDesc: StateFlow<String> = _pendingProtectedActionDesc.asStateFlow()

    private val _isPendingActionPrimaryOnly = MutableStateFlow(false)
    val isPendingActionPrimaryOnly: StateFlow<Boolean> = _isPendingActionPrimaryOnly.asStateFlow()

    private var pendingProtectedActionCallback: (() -> Unit)? = null

    private val _filteredAppsForKeywordExemption = MutableStateFlow<List<com.example.util.AppInfoItem>>(emptyList())
    val filteredAppsForKeywordExemption: StateFlow<List<com.example.util.AppInfoItem>> = _filteredAppsForKeywordExemption.asStateFlow()

    // Productivity and Discipline State (تحسين الإنتاجية والإنظباط)
    private val _productivityRule = MutableStateFlow<com.example.model.ProductivityDisciplineRule?>(
        com.example.util.SaffahBlockRepository.getProductivityRule(context)
    )
    val productivityRule: StateFlow<com.example.model.ProductivityDisciplineRule?> = _productivityRule.asStateFlow()

    private val _isProductivityActiveNow = MutableStateFlow(false)
    val isProductivityActiveNow: StateFlow<Boolean> = _isProductivityActiveNow.asStateFlow()

    private val _productivityAppUsageMap = MutableStateFlow<Map<String, Int>>(emptyMap())
    val productivityAppUsageMap: StateFlow<Map<String, Int>> = _productivityAppUsageMap.asStateFlow()

    // Recovery Center State (مركز التعافي)
    private val _recoveryStats = MutableStateFlow(com.example.util.SaffahRecoveryManager.getRecoveryStats(context))
    val recoveryStats: StateFlow<com.example.model.RecoveryStats> = _recoveryStats.asStateFlow()

    private val _recoveryAnalytics = MutableStateFlow(com.example.util.SaffahRecoveryManager.getRecoveryAnalytics(context))
    val recoveryAnalytics: StateFlow<com.example.model.RecoveryAnalytics> = _recoveryAnalytics.asStateFlow()

    private val _recoveryCalendarHistory = MutableStateFlow<Map<String, com.example.model.DailyCalendarStatus>>(
        com.example.util.SaffahRecoveryManager.getRecoveryCalendarHistory(context)
    )
    val recoveryCalendarHistory: StateFlow<Map<String, com.example.model.DailyCalendarStatus>> = _recoveryCalendarHistory.asStateFlow()

    private val _urgeDatesSet = MutableStateFlow<Set<String>>(
        com.example.util.SaffahRecoveryManager.getUrgeDefeatedDates(context)
    )
    val urgeDatesSet: StateFlow<Set<String>> = _urgeDatesSet.asStateFlow()

    private val _recoveryCurrentTimeMs = MutableStateFlow(System.currentTimeMillis())
    val recoveryCurrentTimeMs: StateFlow<Long> = _recoveryCurrentTimeMs.asStateFlow()

    private val _userName = MutableStateFlow(com.example.util.SaffahRecoveryManager.getUserName(context))
    val userName: StateFlow<String> = _userName.asStateFlow()

    // Recovery Pledge State (وثيقة تعهد وميثاق التعافي)
    private val _recoveryPledge = MutableStateFlow(com.example.util.SaffahRecoveryManager.getRecoveryPledge(context))
    val recoveryPledge: StateFlow<com.example.model.RecoveryPledgeData> = _recoveryPledge.asStateFlow()

    // Daily Baseline State (مؤشر خط الأساس اليومي)
    private val _dailyBaselineHistory = MutableStateFlow<List<com.example.model.DailyBaselineCheckIn>>(
        com.example.util.SaffahRecoveryManager.getDailyBaselineHistory(context)
    )
    val dailyBaselineHistory: StateFlow<List<com.example.model.DailyBaselineCheckIn>> = _dailyBaselineHistory.asStateFlow()

    // Custom Defense Techniques & Triggers (التقنيات الدفاعية والمحفزات المخصصة)
    private val _customDefenseTechniques = MutableStateFlow<List<String>>(
        com.example.util.SaffahRecoveryManager.getCustomDefenseTechniques(context)
    )
    val customDefenseTechniques: StateFlow<List<String>> = _customDefenseTechniques.asStateFlow()

    private val _customTriggers = MutableStateFlow<List<String>>(
        com.example.util.SaffahRecoveryManager.getCustomTriggers(context)
    )
    val customTriggers: StateFlow<List<String>> = _customTriggers.asStateFlow()

    // Recovery Diary State (مذكرات التعافي)
    val audioPlayer = com.example.util.SaffahAudioPlayer(context)
    val audioRecorder = com.example.util.SaffahAudioRecorder(context)
    private val _diaryEntries = MutableStateFlow<List<com.example.model.RecoveryDiaryEntry>>(emptyList())
    val diaryEntries: StateFlow<List<com.example.model.RecoveryDiaryEntry>> = _diaryEntries.asStateFlow()
    private val _trashedDiaryEntries = MutableStateFlow<List<com.example.model.RecoveryDiaryEntry>>(emptyList())
    val trashedDiaryEntries: StateFlow<List<com.example.model.RecoveryDiaryEntry>> = _trashedDiaryEntries.asStateFlow()

    // Recovery Full Backup State (النسخ الاحتياطي الشامل لمركز التعافي)
    private val _recoveryBackupSummary = MutableStateFlow(com.example.util.SaffahRecoveryBackupManager.getRecoveryBackupSummary(context))
    val recoveryBackupSummary: StateFlow<com.example.model.RecoveryBackupSummary> = _recoveryBackupSummary.asStateFlow()

    private val _isRecoveryBackupInProgress = MutableStateFlow(false)
    val isRecoveryBackupInProgress: StateFlow<Boolean> = _isRecoveryBackupInProgress.asStateFlow()

    private val _isRecoveryRestoreInProgress = MutableStateFlow(false)
    val isRecoveryRestoreInProgress: StateFlow<Boolean> = _isRecoveryRestoreInProgress.asStateFlow()

    private val _recoveryBackupStatusMessage = MutableStateFlow<String?>(null)
    val recoveryBackupStatusMessage: StateFlow<String?> = _recoveryBackupStatusMessage.asStateFlow()

    // Privacy Protection (حماية الخصوصية برمز PIN)
    val privacyConfig: StateFlow<com.example.util.SaffahPrivacyManager.PrivacyConfig> =
        com.example.util.SaffahPrivacyManager.configFlow

    val isPrivacySessionUnlocked: StateFlow<Boolean> =
        com.example.util.SaffahPrivacyManager.isSessionUnlocked

    val unlockedPrivacySections: StateFlow<Set<String>> =
        com.example.util.SaffahPrivacyManager.unlockedSections

    private val _navigateToHomeEvent = kotlinx.coroutines.flow.MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val navigateToHomeEvent: kotlinx.coroutines.flow.SharedFlow<Unit> = _navigateToHomeEvent.asSharedFlow()

    fun requestNavigateToHome() {
        _navigateToHomeEvent.tryEmit(Unit)
    }

    @Volatile
    private var initialPermissionsRecorded = false
    @Volatile
    private var previousBatteryOptBypass: Boolean? = null

    fun isSectionLocked(sectionKey: String): Boolean {
        return com.example.util.SaffahPrivacyManager.isSectionLocked(context, sectionKey)
    }

    fun isEntireAppLocked(): Boolean {
        return com.example.util.SaffahPrivacyManager.isEntireAppLocked(context)
    }

    fun unlockPrivacySection(sectionKey: String) {
        com.example.util.SaffahPrivacyManager.unlockSection(sectionKey)
    }

    fun lockPrivacySection(sectionKey: String) {
        com.example.util.SaffahPrivacyManager.lockSection(sectionKey)
    }

    fun lockAllPrivacySections() {
        com.example.util.SaffahPrivacyManager.lockAllSections()
    }

    fun unlockPrivacySession() {
        com.example.util.SaffahPrivacyManager.unlockSession()
    }

    fun refreshPrivacyConfig() {
        com.example.util.SaffahPrivacyManager.refreshConfig(context)
    }

    fun protectPrivacySection(sectionKey: String) {
        com.example.util.SaffahPrivacyManager.protectSection(context, sectionKey)
    }

    fun unprotectPrivacySection(sectionKey: String) {
        com.example.util.SaffahPrivacyManager.unprotectSection(context, sectionKey)
    }

    fun removePrivacyPin() {
        val prefs = context.getSharedPreferences("saffah_privacy_prefs", Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
        com.example.util.SaffahPrivacyManager.lockAllSections()
        com.example.util.SaffahPrivacyManager.refreshConfig(context)
    }

    private var uiRefreshJob: kotlinx.coroutines.Job? = null

    init {
        com.example.util.SaffahPrivacyManager.init(context)
        viewModelScope.launch(Dispatchers.IO) {
            com.example.util.SaffahBlockRepository.ensureSwitchesDefaultOff(context)
            _isDisallowSafeBoot.value = SaffahProtectionManager.isDisallowSafeBootEnabled(context)
            _isDisallowConfigDateTime.value = SaffahProtectionManager.isDisallowConfigDateTimeEnabled(context)
            _isDisallowConfigPrivateDns.value = SaffahProtectionManager.isDisallowConfigPrivateDnsEnabled(context)
            _isDisallowDebuggingFeatures.value = SaffahProtectionManager.isDisallowDebuggingFeaturesEnabled(context)
            _isPenaltyEnabled.value = com.example.util.SaffahPenaltyManager.isPenaltyFeatureEnabled(context)
            _penaltyDurationMinutes.value = com.example.util.SaffahPenaltyManager.getPenaltyDurationMinutes(context)
            _isUrgeFeatureEnabled.value = SaffahUrgeManager.isUrgeFeatureEnabled(context)
            refreshQrKeyConfig()
            refreshTimeDelayStatus()
            refreshPenaltyStatus()
            refreshUrgeStatus()
            loadBedtimeSettings()
            checkPermissions()
            loadBlockData()
            loadRealInstalledApps(forceRefresh = true)
            loadFilteredAppsForBedtime(forceRefresh = true)
            loadFilteredAppsForKeywordExemption(forceRefresh = true)
            loadDiaryEntries()
        }
        viewModelScope.launch {
            SaffahVpnService.isVpnActive.collect { isActive ->
                _permissionStatus.value = _permissionStatus.value.copy(isVpnActive = isActive)
            }
        }
        viewModelScope.launch {
            com.example.util.AppListHelper.packageChangeEvents.collect { changedPkg ->
                android.util.Log.i("MainViewModel", "Package change event received in ViewModel for $changedPkg. Reloading installed apps.")
                loadRealInstalledApps(forceRefresh = true)
                loadFilteredAppsForBedtime(forceRefresh = true)
                loadFilteredAppsForKeywordExemption(forceRefresh = true)
            }
        }
        startUiPeriodicRefresh()
    }

    /**
     * Starts the periodic UI refresh loop when the UI is visible/foregrounded.
     * Executes an immediate refresh then repeats every 1000ms.
     */
    fun startUiPeriodicRefresh() {
        uiRefreshJob?.cancel()
        uiRefreshJob = viewModelScope.launch(Dispatchers.IO) {
            var cycle = 0
            while (isActive) {
                refreshTimeDelayStatus()
                refreshPenaltyStatus()
                refreshUrgeStatus()
                _recoveryCurrentTimeMs.value = System.currentTimeMillis()
                val isBt = com.example.util.SaffahBlockRepository.isCurrentlyBedtime(context)
                if (_isCurrentlyBedtime.value != isBt) {
                    _isCurrentlyBedtime.value = isBt
                }
                val isProd = com.example.util.SaffahBlockRepository.isProductivityActiveNow(context)
                if (_isProductivityActiveNow.value != isProd) {
                    _isProductivityActiveNow.value = isProd
                }
                // Throttle heavy productivity usage queries to once every 15-20s to eliminate high CPU cycles and phone heating
                if (cycle % 8 == 0) {
                    refreshProductivityUsage()
                }
                cycle++
                val hasActiveCountdown = _isTimeDelayActive.value || _isPenaltyActive.value || _isUrgeSessionActive.value
                delay(if (hasActiveCountdown) 1000L else 2500L)
            }
        }
    }

    /**
     * Stops the periodic UI refresh loop when the app goes to background to save battery and CPU cycles.
     */
    fun stopUiPeriodicRefresh() {
        uiRefreshJob?.cancel()
        uiRefreshJob = null
    }

    fun showFeedback(message: String) {
        viewModelScope.launch(Dispatchers.Main) {
            _userFeedbackMessage.value = message
            android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    fun refreshTimeDelayStatus() {
        val active = com.example.util.SaffahBlockRepository.isTimeDelayActive(context)
        val remaining = com.example.util.SaffahBlockRepository.getTimeDelayRemainingMs(context)
        val until = com.example.util.SaffahBlockRepository.getTimeDelayUntilTimestamp(context)
        val hours = com.example.util.SaffahBlockRepository.getConfiguredTimeDelayHours(context)
        if (_isTimeDelayActive.value != active) _isTimeDelayActive.value = active
        if (_remainingTimeDelayMs.value != remaining) _remainingTimeDelayMs.value = remaining
        if (_timeDelayUntilTimestamp.value != until) _timeDelayUntilTimestamp.value = until
        if (_configuredTimeDelayHours.value != hours) _configuredTimeDelayHours.value = hours
    }

    fun startTimeDelay(hours: Long) {
        if (_isQrKeyActive.value || com.example.util.SaffahQrKeyManager.isQrKeyProtectionActive(context)) {
            showFeedback("قفل QR المادي مفعّل حالياً. يجب حذف وتعطيل قفل QR أولاً قبل تفعيل التأخير الزمني.")
            return
        }
        val validHours = hours.coerceIn(1L, 900_000L)
        val success = com.example.util.SaffahBlockRepository.startTimeDelay(context, validHours)
        refreshTimeDelayStatus()
        if (success) {
            showFeedback("تم تفعيل ميزة التأخير الزمني بنجاح ($validHours ساعة)!")
        } else {
            showFeedback("فشل تفعيل التأخير الزمني؛ يرجى التأكد من تعطيل قفل QR أولاً.")
        }
    }

    fun extendTimeDelay(additionalHours: Long) {
        if (_isQrKeyActive.value || com.example.util.SaffahQrKeyManager.isQrKeyProtectionActive(context)) {
            showFeedback("قفل QR المادي مفعّل حالياً. لا يمكن تمديد التأخير الزمني.")
            return
        }
        if (additionalHours <= 0L) return
        val validAdditional = additionalHours.coerceIn(1L, 900_000L)
        val success = com.example.util.SaffahBlockRepository.extendTimeDelay(context, validAdditional)
        refreshTimeDelayStatus()
        if (success) {
            showFeedback("تم تمديد ميزة التأخير الزمني بمقدار $validAdditional ساعة إضافية!")
        }
    }

    fun loadBedtimeSettings() {
        _isBedtimeEnabled.value = com.example.util.SaffahBlockRepository.isBedtimeModeEnabled(context)
        val schedule = com.example.util.SaffahBlockRepository.getBedtimeSchedule(context)
        _bedtimeStartHour.value = schedule.first.first
        _bedtimeStartMinute.value = schedule.first.second
        _bedtimeEndHour.value = schedule.second.first
        _bedtimeEndMinute.value = schedule.second.second

        _bedtimeAllowedApps.value = com.example.util.SaffahBlockRepository.getBedtimeAllowedApps(context)
        _bedtimeDays.value = com.example.util.SaffahBlockRepository.getBedtimeDays(context)
        _isBedtimeGrayscaleEnabled.value = com.example.util.SaffahBlockRepository.isBedtimeGrayscaleEnabled(context)
        _isBedtimeEyeComfortEnabled.value = com.example.util.SaffahBlockRepository.isBedtimeEyeComfortEnabled(context)
        _isCurrentlyBedtime.value = com.example.util.SaffahBlockRepository.isCurrentlyBedtime(context)
        _isHardwareGrayscaleGranted.value = com.example.util.SaffahBedtimeManager.hasWriteSecureSettingsPermission(context)

        com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
    }

    fun setBedtimeEnabled(enabled: Boolean) {
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isBedtimeModificationAllowedWindow()
        val applyState = {
            com.example.util.SaffahBlockRepository.setBedtimeModeEnabled(context, enabled)
            _isBedtimeEnabled.value = enabled
            _isCurrentlyBedtime.value = com.example.util.SaffahBlockRepository.isCurrentlyBedtime(context)
            com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
            try {
                com.example.service.SaffahAccessibilityService.notifyScheduleOrBedtimeChanged(context)
            } catch (_: Throwable) {}
            if (enabled) showFeedback("تم تفعيل وضع النوم بنجاح")
            else showFeedback("تم تعطيل وضع النوم")
        }

        if (enabled || inAllowedWindow) {
            applyState()
            return
        }

        if (com.example.util.SaffahBlockRepository.isBedtimeModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن تعطيل وضع النوم أثناء سريان التأخير الزمني (يُسمح بالتعديل فقط بين 07:00 و 12:00).")
            return
        }

        executeProtectedAction("DISABLE_BEDTIME", "تعطيل وضع النوم الإجباري") {
            applyState()
        }
    }

    fun updateBedtimeSchedule(startH: Int, startM: Int, endH: Int, endM: Int) {
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isBedtimeModificationAllowedWindow()
        val applySchedule = {
            com.example.util.SaffahBlockRepository.saveBedtimeSchedule(context, startH, startM, endH, endM)
            _bedtimeStartHour.value = startH
            _bedtimeStartMinute.value = startM
            _bedtimeEndHour.value = endH
            _bedtimeEndMinute.value = endM
            _isCurrentlyBedtime.value = com.example.util.SaffahBlockRepository.isCurrentlyBedtime(context)
            com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
            try {
                com.example.service.SaffahAccessibilityService.notifyScheduleOrBedtimeChanged(context)
            } catch (_: Throwable) {}
            showFeedback("تم حفظ جدول وقت النوم بنجاح")
        }

        if (inAllowedWindow) {
            applySchedule()
            return
        }

        val currentDuration = com.example.util.SaffahBlockRepository.calculateBedtimeDurationMinutes(
            _bedtimeStartHour.value, _bedtimeStartMinute.value,
            _bedtimeEndHour.value, _bedtimeEndMinute.value
        )
        val newDuration = com.example.util.SaffahBlockRepository.calculateBedtimeDurationMinutes(
            startH, startM, endH, endM
        )

        if (newDuration >= currentDuration) {
            // Tightening (increasing bedtime duration) -> No QR code needed
            applySchedule()
            return
        }

        // Decreasing duration outside allowed window
        if (com.example.util.SaffahBlockRepository.isBedtimeModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن تقليل مدة نطاق وقت النوم خارج الفترة المسموحة (07:00 - 12:00). يُسمح فقط بزيادة النطاق.")
            return
        }

        executeProtectedAction("UPDATE_BEDTIME_SCHEDULE", "تعديل جدول ومواعيد وضع النوم") {
            applySchedule()
        }
    }

    fun toggleBedtimeAllowedApp(packageName: String) {
        val isAdding = !_bedtimeAllowedApps.value.contains(packageName)
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isBedtimeModificationAllowedWindow()

        val applyToggle = {
            val updated = com.example.util.SaffahBlockRepository.toggleBedtimeAllowedApp(context, packageName)
            _bedtimeAllowedApps.value = updated
            loadFilteredAppsForBedtime()
            com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
            if (updated.contains(packageName)) {
                showFeedback("تمت إضافة التطبيق للمسموحات أثناء النوم")
            } else {
                showFeedback("تمت إزالة التطبيق من مسموحات النوم")
            }
        }

        if (!isAdding || inAllowedWindow) {
            // Removing allowed app (tightening) or in allowed modification window -> No QR code needed
            applyToggle()
            return
        }

        // Adding allowed app outside allowed window
        if (com.example.util.SaffahBlockRepository.isBedtimeModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن إضافة تطبيقات مسموحة جديدة خارج الفترة المسموحة (07:00 - 12:00). يُسمح فقط بإلغاء التطبيقات.")
            return
        }

        executeProtectedAction("TOGGLE_BEDTIME_ALLOWED_APP", "السماح بتطبيق أثناء وضع النوم ($packageName)") {
            applyToggle()
        }
    }

    fun toggleBedtimeDay(dayOfWeek: Int) {
        val isUnchecking = _bedtimeDays.value.contains(dayOfWeek)
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isBedtimeModificationAllowedWindow()

        val applyToggle = {
            val updated = com.example.util.SaffahBlockRepository.toggleBedtimeDay(context, dayOfWeek)
            _bedtimeDays.value = updated
            _isCurrentlyBedtime.value = com.example.util.SaffahBlockRepository.isCurrentlyBedtime(context)
            com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
        }

        if (!isUnchecking || inAllowedWindow) {
            // Adding active day (tightening) or in allowed window -> No QR code needed
            applyToggle()
            return
        }

        // Removing active day outside allowed window
        if (com.example.util.SaffahBlockRepository.isBedtimeModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن استثناء أيام من وضع النوم خارج الفترة المسموحة (07:00 - 12:00). يُسمح فقط بإضافة أيام.")
            return
        }

        executeProtectedAction("TOGGLE_BEDTIME_DAY", "استثناء يوم من جدول وضع النوم") {
            applyToggle()
        }
    }

    fun clearBedtimeAllowedApps() {
        // Clearing all allowed apps is tightening -> No QR code scan needed
        com.example.util.SaffahBlockRepository.saveBedtimeAllowedApps(context, emptySet())
        _bedtimeAllowedApps.value = emptySet()
        loadFilteredAppsForBedtime()
        com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
        showFeedback("تم إلغاء كافة استثناءات النوم")
    }

    fun setBedtimeAllowedApps(apps: Set<String>) {
        val current = _bedtimeAllowedApps.value
        val isAddingNew = apps.any { !current.contains(it) }
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isBedtimeModificationAllowedWindow()

        val applySet = { updatedSet: Set<String> ->
            com.example.util.SaffahBlockRepository.saveBedtimeAllowedApps(context, updatedSet)
            _bedtimeAllowedApps.value = updatedSet
            loadFilteredAppsForBedtime()
            com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
            showFeedback("تم تحديث مسموحات النوم")
        }

        if (!isAddingNew || inAllowedWindow) {
            // Only removing allowed apps (tightening) or in allowed window -> No QR code needed
            applySet(apps)
            return
        }

        // Adding new allowed apps outside allowed window
        if (com.example.util.SaffahBlockRepository.isBedtimeModificationRestrictedByTimeDelay(context)) {
            val filtered = apps.filter { current.contains(it) }.toSet()
            showFeedback("لا يمكن إضافة تطبيقات مسموحة جديدة خارج الفترة المسموحة (07:00 - 12:00).")
            applySet(filtered)
            return
        }

        executeProtectedAction("SET_BEDTIME_ALLOWED_APPS", "تعديل قائمة التطبيقات المسموحة في وضع النوم") {
            applySet(apps)
        }
    }

    fun setBedtimeGrayscaleEnabled(enabled: Boolean) {
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isBedtimeModificationAllowedWindow()
        val applyGrayscale = {
            com.example.util.SaffahBlockRepository.setBedtimeGrayscaleEnabled(context, enabled)
            _isBedtimeGrayscaleEnabled.value = enabled
            com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
            if (enabled) {
                showFeedback("تم تفعيل ميزة الأبيض والأسود (تبدأ تلقائياً قبل 30 دقيقة من موعد النوم)")
            } else {
                showFeedback("تم إلغاء ميزة تحويل الشاشة إلى الأبيض والأسود")
            }
        }

        if (enabled || inAllowedWindow) {
            applyGrayscale()
            return
        }

        if (com.example.util.SaffahBlockRepository.isBedtimeModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن تعطيل ميزة Grayscale أثناء سريان التأخير الزمني (يُسمح بالتعديل فقط بين 07:00 و 12:00).")
            return
        }

        executeProtectedAction("DISABLE_BEDTIME_GRAYSCALE", "تعطيل تحويل الشاشة للأبيض والأسود لوضع النوم") {
            applyGrayscale()
        }
    }

    fun setBedtimeEyeComfortEnabled(enabled: Boolean) {
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isBedtimeModificationAllowedWindow()
        val applyEyeComfort = {
            com.example.util.SaffahBlockRepository.setBedtimeEyeComfortEnabled(context, enabled)
            _isBedtimeEyeComfortEnabled.value = enabled
            com.example.util.SaffahBedtimeManager.evaluateBedtimeState(context)
            if (enabled) {
                showFeedback("تم تفعيل وضع راحة العين (يبدأ تلقائياً قبل 30 دقيقة من موعد النوم)")
            } else {
                showFeedback("تم تعطيل وضع راحة العين")
            }
        }

        if (enabled || inAllowedWindow) {
            applyEyeComfort()
            return
        }

        if (com.example.util.SaffahBlockRepository.isBedtimeModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن تعطيل ميزة وضع راحة العين أثناء سريان التأخير الزمني (يُسمح بالتعديل فقط بين 07:00 و 12:00).")
            return
        }

        executeProtectedAction("DISABLE_BEDTIME_EYE_COMFORT", "تعطيل وضع راحة العين لوضع النوم") {
            applyEyeComfort()
        }
    }

    fun refreshGrayscalePermissionState() {
        _isHardwareGrayscaleGranted.value = com.example.util.SaffahBedtimeManager.hasWriteSecureSettingsPermission(context)
    }

    fun testGrayscaleNow(durationSeconds: Int = 5) {
        if (_isTestingGrayscale.value) return
        _isTestingGrayscale.value = true
        showFeedback("جاري اختبار تحويل الشاشة إلى أبيض وأسود لمدة $durationSeconds ثوان...")
        com.example.util.SaffahBedtimeManager.testGrayscale(context, durationSeconds) {
            _isTestingGrayscale.value = false
            showFeedback("انتهى الاختبار وتمت استعادة الألوان بنجاح")
        }
    }

    fun getAdbCommandForGrayscale(): String {
        return "adb shell pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS"
    }

    // --- PHYSICAL QR CODE KEY PROTECTION MANAGEMENT ---
    fun refreshQrKeyConfig() {
        _qrKeyConfig.value = com.example.util.SaffahQrKeyManager.getQrKeyConfig(context)
        val active = com.example.util.SaffahQrKeyManager.isQrKeyProtectionActive(context)
        _isQrKeyActive.value = active
        if (active) {
            // عند تفعيل الحماية عبر قفل QR المادي يتم تعطيل الحماية عبر ميزة التأخير الزمني
            com.example.util.SaffahBlockRepository.stopTimeDelay(context)
            refreshTimeDelayStatus()
        }
    }

    fun registerQrKey(rawCode: String, customLabel: String? = null): Boolean {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("ميزة التأخير الزمني نشطة حالياً. لا يُسمح بتفعيل قفل QR إلا بعد انتهاء مدة التأخير الزمني.")
            return false
        }
        return when (val result = com.example.util.SaffahQrKeyManager.registerQrKey(context, rawCode, customLabel)) {
            is com.example.util.SaffahQrKeyManager.RegisterKeyResult.Success -> {
                refreshQrKeyConfig()
                refreshTimeDelayStatus()
                showFeedback("تم تفعيل قفل QR بنجاح (${result.key.label}) وتم تعطيل التأخير الزمني.")
                true
            }
            is com.example.util.SaffahQrKeyManager.RegisterKeyResult.TimeDelayActive -> {
                showFeedback("ميزة التأخير الزمني نشطة حالياً. لا يُسمح بتفعيل قفل QR إلا بعد انتهاء مدة التأخير الزمني.")
                false
            }
            is com.example.util.SaffahQrKeyManager.RegisterKeyResult.AlreadyExists -> {
                showFeedback("هذا الرمز مسجل ومضاف مسبقاً في قائمة الأكواد.")
                false
            }
            is com.example.util.SaffahQrKeyManager.RegisterKeyResult.InvalidCode -> {
                showFeedback("فشل تسجيل الرمز، يرجى المحاولة مرة أخرى.")
                false
            }
        }
    }

    fun findKeyByRawCode(rawCode: String): com.example.util.SaffahQrKeyManager.QrKeyItem? {
        return com.example.util.SaffahQrKeyManager.findKeyByRawCode(context, rawCode)
    }

    fun deleteQrKeyByScannedCode(rawCode: String): Boolean {
        val success = com.example.util.SaffahQrKeyManager.deleteQrKeyByRawCode(context, rawCode)
        refreshQrKeyConfig()
        refreshTimeDelayStatus()
        if (success) {
            showFeedback("تم حذف كود الحماية المسجل بنجاح.")
        }
        return success
    }

    fun deleteQrKey(keyId: String, keyLabel: String = "كود الحماية", bypassGate: Boolean = false) {
        val doDelete = {
            val success = com.example.util.SaffahQrKeyManager.deleteQrKey(context, keyId)
            refreshQrKeyConfig()
            refreshTimeDelayStatus()
            if (success) {
                showFeedback("تم حذف $keyLabel بنجاح.")
            }
        }
        if (bypassGate) {
            doDelete()
        } else {
            executeProtectedAction(
                actionType = "DELETE_QR_KEY",
                actionDescription = "حذف $keyLabel (يلزم مسح الكود الأساسي الأول)",
                requirePrimaryOnly = true
            ) {
                doDelete()
            }
        }
    }

    fun verifyQrKeyAndExecute(scannedCode: String): Pair<Boolean, String?> {
        val requirePrimary = _isPendingActionPrimaryOnly.value
        return when (val result = com.example.util.SaffahQrKeyManager.verifyScannedCodeDetails(context, scannedCode, requirePrimary)) {
            is com.example.util.SaffahQrKeyManager.VerificationResult.Success -> {
                val callback = pendingProtectedActionCallback
                pendingProtectedActionCallback = null
                _showQrKeyVerificationDialog.value = false
                _isPendingActionPrimaryOnly.value = false
                callback?.invoke()
                showFeedback("تم التحقق بنجاح من الرمز! تم تنفيذ الإجراء.")
                Pair(true, null)
            }
            is com.example.util.SaffahQrKeyManager.VerificationResult.SecondaryKeyWhenPrimaryRequired -> {
                val msg = "تم مسح '${result.scannedKey.label}' وهو كود إضافي. يلزم مسح الكود الأساسي الأول (${result.primaryKey.label}) لإتمام هذا الإجراء."
                Pair(false, msg)
            }
            is com.example.util.SaffahQrKeyManager.VerificationResult.NotRegistered -> {
                Pair(false, "الرمز الممسوح غير مسجل! يرجى مسح رمز حماية معتمد.")
            }
            is com.example.util.SaffahQrKeyManager.VerificationResult.InvalidCode -> {
                Pair(false, "رمز غير صالح! يرجى مسح كود QR صالح.")
            }
        }
    }

    fun clearQrKey() {
        executeProtectedAction(
            actionType = "CLEAR_QR_KEYS",
            actionDescription = "حذف وتعطيل جميع أكواد الـ QR (يلزم مسح الكود الأساسي الأول)",
            requirePrimaryOnly = true
        ) {
            com.example.util.SaffahQrKeyManager.clearQrKey(context)
            refreshQrKeyConfig()
            refreshTimeDelayStatus()
            showFeedback("تم حذف جميع مفاتيح الـ QR وتعطيل الميزة تلقائياً.")
        }
    }

    fun dismissQrKeyDialog() {
        _showQrKeyVerificationDialog.value = false
        _isPendingActionPrimaryOnly.value = false
        pendingProtectedActionCallback = null
    }

    fun executeProtectedAction(
        actionType: String,
        actionDescription: String,
        requirePrimaryOnly: Boolean = false,
        onAction: () -> Unit
    ) {
        if (!_isQrKeyActive.value) {
            pendingProtectedActionCallback = null
            _isPendingActionPrimaryOnly.value = false
            onAction()
            return
        }
        _pendingProtectedActionDesc.value = actionDescription
        _isPendingActionPrimaryOnly.value = requirePrimaryOnly
        pendingProtectedActionCallback = onAction
        _showQrKeyVerificationDialog.value = true
    }

    fun loadFilteredAppsForBedtime(forceRefresh: Boolean = true) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = com.example.util.AppListHelper.getFilteredInstalledApps(context, forceRefresh = forceRefresh)
            withContext(Dispatchers.Main) {
                _filteredAppsForBedtime.value = list
            }
        }
    }

    fun loadFilteredAppsForKeywordExemption(forceRefresh: Boolean = true) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = com.example.util.AppListHelper.getFilteredInstalledApps(context, forceRefresh = forceRefresh)
            withContext(Dispatchers.Main) {
                _filteredAppsForKeywordExemption.value = list
            }
        }
    }

    fun toggleKeywordExemptedApp(packageName: String) {
        val current = _keywordExemptedApps.value
        val isAdding = !current.contains(packageName)

        val applyToggle = {
            val updated = com.example.util.SaffahBlockRepository.toggleKeywordExemptedApp(context, packageName)
            _keywordExemptedApps.value = updated
            loadFilteredAppsForKeywordExemption()
            if (updated.contains(packageName)) {
                showFeedback("تم استثناء التطبيق من الكلمات المحظورة")
            } else {
                showFeedback("تم إلغاء استثناء التطبيق من الكلمات المحظورة")
            }
        }

        if (!isAdding) {
            // Removing exemption (tightening) -> No QR code scan needed
            applyToggle()
            return
        }

        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن إضافة تطبيقات جديدة للاستثناء أثناء سريان ميزة التأخير الزمني. يُسمح فقط بإلغاء الاستثناء.")
            return
        }

        executeProtectedAction("TOGGLE_KEYWORD_EXEMPTION", "استثناء تطبيق من فحص الكلمات المحظورة ($packageName)") {
            applyToggle()
        }
    }

    fun removeKeywordExemptedApp(packageName: String) {
        // Removing exemption (tightening) -> No QR code scan needed
        val updated = com.example.util.SaffahBlockRepository.removeKeywordExemptedApp(context, packageName)
        _keywordExemptedApps.value = updated
        loadFilteredAppsForKeywordExemption()
        showFeedback("تم إلغاء استثناء التطبيق من الكلمات المحظورة")
    }

    fun setKeywordExemptedApps(apps: Set<String>) {
        val current = _keywordExemptedApps.value
        val isAddingNew = apps.any { !current.contains(it) }

        val applySet = {
            com.example.util.SaffahBlockRepository.saveKeywordExemptedApps(context, apps)
            _keywordExemptedApps.value = apps
            loadFilteredAppsForKeywordExemption()
            showFeedback("تم حفظ قائمة الاستثناءات بنجاح")
        }

        if (!isAddingNew) {
            // Only removing exemptions (tightening) -> No QR code scan needed
            applySet()
            return
        }

        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن إضافة تطبيقات جديدة للاستثناء أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("SET_KEYWORD_EXEMPTED_APPS", "تعديل قائمة التطبيقات المستثناة من الكلمات المحظورة") {
            applySet()
        }
    }

    fun clearAllKeywordExemptedApps() {
        // Removing all exemptions (tightening) -> No QR code scan needed
        com.example.util.SaffahBlockRepository.saveKeywordExemptedApps(context, emptySet())
        _keywordExemptedApps.value = emptySet()
        loadFilteredAppsForKeywordExemption()
        showFeedback("تم إلغاء جميع استثناءات التطبيقات من الكلمات المحظورة")
    }

    fun loadBlockData() {
        _blockedKeywords.value = com.example.util.SaffahBlockRepository.getBlockedKeywords(context)
        _blockedSites.value = com.example.util.SaffahBlockRepository.getBlockedSites(context)
        _blockLogs.value = com.example.util.SaffahBlockRepository.getBlockLogs(context)
        _keywordExemptedApps.value = com.example.util.SaffahBlockRepository.getKeywordExemptedApps(context)
        _isTelegramSearchBlocked.value = com.example.util.SaffahBlockRepository.isTelegramSearchBlocked(context)
        _isWhatsAppChannelsBlocked.value = com.example.util.SaffahBlockRepository.isWhatsAppChannelsBlocked(context)
        _isYouTubeShortsBlocked.value = com.example.util.SaffahBlockRepository.isYouTubeShortsBlocked(context)
        _isFacebookLiteReelsBlocked.value = com.example.util.SaffahBlockRepository.isFacebookLiteReelsBlocked(context)
        _isInstagramReelsBlocked.value = com.example.util.SaffahBlockRepository.isInstagramReelsBlocked(context)
        _isBlockUnsupportedBrowsers.value = com.example.util.SaffahBlockRepository.isBlockUnsupportedBrowsers(context)
        _isBlockInAppBrowsers.value = com.example.util.SaffahBlockRepository.isBlockInAppBrowsers(context)
        _isHideVpnNotification.value = com.example.util.SaffahBlockRepository.isHideVpnNotification(context)
        _isAiProtectionEnabled.value = com.example.util.SaffahBlockRepository.isAiProtectionEnabled(context)
        _isAiNudeNetEnabled.value = com.example.util.SaffahBlockRepository.isAiNudeNetEnabled(context)
        _isAiAnimeEnabled.value = com.example.util.SaffahBlockRepository.isAiAnimeEnabled(context)
        _isAiDryRunEnabled.value = com.example.util.SaffahBlockRepository.isAiDryRunEnabled(context)
        _animeConfig.value = com.example.util.SaffahBlockRepository.getAnimeConfig(context)
        _nudeConfig.value = com.example.util.SaffahBlockRepository.getNudeConfig(context)
        _aiProtectionIncludedApps.value = com.example.util.SaffahBlockRepository.getAiProtectionIncludedApps(context)
        _isKeeperServiceEnabled.value = com.example.util.SaffahProtectionManager.isKeeperServiceEnabled(context)
        _isAppScheduleMasterEnabled.value = com.example.util.SaffahBlockRepository.isAppScheduleMasterEnabled(context)
        _appScheduleRules.value = com.example.util.SaffahBlockRepository.getAppScheduleRules(context)
        _isUsageMasterEnabled.value = com.example.util.SaffahBlockRepository.isUsageMasterEnabled(context)
        _usageRules.value = com.example.util.SaffahBlockRepository.getUsageRules(context)
        _permanentBlockedPackages.value = com.example.util.SaffahBlockRepository.getPermanentBlockedPackages(context)
        _uninstallBlockedPackages.value = com.example.util.SaffahBlockRepository.getUninstallBlockedPackages(context)
        com.example.util.SaffahProtectionManager.syncUninstallBlockedPackages(context)
        _productivityRule.value = com.example.util.SaffahBlockRepository.getProductivityRule(context)
        _isProductivityActiveNow.value = com.example.util.SaffahBlockRepository.isProductivityActiveNow(context)
        refreshProductivityUsage()
        loadBedtimeSettings()
        loadRealInstalledApps(forceRefresh = true)
        com.example.util.SaffahBlockRepository.applyPackageSuspensionIfNeeded(context)
    }

    fun addPermanentBlockedPackage(packageName: String) {
        com.example.util.SaffahBlockRepository.addPermanentBlockedPackage(context, packageName)
        _permanentBlockedPackages.value = com.example.util.SaffahBlockRepository.getPermanentBlockedPackages(context)
    }

    fun removePermanentBlockedPackage(packageName: String) {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن إزالة التطبيقات من الحظر المؤبد أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("REMOVE_PERMANENT_APP", "إزالة تطبيق من قائمة الحظر المؤبد ($packageName)") {
            com.example.util.SaffahBlockRepository.removePermanentBlockedPackage(context, packageName)
            _permanentBlockedPackages.value = com.example.util.SaffahBlockRepository.getPermanentBlockedPackages(context)
            showFeedback("تم إزالة التطبيق من قائمة الحظر المؤبد.")
        }
    }

    fun setPermanentBlockedPackages(packages: Set<String>) {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            val current = _permanentBlockedPackages.value
            if (!packages.containsAll(current)) {
                showFeedback("لا يمكن إزالة التطبيقات من الحظر المؤبد أثناء سريان ميزة التأخير الزمني.")
                return
            }
        }
        com.example.util.SaffahBlockRepository.setPermanentBlockedPackages(context, packages)
        _permanentBlockedPackages.value = com.example.util.SaffahBlockRepository.getPermanentBlockedPackages(context)
    }

    fun togglePermanentBlockedPackage(packageName: String) {
        val current = _permanentBlockedPackages.value.toMutableSet()
        if (current.contains(packageName)) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن إزالة التطبيقات من الحظر المؤبد أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("REMOVE_PERMANENT_APP", "إزالة تطبيق من قائمة الحظر المؤبد ($packageName)") {
                current.remove(packageName)
                setPermanentBlockedPackages(current)
                showFeedback("تم إزالة التطبيق من قائمة الحظر المؤبد.")
            }
        } else {
            current.add(packageName)
            setPermanentBlockedPackages(current)
        }
    }

    fun addUninstallBlockedPackage(packageName: String) {
        com.example.util.SaffahBlockRepository.addUninstallBlockedPackage(context, packageName)
        _uninstallBlockedPackages.value = com.example.util.SaffahBlockRepository.getUninstallBlockedPackages(context)
        if (_permissionStatus.value.isDeviceOwnerActive) {
            showFeedback("تمت إضافة التطبيق لمنع حذفه عبر مشرف الجهاز.")
        } else {
            showFeedback("تمت الإضافة. يلزم تفعيل صلاحية مشرف الجهاز (Device Owner) لتفعيل الحماية.")
        }
    }

    fun removeUninstallBlockedPackage(packageName: String) {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن إزالة التطبيقات من قائمة منع الحذف أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("REMOVE_UNINSTALL_BLOCKED_APP", "إزالة تطبيق من قائمة منع الحذف ($packageName)") {
            com.example.util.SaffahBlockRepository.removeUninstallBlockedPackage(context, packageName)
            _uninstallBlockedPackages.value = com.example.util.SaffahBlockRepository.getUninstallBlockedPackages(context)
            showFeedback("تم إزالة التطبيق من قائمة منع الحذف والسماح بإلغاء تثبيته.")
        }
    }

    fun setUninstallBlockedPackages(packages: Set<String>) {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            val current = _uninstallBlockedPackages.value
            if (!packages.containsAll(current)) {
                showFeedback("لا يمكن إزالة التطبيقات من قائمة منع الحذف أثناء سريان ميزة التأخير الزمني.")
                return
            }
        }
        val current = _uninstallBlockedPackages.value
        val isRemoving = !packages.containsAll(current)
        if (isRemoving) {
            executeProtectedAction("UPDATE_UNINSTALL_BLOCKED_APPS", "تعديل قائمة منع حذف التطبيقات") {
                com.example.util.SaffahBlockRepository.setUninstallBlockedPackages(context, packages)
                _uninstallBlockedPackages.value = com.example.util.SaffahBlockRepository.getUninstallBlockedPackages(context)
                if (_permissionStatus.value.isDeviceOwnerActive) {
                    showFeedback("تم تحديث قائمة منع حذف التطبيقات وتطبيقها عبر مشرف الجهاز.")
                } else {
                    showFeedback("تم حفظ القائمة. يلزم تفعيل صلاحية مشرف الجهاز لتطبيق الحماية.")
                }
            }
        } else {
            com.example.util.SaffahBlockRepository.setUninstallBlockedPackages(context, packages)
            _uninstallBlockedPackages.value = com.example.util.SaffahBlockRepository.getUninstallBlockedPackages(context)
            if (_permissionStatus.value.isDeviceOwnerActive) {
                showFeedback("تم تحديث قائمة منع حذف التطبيقات وتطبيقها عبر مشرف الجهاز.")
            } else {
                showFeedback("تم حفظ القائمة. يلزم تفعيل صلاحية مشرف الجهاز لتطبيق الحماية.")
            }
        }
    }

    fun toggleAppScheduleMasterEnabled(enabled: Boolean) {
        if (!enabled) {
            val rules = _appScheduleRules.value
            if (rules.any { it.isEnabled }) {
                if (com.example.util.SaffahBlockRepository.isAppScheduleRuleModificationRestricted(context)) {
                    showFeedback("يمنع تعطيل ميزة الحظر الدوري عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00).")
                    return
                }
                com.example.util.SaffahBlockRepository.setAppScheduleMasterEnabled(context, false)
                _isAppScheduleMasterEnabled.value = false
                showFeedback("تم تعطيل الحظر الدوري.")
                return
            }
        }
        com.example.util.SaffahBlockRepository.setAppScheduleMasterEnabled(context, enabled)
        _isAppScheduleMasterEnabled.value = enabled
    }

    fun upsertAppScheduleRule(rule: AppBlockScheduleRule) {
        val validationError = com.example.util.SaffahBlockRepository.validateAppScheduleRuleModification(context, rule)
        if (validationError != null) {
            showFeedback(validationError)
            return
        }
        val updated = com.example.util.SaffahBlockRepository.upsertAppScheduleRule(context, rule)
        _appScheduleRules.value = updated
        showFeedback("تم حفظ عملية الحظر الدورية بنجاح.")
    }

    fun deleteAppScheduleRule(id: Long) {
        if (com.example.util.SaffahBlockRepository.isAppScheduleRuleModificationRestricted(context)) {
            showFeedback("يمنع حذف عمليات الحظر الدورية عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00).")
            return
        }
        val updated = com.example.util.SaffahBlockRepository.deleteAppScheduleRule(context, id)
        _appScheduleRules.value = updated
        showFeedback("تم حذف عملية الحظر الدورية.")
    }

    fun reorderAppScheduleRules(newRules: List<AppBlockScheduleRule>) {
        val updated = com.example.util.SaffahBlockRepository.reorderAppScheduleRules(context, newRules)
        _appScheduleRules.value = updated
    }

    fun toggleAppScheduleRuleEnabled(id: Long) {
        val rule = _appScheduleRules.value.find { it.id == id }
        if (rule != null && rule.isEnabled) {
            if (com.example.util.SaffahBlockRepository.isAppScheduleRuleModificationRestricted(context)) {
                showFeedback("يمنع تعطيل عملية الحظر الدورية عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00).")
                return
            }
            val updated = com.example.util.SaffahBlockRepository.toggleAppScheduleRuleEnabled(context, id)
            _appScheduleRules.value = updated
            showFeedback("تم تعطيل عملية الحظر الدورية.")
            return
        }
        val updated = com.example.util.SaffahBlockRepository.toggleAppScheduleRuleEnabled(context, id)
        _appScheduleRules.value = updated
    }

    fun toggleUsageMasterEnabled(enabled: Boolean) {
        if (!enabled) {
            val rules = _usageRules.value
            if (rules.any { it.isEnabled }) {
                if (com.example.util.SaffahBlockRepository.isUsageRuleModificationRestricted(context)) {
                    showFeedback("يمنع تعطيل ميزة الحظر بالاستخدام عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00).")
                    return
                }
                com.example.util.SaffahBlockRepository.setUsageMasterEnabled(context, false)
                _isUsageMasterEnabled.value = false
                showFeedback("تم تعطيل الحظر بالاستخدام.")
                return
            }
        }
        com.example.util.SaffahBlockRepository.setUsageMasterEnabled(context, enabled)
        _isUsageMasterEnabled.value = enabled
    }

    fun upsertUsageRule(rule: UsageBlockRule) {
        val validationError = com.example.util.SaffahBlockRepository.validateUsageRuleModification(context, rule)
        if (validationError != null) {
            showFeedback(validationError)
            return
        }
        val updated = com.example.util.SaffahBlockRepository.upsertUsageRule(context, rule)
        _usageRules.value = updated
        _isUsageMasterEnabled.value = com.example.util.SaffahBlockRepository.isUsageMasterEnabled(context)
        showFeedback("تم حفظ وتطبيق عملية الحظر بنجاح.")
    }

    fun deleteUsageRule(id: Long) {
        if (com.example.util.SaffahBlockRepository.isUsageRuleModificationRestricted(context)) {
            showFeedback("يمنع حذف عمليات الحظر بالاستخدام عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00).")
            return
        }
        val updated = com.example.util.SaffahBlockRepository.deleteUsageRule(context, id)
        _usageRules.value = updated
        _isUsageMasterEnabled.value = com.example.util.SaffahBlockRepository.isUsageMasterEnabled(context)
        showFeedback("تم حذف عملية الحظر.")
    }

    fun reorderUsageRules(newRules: List<UsageBlockRule>) {
        val updated = com.example.util.SaffahBlockRepository.reorderUsageRules(context, newRules)
        _usageRules.value = updated
    }

    fun toggleUsageRuleEnabled(id: Long) {
        val rule = _usageRules.value.find { it.id == id }
        if (rule != null && rule.isEnabled) {
            if (com.example.util.SaffahBlockRepository.isUsageRuleModificationRestricted(context)) {
                showFeedback("يمنع تعطيل عملية الحظر بالاستخدام عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00).")
                return
            }
            val updated = com.example.util.SaffahBlockRepository.toggleUsageRuleEnabled(context, id)
            _usageRules.value = updated
            _isUsageMasterEnabled.value = com.example.util.SaffahBlockRepository.isUsageMasterEnabled(context)
            showFeedback("تم تعطيل عملية الحظر بالاستخدام.")
            return
        }
        val updated = com.example.util.SaffahBlockRepository.toggleUsageRuleEnabled(context, id)
        _usageRules.value = updated
        _isUsageMasterEnabled.value = com.example.util.SaffahBlockRepository.isUsageMasterEnabled(context)
    }

    fun toggleTelegramSearchBlocked(enabled: Boolean) {
        if (!enabled && _isTelegramSearchBlocked.value) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر بحث تيليجرام أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_TELEGRAM_BLOCK", "تعطيل حظر البحث في تيليجرام") {
                com.example.util.SaffahBlockRepository.setTelegramSearchBlocked(context, false)
                _isTelegramSearchBlocked.value = false
                showFeedback("تم تعطيل حظر البحث في تيليجرام.")
            }
            return
        }
        com.example.util.SaffahBlockRepository.setTelegramSearchBlocked(context, enabled)
        _isTelegramSearchBlocked.value = enabled
        if (enabled) showFeedback("تم تفعيل حظر البحث في تيليجرام.")
    }

    fun toggleWhatsAppChannelsBlocked(enabled: Boolean) {
        if (!enabled && _isWhatsAppChannelsBlocked.value) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر قنوات واتساب أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_WHATSAPP_CHANNELS", "تعطيل حظر استكشاف وقنوات واتساب") {
                com.example.util.SaffahBlockRepository.setWhatsAppChannelsBlocked(context, false)
                _isWhatsAppChannelsBlocked.value = false
                showFeedback("تم تعطيل حظر قنوات واتساب.")
            }
            return
        }
        com.example.util.SaffahBlockRepository.setWhatsAppChannelsBlocked(context, enabled)
        _isWhatsAppChannelsBlocked.value = enabled
        if (enabled) showFeedback("تم تفعيل حظر استكشاف وقنوات واتساب.")
    }

    fun toggleYouTubeShortsBlocked(enabled: Boolean) {
        if (!enabled && _isYouTubeShortsBlocked.value) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر يوتيوب شورتس أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_SHORTS_BLOCK", "تعطيل حظر يوتيوب شورتس") {
                com.example.util.SaffahBlockRepository.setYouTubeShortsBlocked(context, false)
                _isYouTubeShortsBlocked.value = false
                showFeedback("تم تعطيل حظر يوتيوب شورتس.")
            }
            return
        }
        com.example.util.SaffahBlockRepository.setYouTubeShortsBlocked(context, enabled)
        _isYouTubeShortsBlocked.value = enabled
        if (enabled) showFeedback("تم تفعيل حظر يوتيوب شورتس.")
    }

    fun toggleFacebookLiteReelsBlocked(enabled: Boolean) {
        if (!enabled && _isFacebookLiteReelsBlocked.value) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر ريلز فيسبوك لايت أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_FB_REELS_BLOCK", "تعطيل حظر ريلز فيسبوك لايت") {
                com.example.util.SaffahBlockRepository.setFacebookLiteReelsBlocked(context, false)
                _isFacebookLiteReelsBlocked.value = false
                showFeedback("تم تعطيل حظر ريلز فيسبوك لايت.")
            }
            return
        }
        com.example.util.SaffahBlockRepository.setFacebookLiteReelsBlocked(context, enabled)
        _isFacebookLiteReelsBlocked.value = enabled
        if (enabled) showFeedback("تم تفعيل حظر ريلز فيسبوك لايت.")
    }

    fun toggleInstagramReelsBlocked(enabled: Boolean) {
        if (!enabled && _isInstagramReelsBlocked.value) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر ريلز انستغرام أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_INSTA_REELS_BLOCK", "تعطيل حظر ريلز انستغرام") {
                com.example.util.SaffahBlockRepository.setInstagramReelsBlocked(context, false)
                _isInstagramReelsBlocked.value = false
                showFeedback("تم تعطيل حظر ريلز انستغرام.")
            }
            return
        }
        com.example.util.SaffahBlockRepository.setInstagramReelsBlocked(context, enabled)
        _isInstagramReelsBlocked.value = enabled
        if (enabled) showFeedback("تم تفعيل حظر ريلز انستغرام.")
    }

    private val _totalBlockEventsCount = MutableStateFlow(0)
    val totalBlockEventsCount: StateFlow<Int> = _totalBlockEventsCount.asStateFlow()

    private val _detectedKeywordsCount = MutableStateFlow(0)
    val detectedKeywordsCount: StateFlow<Int> = _detectedKeywordsCount.asStateFlow()

    private val _detectedSitesCount = MutableStateFlow(0)
    val detectedSitesCount: StateFlow<Int> = _detectedSitesCount.asStateFlow()

    private val _detectedImagesCount = MutableStateFlow(0)
    val detectedImagesCount: StateFlow<Int> = _detectedImagesCount.asStateFlow()

    fun refreshBlockLogs() {
        val logs = com.example.util.SaffahBlockRepository.getBlockLogs(context)
        _blockLogs.value = logs

        val repoKW = com.example.util.SaffahBlockRepository.getDetectedKeywordsCount(context)
        val repoSites = com.example.util.SaffahBlockRepository.getDetectedSitesCount(context)
        val repoImages = com.example.util.SaffahBlockRepository.getDetectedImagesCount(context)
        val repoTotal = com.example.util.SaffahBlockRepository.getTotalBlockEventsCount(context)

        val logKW = logs.count { it.type.contains("كلمة") }
        val logSites = logs.count { it.type.contains("موقع") }
        val logImages = logs.count { it.type.contains("صورة") || it.type.contains("صور") || it.type.contains("AI") || it.type.contains("الذكاء") }

        _detectedKeywordsCount.value = maxOf(repoKW, logKW)
        _detectedSitesCount.value = maxOf(repoSites, logSites)
        _detectedImagesCount.value = maxOf(repoImages, logImages)
        _totalBlockEventsCount.value = maxOf(repoTotal, logs.size)
    }

    fun clearBlockLogs() {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن مسح سجل الحظر أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("CLEAR_BLOCK_LOGS", "مسح سجلات ومحاولات الحظر") {
            com.example.util.SaffahBlockRepository.clearBlockLogs(context)
            refreshBlockLogs()
            showFeedback("تم مسح سجلات الحظر بنجاح.")
        }
    }

    fun togglePenaltyEnabled(enabled: Boolean) {
        if (!enabled && _isPenaltyEnabled.value) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل شاشة العقوبة المقفلة أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_PENALTY_SCREEN", "تعطيل شاشة العقوبة المقفلة") {
                com.example.util.SaffahPenaltyManager.setPenaltyFeatureEnabled(context, false)
                _isPenaltyEnabled.value = false
                refreshPenaltyStatus()
                showFeedback("تم تعطيل شاشة العقوبة المقفلة.")
            }
            return
        }
        com.example.util.SaffahPenaltyManager.setPenaltyFeatureEnabled(context, enabled)
        _isPenaltyEnabled.value = enabled
        refreshPenaltyStatus()
        if (enabled) showFeedback("تم تفعيل شاشة العقوبة المقفلة.")
    }

    fun setPenaltyDuration(minutes: Int) {
        val clamped = minutes.coerceIn(1, 15)
        if (clamped < _penaltyDurationMinutes.value) {
            if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تقليل مدة العقوبة أثناء سريان ميزة التأخير الزمني. يُسمح فقط بزيادة المدة.")
                return
            }
            executeProtectedAction("REDUCE_PENALTY_DURATION", "تقليل مدة شاشة العقوبة إلى $clamped دقيقة") {
                com.example.util.SaffahPenaltyManager.setPenaltyDurationMinutes(context, clamped)
                _penaltyDurationMinutes.value = clamped
                showFeedback("تم تعديل مدة العقوبة إلى $clamped دقائق.")
            }
            return
        }
        com.example.util.SaffahPenaltyManager.setPenaltyDurationMinutes(context, clamped)
        _penaltyDurationMinutes.value = clamped
    }

    fun refreshPenaltyStatus() {
        val active = com.example.util.SaffahPenaltyManager.isPenaltyActive(context)
        if (_isPenaltyActive.value != active) {
            _isPenaltyActive.value = active
        }
        val remaining = if (active) com.example.util.SaffahPenaltyManager.getRemainingPenaltyTimeMs(context) else 0L
        if (_remainingPenaltyMs.value != remaining) {
            _remainingPenaltyMs.value = remaining
        }
    }

    // --- 15-MINUTE URGE SUPPRESSION MANAGEMENT (قاعدة 15د لدحر الرغبة) ---
    fun refreshUrgeStatus() {
        val enabled = SaffahUrgeManager.isUrgeFeatureEnabled(context)
        if (_isUrgeFeatureEnabled.value != enabled) {
            _isUrgeFeatureEnabled.value = enabled
        }
        val active = SaffahUrgeManager.isUrgeSessionActive(context)
        if (_isUrgeSessionActive.value != active) {
            _isUrgeSessionActive.value = active
        }
        val remaining = if (active) SaffahUrgeManager.getUrgeSessionRemainingMs(context) else 0L
        if (_remainingUrgeSessionMs.value != remaining) {
            _remainingUrgeSessionMs.value = remaining
        }
    }

    fun toggleUrgeFeature(enabled: Boolean) {
        if (!enabled) {
            // Disabling the feature: Protected by Time Delay & QR Code
            if (_isUrgeFeatureEnabled.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل قاعدة الـ 15 دقيقة أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_URGE_RULE", "تعطيل قاعدة الـ 15 دقيقة لدحر الرغبة") {
                SaffahUrgeManager.setUrgeFeatureEnabled(context, false)
                _isUrgeFeatureEnabled.value = false
                refreshUrgeStatus()
                showFeedback("تم تعطيل قاعدة الـ 15 دقيقة لدحر الرغبة.")
            }
            return
        }
        SaffahUrgeManager.setUrgeFeatureEnabled(context, true)
        _isUrgeFeatureEnabled.value = true
        refreshUrgeStatus()
        showFeedback("تم تفعيل قاعدة الـ 15 دقيقة لدحر الرغبة بنجاح.")
    }

    fun startUrgeSessionManually(durationMinutes: Int = 15) {
        SaffahUrgeManager.setUrgeFeatureEnabled(context, true)
        _isUrgeFeatureEnabled.value = true
        if (SaffahUrgeManager.isUrgeSessionActive(context)) {
            com.example.util.SaffahLockTaskManager.launchLockTaskApp(context, com.example.util.SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
            showFeedback("جلسة دحر الرغبة نشطة بالفعل.")
            return
        }
        SaffahUrgeManager.startUrgeSession(context, durationMinutes)
        refreshUrgeStatus()
        showFeedback("تم بدء جلسة دحر الرغبة لمدة $durationMinutes دقيقة.")
    }

    fun stopUrgeSessionManually() {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن إيقاف جلسة دحر الرغبة أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("STOP_URGE_SESSION", "إيقاف جلسة دحر الرغبة الجارية") {
            SaffahUrgeManager.stopUrgeSession(context)
            refreshUrgeStatus()
            showFeedback("تم إيقاف جلسة دحر الرغبة.")
        }
    }

    fun openUrgeLogDialog() {
        _showUrgeLogDialog.value = true
    }

    fun closeUrgeLogDialog() {
        _showUrgeLogDialog.value = false
    }

    fun openUrgeVictoryDialog() {
        _showUrgeVictoryDialog.value = true
    }

    fun closeUrgeVictoryDialog() {
        _showUrgeVictoryDialog.value = false
    }

    fun recordCompletedUrgeSession(
        intensity: Int,
        triggerStr: String,
        emotionStr: String,
        notes: String
    ) {
        val trig = when {
            triggerStr.contains("ملل") || triggerStr.contains("فراغ") -> com.example.model.RelapseTrigger.BOREDOM
            triggerStr.contains("سهر") || triggerStr.contains("ليل") -> com.example.model.RelapseTrigger.LATE_NIGHT
            triggerStr.contains("تصفح") -> com.example.model.RelapseTrigger.RANDOM_BROWSING
            triggerStr.contains("ضغط") || triggerStr.contains("توتر") -> com.example.model.RelapseTrigger.STRESS
            triggerStr.contains("وحدة") || triggerStr.contains("عزلة") -> com.example.model.RelapseTrigger.LONELINESS
            triggerStr.contains("إرهاق") || triggerStr.contains("تعب") -> com.example.model.RelapseTrigger.FATIGUE
            triggerStr.contains("غضب") || triggerStr.contains("إحباط") -> com.example.model.RelapseTrigger.ANGER
            else -> com.example.model.RelapseTrigger.OTHER
        }

        val intEnum = when (intensity) {
            1 -> com.example.model.UrgeIntensity.MILD
            2 -> com.example.model.UrgeIntensity.MODERATE
            3 -> com.example.model.UrgeIntensity.STRONG
            else -> com.example.model.UrgeIntensity.CRITICAL
        }

        val noteFull = buildString {
            if (emotionStr.isNotBlank()) append("الحالة النفسية والمشاعر: $emotionStr\n")
            if (notes.isNotBlank()) append("ملاحظات: $notes")
        }

        logUrge(
            intensity = intEnum,
            trigger = trig,
            technique = com.example.model.UrgeDefenseTechnique.MINUTES_15_RULE,
            durationMinutes = 15,
            resistedSuccessfully = true,
            note = noteFull.trim()
        )
        _showUrgeLogDialog.value = false
        _showUrgeVictoryDialog.value = true
    }

    fun checkPermissions() {
        viewModelScope.launch(Dispatchers.IO) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val compName = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            val isDeviceOwner = try {
                dpm != null && (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(compName))
            } catch (e: Exception) {
                false
            }

            val hasExactAlarm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                alarmManager.canScheduleExactAlarms()
            } else true

            val isAccess = checkAccessibilityPermission()
            val isNotif = checkNotificationListenerPermission()
            val isVpn = SaffahVpnService.isVpnActive.value
            val hasBatteryOptBypass = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
                pm?.isIgnoringBatteryOptimizations(context.packageName) ?: true
            } else true

            val oldStatus = _permissionStatus.value
            val oldBattery = previousBatteryOptBypass

            val newStatus = PermissionStatus(
                isAccessibilityEnabled = isAccess,
                isExactAlarmEnabled = hasExactAlarm,
                isNotificationAccessEnabled = isNotif,
                isDeviceOwnerActive = isDeviceOwner,
                isVpnActive = isVpn
            )

            val wasAnyServiceOrPermissionNewlyEnabled = initialPermissionsRecorded && (
                (!oldStatus.isAccessibilityEnabled && newStatus.isAccessibilityEnabled) ||
                (!oldStatus.isNotificationAccessEnabled && newStatus.isNotificationAccessEnabled) ||
                (!oldStatus.isExactAlarmEnabled && newStatus.isExactAlarmEnabled) ||
                (!oldStatus.isDeviceOwnerActive && newStatus.isDeviceOwnerActive) ||
                (!oldStatus.isVpnActive && newStatus.isVpnActive) ||
                (oldBattery == false && hasBatteryOptBypass)
            )

            initialPermissionsRecorded = true
            previousBatteryOptBypass = hasBatteryOptBypass

            withContext(Dispatchers.Main) {
                _permissionStatus.value = newStatus
                if (wasAnyServiceOrPermissionNewlyEnabled) {
                    _navigateToHomeEvent.tryEmit(Unit)
                }
            }
        }
    }

    private fun checkAccessibilityPermission(): Boolean {
        return com.example.util.SaffahLockTaskManager.isAccessibilityEnabled(context)
    }

    private fun checkNotificationListenerPermission(): Boolean {
        return try {
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: ""
            flat.contains(context.packageName) || flat.contains("SaffahNotificationListenerService")
        } catch (e: Exception) {
            false
        }
    }

    fun setDnsServer(server: DnsFilterServer) {
        _selectedDnsServer.value = server
        if (_permissionStatus.value.isVpnActive) {
            toggleVpn(true)
        }
    }

    fun toggleVpn(enable: Boolean) {
        if (!enable && _permissionStatus.value.isVpnActive && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن تعطيل VPN أثناء سريان ميزة التأخير الزمني.")
            return
        }
        if (!enable && _permissionStatus.value.isVpnActive && _isQrKeyActive.value) {
            executeProtectedAction("DISABLE_VPN", "تعطيل طبقة حماية الـ VPN") {
                stopVpnInternal()
            }
            return
        }
        if (enable) {
            startVpnInternal()
        } else {
            stopVpnInternal()
        }
    }

    private fun startVpnInternal() {
        val intent = Intent(context, SaffahVpnService::class.java)
        com.example.util.SaffahLockTaskManager.setVpnEnabledByUser(context, true)
        intent.action = SaffahVpnService.ACTION_START_VPN
        intent.putExtra(SaffahVpnService.EXTRA_DNS_SERVER, _selectedDnsServer.value.ordinal)
        val excluded = com.example.util.SaffahBlockRepository.getExcludedVpnApps(context).toTypedArray()
        intent.putExtra(SaffahVpnService.EXTRA_EXCLUDED_PACKAGES, excluded)
        try {
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
            _permissionStatus.value = _permissionStatus.value.copy(isVpnActive = true)
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to start VPN foreground service: ${e.message}")
        }
    }

    private fun stopVpnInternal() {
        try {
            val intent = Intent(context, SaffahVpnService::class.java)
            com.example.util.SaffahLockTaskManager.setVpnEnabledByUser(context, false)
            intent.action = SaffahVpnService.ACTION_STOP_VPN
            context.startService(intent)
            _permissionStatus.value = _permissionStatus.value.copy(isVpnActive = false)
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to stop VPN service: ${e.message}")
        }
    }

    fun toggleAppVpnExclusion(packageName: String) {
        val currentExcluded = com.example.util.SaffahBlockRepository.getExcludedVpnApps(context)
        val isAddingExclusion = !currentExcluded.contains(packageName)

        val applyToggle = {
            val updatedSet = com.example.util.SaffahBlockRepository.toggleExcludedVpnApp(context, packageName)
            _installedApps.value = _installedApps.value.map { app ->
                if (app.packageName == packageName) app.copy(isExcludedFromVpn = updatedSet.contains(app.packageName))
                else app
            }
            if (_permissionStatus.value.isVpnActive) {
                toggleVpn(true)
            }
            if (updatedSet.contains(packageName)) {
                showFeedback("تم استثناء التطبيق من حماية VPN")
            } else {
                showFeedback("تمت إعادة التطبيق لحماية VPN")
            }
        }

        if (!isAddingExclusion) {
            // Restoring VPN protection (tightening) -> No QR code scan needed
            applyToggle()
            return
        }

        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن استثناء تطبيقات جديدة من VPN أثناء سريان ميزة التأخير الزمني.")
            return
        }

        executeProtectedAction("TOGGLE_VPN_EXCLUSION", "استثناء تطبيق من حماية الـ VPN ($packageName)") {
            applyToggle()
        }
    }

    fun toggleAppBlock(packageName: String) {
        _installedApps.value = _installedApps.value.map { app ->
            if (app.packageName == packageName) app.copy(isBlocked = !app.isBlocked)
            else app
        }
    }

    fun addBlockedKeyword(keyword: String) {
        if (keyword.isBlank()) return
        _blockedKeywords.value = com.example.util.SaffahBlockRepository.addBlockedKeyword(context, keyword)
    }

    fun importBlockedKeywordsFromLines(lines: List<String>) {
        if (lines.isEmpty()) {
            showFeedback("الملف فارغ، لم يتم العثور على كلمات للاستيراد.")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _isImportingBlockedData.value = true
            try {
                val (updatedList, addedCount) = com.example.util.SaffahBlockRepository.addBlockedKeywordsBulk(context, lines)
                _blockedKeywords.value = updatedList
                withContext(Dispatchers.Main) {
                    if (addedCount > 0) {
                        showFeedback("تم استيراد $addedCount كلمة بنجاح (مع تجاهل المتكرر).")
                    } else {
                        showFeedback("جميع الكلمات الموجودة في الملف مضافة مسبقاً أو متكررة.")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showFeedback("حدث خطأ أثناء استيراد الكلمات: ${e.localizedMessage}")
                }
            } finally {
                _isImportingBlockedData.value = false
            }
        }
    }

    fun removeBlockedKeyword(id: Long, keyword: String? = null) {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن حذف الكلمات المحظورة أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("REMOVE_KEYWORD", "حذف كلمة محظورة (${keyword ?: ""})") {
            _blockedKeywords.value = com.example.util.SaffahBlockRepository.removeBlockedKeyword(context, id, keyword)
            showFeedback("تم حذف الكلمة من قائمة الحظر.")
        }
    }

    fun addBlockedSite(site: String) {
        if (site.isBlank()) return
        val cleaned = com.example.util.SaffahBlockRepository.cleanAndExtractDomain(site)
        if (cleaned == null) {
            showFeedback("يرجى إدخال نطاق موقع صالح (مثال: example.com) وليس كلمة مفردة.")
            return
        }
        val current = _blockedSites.value
        if (current.any { it.domain.equals(cleaned, ignoreCase = true) }) {
            showFeedback("الموقع ($cleaned) مضاف مسبقاً في قائمة الحظر.")
            return
        }
        _blockedSites.value = com.example.util.SaffahBlockRepository.addBlockedSite(context, cleaned)
        showFeedback("تمت إضافة النطاق ($cleaned) إلى قائمة حظر المواقع.")
    }

    fun importBlockedSitesFromLines(lines: List<String>) {
        if (lines.isEmpty()) {
            showFeedback("الملف فارغ، لم يتم العثور على روابط أو مواقع للاستيراد.")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _isImportingBlockedData.value = true
            try {
                val (updatedList, addedCount) = com.example.util.SaffahBlockRepository.addBlockedSitesBulk(context, lines)
                _blockedSites.value = updatedList
                withContext(Dispatchers.Main) {
                    if (addedCount > 0) {
                        showFeedback("تم استيراد $addedCount نطاق بنجاح (مع تجاهل المتكرر والنطاقات غير المكتملة).")
                    } else {
                        showFeedback("لم تتم إضافة أي نطاق جديد (النطاقات مضافة مسبقاً أو غير صالحة/غير مكتملة).")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showFeedback("حدث خطأ أثناء استيراد المواقع: ${e.localizedMessage}")
                }
            } finally {
                _isImportingBlockedData.value = false
            }
        }
    }

    fun removeBlockedSite(id: Long, domain: String? = null) {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن حذف المواقع المحظورة أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("REMOVE_SITE", "فك حظر الموقع أو النطاق (${domain ?: ""})") {
            _blockedSites.value = com.example.util.SaffahBlockRepository.removeBlockedSite(context, id, domain)
            showFeedback("تم حذف الموقع من قائمة الحظر.")
        }
    }

    fun clearAllBlockedKeywords() {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن حذف وتفريغ الكلمات المحظورة أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("CLEAR_ALL_KEYWORDS", "تفريغ وحذف جميع الكلمات المحظورة دفعة واحدة") {
            viewModelScope.launch(Dispatchers.IO) {
                val emptyKeywords = com.example.util.SaffahBlockRepository.clearAllBlockedKeywords(context)
                withContext(Dispatchers.Main) {
                    _blockedKeywords.value = emptyKeywords
                    showFeedback("تم تفريغ وحذف جميع الكلمات المحظورة بنجاح.")
                }
            }
        }
    }

    fun clearAllBlockedSites() {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن حذف وتفريغ المواقع المحظورة أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("CLEAR_ALL_SITES", "تفريغ وحذف جميع المواقع المحظورة دفعة واحدة") {
            viewModelScope.launch(Dispatchers.IO) {
                val emptySites = com.example.util.SaffahBlockRepository.clearAllBlockedSites(context)
                withContext(Dispatchers.Main) {
                    _blockedSites.value = emptySites
                    showFeedback("تم تفريغ وحذف جميع المواقع المحظورة بنجاح.")
                }
            }
        }
    }

    fun clearAllBlockedKeywordsAndSites() {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            showFeedback("لا يمكن حذف وتفريغ الكلمات والمواقع المحظورة أثناء سريان ميزة التأخير الزمني.")
            return
        }
        executeProtectedAction("CLEAR_ALL_KEYWORDS_AND_SITES", "تفريغ وحذف جميع الكلمات والمواقع المحظورة دفعة واحدة") {
            viewModelScope.launch(Dispatchers.IO) {
                val emptyKeywords = com.example.util.SaffahBlockRepository.clearAllBlockedKeywords(context)
                val emptySites = com.example.util.SaffahBlockRepository.clearAllBlockedSites(context)
                withContext(Dispatchers.Main) {
                    _blockedKeywords.value = emptyKeywords
                    _blockedSites.value = emptySites
                    showFeedback("تم تفريغ وحذف جميع الكلمات والمواقع المحظورة بنجاح.")
                }
            }
        }
    }

    fun toggleDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
        context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("dark_mode", enabled)
            .apply()
    }

    fun stopTimeDelay() {
        if (_isQrKeyActive.value) {
            executeProtectedAction("STOP_TIME_DELAY", "إيقاف ميزة قفل التأخير الزمني قبل انتهاء المدة") {
                com.example.util.SaffahBlockRepository.stopTimeDelay(context)
                refreshTimeDelayStatus()
                showFeedback("تم إيقاف ميزة التأخير الزمني بنجاح.")
            }
        } else {
            com.example.util.SaffahBlockRepository.stopTimeDelay(context)
            refreshTimeDelayStatus()
            showFeedback("تم إيقاف ميزة التأخير الزمني.")
        }
    }

    fun toggleDisallowSafeBoot(enabled: Boolean) {
        if (!enabled) {
            if (_isDisallowSafeBoot.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر Safe Boot أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_SAFE_BOOT", "تعطيل حظر وضع التشغيل الآمن (Safe Boot)") {
                _isDisallowSafeBoot.value = false
                viewModelScope.launch(Dispatchers.IO) {
                    SaffahProtectionManager.setDisallowSafeBoot(context, false)
                }
                showFeedback("تم إلغاء منع وضع التشغيل الآمن")
            }
            return
        }
        _isDisallowSafeBoot.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val applied = SaffahProtectionManager.setDisallowSafeBoot(context, true)
            withContext(Dispatchers.Main) {
                if (!applied) {
                    showFeedback("يلزم تفعيل مسؤول الجهاز (Device Admin) لتطبيق حظر Safe Boot.")
                } else {
                    showFeedback("تم تفعيل منع الدخول في وضع التشغيل الآمن (Safe Boot) بنجاح")
                }
            }
        }
    }

    fun toggleDisallowConfigDateTime(enabled: Boolean) {
        if (!enabled) {
            if (_isDisallowConfigDateTime.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل منع التلاعب بالوقت أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_DATETIME_PROTECTION", "تعطيل منع التلاعب بالوقت والتاريخ") {
                _isDisallowConfigDateTime.value = false
                viewModelScope.launch(Dispatchers.IO) {
                    SaffahProtectionManager.setDisallowConfigDateTime(context, false)
                }
                showFeedback("تم إلغاء منع التلاعب بالوقت")
            }
            return
        }
        _isDisallowConfigDateTime.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val applied = SaffahProtectionManager.setDisallowConfigDateTime(context, true)
            withContext(Dispatchers.Main) {
                if (!applied) {
                    showFeedback("يلزم تفعيل مسؤول الجهاز (Device Admin) لتطبيق منع التلاعب بالوقت.")
                } else {
                    showFeedback("تم تفعيل منع التلاعب بالوقت وتعديل التاريخ بنجاح")
                }
            }
        }
    }

    fun toggleDisallowConfigPrivateDns(enabled: Boolean) {
        if (!enabled) {
            if (_isDisallowConfigPrivateDns.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر إعدادات DNS أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_DNS_PROTECTION", "تعطيل تثبيت وحظر إعدادات DNS الخاص") {
                _isDisallowConfigPrivateDns.value = false
                viewModelScope.launch(Dispatchers.IO) {
                    SaffahProtectionManager.setDisallowConfigPrivateDns(context, false)
                }
                showFeedback("تم إلغاء تعطيل إعدادات DNS الخاص")
            }
            return
        }
        _isDisallowConfigPrivateDns.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val applied = SaffahProtectionManager.setDisallowConfigPrivateDns(context, true)
            withContext(Dispatchers.Main) {
                if (!applied) {
                    showFeedback("يلزم تفعيل مسؤول الجهاز (Device Admin) لتطبيق حظر إعدادات DNS.")
                } else {
                    showFeedback("تم تفعيل تعطيل وتثبيت إعدادات DNS الخاص بنجاح")
                }
            }
        }
    }

    fun toggleDisallowDebuggingFeatures(enabled: Boolean) {
        if (!enabled) {
            if (_isDisallowDebuggingFeatures.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر خيارات وتصحيح المطورين أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_DEBUG_PROTECTION", "تعطيل حظر خيارات المطورين والتصحيح") {
                _isDisallowDebuggingFeatures.value = false
                viewModelScope.launch(Dispatchers.IO) {
                    SaffahProtectionManager.setDisallowDebuggingFeatures(context, false)
                }
                showFeedback("تم إلغاء حظر خيارات وتصحيح المطورين")
            }
            return
        }
        _isDisallowDebuggingFeatures.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val applied = SaffahProtectionManager.setDisallowDebuggingFeatures(context, true)
            withContext(Dispatchers.Main) {
                if (!applied) {
                    showFeedback("يلزم تفعيل مسؤول الجهاز (Device Owner) لتطبيق حظر خيارات المطورين.")
                } else {
                    showFeedback("تم تفعيل حظر خيارات وتصحيح المطورين")
                }
            }
        }
    }

    fun toggleBlockUnsupportedBrowsers(enabled: Boolean) {
        if (!enabled) {
            if (_isBlockUnsupportedBrowsers.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر المتصفحات غير المدعومة أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_UNSUPPORTED_BROWSERS_BLOCK", "تعطيل حظر المتصفحات غير المدعومة") {
                _isBlockUnsupportedBrowsers.value = false
                com.example.util.SaffahBlockRepository.setBlockUnsupportedBrowsers(context, false)
                showFeedback("تم السماح باستخدام جميع المتصفحات")
            }
            return
        }
        _isBlockUnsupportedBrowsers.value = true
        com.example.util.SaffahBlockRepository.setBlockUnsupportedBrowsers(context, true)
        showFeedback("تم تفعيل حظر المتصفحات غير المدعومة بنجاح")
    }

    fun toggleBlockInAppBrowsers(enabled: Boolean) {
        if (!enabled) {
            if (_isBlockInAppBrowsers.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل حظر المتصفح داخل التطبيق أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_IN_APP_BROWSERS_BLOCK", "تعطيل حظر المتصفح داخل التطبيق (In-App Browsers & WebViews)") {
                _isBlockInAppBrowsers.value = false
                com.example.util.SaffahBlockRepository.setBlockInAppBrowsers(context, false)
                showFeedback("تم السماح بفتح المتصفحات الداخلية في التطبيقات")
            }
            return
        }
        _isBlockInAppBrowsers.value = true
        com.example.util.SaffahBlockRepository.setBlockInAppBrowsers(context, true)
        showFeedback("تم تفعيل حظر المتصفح داخل التطبيق بنجاح")
    }

    fun toggleAiProtection(enabled: Boolean) {
        if (!enabled) {
            if (_isAiProtectionEnabled.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل الحماية بالذكاء الاصطناعي أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_AI_PROTECTION", "تعطيل درع الذكاء الاصطناعي بالكامل") {
                _isAiProtectionEnabled.value = false
                _isAiNudeNetEnabled.value = false
                _isAiAnimeEnabled.value = false
                com.example.util.SaffahBlockRepository.setAiProtectionEnabled(context, false)
                showFeedback("تم تعطيل الحماية بالذكاء الاصطناعي")
            }
            return
        }
        _isAiProtectionEnabled.value = true
        _isAiNudeNetEnabled.value = true
        _isAiAnimeEnabled.value = true
        com.example.util.SaffahBlockRepository.setAiProtectionEnabled(context, true)
        showFeedback("تم تفعيل الحماية بالذكاء الاصطناعي لكلا النموذجين بنجاح")
    }

    fun toggleAiNudeNet(enabled: Boolean) {
        if (!enabled) {
            if (_isAiNudeNetEnabled.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل نموذج فحص العري أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_AI_NUDENET", "تعطيل فحص العري والمحتوى الواقعي (NudeNet)") {
                _isAiNudeNetEnabled.value = false
                com.example.util.SaffahBlockRepository.setAiNudeNetEnabled(context, false)
                _isAiProtectionEnabled.value = com.example.util.SaffahBlockRepository.isAiProtectionEnabled(context)
                showFeedback("تم تعطيل نموذج NudeNet (الواقعي)")
            }
            return
        }
        _isAiNudeNetEnabled.value = true
        com.example.util.SaffahBlockRepository.setAiNudeNetEnabled(context, true)
        _isAiProtectionEnabled.value = com.example.util.SaffahBlockRepository.isAiProtectionEnabled(context)
        showFeedback("تم تفعيل نموذج NudeNet (فحص المحتوى الواقعي والعري)")
    }

    fun toggleAiAnime(enabled: Boolean) {
        if (!enabled) {
            if (_isAiAnimeEnabled.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل فحص الأنمي والهينتاي أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_AI_ANIME", "تعطيل فحص الأنمي والهينتاي (MobileNetV3)") {
                _isAiAnimeEnabled.value = false
                com.example.util.SaffahBlockRepository.setAiAnimeEnabled(context, false)
                _isAiProtectionEnabled.value = com.example.util.SaffahBlockRepository.isAiProtectionEnabled(context)
                showFeedback("تم تعطيل نموذج MobileNetV3 (الأنمي والهينتاي)")
            }
            return
        }
        _isAiAnimeEnabled.value = true
        com.example.util.SaffahBlockRepository.setAiAnimeEnabled(context, true)
        _isAiProtectionEnabled.value = com.example.util.SaffahBlockRepository.isAiProtectionEnabled(context)
        showFeedback("تم تفعيل نموذج MobileNetV3 (فحص الأنمي والهينتاي)")
    }

    fun toggleAiDryRun(enabled: Boolean) {
        _isAiDryRunEnabled.value = enabled
        com.example.util.SaffahBlockRepository.setAiDryRunEnabled(context, enabled)
        showFeedback(if (enabled) "تم تفعيل وضع التجربة (Dry Run) بدون إغلاق الشاشة" else "تم تعطيل وضع التجربة (الحماية الفعلية نشطة)")
    }

    fun updateAnimeConfig(cfg: com.example.util.AnimeCfg) {
        _animeConfig.value = cfg
        com.example.util.SaffahBlockRepository.saveAnimeConfig(context, cfg)
        showFeedback("تم حفظ وتحديث إعدادات وعتبات نموذج الأنمي")
    }

    fun resetAnimeConfigToDefaults() {
        val def = com.example.util.AnimeCfg()
        _animeConfig.value = def
        com.example.util.SaffahBlockRepository.resetAnimeConfigToDefaults(context)
        showFeedback("تمت استعادة العتبات الافتراضية لنموذج الأنمي")
    }

    fun updateNudeConfig(cfg: com.example.util.NudeCfg) {
        _nudeConfig.value = cfg
        com.example.util.SaffahBlockRepository.saveNudeConfig(context, cfg)
        showFeedback("تم حفظ وتحديث إعدادات وعتبات نموذج NudeNet")
    }

    fun resetNudeConfigToDefaults() {
        val def = com.example.util.NudeCfg()
        _nudeConfig.value = def
        com.example.util.SaffahBlockRepository.resetNudeConfigToDefaults(context)
        showFeedback("تمت استعادة العتبات الافتراضية لنموذج NudeNet")
    }

    fun toggleAiProtectionIncludedApp(packageName: String) {
        val isNowIncluded = com.example.util.SaffahBlockRepository.toggleAiProtectionIncludedApp(context, packageName)
        _aiProtectionIncludedApps.value = com.example.util.SaffahBlockRepository.getAiProtectionIncludedApps(context)
        val appName = com.example.util.AppListHelper.resolveAppLabelFast(context, packageName)
        if (isNowIncluded) {
            showFeedback("تم شمول $appName في حجب الصور والفيديوهات.")
        } else {
            showFeedback("تم إزالة $appName من حجب الصور والفيديوهات.")
        }
    }

    fun setAiProtectionIncludedApps(apps: Set<String>) {
        com.example.util.SaffahBlockRepository.setAiProtectionIncludedApps(context, apps)
        _aiProtectionIncludedApps.value = apps
        showFeedback("تم حفظ التطبيقات المشمولة بالحجب البصري (${apps.size} تطبيق).")
    }

    fun setAllBrowsersAiProtectionIncluded() {
        val browsers = _installedApps.value.filter { app ->
            val pkg = app.packageName.lowercase()
            pkg.contains("browser") || pkg.contains("chrome") || pkg.contains("firefox") ||
            pkg.contains("opera") || pkg.contains("edge") || pkg.contains("brave") || pkg.contains("duckduckgo")
        }.map { it.packageName }.toSet()
        val current = _aiProtectionIncludedApps.value.toMutableSet()
        current.addAll(browsers)
        com.example.util.SaffahBlockRepository.setAiProtectionIncludedApps(context, current)
        _aiProtectionIncludedApps.value = current
        showFeedback("تم شمول كافة المتصفحات في الحماية البصرية.")
    }

    fun toggleHideVpnNotification(enabled: Boolean, onPermissionRequired: () -> Unit = {}) {
        if (!enabled) {
            if (_isHideVpnNotification.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل إخفاء إشعار VPN أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_HIDE_VPN_NOTIFICATION", "إلغاء إخفاء إشعار الـ VPN في شريط الحالة") {
                _isHideVpnNotification.value = false
                com.example.util.SaffahBlockRepository.setHideVpnNotification(context, false)
                showFeedback("تم إظهار إشعار VPN بشكل طبيعي")
            }
            return
        }
        if (!_permissionStatus.value.isNotificationAccessEnabled) {
            onPermissionRequired()
        }
        _isHideVpnNotification.value = true
        com.example.util.SaffahBlockRepository.setHideVpnNotification(context, true)
        showFeedback("تم تفعيل إخفاء إشعار VPN بنجاح")
    }

    fun toggleKeeperService(enabled: Boolean) {
        if (!enabled) {
            if (_isKeeperServiceEnabled.value && com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
                showFeedback("لا يمكن تعطيل خدمة الحماية الدائمة أثناء سريان ميزة التأخير الزمني.")
                return
            }
            executeProtectedAction("DISABLE_KEEPER_SERVICE", "إيقاف خدمة الحماية الدائمة في الخلفية") {
                _isKeeperServiceEnabled.value = false
                com.example.util.SaffahProtectionManager.setKeeperServiceEnabled(context, false)
                showFeedback("تم إيقاف خدمة الحماية الدائمة")
            }
            return
        }
        _isKeeperServiceEnabled.value = true
        com.example.util.SaffahProtectionManager.setKeeperServiceEnabled(context, true)
        showFeedback("تم تشغيل خدمة الحماية الدائمة بنجاح")
    }

    fun openNotificationAccessSettings() {
        com.example.service.SaffahNotificationListenerService.openNotificationAccessSettings(context)
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
    }

    fun refreshBackupSummary() {
        _backupSummary.value = com.example.util.GoogleDriveBackupManager.getBackupSummary(context)
    }

    fun exportBackupToFile(uri: android.net.Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _isBackupInProgress.value = true
            _backupStatusMessage.value = "جاري إنشاء وحفظ النسخة الاحتياطية على الهاتف..."
            val result = com.example.util.GoogleDriveBackupManager.exportBackupToUri(context, uri)
            _isBackupInProgress.value = false
            withContext(Dispatchers.Main) {
                result.onSuccess { count ->
                    refreshBackupSummary()
                    val msg = "تم حفظ النسخة الاحتياطية بنجاح على الهاتف ($count قاعدة مسجلة)."
                    _backupStatusMessage.value = msg
                    showFeedback(msg)
                }.onFailure { error ->
                    val msg = "فشل حفظ النسخة الاحتياطية: ${error.localizedMessage}"
                    _backupStatusMessage.value = msg
                    showFeedback(msg)
                }
            }
        }
    }

    fun importBackupFromFile(uri: android.net.Uri) {
        if (com.example.util.SaffahBlockRepository.isTimeDelayActive(context)) {
            val remainingMs = com.example.util.SaffahBlockRepository.getTimeDelayRemainingMs(context)
            val hours = remainingMs / (1000 * 60 * 60)
            val minutes = (remainingMs / (1000 * 60)) % 60
            val timeStr = if (hours > 0) "$hours ساعة و $minutes دقيقة" else "$minutes دقيقة"
            val msg = "ميزة التأخير الزمني نشطة حالياً! يُمنع استيراد ملف النسخة الاحتياطية لمنع التلاعب بالحظر حتى تنتهي الفترة ($timeStr)."
            _backupStatusMessage.value = msg
            showFeedback(msg)
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _isRestoreInProgress.value = true
            _backupStatusMessage.value = "جاري قراءة واستعادة قواعد الحظر من ملف النسخة الاحتياطية..."
            val result = com.example.util.GoogleDriveBackupManager.importBackupFromUri(context, uri)
            _isRestoreInProgress.value = false
            withContext(Dispatchers.Main) {
                result.onSuccess { meta ->
                    loadBlockData()
                    refreshBackupSummary()
                    refreshAllRecoveryData()
                    refreshPrivacyConfig()
                    _isDarkMode.value = context.getSharedPreferences("saffah_prefs", android.content.Context.MODE_PRIVATE).getBoolean("dark_mode", false)
                    val msg = "تمت استعادة وتطبيق النسخة الاحتياطية بنجاح!\n(${meta.keywordsCount} كلمة، ${meta.sitesCount} موقع، ${meta.permanentBlockedCount} تطبيق، ${meta.contentFiltersCount} فلتر محتوى، ${meta.diariesCount} مذكرة، ${meta.blockLogsCount} سجل حظر)"
                    _backupStatusMessage.value = msg
                    showFeedback(msg)
                }.onFailure { error ->
                    val msg = "فشل استيراد الملف: ${error.localizedMessage}"
                    _backupStatusMessage.value = msg
                    showFeedback(msg)
                }
            }
        }
    }

    fun refreshAllRecoveryData() {
        refreshRecoveryStats()
        _userName.value = com.example.util.SaffahRecoveryManager.getUserName(context)
        _recoveryPledge.value = com.example.util.SaffahRecoveryManager.getRecoveryPledge(context)
        _dailyBaselineHistory.value = com.example.util.SaffahRecoveryManager.getDailyBaselineHistory(context)
        _customDefenseTechniques.value = com.example.util.SaffahRecoveryManager.getCustomDefenseTechniques(context)
        _customTriggers.value = com.example.util.SaffahRecoveryManager.getCustomTriggers(context)
        _diaryEntries.value = com.example.util.SaffahDiaryRepository.getAllEntries(context)
        _trashedDiaryEntries.value = com.example.util.SaffahDiaryRepository.getTrashEntries(context)
        _recoveryBackupSummary.value = com.example.util.SaffahRecoveryBackupManager.getRecoveryBackupSummary(context)
    }

    fun refreshRecoveryBackupSummary() {
        _recoveryBackupSummary.value = com.example.util.SaffahRecoveryBackupManager.getRecoveryBackupSummary(context)
    }

    fun exportRecoveryBackupToFile(uri: android.net.Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _isRecoveryBackupInProgress.value = true
            _recoveryBackupStatusMessage.value = "جاري تجميع وضغط كافة ملفات وبيانات مركز التعافي في حزمة ZIP..."
            val result = com.example.util.SaffahRecoveryBackupManager.exportRecoveryFullBackup(context, uri)
            _isRecoveryBackupInProgress.value = false
            withContext(Dispatchers.Main) {
                result.onSuccess { res ->
                    refreshRecoveryBackupSummary()
                    val mb = String.format(java.util.Locale.US, "%.1f", res.totalBytesWritten / (1024.0 * 1024.0))
                    val msg = "تم تصدير وحفظ النسخة الاحتياطية الشاملة لمركز التعافي بنجاح ($mb ميغابايت، ${res.totalFilesArchived} ملفاً مؤرشفاً)."
                    _recoveryBackupStatusMessage.value = msg
                    showFeedback(msg)
                }.onFailure { error ->
                    val msg = "فشل تصدير النسخة الاحتياطية لمركز التعافي: ${error.localizedMessage}"
                    _recoveryBackupStatusMessage.value = msg
                    showFeedback(msg)
                }
            }
        }
    }

    fun importRecoveryBackupFromFile(uri: android.net.Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _isRecoveryRestoreInProgress.value = true
            _recoveryBackupStatusMessage.value = "جاري قراءة الحزمة وفك ضغط الوسائط واستعادة بيانات مركز التعافي..."
            val result = com.example.util.SaffahRecoveryBackupManager.importRecoveryFullBackup(context, uri)
            _isRecoveryRestoreInProgress.value = false
            withContext(Dispatchers.Main) {
                result.onSuccess { res ->
                    refreshAllRecoveryData()
                    _recoveryBackupStatusMessage.value = res.message
                    showFeedback(res.message)
                }.onFailure { error ->
                    val msg = "فشلت استعادة نسخة مركز التعافي: ${error.localizedMessage}"
                    _recoveryBackupStatusMessage.value = msg
                    showFeedback(msg)
                }
            }
        }
    }

    fun clearRecoveryBackupMessage() {
        _recoveryBackupStatusMessage.value = null
    }

    fun clearBackupMessage() {
        _backupStatusMessage.value = null
    }

    fun loadRealInstalledApps(forceRefresh: Boolean = true) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val items = com.example.util.AppListHelper.getFilteredInstalledApps(context, forceRefresh = forceRefresh)
                val currentlyExcludedSet = com.example.util.SaffahBlockRepository.getExcludedVpnApps(context)
                val mapped = items.map { item ->
                    InstalledApp(
                        packageName = item.packageName,
                        appName = item.appName,
                        isExcludedFromVpn = currentlyExcludedSet.contains(item.packageName),
                        isBlocked = false,
                        isSystemApp = item.isSystemApp,
                        iconDrawable = item.icon
                    )
                }.sortedWith(
                    compareBy<InstalledApp> { it.isSystemApp }.thenBy { it.appName.lowercase() }
                )

                if (mapped.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        _installedApps.value = mapped
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Error querying installed apps: ${e.message}")
            }
        }
    }

    private fun loadInitialMockData() {
        val savedExcluded = com.example.util.SaffahBlockRepository.getExcludedVpnApps(context)
        // App List
        _installedApps.value = listOf(
            InstalledApp("com.android.chrome", "متصفح Chrome", isExcludedFromVpn = savedExcluded.contains("com.android.chrome"), isBlocked = false),
            InstalledApp("net.quetta.browser", "متصفح Quetta", isExcludedFromVpn = savedExcluded.contains("net.quetta.browser"), isBlocked = false),
            InstalledApp("com.google.android.youtube", "YouTube", isExcludedFromVpn = savedExcluded.contains("com.google.android.youtube"), isBlocked = false),
            InstalledApp("com.instagram.android", "Instagram", isExcludedFromVpn = savedExcluded.contains("com.instagram.android"), isBlocked = false),
            InstalledApp("com.tiktok.app", "TikTok", isExcludedFromVpn = savedExcluded.contains("com.tiktok.app"), isBlocked = true),
            InstalledApp("com.twitter.android", "X (Twitter)", isExcludedFromVpn = savedExcluded.contains("com.twitter.android"), isBlocked = false),
            InstalledApp("com.whatsapp", "WhatsApp", isExcludedFromVpn = savedExcluded.contains("com.whatsapp"), isBlocked = false)
        )

        // Blocked Keywords Infrastructure
        _blockedKeywords.value = listOf(
            BlockedKeyword(1, "xxx", "2026-08-01"),
            BlockedKeyword(2, "adult content", "2026-08-02"),
            BlockedKeyword(3, "porn", "2026-08-03")
        )

        // Blocked Sites Infrastructure
        _blockedSites.value = listOf(
            BlockedSite(1, "explicit-website-example.com", "2026-08-01"),
            BlockedSite(2, "adult-portal-test.net", "2026-08-02"),
            BlockedSite(3, "bad-content-domain.org", "2026-08-04")
        )

        // Block Logs Infrastructure
        _blockLogs.value = listOf(
            BlockLogEntry(1, "bad-content-domain.org", "موقع محظور", "اليوم 10:45", "net.quetta.browser"),
            BlockLogEntry(2, "xxx", "كلمة محظورة", "اليوم 09:20", "com.android.chrome"),
            BlockLogEntry(3, "adult content", "كلمة محظورة", "أمس 23:15", "com.instagram.android"),
            BlockLogEntry(4, "explicit-website-example.com", "موقع محظور", "أمس 16:30", "net.quetta.browser"),
            BlockLogEntry(5, "porn", "كلمة محظورة", "03 أغسطس 20:10", "com.android.chrome"),
            BlockLogEntry(6, "صورة غير لائقة (محتوى فاضح 94%)", "صورة محظورة", "03 أغسطس 18:30", "com.android.chrome")
        )
    }

    // --- Productivity and Discipline (تحسين الإنتاجية والإنظباط) Control Methods ---

    fun refreshProductivityUsage() {
        val rule = _productivityRule.value ?: com.example.util.SaffahBlockRepository.getProductivityRule(context)
        if (rule != null) {
            val usageMap = mutableMapOf<String, Int>()
            rule.targetApps.forEach { targetApp ->
                usageMap[targetApp.packageName] = com.example.util.SaffahBlockRepository.getProductivityAppSpentMinutes(context, targetApp.packageName)
            }
            if (_productivityAppUsageMap.value != usageMap) {
                _productivityAppUsageMap.value = usageMap
            }
        }
    }

    fun saveProductivityRule(rule: com.example.model.ProductivityDisciplineRule?) {
        val currentRule = _productivityRule.value
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isProductivityModificationAllowedWindow()
        val isRestricted = com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)

        val applyChanges = {
            if (currentRule != null && rule != null) {
                for (newTarget in rule.targetApps) {
                    val oldTarget = currentRule.targetApps.find { it.packageName.equals(newTarget.packageName, ignoreCase = true) }
                    if (oldTarget != null && newTarget.targetMinutes != oldTarget.targetMinutes) {
                        com.example.util.SaffahNotificationManager.onProductivityTargetMinutesUpdated(
                            context = context,
                            packageName = newTarget.packageName,
                            oldMinutes = oldTarget.targetMinutes,
                            newMinutes = newTarget.targetMinutes
                        )
                    }
                }
            }
            com.example.util.SaffahBlockRepository.saveProductivityRule(context, rule)
            val updated = com.example.util.SaffahBlockRepository.getProductivityRule(context)
            _productivityRule.value = updated
            _isProductivityActiveNow.value = com.example.util.SaffahBlockRepository.isProductivityActiveNow(context)
            refreshProductivityUsage()
            com.example.util.SaffahNotificationManager.evaluateAndTriggerProductivityGoalNotifications(context)
            showFeedback("تم حفظ إعدادات تحسين الإنتاجية والإنظباط بنجاح!")
        }

        // 1. If deleting the rule
        if (rule == null) {
            if (currentRule == null) return
            if (inAllowedWindow) {
                applyChanges()
                return
            }
            if (isRestricted) {
                showFeedback("لا يمكن حذف عملية تحسين الإنتاجية أثناء سريان التأخير الزمني (يُسمح بالحذف بين 22:00 و 06:00).")
                return
            }
            executeProtectedAction("DELETE_PRODUCTIVITY_RULE", "حذف قاعدة تحسين الإنتاجية والإنظباط نهائياً") {
                applyChanges()
            }
            return
        }

        // 2. If creating the rule for the first time
        if (currentRule == null) {
            applyChanges()
            return
        }

        // 3. If within the allowed modification window (22:00 to 06:00)
        if (inAllowedWindow) {
            applyChanges()
            return
        }

        // 4. Outside allowed window: check what kind of modifications were made
        val isDisabling = currentRule.isEnabled && !rule.isEnabled
        val removedDays = currentRule.activeDays - rule.activeDays
        val isRemovingDays = removedDays.isNotEmpty()

        // Check if any existing target was deleted or target minutes reduced
        val isRemovingTargetApp = currentRule.targetApps.any { curr ->
            rule.targetApps.none { it.packageName.equals(curr.packageName, ignoreCase = true) }
        }
        val isReducingTargetMinutes = currentRule.targetApps.any { curr ->
            val newTarget = rule.targetApps.find { it.packageName.equals(curr.packageName, ignoreCase = true) }
            newTarget != null && newTarget.targetMinutes < curr.targetMinutes
        }

        // Check if new allowed apps were added (loosening)
        val isAddingAllowedApps = rule.allowedApps.any { !currentRule.allowedApps.contains(it) }

        val isLoosening = isDisabling || isRemovingDays || isRemovingTargetApp || isReducingTargetMinutes || isAddingAllowedApps

        if (isRestricted && isLoosening) {
            if (isDisabling) {
                showFeedback("لا يمكن تعطيل تحسين الإنتاجية أثناء سريان التأخير الزمني (يُسمح بالتعديل بين 22:00 و 06:00).")
                return
            }
            if (isRemovingDays) {
                showFeedback("ممنوع استثناء أو إزالة أيام سريان الحظر أثناء سريان ميزة التأخير الزمني (يُسمح بالتعديل بين 22:00 و 06:00).")
                return
            }
            if (isRemovingTargetApp) {
                showFeedback("لا يمكن حذف تطبيقات الهدف أثناء سريان التأخير الزمني.")
                return
            }
            if (isReducingTargetMinutes) {
                showFeedback("ممنوع تقليل سقف وقت الاستخدام أثناء سريان التأخير الزمني (يُسمح بالزيادة فقط).")
                return
            }
            if (isAddingAllowedApps) {
                showFeedback("ممنوع إضافة تطبيقات مسموحة جديدة أثناء سريان التأخير الزمني.")
                return
            }
        }

        if (!isLoosening) {
            // Only tightening actions occurred:
            // - Adding new target apps
            // - Adding previously exempted days
            // - Increasing target minutes
            // - Unchecking/removing apps from allowed apps
            // -> No QR code scan needed!
            applyChanges()
            return
        }

        // Loosening action outside allowed window requires QR verification
        executeProtectedAction("SAVE_PRODUCTIVITY_RULE", "حفظ وتعديل قواعد تحسين الإنتاجية والإنظباط") {
            applyChanges()
        }
    }

    fun toggleProductivityRuleEnabled(enabled: Boolean) {
        val currentRule = _productivityRule.value ?: return
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isProductivityModificationAllowedWindow()

        val applyToggle = {
            val updated = currentRule.copy(isEnabled = enabled)
            com.example.util.SaffahBlockRepository.saveProductivityRule(context, updated)
            _productivityRule.value = updated
            _isProductivityActiveNow.value = com.example.util.SaffahBlockRepository.isProductivityActiveNow(context)
            refreshProductivityUsage()
            if (enabled) showFeedback("تم تفعيل ميزة تحسين الإنتاجية")
            else showFeedback("تم تعطيل ميزة تحسين الإنتاجية")
        }

        if (enabled || inAllowedWindow) {
            applyToggle()
            return
        }

        if (com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن تعطيل تحسين الإنتاجية أثناء سريان التأخير الزمني (يُسمح بالتعديل بين 22:00 و 06:00).")
            return
        }

        executeProtectedAction("DISABLE_PRODUCTIVITY", "تعطيل ميزة تحسين الإنتاجية والإنظباط") {
            applyToggle()
        }
    }

    fun deleteProductivityTargetApp(packageName: String) {
        val currentRule = _productivityRule.value ?: return
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isProductivityModificationAllowedWindow()

        val applyDelete = {
            val updatedTargets = currentRule.targetApps.filter { !it.packageName.equals(packageName, ignoreCase = true) }
            val updated = currentRule.copy(targetApps = updatedTargets)
            com.example.util.SaffahBlockRepository.saveProductivityRule(context, updated)
            _productivityRule.value = updated
            _isProductivityActiveNow.value = com.example.util.SaffahBlockRepository.isProductivityActiveNow(context)
            refreshProductivityUsage()
            com.example.util.SaffahNotificationManager.resetProductivityGoalNotificationState(context, packageName)
            showFeedback("تم حذف التطبيق من قائمة الهدف بنجاح.")
        }

        if (inAllowedWindow) {
            applyDelete()
            return
        }

        if (com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن حذف تطبيقات الهدف أثناء سريان التأخير الزمني (يُسمح بالتعديل والحذف بين 22:00 و 06:00).")
            return
        }

        executeProtectedAction("DELETE_PRODUCTIVITY_APP", "حذف تطبيق مقيد من قائمة الإنتاجية ($packageName)") {
            applyDelete()
        }
    }

    fun updateProductivityTargetMinutes(packageName: String, newMinutes: Int) {
        val currentRule = _productivityRule.value ?: return
        val existing = currentRule.targetApps.find { it.packageName.equals(packageName, ignoreCase = true) } ?: return
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isProductivityModificationAllowedWindow()

        val applyUpdate = {
            val updatedTargets = currentRule.targetApps.map {
                if (it.packageName.equals(packageName, ignoreCase = true)) it.copy(targetMinutes = newMinutes) else it
            }
            val updated = currentRule.copy(targetApps = updatedTargets)
            com.example.util.SaffahBlockRepository.saveProductivityRule(context, updated)
            _productivityRule.value = updated
            _isProductivityActiveNow.value = com.example.util.SaffahBlockRepository.isProductivityActiveNow(context)
            refreshProductivityUsage()
            com.example.util.SaffahNotificationManager.onProductivityTargetMinutesUpdated(
                context = context,
                packageName = packageName,
                oldMinutes = existing.targetMinutes,
                newMinutes = newMinutes
            )
            showFeedback("تم تحديث سقف وقت الاستخدام إلى ${com.example.util.SaffahBlockRepository.formatUsageCeilingTime(newMinutes)}.")
        }

        if (newMinutes >= existing.targetMinutes || inAllowedWindow) {
            // Increasing/maintaining minutes (tightening) or in allowed window -> No QR code needed
            applyUpdate()
            return
        }

        // Decreasing minutes outside allowed window
        if (com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)) {
            showFeedback("ممنوع تقليل سقف وقت الاستخدام أثناء سريان التأخير الزمني (يُسمح بالزيادة فقط).")
            return
        }

        executeProtectedAction("UPDATE_PRODUCTIVITY_MINUTES", "تعديل سقف وقت استخدام التطبيق ($packageName إلى ${com.example.util.SaffahBlockRepository.formatUsageCeilingTime(newMinutes)})") {
            applyUpdate()
        }
    }

    fun deleteProductivityRule() {
        val inAllowedWindow = com.example.util.SaffahBlockRepository.isProductivityModificationAllowedWindow()

        val applyDelete = {
            com.example.util.SaffahBlockRepository.saveProductivityRule(context, null)
            _productivityRule.value = null
            _isProductivityActiveNow.value = false
            _productivityAppUsageMap.value = emptyMap()
            showFeedback("تم حذف عملية تحسين الإنتاجية والإنظباط.")
        }

        if (inAllowedWindow) {
            applyDelete()
            return
        }

        if (com.example.util.SaffahBlockRepository.isProductivityModificationRestrictedByTimeDelay(context)) {
            showFeedback("لا يمكن حذف عملية تحسين الإنتاجية أثناء سريان التأخير الزمني (يُسمح بالحذف بين 22:00 و 06:00).")
            return
        }

        executeProtectedAction("DELETE_PRODUCTIVITY_RULE", "حذف قاعدة تحسين الإنتاجية والإنظباط نهائياً") {
            applyDelete()
        }
    }

    // --- RECOVERY CENTER MANAGEMENT (مركز التعافي) ---
    fun refreshRecoveryStats() {
        _recoveryStats.value = com.example.util.SaffahRecoveryManager.getRecoveryStats(context)
        _recoveryAnalytics.value = com.example.util.SaffahRecoveryManager.getRecoveryAnalytics(context)
        refreshCustomDefenseTechniques()
        refreshRecoveryCalendar()
    }

    fun refreshRecoveryCalendar() {
        _recoveryCalendarHistory.value = com.example.util.SaffahRecoveryManager.getRecoveryCalendarHistory(context)
        _urgeDatesSet.value = com.example.util.SaffahRecoveryManager.getUrgeDefeatedDates(context)
    }

    fun setCalendarDayStatus(dateKey: String, status: com.example.model.DailyCalendarStatus) {
        com.example.util.SaffahRecoveryManager.setCalendarDayStatus(context, dateKey, status)
        refreshRecoveryStats()
    }

    fun refreshCustomDefenseTechniques() {
        _customDefenseTechniques.value = com.example.util.SaffahRecoveryManager.getCustomDefenseTechniques(context)
        _customTriggers.value = com.example.util.SaffahRecoveryManager.getCustomTriggers(context)
    }

    fun saveCustomDefenseTechnique(technique: String) {
        com.example.util.SaffahRecoveryManager.saveCustomDefenseTechnique(context, technique)
        refreshCustomDefenseTechniques()
    }

    fun deleteCustomDefenseTechnique(technique: String) {
        com.example.util.SaffahRecoveryManager.deleteCustomDefenseTechnique(context, technique)
        refreshCustomDefenseTechniques()
        showFeedback("تم حذف التقنية الدفاعية المخصصة.")
    }

    fun saveCustomTrigger(trigger: String) {
        com.example.util.SaffahRecoveryManager.saveCustomTrigger(context, trigger)
        refreshCustomDefenseTechniques()
    }

    fun deleteCustomTrigger(trigger: String) {
        com.example.util.SaffahRecoveryManager.deleteCustomTrigger(context, trigger)
        refreshCustomDefenseTechniques()
        showFeedback("تم حذف المحفز المخصص.")
    }

    fun setRecoveryStartTime(year: Int, month: Int, day: Int, hour: Int, minute: Int) {
        com.example.util.SaffahRecoveryManager.setRecoveryStartTime(context, year, month, day, hour, minute)
        refreshRecoveryStats()
        showFeedback("تم تعيين وضبط موعد بداية التعافي بنجاح.")
    }

    fun setUserName(name: String) {
        com.example.util.SaffahRecoveryManager.setUserName(context, name)
        _userName.value = name.trim()
        showFeedback("تم حفظ الاسم بنجاح.")
    }

    fun refreshRecoveryPledge() {
        _recoveryPledge.value = com.example.util.SaffahRecoveryManager.getRecoveryPledge(context)
    }

    fun saveRecoveryPledge(data: com.example.model.RecoveryPledgeData) {
        com.example.util.SaffahRecoveryManager.saveRecoveryPledge(context, data)
        _recoveryPledge.value = data
        if (data.signerName.isNotBlank()) {
            _userName.value = data.signerName
        }
        showFeedback("تم توثيق وحفظ وثيقة التعهد بنجاح.")
    }

    fun clearRecoveryPledge() {
        com.example.util.SaffahRecoveryManager.clearRecoveryPledge(context)
        _recoveryPledge.value = com.example.util.SaffahRecoveryManager.getRecoveryPledge(context)
        showFeedback("تم تفريغ وثيقة التعهد.")
    }

    fun compressAndSavePledgeVideo(sourceUri: android.net.Uri, onComplete: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val pledgeDir = java.io.File(context.filesDir, "recovery_pledge").apply {
                    if (!exists()) mkdirs()
                    val nomedia = java.io.File(this, ".nomedia")
                    if (!nomedia.exists()) nomedia.createNewFile()
                }
                val rawTemp = java.io.File(context.cacheDir, "raw_pledge_video_${System.currentTimeMillis()}.mp4")
                context.contentResolver.openInputStream(sourceUri)?.use { input ->
                    java.io.FileOutputStream(rawTemp).use { output ->
                        input.copyTo(output)
                    }
                }
                val destFile = java.io.File(pledgeDir, "pledge_video_${System.currentTimeMillis()}.mp4")
                val compressed = com.example.util.SaffahMediaCompressor.compressVideoFile(rawTemp, destFile)
                try { if (rawTemp.exists()) rawTemp.delete() } catch (_: Exception) {}
                val finalPath = compressed.absolutePath
                withContext(Dispatchers.Main) {
                    val updated = _recoveryPledge.value.copy(videoPath = finalPath)
                    com.example.util.SaffahRecoveryManager.saveRecoveryPledge(context, updated)
                    _recoveryPledge.value = updated
                    onComplete(finalPath)
                    showFeedback("تم ضغط وتأمين فيديو التعهد بنجاح.")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showFeedback("تعذر معالجة فيديو التعهد: ${e.message}")
                }
            }
        }
    }

    fun removePledgeVideo() {
        val current = _recoveryPledge.value
        if (current.videoPath.isNotBlank()) {
            try {
                val f = java.io.File(current.videoPath)
                if (f.exists()) f.delete()
            } catch (_: Exception) {}
        }
        val updated = current.copy(videoPath = "")
        com.example.util.SaffahRecoveryManager.saveRecoveryPledge(context, updated)
        _recoveryPledge.value = updated
        showFeedback("تم إزالة فيديو التعهد.")
    }

    fun recordRecoveryRelapse(
        note: String = "",
        triggerId: String = com.example.model.RelapseTrigger.OTHER.id,
        defenseAction: String = "",
        initialSpark: String = "",
        loopholeType: String = "",
        haltMoodState: String = "",
        preventiveDecision: String = "",
        saveToDiaries: Boolean = true,
        newBlockedKeyword: String? = null,
        blockAppPackage: String? = null
    ) {
        val effectiveDefense = defenseAction.ifBlank { preventiveDecision }
        com.example.util.SaffahRecoveryManager.recordRelapse(
            context = context,
            note = note,
            triggerId = triggerId,
            defenseAction = effectiveDefense,
            initialSpark = initialSpark,
            loopholeType = loopholeType,
            haltMoodState = haltMoodState,
            preventiveDecision = preventiveDecision.ifBlank { effectiveDefense }
        )
        refreshRecoveryStats()

        // تطبيق إجراءات الحظر المباشرة إذا تم طلبها في القرار الوقائي
        if (!newBlockedKeyword.isNullOrBlank()) {
            addBlockedKeyword(newBlockedKeyword.trim())
        }
        if (!blockAppPackage.isNullOrBlank()) {
            val target = blockAppPackage.trim()
            val matchedApp = _installedApps.value.find {
                it.packageName.equals(target, ignoreCase = true) ||
                it.appName.equals(target, ignoreCase = true) ||
                it.appName.contains(target, ignoreCase = true)
            }
            if (matchedApp != null) {
                if (!matchedApp.isBlocked) {
                    toggleAppBlock(matchedApp.packageName)
                }
            } else {
                toggleAppBlock(target)
            }
        }

        if (saveToDiaries) {
            viewModelScope.launch(Dispatchers.IO) {
                val triggerObj = com.example.model.RelapseTrigger.values().find { it.id == triggerId }
                val triggerTitle = triggerObj?.title ?: "غير محدد"
                val contentBuilder = StringBuilder()
                contentBuilder.append("• استمارة تشريح الزلة وتصفير العداد الصارم:\n\n")
                if (initialSpark.isNotBlank()) {
                    contentBuilder.append("1. التسلسل الزمني والشرارة الأولى: ").append(initialSpark).append("\n")
                }
                if (loopholeType.isNotBlank()) {
                    contentBuilder.append("2. الثغرة التقنية / السلوكية: ").append(loopholeType).append("\n")
                }
                if (haltMoodState.isNotBlank()) {
                    contentBuilder.append("3. الحالة المزاجية قبل الزلة: ").append(haltMoodState).append("\n")
                }
                if (effectiveDefense.isNotBlank()) {
                    contentBuilder.append("4. القرار الوقائي الإلزامي: ").append(effectiveDefense).append("\n")
                }
                if (note.isNotBlank()) {
                    contentBuilder.append("\n• ملاحظات إضافية: ").append(note).append("\n")
                }
                contentBuilder.append("\n(معيار النقاء 100%: الزلة درس عملي لسد الثغرات والبدء الفوري بنقاء تام)")

                val diaryEntry = com.example.model.RecoveryDiaryEntry(
                    id = java.util.UUID.randomUUID().toString(),
                    title = "تشريح زلة: ${if (initialSpark.isNotBlank()) initialSpark.take(24) else triggerTitle}",
                    content = contentBuilder.toString(),
                    emotions = listOf("عزيمة", "انضباط")
                )
                com.example.util.SaffahDiaryRepository.saveEntry(context, diaryEntry)
                loadDiaryEntries()
            }
        }

        showFeedback("تم تصفير العداد والبدء بنقاء 100% من جديد. التعافي مستمر ولا مجال للاستسلام!")
    }

    fun addHistoricalRelapse(
        timestamp: Long,
        note: String = "",
        triggerId: String = com.example.model.RelapseTrigger.OTHER.id,
        defenseAction: String = "",
        initialSpark: String = "",
        loopholeType: String = "",
        haltMoodState: String = "",
        preventiveDecision: String = ""
    ) {
        com.example.util.SaffahRecoveryManager.addHistoricalRelapse(
            context = context,
            timestamp = timestamp,
            note = note,
            triggerId = triggerId,
            defenseAction = defenseAction,
            initialSpark = initialSpark,
            loopholeType = loopholeType,
            haltMoodState = haltMoodState,
            preventiveDecision = preventiveDecision
        )
        refreshRecoveryStats()
        showFeedback("تم تسجيل الانتكاسة وتحديث الإحصائيات بنجاح.")
    }

    fun deleteRelapseRecord(id: String) {
        com.example.util.SaffahRecoveryManager.deleteRelapseRecord(context, id)
        refreshRecoveryStats()
        showFeedback("تم حذف سجل الانتكاسة.")
    }

    fun clearAllRelapses() {
        com.example.util.SaffahRecoveryManager.clearAllRelapses(context)
        refreshRecoveryStats()
        showFeedback("تم مسح كافة سجلات الانتكاسات بنجاح.")
    }

    // --- URGE SURFING & CRAVING DEFENSE (دحر نوبات الشوق) ---
    fun logUrge(
        intensity: com.example.model.UrgeIntensity,
        trigger: com.example.model.RelapseTrigger,
        technique: com.example.model.UrgeDefenseTechnique,
        durationMinutes: Int = 15,
        resistedSuccessfully: Boolean = true,
        note: String = "",
        customTechnique: String = "",
        customTrigger: String = "",
        audioPath: String? = null
    ) {
        com.example.util.SaffahRecoveryManager.logUrge(
            context = context,
            intensity = intensity,
            trigger = trigger,
            technique = technique,
            durationMinutes = durationMinutes,
            resistedSuccessfully = resistedSuccessfully,
            note = note,
            customTechnique = customTechnique,
            customTrigger = customTrigger,
            audioPath = audioPath
        )
        refreshRecoveryStats()
        if (resistedSuccessfully) {
            showFeedback("نصر سلوكي عظيم! تم تسجيل دحر موجة الشوق بنجاح وترسيخ سيادة الفص الجبهي.")
        } else {
            showFeedback("تم تسجيل الملاحظة لتقييم المسار وتفادي الثغرات.")
        }
    }

    fun deleteUrge(id: String) {
        com.example.util.SaffahRecoveryManager.deleteUrge(context, id)
        refreshRecoveryStats()
        showFeedback("تم حذف سجل الرغبة.")
    }

    // --- DOPAMINE BIO-CHECK (الفحص البيولوجي اليومي) ---
    fun saveDopamineBioCheck(
        brainClarity: Int,
        moodStability: Int,
        sleepQuality: Int,
        vitalEnergy: Int,
        note: String = ""
    ) {
        com.example.util.SaffahRecoveryManager.saveTodayBioCheck(
            context = context,
            brainClarity = brainClarity,
            moodStability = moodStability,
            sleepQuality = sleepQuality,
            vitalEnergy = vitalEnergy,
            note = note
        )
        refreshRecoveryStats()
        showFeedback("تم توثيق الفحص البيولوجي اليومي لمؤشرات تعافي الدوبامين بنجاح.")
    }

    // --- DAILY BASELINE CHECK-IN (مؤشر خط الأساس اليومي) ---
    fun refreshDailyBaseline() {
        _dailyBaselineHistory.value = com.example.util.SaffahRecoveryManager.getDailyBaselineHistory(context)
    }

    fun saveDailyBaselineCheckIn(
        clarity: Int,
        mood: Int,
        sleep: Int,
        energy: Int,
        timestamp: Long = System.currentTimeMillis()
    ) {
        val checkIn = com.example.model.DailyBaselineCheckIn(
            timestamp = timestamp,
            clarityOfMind = clarity.coerceIn(1, 5),
            moodStability = mood.coerceIn(1, 5),
            sleepQuality = sleep.coerceIn(1, 5),
            energyAndMotivation = energy.coerceIn(1, 5)
        )
        com.example.util.SaffahRecoveryManager.saveDailyBaselineCheckIn(context, checkIn)
        refreshDailyBaseline()
        refreshRecoveryStats()
        val currentScore = com.example.util.SaffahRecoveryManager.getCurrentBaselineRecoveryScore(context)
        showFeedback("تم توثيق الفحص بنجاح (مؤشر مسار التعافي: $currentScore%).")
    }

    fun deleteDailyBaselineCheckIn(id: String) {
        com.example.util.SaffahRecoveryManager.deleteDailyBaselineCheckIn(context, id)
        refreshDailyBaseline()
        refreshRecoveryStats()
        showFeedback("تم حذف فحص خط الأساس.")
    }

    // --- RECOVERY DIARIES MANAGEMENT (مذكرات التعافي وسلة المحذوفات) ---
    fun loadDiaryEntries() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = com.example.util.SaffahDiaryRepository.getAllEntries(context)
            val trashed = com.example.util.SaffahDiaryRepository.getTrashEntries(context)
            _diaryEntries.value = list
            _trashedDiaryEntries.value = trashed
        }
    }

    fun saveDiaryEntry(entry: com.example.model.RecoveryDiaryEntry) {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.util.SaffahDiaryRepository.saveEntry(context, entry)
            loadDiaryEntries()
            showFeedback("تم حفظ المذكرة بنجاح.")
        }
    }

    fun deleteDiaryEntry(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.util.SaffahDiaryRepository.deleteEntry(context, id)
            loadDiaryEntries()
            showFeedback("تم نقل المذكرة إلى سلة المحذوفات.")
        }
    }

    fun restoreDiaryEntry(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.util.SaffahDiaryRepository.restoreEntry(context, id)
            loadDiaryEntries()
            showFeedback("تم استرجاع المذكرة بنجاح.")
        }
    }

    fun permanentlyDeleteDiaryEntry(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.util.SaffahDiaryRepository.permanentlyDeleteEntry(context, id)
            loadDiaryEntries()
            showFeedback("تم حذف المذكرة نهائياً.")
        }
    }

    fun emptyTrash() {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.util.SaffahDiaryRepository.emptyTrash(context)
            loadDiaryEntries()
            showFeedback("تم إفراغ سلة المحذوفات بالكامل.")
        }
    }

    // =========================================================================
    // SMART NOTIFICATIONS MANAGEMENT (إدارة الإشعارات الذكية)
    // =========================================================================
    private val _isCleanDayNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isCleanDayNotifEnabled(context))
    val isCleanDayNotifEnabled: StateFlow<Boolean> = _isCleanDayNotifEnabled.asStateFlow()

    private val _isMapMilestoneNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isMapMilestoneNotifEnabled(context))
    val isMapMilestoneNotifEnabled: StateFlow<Boolean> = _isMapMilestoneNotifEnabled.asStateFlow()

    private val _isDopamineSurveyNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isDopamineSurveyNotifEnabled(context))
    val isDopamineSurveyNotifEnabled: StateFlow<Boolean> = _isDopamineSurveyNotifEnabled.asStateFlow()

    private val _dopamineSurveyTime = MutableStateFlow(com.example.util.SaffahNotificationManager.getDopamineSurveyTime(context))
    val dopamineSurveyTime: StateFlow<Pair<Int, Int>> = _dopamineSurveyTime.asStateFlow()

    private val _showDopamineAssessmentDialog = MutableStateFlow(false)
    val showDopamineAssessmentDialog: StateFlow<Boolean> = _showDopamineAssessmentDialog.asStateFlow()

    private val _notificationNavDestination = MutableStateFlow<String?>(null)
    val notificationNavDestination: StateFlow<String?> = _notificationNavDestination.asStateFlow()

    fun setNotificationNavDestination(dest: String?) {
        _notificationNavDestination.value = dest
    }

    fun clearNotificationNavDestination() {
        _notificationNavDestination.value = null
    }

    private val _isDangerWindowNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isDangerWindowNotifEnabled(context))
    val isDangerWindowNotifEnabled: StateFlow<Boolean> = _isDangerWindowNotifEnabled.asStateFlow()

    private val _isBedtimeReminderNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isBedtimeReminderNotifEnabled(context))
    val isBedtimeReminderNotifEnabled: StateFlow<Boolean> = _isBedtimeReminderNotifEnabled.asStateFlow()

    private val _isBedtimeModWindowNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isBedtimeModWindowNotifEnabled(context))
    val isBedtimeModWindowNotifEnabled: StateFlow<Boolean> = _isBedtimeModWindowNotifEnabled.asStateFlow()

    private val _isUsageLimitNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isUsageLimitNotifEnabled(context))
    val isUsageLimitNotifEnabled: StateFlow<Boolean> = _isUsageLimitNotifEnabled.asStateFlow()

    private val _isLaunchCountNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isLaunchCountNotifEnabled(context))
    val isLaunchCountNotifEnabled: StateFlow<Boolean> = _isLaunchCountNotifEnabled.asStateFlow()

    private val _isRecordStreakNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isRecordStreakNotifEnabled(context))
    val isRecordStreakNotifEnabled: StateFlow<Boolean> = _isRecordStreakNotifEnabled.asStateFlow()

    private val _isDopamineReceptorNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isDopamineReceptorNotifEnabled(context))
    val isDopamineReceptorNotifEnabled: StateFlow<Boolean> = _isDopamineReceptorNotifEnabled.asStateFlow()

    private val _isCuriosityRadarNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isCuriosityRadarNotifEnabled(context))
    val isCuriosityRadarNotifEnabled: StateFlow<Boolean> = _isCuriosityRadarNotifEnabled.asStateFlow()

    private val _isNewTerrainNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isNewTerrainNotifEnabled(context))
    val isNewTerrainNotifEnabled: StateFlow<Boolean> = _isNewTerrainNotifEnabled.asStateFlow()

    private val _isContentBlockNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isContentBlockNotifEnabled(context))
    val isContentBlockNotifEnabled: StateFlow<Boolean> = _isContentBlockNotifEnabled.asStateFlow()

    private val _isModificationWindowNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isModificationWindowNotifEnabled(context))
    val isModificationWindowNotifEnabled: StateFlow<Boolean> = _isModificationWindowNotifEnabled.asStateFlow()

    private val _isScheduledBlockNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isScheduledBlockNotifEnabled(context))
    val isScheduledBlockNotifEnabled: StateFlow<Boolean> = _isScheduledBlockNotifEnabled.asStateFlow()

    private val _isProductivityGoalNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isProductivityGoalNotifEnabled(context))
    val isProductivityGoalNotifEnabled: StateFlow<Boolean> = _isProductivityGoalNotifEnabled.asStateFlow()

    private val _isDailyBlockHarvestNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isDailyBlockHarvestNotifEnabled(context))
    val isDailyBlockHarvestNotifEnabled: StateFlow<Boolean> = _isDailyBlockHarvestNotifEnabled.asStateFlow()

    private val _isTimeDelayNotifEnabled = MutableStateFlow(com.example.util.SaffahNotificationManager.isTimeDelayNotifEnabled(context))
    val isTimeDelayNotifEnabled: StateFlow<Boolean> = _isTimeDelayNotifEnabled.asStateFlow()

    private val _dangerWindowAnalysis = MutableStateFlow(com.example.util.SaffahNotificationManager.analyzeDangerWindow(context))
    val dangerWindowAnalysis: StateFlow<com.example.util.SaffahNotificationManager.DangerWindowAnalysis> = _dangerWindowAnalysis.asStateFlow()

    private val _currentBedtimeTipPreview = MutableStateFlow(com.example.util.SaffahNotificationManager.getCurrentBedtimeTipPreview(context))
    val currentBedtimeTipPreview: StateFlow<String> = _currentBedtimeTipPreview.asStateFlow()

    fun refreshNotificationSettings() {
        _isCleanDayNotifEnabled.value = com.example.util.SaffahNotificationManager.isCleanDayNotifEnabled(context)
        _isMapMilestoneNotifEnabled.value = com.example.util.SaffahNotificationManager.isMapMilestoneNotifEnabled(context)
        _isDopamineSurveyNotifEnabled.value = com.example.util.SaffahNotificationManager.isDopamineSurveyNotifEnabled(context)
        _dopamineSurveyTime.value = com.example.util.SaffahNotificationManager.getDopamineSurveyTime(context)
        _isDangerWindowNotifEnabled.value = com.example.util.SaffahNotificationManager.isDangerWindowNotifEnabled(context)
        _isBedtimeReminderNotifEnabled.value = com.example.util.SaffahNotificationManager.isBedtimeReminderNotifEnabled(context)
        _isBedtimeModWindowNotifEnabled.value = com.example.util.SaffahNotificationManager.isBedtimeModWindowNotifEnabled(context)
        _isUsageLimitNotifEnabled.value = com.example.util.SaffahNotificationManager.isUsageLimitNotifEnabled(context)
        _isLaunchCountNotifEnabled.value = com.example.util.SaffahNotificationManager.isLaunchCountNotifEnabled(context)
        _isRecordStreakNotifEnabled.value = com.example.util.SaffahNotificationManager.isRecordStreakNotifEnabled(context)
        _isDopamineReceptorNotifEnabled.value = com.example.util.SaffahNotificationManager.isDopamineReceptorNotifEnabled(context)
        _isCuriosityRadarNotifEnabled.value = com.example.util.SaffahNotificationManager.isCuriosityRadarNotifEnabled(context)
        _isNewTerrainNotifEnabled.value = com.example.util.SaffahNotificationManager.isNewTerrainNotifEnabled(context)
        _isContentBlockNotifEnabled.value = com.example.util.SaffahNotificationManager.isContentBlockNotifEnabled(context)
        _isModificationWindowNotifEnabled.value = com.example.util.SaffahNotificationManager.isModificationWindowNotifEnabled(context)
        _isScheduledBlockNotifEnabled.value = com.example.util.SaffahNotificationManager.isScheduledBlockNotifEnabled(context)
        _isProductivityGoalNotifEnabled.value = com.example.util.SaffahNotificationManager.isProductivityGoalNotifEnabled(context)
        _isDailyBlockHarvestNotifEnabled.value = com.example.util.SaffahNotificationManager.isDailyBlockHarvestNotifEnabled(context)
        _isTimeDelayNotifEnabled.value = com.example.util.SaffahNotificationManager.isTimeDelayNotifEnabled(context)
        _dangerWindowAnalysis.value = com.example.util.SaffahNotificationManager.analyzeDangerWindow(context)
        _currentBedtimeTipPreview.value = com.example.util.SaffahNotificationManager.getCurrentBedtimeTipPreview(context)
    }

    fun toggleTimeDelayNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setTimeDelayNotifEnabled(context, enabled)
        _isTimeDelayNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل التنبيه بانتهاء مدة التأخير الزمني." else "تم إيقاف التنبيه بانتهاء مدة التأخير الزمني.")
    }

    fun toggleProductivityGoalNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setProductivityGoalNotifEnabled(context, enabled)
        _isProductivityGoalNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تنبيه تحقيق الهدف اليومي للتطبيقات." else "تم إيقاف تنبيه تحقيق الهدف اليومي للتطبيقات.")
    }

    fun toggleDailyBlockHarvestNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setDailyBlockHarvestNotifEnabled(context, enabled)
        _isDailyBlockHarvestNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل إشعار حصاد الحظر اليومي (21:00)." else "تم إيقاف إشعار حصاد الحظر اليومي (21:00).")
    }

    fun toggleModificationWindowNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setModificationWindowNotifEnabled(context, enabled)
        _isModificationWindowNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل التنبيه بدخول وقت السماح بالتعديل." else "تم إيقاف التنبيه بدخول وقت السماح بالتعديل.")
    }

    fun toggleScheduledBlockNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setScheduledBlockNotifEnabled(context, enabled)
        _isScheduledBlockNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تنبيه بدأ وانتهاء الحظر المجدول." else "تم إيقاف تنبيه بدأ وانتهاء الحظر المجدول.")
    }

    fun toggleNewTerrainNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setNewTerrainNotifEnabled(context, enabled)
        _isNewTerrainNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل إنذار دخول تضاريس جديدة." else "تم إيقاف إنذار دخول تضاريس جديدة.")
    }

    fun toggleContentBlockNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setContentBlockNotifEnabled(context, enabled)
        _isContentBlockNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل إشعار حظر المحتوى الفوري." else "تم إيقاف إشعار حظر المحتوى الفوري.")
    }

    fun toggleDangerWindowNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setDangerWindowNotifEnabled(context, enabled)
        _isDangerWindowNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تحذير نافذة الخطر الزمني." else "تم إيقاف تحذير نافذة الخطر الزمني.")
    }

    fun toggleBedtimeReminderNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setBedtimeReminderNotifEnabled(context, enabled)
        _isBedtimeReminderNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تنبيه بدء وقت النوم." else "تم إيقاف تنبيه بدء وقت النوم.")
    }

    fun toggleBedtimeModWindowNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setBedtimeModWindowNotifEnabled(context, enabled)
        _isBedtimeModWindowNotifEnabled.value = enabled
        if (enabled) {
            com.example.util.SaffahNotificationManager.scheduleBedtimeModWindowAlarm(context)
            com.example.util.SaffahNotificationManager.evaluateAndTriggerBedtimeModWindowNotification(context)
        }
        showFeedback(if (enabled) "تم تفعيل تنبيه ضبط وقت النوم (11:30)." else "تم إيقاف تنبيه ضبط وقت النوم (11:30).")
    }

    fun toggleUsageLimitNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setUsageLimitNotifEnabled(context, enabled)
        _isUsageLimitNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تنبيهات وقت التطبيقات المقيدة (100%)." else "تم إيقاف تنبيهات وقت التطبيقات المقيدة.")
    }

    fun toggleLaunchCountNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setLaunchCountNotifEnabled(context, enabled)
        _isLaunchCountNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تنبيه بلوغ سقف مرات الفتح." else "تم إيقاف تنبيه بلوغ سقف مرات الفتح.")
    }

    fun toggleRecordStreakNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setRecordStreakNotifEnabled(context, enabled)
        _isRecordStreakNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تنبيه كسر الرقم القياسي للتعافي." else "تم إيقاف تنبيه كسر الرقم القياسي للتعافي.")
    }

    fun toggleDopamineReceptorNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setDopamineReceptorNotifEnabled(context, enabled)
        _isDopamineReceptorNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تنبيه التغير الحيوي لمستقبلات الدوبامين." else "تم إيقاف تنبيه التغير الحيوي لمستقبلات الدوبامين.")
    }

    fun toggleCuriosityRadarNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setCuriosityRadarNotifEnabled(context, enabled)
        _isCuriosityRadarNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل رادار الفضول المتصاعد الوقائي." else "تم إيقاف رادار الفضول المتصاعد الوقائي.")
    }

    fun toggleCleanDayNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setCleanDayNotifEnabled(context, enabled)
        _isCleanDayNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل إشعار إنجاز اليوم النظيف." else "تم إيقاف إشعار إنجاز اليوم النظيف.")
    }

    fun toggleMapMilestoneNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setMapMilestoneNotifEnabled(context, enabled)
        _isMapMilestoneNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل إشعار فتح محطات الخريطة." else "تم إيقاف إشعار فتح محطات الخريطة.")
    }

    fun toggleDopamineSurveyNotification(enabled: Boolean) {
        com.example.util.SaffahNotificationManager.setDopamineSurveyNotifEnabled(context, enabled)
        _isDopamineSurveyNotifEnabled.value = enabled
        showFeedback(if (enabled) "تم تفعيل تذكير استبيان التوازن الدوباميني." else "تم إيقاف تذكير استبيان التوازن الدوباميني.")
    }

    fun updateDopamineSurveyTime(hour: Int, minute: Int) {
        com.example.util.SaffahNotificationManager.setDopamineSurveyTime(context, hour, minute)
        _dopamineSurveyTime.value = Pair(hour, minute)
        val formattedTime = String.format(java.util.Locale.US, "%02d:%02d", hour, minute)
        showFeedback("تم ضبط موعد استبيان الدوبامين على الساعة $formattedTime.")
    }

    fun openDopamineAssessmentDialog() {
        _showDopamineAssessmentDialog.value = true
    }

    fun closeDopamineAssessmentDialog() {
        _showDopamineAssessmentDialog.value = false
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stopAudio()
        audioRecorder.stopRecording()
    }
}

