package com.example.util

import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*

/**
 * مدير النسخ الاحتياطي المحلي الشامل وتصدير واستعادة كافة بيانات تطبيق السَّفاح.
 * يغطي 100% من بيانات التطبيق:
 * 1. الكلمات المحظورة والتطبيقات المستثناة منها
 * 2. المواقع المحظورة وتطبيقات استثناء VPN
 * 3. حظر التطبيقات المؤبد ومنع حذف التطبيقات
 * 4. قواعد استخدام التطبيقات (سقف المدة وعدد مرات الفتح)
 * 5. جداول الحظر الدوري للتطبيقات
 * 6. ضبط وقت النوم (المواعيد، التطبيقات المسموحة، كتم الصوت، الرمادي، راحة العين)
 * 7. قواعد تحسين الإنتاجية والانضباط
 * 8. فلاتر المحتوى الخاصة (تيليجرام، واتساب، يوتيوب شورتس، فيسبوك ريلز، انستغرام ريلز، المتصفحات)
 * 9. إعدادات وقت التأخير الزمني
 * 10. نظام عقوبة المحاولات المحظورة
 * 11. قاعدة الـ 15 دقيقة لدحر الرغبة
 * 12. حماية الخصوصية ورمز PIN والأقسام المحمية
 * 13. مفاتيح QR المادية المشفرة
 * 14. تفضيلات وإعدادات الإشعارات والتنبيهات
 * 15. قيود الأمان والمالك للجهاز (SafeBoot، الوقت، DNS، تصحيح الأخطاء)
 * 16. سجلات الحظر والانتهاكات المسجلة
 * 17. المظهر والتفضيلات العامة (الوضع الليلي)
 * 18. كافة بيانات وإحصائيات مركز التعافي (العداد، الانتكاسات، الرغبات، الميثاق، المذكرات النصية)
 */
object GoogleDriveBackupManager {

    private const val TAG = "SaffahLocalBackup"
    private const val PREFS_NAME = "saffah_backup_prefs"
    private const val KEY_LAST_BACKUP_TIME = "last_backup_time"
    private const val KEY_LAST_BACKUP_DATE_STR = "last_backup_date_str"
    private const val KEY_LAST_BACKUP_JSON = "last_backup_json"

    private fun getPrefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Generates a complete JSON payload containing 100% of all app data and rules.
     */
    fun generateBackupJson(context: Context): String {
        val keywords = SaffahBlockRepository.getBlockedKeywords(context)
        val sites = SaffahBlockRepository.getBlockedSites(context)
        val permanentPackages = SaffahBlockRepository.getPermanentBlockedPackages(context)
        val usageRules = SaffahBlockRepository.getUsageRules(context)
        val scheduleRules = SaffahBlockRepository.getAppScheduleRules(context)

        val now = System.currentTimeMillis()
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val dateFormatted = sdf.format(Date(now))

        val root = JSONObject()
        root.put("version", 2)
        root.put("appName", "السَّفاح (Saffah Protection)")
        root.put("applicationId", context.packageName)
        root.put("timestamp", now)
        root.put("backupDate", dateFormatted)
        root.put("deviceModel", "${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})")

        // 1. Blocked Keywords
        val keywordsArray = JSONArray()
        for (kw in keywords) {
            val kwObj = JSONObject().apply {
                put("id", kw.id)
                put("keyword", kw.keyword)
                put("dateAdded", kw.dateAdded)
                put("isEnabled", kw.isEnabled)
            }
            keywordsArray.put(kwObj)
        }
        root.put("blockedKeywords", keywordsArray)

        // 1.b Keyword Exempted Apps
        val keywordExemptedApps = SaffahBlockRepository.getKeywordExemptedApps(context)
        val keywordExemptedArray = JSONArray()
        for (pkg in keywordExemptedApps) {
            keywordExemptedArray.put(pkg)
        }
        root.put("keywordExemptedApps", keywordExemptedArray)

        // 1.c VPN Excluded Apps
        val excludedVpnApps = SaffahBlockRepository.getExcludedVpnApps(context)
        val vpnExcludedArray = JSONArray()
        for (pkg in excludedVpnApps) {
            vpnExcludedArray.put(pkg)
        }
        root.put("excludedVpnApps", vpnExcludedArray)

        // 2. Blocked Sites
        val sitesArray = JSONArray()
        for (site in sites) {
            val siteObj = JSONObject().apply {
                put("id", site.id)
                put("domain", site.domain)
                put("dateAdded", site.dateAdded)
                put("isEnabled", site.isEnabled)
            }
            sitesArray.put(siteObj)
        }
        root.put("blockedSites", sitesArray)

        // 3. App Blocking Section
        val appBlockingObj = JSONObject()

        // 3.a Permanent Blocks
        val permanentArray = JSONArray()
        for (pkg in permanentPackages) {
            permanentArray.put(pkg)
        }
        appBlockingObj.put("permanentBlockedPackages", permanentArray)

        // 3.a.2 Uninstall Blocked Packages
        val uninstallBlockedPackages = SaffahBlockRepository.getUninstallBlockedPackages(context)
        val uninstallBlockedArray = JSONArray()
        for (pkg in uninstallBlockedPackages) {
            uninstallBlockedArray.put(pkg)
        }
        appBlockingObj.put("uninstallBlockedPackages", uninstallBlockedArray)
        root.put("uninstallBlockedPackages", uninstallBlockedArray)

        // 3.b Usage Block Rules
        val usageArray = JSONArray()
        for (ur in usageRules) {
            val urObj = JSONObject().apply {
                put("id", ur.id)
                put("name", ur.name)
                put("isEnabled", ur.isEnabled)
                put("limitType", ur.limitType.name)
                put("limitValue", ur.limitValue)
                put("activeDays", JSONArray(ur.activeDays.toList()))
                put("selectedPackages", JSONArray(ur.selectedPackages.toList()))
                put("createdAt", ur.createdAt)
                put("lastActivatedAt", ur.lastActivatedAt)
                val pkgAddedAtObj = JSONObject()
                ur.packageAddedAt.forEach { (pkg, ts) -> pkgAddedAtObj.put(pkg, ts) }
                put("packageAddedAt", pkgAddedAtObj)
            }
            usageArray.put(urObj)
        }
        appBlockingObj.put("usageBlockRules", usageArray)
        appBlockingObj.put("isUsageMasterEnabled", SaffahBlockRepository.isUsageMasterEnabled(context))

        // 3.c Scheduled Block Rules
        val scheduleArray = JSONArray()
        for (sr in scheduleRules) {
            val effectiveRanges = sr.getEffectiveTimeRanges()
            val timeRangesArr = JSONArray()
            for (tr in effectiveRanges) {
                val trObj = JSONObject().apply {
                    put("startHour", tr.startHour)
                    put("startMinute", tr.startMinute)
                    put("endHour", tr.endHour)
                    put("endMinute", tr.endMinute)
                }
                timeRangesArr.put(trObj)
            }
            val firstRange = effectiveRanges.firstOrNull() ?: com.example.model.ScheduleTimeRange()
            val srObj = JSONObject().apply {
                put("id", sr.id)
                put("name", sr.name)
                put("isEnabled", sr.isEnabled)
                put("startHour", firstRange.startHour)
                put("startMinute", firstRange.startMinute)
                put("endHour", firstRange.endHour)
                put("endMinute", firstRange.endMinute)
                put("timeRanges", timeRangesArr)
                put("blockType", sr.blockType.name)
                put("activeDays", JSONArray(sr.activeDays.toList()))
                put("selectedPackages", JSONArray(sr.selectedPackages.toList()))
            }
            scheduleArray.put(srObj)
        }
        appBlockingObj.put("appScheduleRules", scheduleArray)
        appBlockingObj.put("isAppScheduleMasterEnabled", SaffahBlockRepository.isAppScheduleMasterEnabled(context))

        root.put("appBlocking", appBlockingObj)

        // 3.d Bedtime Mode Settings
        val bedtimeSchedule = SaffahBlockRepository.getBedtimeSchedule(context)
        val bedtimeObj = JSONObject().apply {
            put("isEnabled", SaffahBlockRepository.isBedtimeModeEnabled(context))
            put("startHour", bedtimeSchedule.first.first)
            put("startMinute", bedtimeSchedule.first.second)
            put("endHour", bedtimeSchedule.second.first)
            put("endMinute", bedtimeSchedule.second.second)
            put("activeDays", JSONArray(SaffahBlockRepository.getBedtimeDays(context).toList()))
            put("allowedApps", JSONArray(SaffahBlockRepository.getBedtimeAllowedApps(context).toList()))
            put("isGrayscaleEnabled", SaffahBlockRepository.isBedtimeGrayscaleEnabled(context))
            put("isEyeComfortEnabled", SaffahBlockRepository.isBedtimeEyeComfortEnabled(context))
        }
        root.put("bedtimeSettings", bedtimeObj)

        // 3.e Productivity & Discipline Rule
        val prodRule = SaffahBlockRepository.getProductivityRule(context)
        if (prodRule != null) {
            val prodObj = JSONObject().apply {
                put("id", prodRule.id)
                put("name", prodRule.name)
                put("isEnabled", prodRule.isEnabled)
                put("activeDays", JSONArray(prodRule.activeDays.toList()))
                val targetsArr = JSONArray()
                for (target in prodRule.targetApps) {
                    val tObj = JSONObject().apply {
                        put("packageName", target.packageName)
                        put("targetMinutes", target.targetMinutes)
                        put("baselineMillis", target.baselineMillis)
                        put("addedAt", target.addedAt)
                    }
                    targetsArr.put(tObj)
                }
                put("targetApps", targetsArr)
                put("allowedApps", JSONArray(prodRule.allowedApps.toList()))
            }
            root.put("productivityDisciplineRule", prodObj)
        }

        // 4. Content Filters (فلاتر المحتوى الخاصة)
        val contentFiltersObj = JSONObject().apply {
            put("blockTelegramSearch", SaffahBlockRepository.isTelegramSearchBlocked(context))
            put("blockWhatsappChannels", SaffahBlockRepository.isWhatsAppChannelsBlocked(context))
            put("blockYoutubeShorts", SaffahBlockRepository.isYouTubeShortsBlocked(context))
            put("blockFacebookLiteReels", SaffahBlockRepository.isFacebookLiteReelsBlocked(context))
            put("blockInstagramReels", SaffahBlockRepository.isInstagramReelsBlocked(context))
            put("blockUnsupportedBrowsers", SaffahBlockRepository.isBlockUnsupportedBrowsers(context))
            put("blockInAppBrowsers", SaffahBlockRepository.isBlockInAppBrowsers(context))
            put("hideVpnNotification", SaffahBlockRepository.isHideVpnNotification(context))
        }
        root.put("contentFilters", contentFiltersObj)

        // 5. Time Delay Settings (التأخير الزمني)
        val timeDelayObj = JSONObject().apply {
            put("configuredHours", SaffahBlockRepository.getConfiguredTimeDelayHours(context))
        }
        root.put("timeDelaySettings", timeDelayObj)

        // 6. Penalty System Settings (نظام العقوبة)
        val penaltyObj = JSONObject().apply {
            put("isPenaltyEnabled", SaffahPenaltyManager.isPenaltyFeatureEnabled(context))
            put("penaltyDurationMinutes", SaffahPenaltyManager.getPenaltyDurationMinutes(context))
        }
        root.put("penaltySettings", penaltyObj)

        // 7. Urge Surfing Settings (قاعدة الـ 15 دقيقة)
        val urgeObj = JSONObject().apply {
            put("isUrgeRuleEnabled", SaffahUrgeManager.isUrgeFeatureEnabled(context))
            put("lastCompletedSessionTime", SaffahUrgeManager.getLastCompletedSessionTime(context))
        }
        root.put("urgeSettings", urgeObj)

        // 8. Privacy & Section Protection (حماية الخصوصية ورمز PIN)
        val privacyObj = JSONObject().apply {
            put("pinHash", SaffahPrivacyManager.getPinHash(context) ?: "")
            put("protectedSections", JSONArray(SaffahPrivacyManager.getProtectedSections(context).toList()))
        }
        root.put("privacySettings", privacyObj)

        // 9. Physical QR Keys (حماية المفتاح المادي QR)
        val qrConfig = SaffahQrKeyManager.getQrKeyConfig(context)
        val qrObj = JSONObject().apply {
            put("isEnabled", qrConfig.isEnabled)
            val keysArray = JSONArray()
            for (k in qrConfig.keys) {
                val kObj = JSONObject().apply {
                    put("id", k.id)
                    put("hash", k.hash)
                    put("preview", k.preview)
                    put("length", k.length)
                    put("registeredAt", k.registeredAt)
                    put("label", k.label)
                }
                keysArray.put(kObj)
            }
            put("keys", keysArray)
        }
        root.put("qrKeySettings", qrObj)

        // 10. Notification Settings (تفضيلات الإشعارات)
        val notifPrefs = context.getSharedPreferences("saffah_notification_prefs", Context.MODE_PRIVATE)
        val notifObj = JSONObject().apply {
            put("cleanDayNotifEnabled", SaffahNotificationManager.isCleanDayNotifEnabled(context))
            put("mapMilestoneNotifEnabled", SaffahNotificationManager.isMapMilestoneNotifEnabled(context))
            put("dopamineSurveyNotifEnabled", SaffahNotificationManager.isDopamineSurveyNotifEnabled(context))
            put("dopamineHour", notifPrefs.getInt("notif_dopamine_hour", 21))
            put("dopamineMinute", notifPrefs.getInt("notif_dopamine_minute", 30))
            put("dangerWindowNotifEnabled", SaffahNotificationManager.isDangerWindowNotifEnabled(context))
            put("bedtimeReminderNotifEnabled", SaffahNotificationManager.isBedtimeReminderNotifEnabled(context))
            put("bedtimeModWindowNotifEnabled", SaffahNotificationManager.isBedtimeModWindowNotifEnabled(context))
            put("usageLimitNotifEnabled", SaffahNotificationManager.isUsageLimitNotifEnabled(context))
            put("launchCountNotifEnabled", SaffahNotificationManager.isLaunchCountNotifEnabled(context))
            put("recordStreakNotifEnabled", SaffahNotificationManager.isRecordStreakNotifEnabled(context))
            put("dopamineReceptorNotifEnabled", SaffahNotificationManager.isDopamineReceptorNotifEnabled(context))
            put("curiosityRadarNotifEnabled", SaffahNotificationManager.isCuriosityRadarNotifEnabled(context))
            put("newTerrainNotifEnabled", SaffahNotificationManager.isNewTerrainNotifEnabled(context))
            put("contentBlockNotifEnabled", SaffahNotificationManager.isContentBlockNotifEnabled(context))
            put("modificationWindowNotifEnabled", SaffahNotificationManager.isModificationWindowNotifEnabled(context))
            put("scheduledBlockNotifEnabled", SaffahNotificationManager.isScheduledBlockNotifEnabled(context))
            put("productivityGoalNotifEnabled", SaffahNotificationManager.isProductivityGoalNotifEnabled(context))
            put("dailyBlockHarvestNotifEnabled", SaffahNotificationManager.isDailyBlockHarvestNotifEnabled(context))
            put("timeDelayNotifEnabled", SaffahNotificationManager.isTimeDelayNotifEnabled(context))
        }
        root.put("notificationSettings", notifObj)

        // 11. Security Restrictions (قيود الجهاز المالك)
        val securityObj = JSONObject().apply {
            put("disallowSafeBoot", SaffahProtectionManager.isDisallowSafeBootEnabled(context))
            put("disallowConfigDateTime", SaffahProtectionManager.isDisallowConfigDateTimeEnabled(context))
            put("disallowConfigPrivateDns", SaffahProtectionManager.isDisallowConfigPrivateDnsEnabled(context))
            put("disallowDebuggingFeatures", SaffahProtectionManager.isDisallowDebuggingFeaturesEnabled(context))
        }
        root.put("securityRestrictions", securityObj)

        // 12. App Preferences (تفضيلات التطبيق العامة)
        val appPrefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        val prefsObj = JSONObject().apply {
            put("darkMode", appPrefs.getBoolean("dark_mode", false))
        }
        root.put("appPreferences", prefsObj)

        // 13. Block Logs (سجل عمليات الحظر)
        val blockLogs = SaffahBlockRepository.getBlockLogs(context)
        val blockLogsArray = JSONArray()
        for (logEntry in blockLogs) {
            val logObj = JSONObject().apply {
                put("id", logEntry.id)
                put("blockedItem", logEntry.blockedItem)
                put("type", logEntry.type)
                put("timestamp", logEntry.timestamp)
                put("sourceApp", logEntry.sourceApp)
            }
            blockLogsArray.put(logObj)
        }
        root.put("blockLogs", blockLogsArray)

        // 14. Recovery Center (مركز التعافي والمذكرات النصية)
        var diariesCount = 0
        try {
            val recoveryObj = JSONObject().apply {
                val stats = SaffahRecoveryManager.getRecoveryStats(context)
                put("stats", JSONObject().apply {
                    put("startTimestamp", stats.startTimestamp)
                    put("firstEverStartTimestamp", SaffahRecoveryManager.getFirstEverStartTime(context))
                    put("relapseCount", stats.relapseCount)
                    put("longestStreakSeconds", stats.longestStreakSeconds)
                    put("userName", SaffahRecoveryManager.getUserName(context))
                })
                val recPrefs = context.getSharedPreferences("saffah_recovery_prefs", Context.MODE_PRIVATE)
                put("relapseHistory", JSONArray(recPrefs.getString("recovery_relapse_history_json", "[]") ?: "[]"))
                put("urgeHistory", JSONArray(recPrefs.getString("recovery_urge_history_json", "[]") ?: "[]"))
                put("customTechniques", JSONArray(SaffahRecoveryManager.getCustomDefenseTechniques(context)))
                put("customTriggers", JSONArray(SaffahRecoveryManager.getCustomTriggers(context)))
                put("dopamineBio", JSONArray(recPrefs.getString("recovery_dopamine_bio_json", "[]") ?: "[]"))
                put("dailyBaseline", JSONArray(recPrefs.getString("recovery_daily_baseline_json", "[]") ?: "[]"))
                put("pledge", JSONObject(recPrefs.getString("recovery_pledge_document_json", "{}") ?: "{}"))

                // Active Diaries
                val activeDiaries = SaffahDiaryRepository.getAllEntries(context)
                diariesCount = activeDiaries.size
                val activeDiariesArray = JSONArray()
                for (d in activeDiaries) {
                    val dObj = JSONObject().apply {
                        put("id", d.id)
                        put("title", d.title)
                        put("content", d.content)
                        put("createdAt", d.createdAt)
                        put("updatedAt", d.updatedAt)
                        val mArr = JSONArray()
                        for (m in d.mediaList) {
                            val mObj = JSONObject().apply {
                                put("id", m.id)
                                put("type", m.type.name)
                                put("source", m.source.name)
                                put("filePath", m.filePath)
                                put("fileName", m.fileName)
                                put("durationSeconds", m.durationSeconds)
                                put("fileSizeBytes", m.fileSizeBytes)
                                put("createdAt", m.createdAt)
                            }
                            mArr.put(mObj)
                        }
                        put("mediaList", mArr)
                        put("emotions", JSONArray(d.emotions))
                    }
                    activeDiariesArray.put(dObj)
                }
                put("activeDiaries", activeDiariesArray)

                // Trashed Diaries
                val trashDiaries = SaffahDiaryRepository.getTrashEntries(context)
                val trashDiariesArray = JSONArray()
                for (d in trashDiaries) {
                    val dObj = JSONObject().apply {
                        put("id", d.id)
                        put("title", d.title)
                        put("content", d.content)
                        put("createdAt", d.createdAt)
                        put("updatedAt", d.updatedAt)
                        val mArr = JSONArray()
                        for (m in d.mediaList) {
                            val mObj = JSONObject().apply {
                                put("id", m.id)
                                put("type", m.type.name)
                                put("source", m.source.name)
                                put("filePath", m.filePath)
                                put("fileName", m.fileName)
                                put("durationSeconds", m.durationSeconds)
                                put("fileSizeBytes", m.fileSizeBytes)
                                put("createdAt", m.createdAt)
                            }
                            mArr.put(mObj)
                        }
                        put("mediaList", mArr)
                        put("emotions", JSONArray(d.emotions))
                    }
                    trashDiariesArray.put(dObj)
                }
                put("trashDiaries", trashDiariesArray)
            }
            root.put("recoveryCenter", recoveryObj)
        } catch (e: Exception) {
            Log.w(TAG, "Could not serialize recoveryCenter in backup json: ${e.message}")
        }

        // Active content filters count
        var activeContentFilters = 0
        if (SaffahBlockRepository.isTelegramSearchBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isWhatsAppChannelsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isYouTubeShortsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isFacebookLiteReelsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isInstagramReelsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isBlockUnsupportedBrowsers(context)) activeContentFilters++
        if (SaffahBlockRepository.isBlockInAppBrowsers(context)) activeContentFilters++
        if (SaffahBlockRepository.isHideVpnNotification(context)) activeContentFilters++

        var activeSecurityRestrictions = 0
        if (SaffahProtectionManager.isDisallowSafeBootEnabled(context)) activeSecurityRestrictions++
        if (SaffahProtectionManager.isDisallowConfigDateTimeEnabled(context)) activeSecurityRestrictions++
        if (SaffahProtectionManager.isDisallowConfigPrivateDnsEnabled(context)) activeSecurityRestrictions++
        if (SaffahProtectionManager.isDisallowDebuggingFeaturesEnabled(context)) activeSecurityRestrictions++

        var activeNotifications = 0
        if (SaffahNotificationManager.isCleanDayNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isMapMilestoneNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDopamineSurveyNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDangerWindowNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isBedtimeReminderNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isBedtimeModWindowNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isUsageLimitNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isLaunchCountNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isRecordStreakNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDopamineReceptorNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isCuriosityRadarNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isNewTerrainNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isContentBlockNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isModificationWindowNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isScheduledBlockNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isProductivityGoalNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDailyBlockHarvestNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isTimeDelayNotifEnabled(context)) activeNotifications++

        // Statistics / Metadata
        val totalCount = keywords.size + sites.size + permanentPackages.size + usageRules.size +
                scheduleRules.size + excludedVpnApps.size + uninstallBlockedPackages.size +
                keywordExemptedApps.size + activeContentFilters + activeSecurityRestrictions +
                (if (SaffahBlockRepository.isBedtimeModeEnabled(context)) 1 else 0) +
                (if (prodRule?.isEnabled == true) 1 else 0) +
                (if (SaffahPenaltyManager.isPenaltyFeatureEnabled(context)) 1 else 0) +
                (if (SaffahUrgeManager.isUrgeFeatureEnabled(context)) 1 else 0) +
                (if (qrConfig.isEnabled) 1 else 0)

        val metaObj = JSONObject().apply {
            put("keywordsCount", keywords.size)
            put("sitesCount", sites.size)
            put("permanentBlockedCount", permanentPackages.size)
            put("usageRulesCount", usageRules.size)
            put("scheduleRulesCount", scheduleRules.size)
            put("blockLogsCount", blockLogs.size)
            put("vpnExcludedCount", excludedVpnApps.size)
            put("uninstallBlockedCount", uninstallBlockedPackages.size)
            put("keywordExemptedCount", keywordExemptedApps.size)
            put("contentFiltersCount", activeContentFilters)
            put("securityRestrictionsCount", activeSecurityRestrictions)
            put("notificationsCount", activeNotifications)
            put("diariesCount", diariesCount)
            put("isBedtimeConfigured", SaffahBlockRepository.isBedtimeModeEnabled(context))
            put("isProductivityConfigured", prodRule?.isEnabled == true)
            put("isPenaltyConfigured", SaffahPenaltyManager.isPenaltyFeatureEnabled(context))
            put("isUrgeRuleConfigured", SaffahUrgeManager.isUrgeFeatureEnabled(context))
            put("isQrKeyConfigured", qrConfig.isEnabled)
            put("isPrivacyPinConfigured", SaffahPrivacyManager.isPinConfigured(context))
            put("totalRulesCount", totalCount)
        }
        root.put("metadata", metaObj)

        return root.toString(2)
    }

    /**
     * Safely restores all blocking rules and app data from a JSON backup string.
     */
    fun restoreBackupFromJson(context: Context, jsonStr: String): Result<BackupMetadata> {
        if (SaffahBlockRepository.isTimeDelayActive(context)) {
            val remainingMs = SaffahBlockRepository.getTimeDelayRemainingMs(context)
            val hours = remainingMs / (1000 * 60 * 60)
            val minutes = (remainingMs / (1000 * 60)) % 60
            val timeText = if (hours > 0) "$hours ساعة و $minutes دقيقة" else "$minutes دقيقة"
            return Result.failure(
                Exception("Time Delay active: ميزة التأخير الزمني نشطة حالياً! يُمنع تماماً استعادة النسخة الاحتياطية لمنع التلاعب بالحظر حتى تنتهي الفترة المتبقية ($timeText).")
            )
        }

        return try {
            val root = JSONObject(jsonStr)

            // 1. Restore Blocked Keywords
            val keywordsList = mutableListOf<BlockedKeyword>()
            val keywordsArray = root.optJSONArray("blockedKeywords")
            if (keywordsArray != null) {
                for (i in 0 until keywordsArray.length()) {
                    val obj = keywordsArray.getJSONObject(i)
                    keywordsList.add(
                        BlockedKeyword(
                            id = obj.optLong("id", System.currentTimeMillis() + i),
                            keyword = obj.optString("keyword", "").trim(),
                            dateAdded = obj.optString("dateAdded", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())),
                            isEnabled = obj.optBoolean("isEnabled", true)
                        )
                    )
                }
                if (keywordsList.isNotEmpty()) {
                    SaffahBlockRepository.saveBlockedKeywords(context, keywordsList.filter { it.keyword.isNotBlank() })
                }
            }

            // 1.b Restore Keyword Exempted Apps
            var restoredKeywordExemptedCount = 0
            val keywordExemptedArray = root.optJSONArray("keywordExemptedApps")
            if (keywordExemptedArray != null) {
                val exemptedSet = mutableSetOf<String>()
                for (i in 0 until keywordExemptedArray.length()) {
                    val pkg = keywordExemptedArray.getString(i).trim()
                    if (pkg.isNotEmpty()) exemptedSet.add(pkg)
                }
                SaffahBlockRepository.saveKeywordExemptedApps(context, exemptedSet)
                restoredKeywordExemptedCount = exemptedSet.size
            }

            // 1.c Restore VPN Excluded Apps
            var restoredVpnExcludedCount = 0
            val vpnExcludedArray = root.optJSONArray("excludedVpnApps")
            if (vpnExcludedArray != null) {
                val vpnSet = mutableSetOf<String>()
                for (i in 0 until vpnExcludedArray.length()) {
                    val pkg = vpnExcludedArray.getString(i).trim()
                    if (pkg.isNotEmpty()) vpnSet.add(pkg)
                }
                SaffahBlockRepository.saveExcludedVpnApps(context, vpnSet)
                restoredVpnExcludedCount = vpnSet.size
            }

            // 2. Restore Blocked Sites
            val sitesList = mutableListOf<BlockedSite>()
            val sitesArray = root.optJSONArray("blockedSites")
            if (sitesArray != null) {
                for (i in 0 until sitesArray.length()) {
                    val obj = sitesArray.getJSONObject(i)
                    sitesList.add(
                        BlockedSite(
                            id = obj.optLong("id", System.currentTimeMillis() + i),
                            domain = obj.optString("domain", "").trim().lowercase(),
                            dateAdded = obj.optString("dateAdded", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())),
                            isEnabled = obj.optBoolean("isEnabled", true)
                        )
                    )
                }
                if (sitesList.isNotEmpty()) {
                    SaffahBlockRepository.saveBlockedSites(context, sitesList.filter { it.domain.isNotBlank() })
                }
            }

            // 3. Restore App Blocking Rules
            var permanentCount = 0
            var usageCount = 0
            var scheduleCount = 0
            var restoredUninstallBlockedCount = 0

            val appBlockingObj = root.optJSONObject("appBlocking")
            if (appBlockingObj != null) {
                // 3.a Permanent Blocks
                val permArray = appBlockingObj.optJSONArray("permanentBlockedPackages")
                if (permArray != null) {
                    val permSet = mutableSetOf<String>()
                    for (i in 0 until permArray.length()) {
                        val pkg = permArray.getString(i).trim()
                        if (pkg.isNotEmpty()) permSet.add(pkg)
                    }
                    SaffahBlockRepository.setPermanentBlockedPackages(context, permSet)
                    permanentCount = permSet.size
                }

                // 3.a.2 Uninstall Blocked Packages
                val uninstallArray = root.optJSONArray("uninstallBlockedPackages")
                    ?: appBlockingObj.optJSONArray("uninstallBlockedPackages")
                if (uninstallArray != null) {
                    val uninstallSet = mutableSetOf<String>()
                    for (i in 0 until uninstallArray.length()) {
                        val pkg = uninstallArray.getString(i).trim()
                        if (pkg.isNotEmpty()) uninstallSet.add(pkg)
                    }
                    SaffahBlockRepository.setUninstallBlockedPackages(context, uninstallSet)
                    SaffahProtectionManager.syncUninstallBlockedPackages(context)
                    restoredUninstallBlockedCount = uninstallSet.size
                }

                // 3.b Usage Rules
                val usageArray = appBlockingObj.optJSONArray("usageBlockRules")
                if (usageArray != null) {
                    val usageRulesList = mutableListOf<UsageBlockRule>()
                    for (i in 0 until usageArray.length()) {
                        val obj = usageArray.getJSONObject(i)
                        val daysArray = obj.optJSONArray("activeDays")
                        val activeDays = mutableSetOf<Int>()
                        if (daysArray != null) {
                            for (j in 0 until daysArray.length()) activeDays.add(daysArray.getInt(j))
                        } else {
                            activeDays.addAll(listOf(1, 2, 3, 4, 5, 6, 7))
                        }

                        val pkgsArray = obj.optJSONArray("selectedPackages")
                        val selectedPkgs = mutableSetOf<String>()
                        if (pkgsArray != null) {
                            for (j in 0 until pkgsArray.length()) selectedPkgs.add(pkgsArray.getString(j))
                        }

                        val limitTypeStr = obj.optString("limitType", "DURATION")
                        val limitType = if (limitTypeStr == "LAUNCH_COUNT") UsageLimitType.LAUNCH_COUNT else UsageLimitType.DURATION

                        val createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        val lastActivatedAt = obj.optLong("lastActivatedAt", System.currentTimeMillis())
                        val pkgAddedAtMap = mutableMapOf<String, Long>()
                        val pkgAddedAtObj = obj.optJSONObject("packageAddedAt")
                        if (pkgAddedAtObj != null) {
                            val keys = pkgAddedAtObj.keys()
                            while (keys.hasNext()) {
                                val pkg = keys.next()
                                pkgAddedAtMap[pkg] = pkgAddedAtObj.optLong(pkg, createdAt)
                            }
                        }
                        for (pkg in selectedPkgs) {
                            if (!pkgAddedAtMap.containsKey(pkg)) {
                                pkgAddedAtMap[pkg] = lastActivatedAt
                            }
                        }

                        usageRulesList.add(
                            UsageBlockRule(
                                id = obj.optLong("id", System.currentTimeMillis() + i),
                                name = obj.optString("name", "قاعدة استخدام"),
                                isEnabled = obj.optBoolean("isEnabled", true),
                                activeDays = activeDays,
                                limitType = limitType,
                                limitValue = obj.optInt("limitValue", 30),
                                selectedPackages = selectedPkgs,
                                createdAt = createdAt,
                                lastActivatedAt = lastActivatedAt,
                                packageAddedAt = pkgAddedAtMap
                            )
                        )
                    }
                    SaffahBlockRepository.saveUsageRules(context, usageRulesList)
                    usageCount = usageRulesList.size
                }

                if (appBlockingObj.has("isUsageMasterEnabled")) {
                    SaffahBlockRepository.setUsageMasterEnabled(context, appBlockingObj.optBoolean("isUsageMasterEnabled", true))
                }

                // 3.c Scheduled Rules
                val schedArray = appBlockingObj.optJSONArray("appScheduleRules")
                if (schedArray != null) {
                    val schedRulesList = mutableListOf<AppBlockScheduleRule>()
                    for (i in 0 until schedArray.length()) {
                        val obj = schedArray.getJSONObject(i)
                        val daysArray = obj.optJSONArray("activeDays")
                        val activeDays = mutableSetOf<Int>()
                        if (daysArray != null) {
                            for (j in 0 until daysArray.length()) activeDays.add(daysArray.getInt(j))
                        } else {
                            activeDays.addAll(listOf(1, 2, 3, 4, 5, 6, 7))
                        }

                        val pkgsArray = obj.optJSONArray("selectedPackages")
                        val selectedPkgs = mutableSetOf<String>()
                        if (pkgsArray != null) {
                            for (j in 0 until pkgsArray.length()) selectedPkgs.add(pkgsArray.getString(j))
                        }

                        val typeStr = obj.optString("blockType", "BLOCK_SPECIFIED")
                        val blockType = if (typeStr == "ALLOW_SPECIFIED_BLOCK_OTHERS") {
                            AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS
                        } else {
                            AppBlockType.BLOCK_SPECIFIED
                        }

                        val timeRangesArray = obj.optJSONArray("timeRanges")
                        val timeRangesList = mutableListOf<com.example.model.ScheduleTimeRange>()
                        if (timeRangesArray != null && timeRangesArray.length() > 0) {
                            for (trIdx in 0 until timeRangesArray.length()) {
                                val trObj = timeRangesArray.getJSONObject(trIdx)
                                timeRangesList.add(
                                    com.example.model.ScheduleTimeRange(
                                        startHour = trObj.optInt("startHour", 9),
                                        startMinute = trObj.optInt("startMinute", 0),
                                        endHour = trObj.optInt("endHour", 17),
                                        endMinute = trObj.optInt("endMinute", 0)
                                    )
                                )
                            }
                        }
                        val startHour = obj.optInt("startHour", 9)
                        val startMinute = obj.optInt("startMinute", 0)
                        val endHour = obj.optInt("endHour", 17)
                        val endMinute = obj.optInt("endMinute", 0)
                        if (timeRangesList.isEmpty()) {
                            timeRangesList.add(
                                com.example.model.ScheduleTimeRange(
                                    startHour = startHour,
                                    startMinute = startMinute,
                                    endHour = endHour,
                                    endMinute = endMinute
                                )
                            )
                        }

                        schedRulesList.add(
                            AppBlockScheduleRule(
                                id = obj.optLong("id", System.currentTimeMillis() + i),
                                name = obj.optString("name", "حظر دوري"),
                                isEnabled = obj.optBoolean("isEnabled", true),
                                timeRanges = timeRangesList,
                                startHour = timeRangesList.first().startHour,
                                startMinute = timeRangesList.first().startMinute,
                                endHour = timeRangesList.first().endHour,
                                endMinute = timeRangesList.first().endMinute,
                                activeDays = activeDays,
                                blockType = blockType,
                                selectedPackages = selectedPkgs
                            )
                        )
                    }
                    SaffahBlockRepository.saveAppScheduleRules(context, schedRulesList)
                    scheduleCount = schedRulesList.size
                }

                if (appBlockingObj.has("isAppScheduleMasterEnabled")) {
                    SaffahBlockRepository.setAppScheduleMasterEnabled(context, appBlockingObj.optBoolean("isAppScheduleMasterEnabled", true))
                }
            }

            // Also check root for uninstallBlockedPackages
            if (root.has("uninstallBlockedPackages") && restoredUninstallBlockedCount == 0) {
                val uninstallArray = root.optJSONArray("uninstallBlockedPackages")
                if (uninstallArray != null) {
                    val uninstallSet = mutableSetOf<String>()
                    for (i in 0 until uninstallArray.length()) {
                        val pkg = uninstallArray.getString(i).trim()
                        if (pkg.isNotEmpty()) uninstallSet.add(pkg)
                    }
                    SaffahBlockRepository.setUninstallBlockedPackages(context, uninstallSet)
                    SaffahProtectionManager.syncUninstallBlockedPackages(context)
                    restoredUninstallBlockedCount = uninstallSet.size
                }
            }

            // 3.d Restore Bedtime Settings
            var isBedtimeRestored = false
            val bedtimeObj = root.optJSONObject("bedtimeSettings")
            if (bedtimeObj != null) {
                val isEnabled = bedtimeObj.optBoolean("isEnabled", false)
                val startHour = bedtimeObj.optInt("startHour", 23)
                val startMinute = bedtimeObj.optInt("startMinute", 0)
                val endHour = bedtimeObj.optInt("endHour", 5)
                val endMinute = bedtimeObj.optInt("endMinute", 0)
                SaffahBlockRepository.saveBedtimeSchedule(context, startHour, startMinute, endHour, endMinute)
                SaffahBlockRepository.setBedtimeModeEnabled(context, isEnabled)

                val daysArray = bedtimeObj.optJSONArray("activeDays")
                if (daysArray != null) {
                    val days = mutableSetOf<Int>()
                    for (i in 0 until daysArray.length()) days.add(daysArray.getInt(i))
                    if (days.isNotEmpty()) SaffahBlockRepository.saveBedtimeDays(context, days)
                }

                val allowedAppsArray = bedtimeObj.optJSONArray("allowedApps")
                if (allowedAppsArray != null) {
                    val allowed = mutableSetOf<String>()
                    for (i in 0 until allowedAppsArray.length()) {
                        val pkg = allowedAppsArray.getString(i).trim()
                        if (pkg.isNotEmpty()) allowed.add(pkg)
                    }
                    SaffahBlockRepository.saveBedtimeAllowedApps(context, allowed)
                }

                if (bedtimeObj.has("isGrayscaleEnabled")) {
                    SaffahBlockRepository.setBedtimeGrayscaleEnabled(context, bedtimeObj.optBoolean("isGrayscaleEnabled", false))
                }
                if (bedtimeObj.has("isEyeComfortEnabled")) {
                    SaffahBlockRepository.setBedtimeEyeComfortEnabled(context, bedtimeObj.optBoolean("isEyeComfortEnabled", false))
                }
                SaffahBedtimeManager.evaluateBedtimeState(context)
                isBedtimeRestored = isEnabled
            }

            // 3.e Restore Productivity & Discipline
            var isProductivityRestored = false
            val prodObj = root.optJSONObject("productivityDisciplineRule")
            if (prodObj != null) {
                val daysArray = prodObj.optJSONArray("activeDays")
                val activeDays = mutableSetOf<Int>()
                if (daysArray != null) {
                    for (j in 0 until daysArray.length()) activeDays.add(daysArray.getInt(j))
                } else {
                    activeDays.addAll(setOf(1, 2, 3, 4, 5, 6, 7))
                }

                val targetAppsArray = prodObj.optJSONArray("targetApps")
                val targetAppsList = mutableListOf<com.example.model.ProductivityTargetApp>()
                if (targetAppsArray != null) {
                    for (j in 0 until targetAppsArray.length()) {
                        val targetObj = targetAppsArray.getJSONObject(j)
                        targetAppsList.add(
                            com.example.model.ProductivityTargetApp(
                                packageName = targetObj.getString("packageName"),
                                targetMinutes = targetObj.getInt("targetMinutes"),
                                baselineMillis = targetObj.optLong("baselineMillis", 0L),
                                addedAt = targetObj.optLong("addedAt", 0L)
                            )
                        )
                    }
                }

                val allowedAppsArray = prodObj.optJSONArray("allowedApps")
                val allowedAppsSet = mutableSetOf<String>()
                if (allowedAppsArray != null) {
                    for (j in 0 until allowedAppsArray.length()) {
                        allowedAppsSet.add(allowedAppsArray.getString(j))
                    }
                }

                val isEnabled = prodObj.optBoolean("isEnabled", false)
                val ruleObj = com.example.model.ProductivityDisciplineRule(
                    id = prodObj.optLong("id", System.currentTimeMillis()),
                    name = prodObj.optString("name", "تحسين الإنتاجية والإنظباط"),
                    isEnabled = isEnabled,
                    activeDays = activeDays,
                    targetApps = targetAppsList,
                    allowedApps = allowedAppsSet
                )
                SaffahBlockRepository.saveProductivityRule(context, ruleObj)
                isProductivityRestored = isEnabled
            }

            // 4. Restore Content Filters
            var restoredContentFiltersCount = 0
            val contentFiltersObj = root.optJSONObject("contentFilters")
            if (contentFiltersObj != null) {
                if (contentFiltersObj.has("blockTelegramSearch")) {
                    val v = contentFiltersObj.getBoolean("blockTelegramSearch")
                    SaffahBlockRepository.setTelegramSearchBlocked(context, v)
                    if (v) restoredContentFiltersCount++
                }
                if (contentFiltersObj.has("blockWhatsappChannels")) {
                    val v = contentFiltersObj.getBoolean("blockWhatsappChannels")
                    SaffahBlockRepository.setWhatsAppChannelsBlocked(context, v)
                    if (v) restoredContentFiltersCount++
                }
                if (contentFiltersObj.has("blockYoutubeShorts")) {
                    val v = contentFiltersObj.getBoolean("blockYoutubeShorts")
                    SaffahBlockRepository.setYouTubeShortsBlocked(context, v)
                    if (v) restoredContentFiltersCount++
                }
                if (contentFiltersObj.has("blockFacebookLiteReels")) {
                    val v = contentFiltersObj.getBoolean("blockFacebookLiteReels")
                    SaffahBlockRepository.setFacebookLiteReelsBlocked(context, v)
                    if (v) restoredContentFiltersCount++
                }
                if (contentFiltersObj.has("blockInstagramReels")) {
                    val v = contentFiltersObj.getBoolean("blockInstagramReels")
                    SaffahBlockRepository.setInstagramReelsBlocked(context, v)
                    if (v) restoredContentFiltersCount++
                }
                if (contentFiltersObj.has("blockUnsupportedBrowsers")) {
                    val v = contentFiltersObj.getBoolean("blockUnsupportedBrowsers")
                    SaffahBlockRepository.setBlockUnsupportedBrowsers(context, v)
                    if (v) restoredContentFiltersCount++
                }
                if (contentFiltersObj.has("blockInAppBrowsers")) {
                    val v = contentFiltersObj.getBoolean("blockInAppBrowsers")
                    SaffahBlockRepository.setBlockInAppBrowsers(context, v)
                    if (v) restoredContentFiltersCount++
                }
                if (contentFiltersObj.has("hideVpnNotification")) {
                    val v = contentFiltersObj.getBoolean("hideVpnNotification")
                    SaffahBlockRepository.setHideVpnNotification(context, v)
                    if (v) restoredContentFiltersCount++
                }
            }

            // 5. Restore Time Delay Settings
            val timeDelayObj = root.optJSONObject("timeDelaySettings")
            if (timeDelayObj != null && timeDelayObj.has("configuredHours")) {
                val hours = timeDelayObj.optLong("configuredHours", 1L)
                SaffahBlockRepository.saveConfiguredTimeDelayHours(context, hours)
            }

            // 6. Restore Penalty System Settings
            var isPenaltyConfigured = false
            val penaltyObj = root.optJSONObject("penaltySettings")
            if (penaltyObj != null) {
                if (penaltyObj.has("isPenaltyEnabled")) {
                    val en = penaltyObj.getBoolean("isPenaltyEnabled")
                    SaffahPenaltyManager.setPenaltyFeatureEnabled(context, en)
                    isPenaltyConfigured = en
                }
                if (penaltyObj.has("penaltyDurationMinutes")) {
                    SaffahPenaltyManager.setPenaltyDurationMinutes(context, penaltyObj.getInt("penaltyDurationMinutes"))
                }
            }

            // 7. Restore Urge Surfing Settings
            var isUrgeRuleConfigured = false
            val urgeObj = root.optJSONObject("urgeSettings")
            if (urgeObj != null) {
                if (urgeObj.has("isUrgeRuleEnabled")) {
                    val en = urgeObj.getBoolean("isUrgeRuleEnabled")
                    SaffahUrgeManager.setUrgeFeatureEnabled(context, en)
                    isUrgeRuleConfigured = en
                }
            }

            // 8. Restore Privacy & Section Protection
            var isPrivacyPinConfigured = false
            val privacyObj = root.optJSONObject("privacySettings")
            if (privacyObj != null) {
                val pinHash = privacyObj.optString("pinHash", "").ifBlank { null }
                val sectionsArr = privacyObj.optJSONArray("protectedSections")
                val sections = mutableSetOf<String>()
                if (sectionsArr != null) {
                    for (i in 0 until sectionsArr.length()) sections.add(sectionsArr.getString(i))
                }
                SaffahPrivacyManager.restorePrivacyConfig(context, pinHash, sections)
                isPrivacyPinConfigured = !pinHash.isNullOrBlank()
            }

            // 9. Restore Physical QR Keys
            var isQrKeyConfigured = false
            val qrObj = root.optJSONObject("qrKeySettings")
            if (qrObj != null) {
                val keysArr = qrObj.optJSONArray("keys")
                if (keysArr != null) {
                    val qrKeysList = mutableListOf<SaffahQrKeyManager.QrKeyItem>()
                    for (i in 0 until keysArr.length()) {
                        val kObj = keysArr.getJSONObject(i)
                        val hash = kObj.optString("hash", "")
                        if (hash.isNotBlank()) {
                            qrKeysList.add(
                                SaffahQrKeyManager.QrKeyItem(
                                    id = kObj.optString("id", UUID.randomUUID().toString()),
                                    hash = hash,
                                    preview = kObj.optString("preview", "****"),
                                    length = kObj.optInt("length", 0),
                                    registeredAt = kObj.optLong("registeredAt", System.currentTimeMillis()),
                                    label = kObj.optString("label", "كود ${i + 1}")
                                )
                            )
                        }
                    }
                    if (qrKeysList.isNotEmpty()) {
                        SaffahQrKeyManager.restoreKeysList(context, qrKeysList)
                        isQrKeyConfigured = qrObj.optBoolean("isEnabled", true)
                    }
                }
            }

            // 10. Restore Notification Settings
            var restoredNotifsCount = 0
            val notifObj = root.optJSONObject("notificationSettings")
            if (notifObj != null) {
                if (notifObj.has("cleanDayNotifEnabled")) {
                    val en = notifObj.getBoolean("cleanDayNotifEnabled")
                    SaffahNotificationManager.setCleanDayNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("mapMilestoneNotifEnabled")) {
                    val en = notifObj.getBoolean("mapMilestoneNotifEnabled")
                    SaffahNotificationManager.setMapMilestoneNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("dopamineSurveyNotifEnabled")) {
                    val en = notifObj.getBoolean("dopamineSurveyNotifEnabled")
                    SaffahNotificationManager.setDopamineSurveyNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("dopamineHour") && notifObj.has("dopamineMinute")) {
                    SaffahNotificationManager.setDopamineSurveyTime(context, notifObj.getInt("dopamineHour"), notifObj.getInt("dopamineMinute"))
                }
                if (notifObj.has("dangerWindowNotifEnabled")) {
                    val en = notifObj.getBoolean("dangerWindowNotifEnabled")
                    SaffahNotificationManager.setDangerWindowNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("bedtimeReminderNotifEnabled")) {
                    val en = notifObj.getBoolean("bedtimeReminderNotifEnabled")
                    SaffahNotificationManager.setBedtimeReminderNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("bedtimeModWindowNotifEnabled")) {
                    val en = notifObj.getBoolean("bedtimeModWindowNotifEnabled")
                    SaffahNotificationManager.setBedtimeModWindowNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("usageLimitNotifEnabled")) {
                    val en = notifObj.getBoolean("usageLimitNotifEnabled")
                    SaffahNotificationManager.setUsageLimitNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("launchCountNotifEnabled")) {
                    val en = notifObj.getBoolean("launchCountNotifEnabled")
                    SaffahNotificationManager.setLaunchCountNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("recordStreakNotifEnabled")) {
                    val en = notifObj.getBoolean("recordStreakNotifEnabled")
                    SaffahNotificationManager.setRecordStreakNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("dopamineReceptorNotifEnabled")) {
                    val en = notifObj.getBoolean("dopamineReceptorNotifEnabled")
                    SaffahNotificationManager.setDopamineReceptorNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("curiosityRadarNotifEnabled")) {
                    val en = notifObj.getBoolean("curiosityRadarNotifEnabled")
                    SaffahNotificationManager.setCuriosityRadarNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("newTerrainNotifEnabled")) {
                    val en = notifObj.getBoolean("newTerrainNotifEnabled")
                    SaffahNotificationManager.setNewTerrainNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("contentBlockNotifEnabled")) {
                    val en = notifObj.getBoolean("contentBlockNotifEnabled")
                    SaffahNotificationManager.setContentBlockNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("modificationWindowNotifEnabled")) {
                    val en = notifObj.getBoolean("modificationWindowNotifEnabled")
                    SaffahNotificationManager.setModificationWindowNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("scheduledBlockNotifEnabled")) {
                    val en = notifObj.getBoolean("scheduledBlockNotifEnabled")
                    SaffahNotificationManager.setScheduledBlockNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("productivityGoalNotifEnabled")) {
                    val en = notifObj.getBoolean("productivityGoalNotifEnabled")
                    SaffahNotificationManager.setProductivityGoalNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("dailyBlockHarvestNotifEnabled")) {
                    val en = notifObj.getBoolean("dailyBlockHarvestNotifEnabled")
                    SaffahNotificationManager.setDailyBlockHarvestNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
                if (notifObj.has("timeDelayNotifEnabled")) {
                    val en = notifObj.getBoolean("timeDelayNotifEnabled")
                    SaffahNotificationManager.setTimeDelayNotifEnabled(context, en)
                    if (en) restoredNotifsCount++
                }
            }

            // 11. Restore Security Restrictions
            var restoredSecurityCount = 0
            val securityObj = root.optJSONObject("securityRestrictions")
            if (securityObj != null) {
                if (securityObj.has("disallowSafeBoot")) {
                    val en = securityObj.getBoolean("disallowSafeBoot")
                    SaffahProtectionManager.applySafeBootRestriction(context, en)
                    if (en) restoredSecurityCount++
                }
                if (securityObj.has("disallowConfigDateTime")) {
                    val en = securityObj.getBoolean("disallowConfigDateTime")
                    SaffahProtectionManager.applyConfigDateTimeRestriction(context, en)
                    if (en) restoredSecurityCount++
                }
                if (securityObj.has("disallowConfigPrivateDns")) {
                    val en = securityObj.getBoolean("disallowConfigPrivateDns")
                    SaffahProtectionManager.applyConfigPrivateDnsRestriction(context, en)
                    if (en) restoredSecurityCount++
                }
                if (securityObj.has("disallowDebuggingFeatures")) {
                    val en = securityObj.getBoolean("disallowDebuggingFeatures")
                    SaffahProtectionManager.applyDebuggingFeaturesRestriction(context, en)
                    if (en) restoredSecurityCount++
                }
                SaffahProtectionManager.applyDeviceOwnerRestrictions(context)
            }

            // 12. Restore App Preferences
            val appPrefsObj = root.optJSONObject("appPreferences")
            if (appPrefsObj != null && appPrefsObj.has("darkMode")) {
                context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("dark_mode", appPrefsObj.getBoolean("darkMode"))
                    .apply()
            }

            // 13. Restore Block Logs
            var restoredLogsCount = 0
            val blockLogsArray = root.optJSONArray("blockLogs")
            if (blockLogsArray != null) {
                val logsList = mutableListOf<BlockLogEntry>()
                for (i in 0 until blockLogsArray.length()) {
                    val obj = blockLogsArray.getJSONObject(i)
                    logsList.add(
                        BlockLogEntry(
                            id = obj.optLong("id", System.currentTimeMillis() - i * 1000L),
                            blockedItem = obj.optString("blockedItem", ""),
                            type = obj.optString("type", "كلمة محظورة"),
                            timestamp = obj.optString("timestamp", ""),
                            sourceApp = obj.optString("sourceApp", "")
                        )
                    )
                }
                if (logsList.isNotEmpty()) {
                    SaffahBlockRepository.saveBlockLogs(context, logsList.filter { it.blockedItem.isNotBlank() })
                    restoredLogsCount = logsList.size
                }
            }

            // 14. Restore Recovery Center Data & Text Diaries
            var restoredDiariesCount = 0
            if (root.has("recoveryCenter")) {
                try {
                    val rObj = root.getJSONObject("recoveryCenter")
                    val recPrefs = context.getSharedPreferences("saffah_recovery_prefs", Context.MODE_PRIVATE)
                    val editor = recPrefs.edit()
                    if (rObj.has("stats")) {
                        val st = rObj.getJSONObject("stats")
                        editor.putLong("recovery_start_timestamp", st.optLong("startTimestamp", System.currentTimeMillis()))
                        editor.putLong("recovery_first_ever_start_timestamp", st.optLong("firstEverStartTimestamp", System.currentTimeMillis()))
                        editor.putInt("recovery_relapse_count", st.optInt("relapseCount", 0))
                        editor.putLong("recovery_longest_streak_seconds", st.optLong("longestStreakSeconds", 0L))
                        if (st.has("userName") && st.getString("userName").isNotBlank()) {
                            editor.putString("recovery_user_name", st.getString("userName"))
                        }
                    }
                    if (rObj.has("relapseHistory")) {
                        editor.putString("recovery_relapse_history_json", rObj.getJSONArray("relapseHistory").toString())
                    }
                    if (rObj.has("urgeHistory")) {
                        editor.putString("recovery_urge_history_json", rObj.getJSONArray("urgeHistory").toString())
                    }
                    if (rObj.has("customTechniques")) {
                        editor.putString("recovery_custom_defense_techniques_json", rObj.getJSONArray("customTechniques").toString())
                    }
                    if (rObj.has("customTriggers")) {
                        editor.putString("recovery_custom_triggers_json", rObj.getJSONArray("customTriggers").toString())
                    }
                    if (rObj.has("dopamineBio")) {
                        editor.putString("recovery_dopamine_bio_json", rObj.getJSONArray("dopamineBio").toString())
                    }
                    if (rObj.has("dailyBaseline")) {
                        editor.putString("recovery_daily_baseline_json", rObj.getJSONArray("dailyBaseline").toString())
                    }
                    if (rObj.has("pledge")) {
                        editor.putString("recovery_pledge_document_json", rObj.getJSONObject("pledge").toString())
                    }
                    editor.apply()

                    // Restore Active Diaries
                    if (rObj.has("activeDiaries")) {
                        val dArray = rObj.getJSONArray("activeDiaries")
                        val diaryList = mutableListOf<RecoveryDiaryEntry>()
                        for (i in 0 until dArray.length()) {
                            val dObj = dArray.getJSONObject(i)
                            val mediaArray = dObj.optJSONArray("mediaList") ?: JSONArray()
                            val mediaList = mutableListOf<DiaryMediaItem>()
                            for (j in 0 until mediaArray.length()) {
                                val mObj = mediaArray.getJSONObject(j)
                                val type = try { DiaryMediaType.valueOf(mObj.getString("type")) } catch (_: Exception) { DiaryMediaType.IMAGE }
                                val source = try { DiaryMediaSource.valueOf(mObj.getString("source")) } catch (_: Exception) { DiaryMediaSource.UPLOADED_FROM_STORAGE }
                                mediaList.add(
                                    DiaryMediaItem(
                                        id = mObj.getString("id"),
                                        type = type,
                                        source = source,
                                        filePath = mObj.getString("filePath"),
                                        fileName = mObj.optString("fileName", ""),
                                        durationSeconds = mObj.optInt("durationSeconds", 0),
                                        fileSizeBytes = mObj.optLong("fileSizeBytes", 0L),
                                        createdAt = mObj.optLong("createdAt", System.currentTimeMillis())
                                    )
                                )
                            }
                            val emArray = dObj.optJSONArray("emotions") ?: JSONArray()
                            val emotions = mutableListOf<String>()
                            for (k in 0 until emArray.length()) emotions.add(emArray.getString(k))

                            diaryList.add(
                                RecoveryDiaryEntry(
                                    id = dObj.getString("id"),
                                    title = dObj.optString("title", ""),
                                    content = dObj.optString("content", ""),
                                    createdAt = dObj.optLong("createdAt", System.currentTimeMillis()),
                                    updatedAt = dObj.optLong("updatedAt", System.currentTimeMillis()),
                                    mediaList = mediaList,
                                    emotions = emotions,
                                    type = dObj.optString("type", "ملاحظة").ifBlank { "ملاحظة" }
                                )
                            )
                        }
                        if (diaryList.isNotEmpty()) {
                            SaffahDiaryRepository.restoreAllEntries(context, diaryList)
                            restoredDiariesCount = diaryList.size
                        }
                    }

                    // Restore Trash Diaries
                    if (rObj.has("trashDiaries")) {
                        val tArray = rObj.getJSONArray("trashDiaries")
                        val trashList = mutableListOf<RecoveryDiaryEntry>()
                        for (i in 0 until tArray.length()) {
                            val dObj = tArray.getJSONObject(i)
                            val mediaArray = dObj.optJSONArray("mediaList") ?: JSONArray()
                            val mediaList = mutableListOf<DiaryMediaItem>()
                            for (j in 0 until mediaArray.length()) {
                                val mObj = mediaArray.getJSONObject(j)
                                val type = try { DiaryMediaType.valueOf(mObj.getString("type")) } catch (_: Exception) { DiaryMediaType.IMAGE }
                                val source = try { DiaryMediaSource.valueOf(mObj.getString("source")) } catch (_: Exception) { DiaryMediaSource.UPLOADED_FROM_STORAGE }
                                mediaList.add(
                                    DiaryMediaItem(
                                        id = mObj.getString("id"),
                                        type = type,
                                        source = source,
                                        filePath = mObj.getString("filePath"),
                                        fileName = mObj.optString("fileName", ""),
                                        durationSeconds = mObj.optInt("durationSeconds", 0),
                                        fileSizeBytes = mObj.optLong("fileSizeBytes", 0L),
                                        createdAt = mObj.optLong("createdAt", System.currentTimeMillis())
                                    )
                                )
                            }
                            val emArray = dObj.optJSONArray("emotions") ?: JSONArray()
                            val emotions = mutableListOf<String>()
                            for (k in 0 until emArray.length()) emotions.add(emArray.getString(k))

                            trashList.add(
                                RecoveryDiaryEntry(
                                    id = dObj.getString("id"),
                                    title = dObj.optString("title", ""),
                                    content = dObj.optString("content", ""),
                                    createdAt = dObj.optLong("createdAt", System.currentTimeMillis()),
                                    updatedAt = dObj.optLong("updatedAt", System.currentTimeMillis()),
                                    mediaList = mediaList,
                                    emotions = emotions,
                                    type = dObj.optString("type", "ملاحظة").ifBlank { "ملاحظة" }
                                )
                            )
                        }
                        if (trashList.isNotEmpty()) {
                            SaffahDiaryRepository.restoreTrashEntries(context, trashList)
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error restoring recoveryCenter from JSON: ${e.message}")
                }
            }

            // Apply newly restored rules immediately across device policy / suspension
            SaffahBlockRepository.applyPackageSuspensionIfNeeded(context)

            val backupDate = root.optString("backupDate", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
            val timestamp = root.optLong("timestamp", System.currentTimeMillis())
            val deviceModel = root.optString("deviceModel", "")

            val metadata = BackupMetadata(
                backupDate = backupDate,
                timestamp = timestamp,
                keywordsCount = keywordsList.size,
                sitesCount = sitesList.size,
                permanentBlockedCount = permanentCount,
                usageRulesCount = usageCount,
                scheduleRulesCount = scheduleCount,
                blockLogsCount = restoredLogsCount,
                vpnExcludedCount = restoredVpnExcludedCount,
                uninstallBlockedCount = restoredUninstallBlockedCount,
                keywordExemptedCount = restoredKeywordExemptedCount,
                contentFiltersCount = restoredContentFiltersCount,
                securityRestrictionsCount = restoredSecurityCount,
                notificationsCount = restoredNotifsCount,
                diariesCount = restoredDiariesCount,
                isBedtimeConfigured = isBedtimeRestored,
                isProductivityConfigured = isProductivityRestored,
                isPenaltyConfigured = isPenaltyConfigured,
                isUrgeRuleConfigured = isUrgeRuleConfigured,
                isQrKeyConfigured = isQrKeyConfigured,
                isPrivacyPinConfigured = isPrivacyPinConfigured,
                deviceModel = deviceModel,
                appVersion = "2.0"
            )

            // Cache snapshot in backup prefs for fast in-memory restores
            getPrefs(context).edit()
                .putLong(KEY_LAST_BACKUP_TIME, timestamp)
                .putString(KEY_LAST_BACKUP_DATE_STR, backupDate)
                .putString(KEY_LAST_BACKUP_JSON, jsonStr)
                .apply()

            Result.success(metadata)
        } catch (e: Exception) {
            Log.e(TAG, "Error restoring backup from JSON: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Gets a live summary of rules and backup status for the UI.
     */
    fun getBackupSummary(context: Context): BackupSummary {
        val keywords = SaffahBlockRepository.getBlockedKeywords(context)
        val sites = SaffahBlockRepository.getBlockedSites(context)
        val permanent = SaffahBlockRepository.getPermanentBlockedPackages(context)
        val usage = SaffahBlockRepository.getUsageRules(context)
        val schedule = SaffahBlockRepository.getAppScheduleRules(context)
        val blockLogs = SaffahBlockRepository.getBlockLogs(context)
        val vpnExcluded = SaffahBlockRepository.getExcludedVpnApps(context)
        val uninstallBlocked = SaffahBlockRepository.getUninstallBlockedPackages(context)
        val keywordExempted = SaffahBlockRepository.getKeywordExemptedApps(context)
        val bedtimeEnabled = SaffahBlockRepository.isBedtimeModeEnabled(context)
        val bedtimeSched = SaffahBlockRepository.getBedtimeSchedule(context)
        val prodRule = SaffahBlockRepository.getProductivityRule(context)
        val isProdConfigured = prodRule != null && prodRule.isEnabled

        var activeContentFilters = 0
        if (SaffahBlockRepository.isTelegramSearchBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isWhatsAppChannelsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isYouTubeShortsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isFacebookLiteReelsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isInstagramReelsBlocked(context)) activeContentFilters++
        if (SaffahBlockRepository.isBlockUnsupportedBrowsers(context)) activeContentFilters++
        if (SaffahBlockRepository.isBlockInAppBrowsers(context)) activeContentFilters++
        if (SaffahBlockRepository.isHideVpnNotification(context)) activeContentFilters++

        var activeSecurityRestrictions = 0
        if (SaffahProtectionManager.isDisallowSafeBootEnabled(context)) activeSecurityRestrictions++
        if (SaffahProtectionManager.isDisallowConfigDateTimeEnabled(context)) activeSecurityRestrictions++
        if (SaffahProtectionManager.isDisallowConfigPrivateDnsEnabled(context)) activeSecurityRestrictions++
        if (SaffahProtectionManager.isDisallowDebuggingFeaturesEnabled(context)) activeSecurityRestrictions++

        var activeNotifications = 0
        if (SaffahNotificationManager.isCleanDayNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isMapMilestoneNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDopamineSurveyNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDangerWindowNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isBedtimeReminderNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isBedtimeModWindowNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isUsageLimitNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isLaunchCountNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isRecordStreakNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDopamineReceptorNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isCuriosityRadarNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isNewTerrainNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isContentBlockNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isModificationWindowNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isScheduledBlockNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isProductivityGoalNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isDailyBlockHarvestNotifEnabled(context)) activeNotifications++
        if (SaffahNotificationManager.isTimeDelayNotifEnabled(context)) activeNotifications++

        val diaries = SaffahDiaryRepository.getAllEntries(context)
        val qrConfig = SaffahQrKeyManager.getQrKeyConfig(context)

        val bedtimeSummaryText = if (bedtimeEnabled) {
            val startStr = "%02d:%02d".format(Locale.US, bedtimeSched.first.first, bedtimeSched.first.second)
            val endStr = "%02d:%02d".format(Locale.US, bedtimeSched.second.first, bedtimeSched.second.second)
            "مفعل ($startStr - $endStr)"
        } else {
            "غير مفعّل"
        }

        val prodSummaryText = if (isProdConfigured) {
            "${prodRule?.targetApps?.size ?: 0} تطبيق محدد"
        } else {
            "غير مفعّل"
        }

        val prefs = getPrefs(context)
        val lastTimestamp = prefs.getLong(KEY_LAST_BACKUP_TIME, 0L)
        val lastFormatted = prefs.getString(KEY_LAST_BACKUP_DATE_STR, null)

        val total = keywords.size + sites.size + permanent.size + usage.size + schedule.size +
                vpnExcluded.size + uninstallBlocked.size + keywordExempted.size +
                activeContentFilters + activeSecurityRestrictions +
                (if (bedtimeEnabled) 1 else 0) + (if (isProdConfigured) 1 else 0) +
                (if (SaffahPenaltyManager.isPenaltyFeatureEnabled(context)) 1 else 0) +
                (if (SaffahUrgeManager.isUrgeFeatureEnabled(context)) 1 else 0) +
                (if (qrConfig.isEnabled) 1 else 0)

        return BackupSummary(
            lastBackupFormatted = lastFormatted,
            lastBackupTimestamp = lastTimestamp,
            keywordsCount = keywords.size,
            sitesCount = sites.size,
            permanentBlockedCount = permanent.size,
            usageRulesCount = usage.size,
            scheduleRulesCount = schedule.size,
            blockLogsCount = blockLogs.size,
            vpnExcludedCount = vpnExcluded.size,
            uninstallBlockedCount = uninstallBlocked.size,
            keywordExemptedCount = keywordExempted.size,
            contentFiltersCount = activeContentFilters,
            securityRestrictionsCount = activeSecurityRestrictions,
            notificationsCount = activeNotifications,
            diariesCount = diaries.size,
            isBedtimeConfigured = bedtimeEnabled,
            bedtimeSummaryText = bedtimeSummaryText,
            isProductivityConfigured = isProdConfigured,
            productivitySummaryText = prodSummaryText,
            isPenaltyConfigured = SaffahPenaltyManager.isPenaltyFeatureEnabled(context),
            isUrgeRuleConfigured = SaffahUrgeManager.isUrgeFeatureEnabled(context),
            isQrKeyConfigured = qrConfig.isEnabled,
            isPrivacyPinConfigured = SaffahPrivacyManager.isPinConfigured(context),
            totalRulesCount = total
        )
    }

    /**
     * Exports backup to a document URI on the device storage.
     */
    fun exportBackupToUri(context: Context, uri: Uri): Result<Int> {
        return try {
            val json = generateBackupJson(context)
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                outputStream.write(json.toByteArray(Charsets.UTF_8))
                outputStream.flush()
            } ?: return Result.failure(Exception("تعذر فتح ملف الوجهة للكتابة على الهاتف"))

            val now = System.currentTimeMillis()
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val formattedDate = sdf.format(Date(now))

            getPrefs(context).edit()
                .putLong(KEY_LAST_BACKUP_TIME, now)
                .putString(KEY_LAST_BACKUP_DATE_STR, formattedDate)
                .putString(KEY_LAST_BACKUP_JSON, json)
                .apply()

            val summary = getBackupSummary(context)
            Result.success(summary.totalRulesCount)
        } catch (e: Exception) {
            Log.e(TAG, "Error exporting backup to storage: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Imports and restores backup from a document URI on the device storage.
     */
    fun importBackupFromUri(context: Context, uri: Uri): Result<BackupMetadata> {
        return try {
            val inStream = context.contentResolver.openInputStream(uri)
                ?: return Result.failure(Exception("تعذر قراءة ملف النسخة الاحتياطية من الهاتف"))

            val bufferedIn = java.io.BufferedInputStream(inStream, 65536)
            bufferedIn.mark(8)
            val header = ByteArray(4)
            val readLen = bufferedIn.read(header)
            bufferedIn.reset()

            val isZip = readLen == 4 &&
                    header[0] == 0x50.toByte() &&
                    header[1] == 0x4B.toByte() &&
                    header[2] == 0x03.toByte() &&
                    header[3] == 0x04.toByte()

            if (isZip) {
                val recoveryRes = SaffahRecoveryBackupManager.importRecoveryFullBackup(context, uri)
                if (recoveryRes.isSuccess) {
                    val res = recoveryRes.getOrThrow()
                    val now = System.currentTimeMillis()
                    val dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(now))
                    return Result.success(
                        BackupMetadata(
                            backupDate = dateFormatted,
                            timestamp = now,
                            keywordsCount = 0,
                            sitesCount = 0,
                            permanentBlockedCount = 0,
                            usageRulesCount = 0,
                            scheduleRulesCount = 0,
                            blockLogsCount = 0,
                            vpnExcludedCount = 0,
                            uninstallBlockedCount = 0,
                            keywordExemptedCount = 0,
                            contentFiltersCount = 0,
                            securityRestrictionsCount = 0,
                            notificationsCount = 0,
                            diariesCount = res.diariesRestored,
                            isBedtimeConfigured = false,
                            isProductivityConfigured = false,
                            isPenaltyConfigured = false,
                            isUrgeRuleConfigured = false,
                            isQrKeyConfigured = false,
                            isPrivacyPinConfigured = false,
                            deviceModel = "Recovery Full Backup Archive",
                            appVersion = "2.0"
                        )
                    )
                } else {
                    return Result.failure(recoveryRes.exceptionOrNull() ?: Exception("فشلت استعادة ملف الحزمة."))
                }
            }

            val stringBuilder = java.lang.StringBuilder()
            BufferedReader(InputStreamReader(bufferedIn, Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                while (line != null) {
                    stringBuilder.append(line).append("\n")
                    line = reader.readLine()
                }
            }

            val jsonContent = stringBuilder.toString().trim()
            if (jsonContent.isEmpty()) {
                return Result.failure(Exception("ملف النسخة الاحتياطية فارغ"))
            }

            restoreBackupFromJson(context, jsonContent)
        } catch (e: Exception) {
            Log.e(TAG, "Error importing backup from storage: ${e.message}", e)
            Result.failure(e)
        }
    }
}
