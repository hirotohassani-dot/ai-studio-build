package com.example.util

import ai.onnxruntime.OrtEnvironment
import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Singleton wrapper around AnimeRatingDetector managing lifecycle, configuration persistence,
 * and live debug state for the settings/debug panel.
 */
object SaffahAnimeClassifier {
    private const val TAG = "SaffahAnimeClassifier"
    private const val MODEL_NAME = "mobilenetv3_sce_dist.onnx"

    private var detector: AnimeRatingDetector? = null
    private var ortEnv: OrtEnvironment? = null
    private val isInitializing = AtomicBoolean(false)
    private val lock = Any()

    data class LiveDebugState(
        val probs: List<FloatArray> = emptyList(), // per window [safe, r15, r18]
        val windowCount: Int = 0,
        val inferenceMs: Long = 0L,
        val historyCount: Int = 0,
        val historyTotal: Int = 0,
        val framePositive: Boolean = false,
        val trigger: Boolean = false,
        val timestamp: Long = 0L
    )

    private val _debugState = MutableStateFlow(LiveDebugState())
    val debugState: StateFlow<LiveDebugState> = _debugState.asStateFlow()

    fun initialize(context: Context): Boolean {
        synchronized(lock) {
            if (detector != null) return true
        }
        if (isInitializing.getAndSet(true)) return false
        try {
            val env = OrtEnvironment.getEnvironment()
            val modelBytes = context.assets.open(MODEL_NAME).use { it.readBytes() }
            val cfg = SaffahBlockRepository.getAnimeConfig(context)
            synchronized(lock) {
                ortEnv = env
                detector = AnimeRatingDetector(env, modelBytes, cfg)
            }
            Log.i(TAG, "AnimeRatingDetector initialized successfully with modelBytes=${modelBytes.size}")
            return true
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to initialize AnimeRatingDetector: ${e.message}", e)
            return false
        } finally {
            isInitializing.set(false)
        }
    }

    fun isReady(): Boolean = synchronized(lock) { detector != null }
    fun getDetector(): AnimeRatingDetector? = synchronized(lock) { detector }

    fun updateConfig(newCfg: AnimeCfg) {
        synchronized(lock) {
            val d = detector ?: return
            d.cfg.tR18 = newCfg.tR18
            d.cfg.tR15 = newCfg.tR15
            d.cfg.tSum = newCfg.tSum
            d.cfg.confirm = newCfg.confirm
            d.cfg.minLumaStd = newCfg.minLumaStd
            d.cfg.maxWindows = newCfg.maxWindows
        }
    }

    fun clearHistory() {
        synchronized(lock) {
            detector?.clearHistory()
        }
    }

    fun process(bmp: Bitmap, nowMs: Long): AnimeRatingDetector.Out? {
        val d = synchronized(lock) { detector } ?: return null
        val out = d.process(bmp, nowMs)
        if (out != null) {
            _debugState.value = LiveDebugState(
                probs = out.probs,
                windowCount = out.probs.size,
                inferenceMs = out.ms,
                historyCount = d.getHistoryCount(),
                historyTotal = d.getHistoryTotal(),
                framePositive = out.framePositive,
                trigger = out.trigger,
                timestamp = nowMs
            )
        }
        return out
    }

    fun close() {
        synchronized(lock) {
            try {
                detector?.close()
                ortEnv?.close()
            } catch (_: Exception) {}
            detector = null
            ortEnv = null
        }
    }
}
