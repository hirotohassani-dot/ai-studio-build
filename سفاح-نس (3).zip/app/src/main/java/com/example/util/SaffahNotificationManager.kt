package com.example.util

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.model.BiomeType
import com.example.model.BlockLogEntry
import com.example.model.DopamineReceptorDataProvider
import com.example.model.DopamineReceptorMilestone
import com.example.model.UsageLimitType
import com.example.receiver.SaffahDeviceAdminReceiver
import com.example.receiver.SaffahNotificationReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object SaffahNotificationManager {

    private const val TAG = "SaffahNotifManager"
    private const val PREFS_NAME = "saffah_notifications_prefs"

    // Action Constants for Broadcasts & Navigation
    const val ACTION_DOPAMINE_SURVEY_ALARM = "com.example.ACTION_NOTIFICATION_DOPAMINE_SURVEY"
    const val ACTION_CLEAN_DAY_ALARM = "com.example.ACTION_NOTIFICATION_CLEAN_DAY_CHECK"
    const val ACTION_DANGER_WINDOW_ALARM = "com.example.ACTION_NOTIFICATION_DANGER_WINDOW"
    const val ACTION_BEDTIME_REMINDER_ALARM = "com.example.ACTION_NOTIFICATION_BEDTIME_REMINDER"
    const val ACTION_BEDTIME_MOD_WINDOW_ALARM = "com.example.ACTION_NOTIFICATION_BEDTIME_MOD_WINDOW"
    const val ACTION_MODIFICATION_WINDOW_ALARM = "com.example.ACTION_NOTIFICATION_MOD_WINDOW"
    const val ACTION_SCHEDULED_BLOCK_ALARM = "com.example.ACTION_NOTIFICATION_SCHEDULED_BLOCK"
    const val ACTION_DAILY_BLOCK_HARVEST_ALARM = "com.example.ACTION_NOTIFICATION_DAILY_BLOCK_HARVEST"
    const val ACTION_TIME_DELAY_EXPIRATION_ALARM = "com.example.ACTION_NOTIFICATION_TIME_DELAY_EXPIRATION"

    const val EXTRA_NAV_DESTINATION = "EXTRA_NAV_DESTINATION"
    const val NAV_DEST_RECOVERY_COUNTER = "RECOVERY_COUNTER"
    const val NAV_DEST_RECOVERY_MAP = "RECOVERY_MAP"
    const val NAV_DEST_DOPAMINE_SURVEY = "DOPAMINE_SURVEY"
    const val NAV_DEST_BLOCK_LOGS = "BLOCK_LOGS"
    const val NAV_DEST_BEDTIME = "BEDTIME"
    const val NAV_DEST_USAGE_RULES = "USAGE_RULES"
    const val NAV_DEST_BLOCK_RULES = "BLOCK_RULES"
    const val NAV_DEST_PROTECTION = "PROTECTION"
    const val NAV_DEST_URGE_SESSION = "URGE_SESSION"

    // Channels
    const val CHANNEL_CLEAN_DAY = "saffah_clean_day_channel"
    const val CHANNEL_MAP_MILESTONE = "saffah_map_milestone_channel"
    const val CHANNEL_DOPAMINE_SURVEY = "saffah_dopamine_survey_channel"
    const val CHANNEL_DANGER_WINDOW = "saffah_danger_window_channel"
    const val CHANNEL_BEDTIME = "saffah_bedtime_channel"
    const val CHANNEL_BEDTIME_MOD_WINDOW = "saffah_bedtime_mod_window_channel"
    const val CHANNEL_USAGE_LIMIT = "saffah_usage_limit_channel"
    const val CHANNEL_RECORD_STREAK = "saffah_record_streak_channel"
    const val CHANNEL_DOPAMINE_RECEPTOR = "saffah_dopamine_receptor_channel"
    const val CHANNEL_CURIOSITY_RADAR = "saffah_curiosity_radar_channel"
    const val CHANNEL_NEW_TERRAIN = "saffah_new_terrain_channel"
    const val CHANNEL_CONTENT_BLOCK = "saffah_content_block_channel"
    const val CHANNEL_MODIFICATION_WINDOW = "saffah_modification_window_channel"
    const val CHANNEL_SCHEDULED_BLOCK = "saffah_scheduled_block_channel"
    const val CHANNEL_PRODUCTIVITY_GOAL = "saffah_productivity_goal_channel"
    const val CHANNEL_DAILY_BLOCK_HARVEST = "saffah_daily_block_harvest_channel"
    const val CHANNEL_TIME_DELAY = "saffah_time_delay_channel"
    const val CHANNEL_URGE_SUPPRESSION = "saffah_urge_suppression_channel"

    // Notification IDs
    const val NOTIF_ID_CLEAN_DAY = 2001
    const val NOTIF_ID_MAP_MILESTONE = 2002
    const val NOTIF_ID_DOPAMINE_SURVEY = 2003
    const val NOTIF_ID_DANGER_WINDOW = 2004
    const val NOTIF_ID_BEDTIME_PRE = 2005
    const val NOTIF_ID_BEDTIME_START = 2006
    const val NOTIF_ID_BEDTIME_MOD_WINDOW = 2007
    const val NOTIF_ID_USAGE_LIMIT_80 = 2010
    const val NOTIF_ID_USAGE_LIMIT_100 = 2020
    const val NOTIF_ID_LAUNCH_COUNT_LIMIT = 2030
    const val NOTIF_ID_RECORD_BREAKING_STREAK = 2040
    const val NOTIF_ID_DOPAMINE_RECEPTOR = 2050
    const val NOTIF_ID_CURIOSITY_RADAR = 2060
    const val NOTIF_ID_NEW_TERRAIN = 2070
    const val NOTIF_ID_CONTENT_BLOCK = 2080
    const val NOTIF_ID_MODIFICATION_WINDOW = 2090
    const val NOTIF_ID_SCHEDULED_BLOCK_ACTIVE = 2100
    const val NOTIF_ID_SCHEDULED_BLOCK_COMPLETE = 2101
    const val NOTIF_ID_DAILY_BLOCK_HARVEST = 2110
    const val NOTIF_ID_PRODUCTIVITY_GOAL_BASE = 2120
    const val NOTIF_ID_TIME_DELAY_EXPIRATION = 2130
    const val NOTIF_ID_URGE_SUPPRESSION = 2140

    // Preference Keys
    private const val KEY_CLEAN_DAY_ENABLED = "notif_clean_day_enabled"
    private const val KEY_MAP_MILESTONE_ENABLED = "notif_map_milestone_enabled"
    private const val KEY_DOPAMINE_SURVEY_ENABLED = "notif_dopamine_survey_enabled"
    private const val KEY_DOPAMINE_HOUR = "notif_dopamine_hour"
    private const val KEY_DOPAMINE_MINUTE = "notif_dopamine_minute"

    private const val KEY_DANGER_WINDOW_ENABLED = "notif_danger_window_enabled"
    private const val KEY_BEDTIME_REMINDER_ENABLED = "notif_bedtime_reminder_enabled"
    private const val KEY_BEDTIME_MOD_WINDOW_NOTIF_ENABLED = "notif_bedtime_mod_window_enabled"
    private const val KEY_USAGE_LIMIT_NOTIF_ENABLED = "notif_usage_limit_enabled"
    private const val KEY_LAUNCH_COUNT_NOTIF_ENABLED = "notif_launch_count_enabled"
    private const val KEY_RECORD_STREAK_NOTIF_ENABLED = "notif_record_streak_enabled"
    private const val KEY_DOPAMINE_RECEPTOR_ENABLED = "notif_dopamine_receptor_enabled"
    private const val KEY_CURIOSITY_RADAR_ENABLED = "notif_curiosity_radar_enabled"
    private const val KEY_NEW_TERRAIN_NOTIF_ENABLED = "notif_new_terrain_enabled"
    private const val KEY_CONTENT_BLOCK_NOTIF_ENABLED = "notif_content_block_enabled"
    private const val KEY_MODIFICATION_WINDOW_NOTIF_ENABLED = "notif_modification_window_enabled"
    private const val KEY_LAST_NOTIFIED_MOD_WINDOW_DATE = "last_notified_mod_window_date"
    private const val KEY_SCHEDULED_BLOCK_NOTIF_ENABLED = "notif_scheduled_block_enabled"
    private const val KEY_SAVED_ACTIVE_SCHEDULE_SESSION = "saved_active_schedule_session"
    private const val KEY_PRODUCTIVITY_GOAL_NOTIF_ENABLED = "notif_productivity_goal_enabled"
    private const val KEY_DAILY_BLOCK_HARVEST_NOTIF_ENABLED = "notif_daily_block_harvest_enabled"
    private const val KEY_LAST_NOTIFIED_DAILY_BLOCK_HARVEST_DATE = "last_notified_daily_block_harvest_date"
    private const val KEY_TIME_DELAY_NOTIF_ENABLED = "notif_time_delay_expiration_enabled"
    private const val KEY_LAST_NOTIFIED_TIME_DELAY_TIMESTAMP = "last_notified_time_delay_timestamp"

    private const val KEY_BEDTIME_TIP_INDEX = "notif_bedtime_tip_index"
    private const val KEY_LAST_NOTIFIED_BEDTIME_PRE_DATE = "last_notified_bedtime_pre_date"
    private const val KEY_LAST_NOTIFIED_BEDTIME_START_DATE = "last_notified_bedtime_start_date"
    private const val KEY_LAST_NOTIFIED_BEDTIME_MOD_WINDOW_DATE = "last_notified_bedtime_mod_window_date"
    private const val KEY_LAST_NOTIFIED_DANGER_WINDOW_KEY = "last_notified_danger_window_key"

    private const val KEY_LAST_NOTIFIED_CLEAN_DAY = "last_notified_clean_day"
    private const val KEY_LAST_NOTIFIED_MAP_STATION = "last_notified_map_station"
    private const val KEY_LAST_NOTIFIED_DOPAMINE_DATE = "last_notified_dopamine_date"
    private const val KEY_LAST_NOTIFIED_RECORD_BREAKING_DAYS = "last_notified_record_breaking_days"
    private const val KEY_LAST_NOTIFIED_DOPAMINE_RECEPTOR_DAY = "last_notified_dopamine_receptor_day"
    private const val KEY_LAST_NOTIFIED_NEW_TERRAIN_DAY = "last_notified_new_terrain_day"

    private const val KEY_CURIOSITY_BURST_ITEMS = "curiosity_radar_burst_items"
    private const val KEY_CURIOSITY_LAST_ALERT_TIME = "curiosity_radar_last_alert_time"
    private const val CURIOSITY_WINDOW_MS = 5 * 60 * 1000L // 5 minutes
    private const val CURIOSITY_BURST_THRESHOLD = 3
    private const val CURIOSITY_ALERT_COOLDOWN_MS = 10 * 60 * 1000L // 10 minutes

    // Minimum blocked attempts threshold before danger window is statistically valid
    const val MIN_DANGER_LOGS_THRESHOLD = 8
    const val MIN_WINDOW_OCCURRENCE_THRESHOLD = 3

    private var lastEvaluationTimeMs = 0L

    // 30 Scientifically grounded, rotating sleep motivation messages
    val BEDTIME_MOTIVATION_TEXTS = listOf(
        "دراسات علم الأعصاب تؤكد: النوم العميق قبل منتصف الليل يضاعف إفراز هرمون النمو بنسبة 200%، وهو المسؤول الأول عن ترميم مستقبلات الدوبامين في الدماغ وإعادة بناء إرادتك.",
        "النوم ليس إهداراً للوقت بل هو ذروة الصيانة العصبية؛ أثناء النوم يبدأ الجهاز الغليمفاوي بتنظيف الدماغ وغسله من السموم المتراكمة طوال اليوم لتستيقظ بذهن نقي.",
        "وفقاً لأبحاث هارفارد، قلة النوم تؤدي إلى فرط نشاط اللوزة الدماغية وضعف قشرة الفص الجبهي، مما يرفع احتمالية الانتكاس والاندفاع العاطفي بنسبة تفوق 60%.",
        "الضوء الأزرق الصادر من الشاشات يثبط إفراز هرمون الميلاتونين بنسبة تصل إلى 80%. ترك الهاتف الآن يمنحك نوماً عميقاً وطاقة بدنية غير مسبوقة غداً.",
        "النوم المبكر المنتظم هو السلاح الأقوى لضبط هرموني الغريلين والليبتين؛ عندما تنام مبكراً تتحكم بشهيتك واستقرارك النفسي وتتخلص من التوتر المجهول.",
        "أعظم الناجحين يربحون يومهم من الليلة السابقة. الاستغراق في النوم الآن هو القرار الأكثر إنتاجية الذي تتخذه اليوم لتبدأ غداً بتركيز حديدي.",
        "مرحلة نوم حركة العين السريعة (REM) في أول ساعات الليل هي المختبر العصبي الذي يعيد معالجة الذكريات وتثبيت المهارات الجديدة والتخلص من الضغوط النفسية.",
        "ترك الهاتف 30 دقيقة قبل النوم يخفض مستويات الكورتيزول ويسمح لجهازك العصبي بالانتقال بسلاسة من حالة التأهب إلى نمط الاسترخاء والترميم الداخلي.",
        "كل ساعة نوم تحصل عليها قبل منتصف الليل تعادل ساعتين من النوم المتأخر في كفاءة إعادة شحن الجهاز العصبي المركزي ومناعة الجسم.",
        "استثمارك في النوم الآن يوفر عليك ساعات من التشتت والكسل غداً؛ النوم الجيد يرفع سرعة الاستجابة الذهنية والقدرة على حل المشكلات المعقدة.",
        "عندما تغلق هاتفك وتنام الآن، تمنح قلبك وأوعيتك الدموية فرصة لخفض ضغط الدم ومعدل النبض، مما يحمي صحتك القلبية ويمنحك هدوءاً مستداماً.",
        "العلم يثبت أن النوم العميق يعزز إنتاج السيتوكينات المناعية؛ مناعتك ضد الأمراض ومقاومتك للإرهاق تعتمد كلياً على جودة ساعات نومك الليلة.",
        "الاستيقاظ المبكر بطاقة كاملة لا يبدأ بالمنبه، بل بقرارك الحازم بإغلاق الشاشة الآن والذهاب إلى الفراش بحب وشغف للغد الأفضل.",
        "دراسات الدوبامين الحديثة توضح أن النوم الكافي يعيد حساسية مستقبلات D2، مما يجعلك تستمتع بأبسط تفاصيل الحياة دون الحاجة لمحفزات اصطناعية.",
        "النوم هو الحصن الذي تبنيه كل ليلة لحماية إنجازك في التعافي؛ العقل المستريح لا يقع فريسة للوساوس أو الاندفاعات المفاجئة.",
        "إذا أردت تركيزاً خارقاً في عملك ومهامك غداً، فأفضل ما تفعله الآن هو منح عقلك إجازة تامة وفصل الاتصال بكل الشاشات والمحادثات.",
        "التحكم بالنفس عضلة تستهلك طاقتها خلال اليوم، والنوم العميق هو الطريقة البيولوجية الوحيدة لإعادة تزويد هذه العضلة بأعلى درجات القوة.",
        "كل رسالة مؤجلة وكل تصفح غير ضروري يمكنه الانتظار للغد. صحتك الذهنية وراحة جهازك العصبي الليلة أولى بكل ثانية من وقتك.",
        "أظهرت الدراسات السريرية أن 8 ساعات من النوم المنتظم تحسن المزاج العام وتقلل مشاعر القلق والاكتئاب إلى النصف مقارنة بالنوم المتقطع.",
        "الشاشات تخدع الدماغ ليبدو في منتصف الظهيرة، إغلاق الشاشة هو إعلان صريح لجسدك بأن الأمان قد حل وحان وقت السكينة والسبات.",
        "قوة الشخصية ليست في مواصلة السهر بلا طائل، بل في القدرة على إيقاف كل المشتتات والالتزام بروتين النوم في وقته المحدد.",
        "تذكر: الصباح المشرق المليء بالإنجاز واليقظة هو الثمرة الطبيعية لنوم هادئ ومبكر يبدأ في هذه اللحظة بالذات.",
        "أثناء النوم العميق يقوم الدماغ بعملية فرز مدهشة، حيث يمحو الوصلات العصبية غير الضرورية ويقوي المسارات التي تدعم عاداتك الإيجابية.",
        "النوم المبكر ليس قيداً بل هو أقصى درجات العناية الذاتية والسيادة على وقتك وصحتك ومستقبلك.",
        "جهازك العصبي يستحق الراحة بعد ساعات طويلة من العمل والتركيز، دعه يرتاح الآن ليعود إليك غداً في أوج تألقه ونشاطه.",
        "دراسات الأداء الرياضي والذهني تثبت أن أفضل تعافٍ للجسد والعضلات والأعصاب يحدث في الثلث الأول من الليل أثناء إفراز هرمونات الترميم.",
        "أنت تبني مستقبلك وقوتك الذهنية في كل ليلة تختار فيها النوم على السهر الفارغ. فلتفخر بهذا الانضباط الراقي.",
        "النوم الجيد يحررك من التوتر الصباحي واللهاث وراء الوقت، يجعلك تبدأ يومك بهدوء وسكينة تملأ قلبك وعقلك.",
        "اترك هاتفك الآن بعيداً عن وسادتك، تنفس بعمق، واستشعر نعمة الهدوء والاسترخاء والتعافي الكامل لجسدك.",
        "اليوم ينتهي هنا بكل ما فيه، وغداً صفحة جديدة نقية تبدأ بنوم عميق ومريح. استمتع بسكون الليل ونم بسلام."
    )

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Creates all notification channels required for the app.
     */
    fun initChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

            // Channel 1: Clean Days
            val cleanDayChannel = NotificationChannel(
                CHANNEL_CLEAN_DAY,
                "إنجازات الأيام النظيفة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تهنئة وتكريم المتعافي عند إتمام أيام نظيفة جديدة"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 2: Map Milestones
            val mapChannel = NotificationChannel(
                CHANNEL_MAP_MILESTONE,
                "محطات خريطة التعافي",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات فتح محطات جديدة في خريطة الـ 105 محطة"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 3: Dopamine Survey
            val dopamineChannel = NotificationChannel(
                CHANNEL_DOPAMINE_SURVEY,
                "تذكير استبيان التوازن الدوباميني",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تذكير مسائي لتقييم المؤشرات الحيوية الأربعة (صفاء الذهن، المزاج، النوم، الطاقة)"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 4: Danger Window Warning
            val dangerWindowChannel = NotificationChannel(
                CHANNEL_DANGER_WINDOW,
                "تحذير نافذة الخطر الزمني",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار وقائي ذكي قبل موعد تكرار محاولات البحث المحظور إحصائياً"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 5: Bedtime & Sleep Reminders
            val bedtimeChannel = NotificationChannel(
                CHANNEL_BEDTIME,
                "الاستعداد لوقت النوم",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تذكيرات تحفيزية علمية قبل موعد النوم بـ 30 دقيقة وعند دخوله"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 6: Usage Limit Warnings
            val usageLimitChannel = NotificationChannel(
                CHANNEL_USAGE_LIMIT,
                "تنبيهات حدود استخدام التطبيقات",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات تحذيرية عند استهلاك 100% من الوقت أو بلوغ سقف مرات الفتح"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 7: Record Streak
            val recordStreakChannel = NotificationChannel(
                CHANNEL_RECORD_STREAK,
                "إنجاز كسر أطول سلسلة تعافٍ",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار احتفالي عند تحطيم وتجاوز أطول رقم قياسي حققته في رحلة التعافي"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 8: Dopamine Receptor Biological Changes
            val dopamineReceptorChannel = NotificationChannel(
                CHANNEL_DOPAMINE_RECEPTOR,
                "التغير الحيوي لمستقبلات الدوبامين",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات علمية رصينة تشرح مراحل استشفاء وترميم مستقبلات الدوبامين في الدماغ"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 9: Curiosity Radar
            val curiosityRadarChannel = NotificationChannel(
                CHANNEL_CURIOSITY_RADAR,
                "رادار الفضول المتصاعد الوقائي",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إنذار وقائي حاسم ينطلق عند رصد 3 محاولات بحث متقاربة حول كلمات أو مواقع حساسة في أقل من 5 دقائق"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 10: New Terrain Approaching Warning
            val newTerrainChannel = NotificationChannel(
                CHANNEL_NEW_TERRAIN,
                "إنذار دخول تضاريس جديدة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إنذار استباقي يُرسل قبل يوم من الانتقال لبيئة جديدة على خريطة التعافي"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 11: Content Block Alert
            val contentBlockChannel = NotificationChannel(
                CHANNEL_CONTENT_BLOCK,
                "إشعار حظر المحتوى الفوري",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار فوري عند حظر كلمة أو موقع محظور يتضمن اسم وأيقونة التطبيق وتحذيراً باسم السفَّاح"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 12: Modification Window Alert
            val modWindowChannel = NotificationChannel(
                CHANNEL_MODIFICATION_WINDOW,
                "التنبيه بدخول وقت السماح بالتعديل",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيه بدخول وقت السماح اليومي (06:00 - 07:00) لتعديل أو إلغاء قواعد الحظر وحدود الاستخدام"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 13: Scheduled Block Notifications
            val scheduledBlockChannel = NotificationChannel(
                CHANNEL_SCHEDULED_BLOCK,
                "تنبيه بدأ وانتهاء الحظر المجدول",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار مستمر بنطاق الحظر المجدول وعداً تنازلياً لوقت الانتهاء وإشعار عند رفعه"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 14: Productivity Goal Achievement
            val productivityGoalChannel = NotificationChannel(
                CHANNEL_PRODUCTIVITY_GOAL,
                "تحقيق الهدف اليومي للتطبيقات",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار تهنئة وتحفيز راقٍ عند إتمام الهدف اليومي المحدد للتطبيقات في نظام الإنتاجية والإنظباط"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 15: Daily Block Harvest Summary (21:00)
            val dailyBlockHarvestChannel = NotificationChannel(
                CHANNEL_DAILY_BLOCK_HARVEST,
                "حصاد الحظر اليومي",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ملخص دفاعي مساء كل يوم 21:00 يعرض محاولات البحث المحظورة المسقطة في الخلفية"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 16: Time Delay Expiration
            val timeDelayChannel = NotificationChannel(
                CHANNEL_TIME_DELAY,
                "انتهاء مدة التأخير الزمني",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيه عند انتهاء مدة التأخير الزمني ورفع قيود تأخير تعديل الإعدادات"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 17: Bedtime Modification Window
            val bedtimeModWindowChannel = NotificationChannel(
                CHANNEL_BEDTIME_MOD_WINDOW,
                "تنبيه ضبط وقت النوم (11:30)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيه تذكيري يومي عند 11:30 قبل الساعة 12:00 ظهراً بـ 30 دقيقة لضبط جدول وتطبيقات وضع النوم"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 18: Urge Suppression Technique Suggestion
            val urgeSuppressionChannel = NotificationChannel(
                CHANNEL_URGE_SUPPRESSION,
                "قاعدة الـ 15 دقيقة واقتراح التقنيات",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اقتراح فوري لأفضل التقنيات السلوكية المثبتة عند تفعيل زر الـ 15 دقيقة لدحر الرغبة"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            manager.createNotificationChannel(cleanDayChannel)
            manager.createNotificationChannel(mapChannel)
            manager.createNotificationChannel(dopamineChannel)
            manager.createNotificationChannel(dangerWindowChannel)
            manager.createNotificationChannel(bedtimeChannel)
            manager.createNotificationChannel(bedtimeModWindowChannel)
            manager.createNotificationChannel(usageLimitChannel)
            manager.createNotificationChannel(recordStreakChannel)
            manager.createNotificationChannel(dopamineReceptorChannel)
            manager.createNotificationChannel(curiosityRadarChannel)
            manager.createNotificationChannel(newTerrainChannel)
            manager.createNotificationChannel(contentBlockChannel)
            manager.createNotificationChannel(modWindowChannel)
            manager.createNotificationChannel(scheduledBlockChannel)
            manager.createNotificationChannel(productivityGoalChannel)
            manager.createNotificationChannel(dailyBlockHarvestChannel)
            manager.createNotificationChannel(timeDelayChannel)
            manager.createNotificationChannel(urgeSuppressionChannel)

            // Channel 19: Permanent Protection Guardian Service (Foreground Service)
            val guardianChannel = NotificationChannel(
                com.example.service.SaffahKeeperService.CHANNEL_ID,
                "درع حماية السفاح الدائم (Foreground Service)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إبقاء التطبيق نشطاً في الخلفية ومراقبة القيود بدون انقطاع"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(guardianChannel)

            // Channel 20: Saffah VPN Service
            val vpnChannel = NotificationChannel(
                com.example.service.SaffahVpnService.CHANNEL_ID,
                "درع السفاح - شبكة VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إبقاء اتصال VPN نشطاً لمراقبة وحجب حركة البيانات الضارة"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(vpnChannel)

            Log.i(TAG, "All notification channels initialized successfully")
        }
    }

    /**
     * Auto-grants POST_NOTIFICATIONS permission if app is Device Owner on Android 13+.
     */
    fun ensureNotificationPermissionGranted(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
                val admin = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
                if (dpm != null && dpm.isDeviceOwnerApp(context.packageName)) {
                    dpm.setPermissionGrantState(
                        admin,
                        context.packageName,
                        android.Manifest.permission.POST_NOTIFICATIONS,
                        DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not set POST_NOTIFICATIONS via DPM: ${e.message}")
            }
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    // --- Preferences Getters & Setters ---

    fun isCleanDayNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_CLEAN_DAY_ENABLED, true)
    }

    fun setCleanDayNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_CLEAN_DAY_ENABLED, enabled).apply()
        if (enabled) {
            evaluateAndTriggerCleanDayAndMapNotifications(context)
            scheduleAlarms(context)
        }
    }

    fun isMapMilestoneNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_MAP_MILESTONE_ENABLED, true)
    }

    fun setMapMilestoneNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_MAP_MILESTONE_ENABLED, enabled).apply()
        if (enabled) {
            evaluateAndTriggerCleanDayAndMapNotifications(context)
            scheduleAlarms(context)
        }
    }

    fun isDopamineSurveyNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_DOPAMINE_SURVEY_ENABLED, true)
    }

    fun setDopamineSurveyNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_DOPAMINE_SURVEY_ENABLED, enabled).apply()
        if (enabled) {
            scheduleAlarms(context)
        }
    }

    fun isDangerWindowNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_DANGER_WINDOW_ENABLED, true)
    }

    fun setDangerWindowNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_DANGER_WINDOW_ENABLED, enabled).apply()
        if (enabled) {
            scheduleDangerWindowAlarm(context)
        }
    }

    fun isBedtimeReminderNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_BEDTIME_REMINDER_ENABLED, true)
    }

    fun setBedtimeReminderNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_BEDTIME_REMINDER_ENABLED, enabled).apply()
        if (enabled) {
            scheduleBedtimeReminderAlarms(context)
        }
    }

    fun isBedtimeModWindowNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_BEDTIME_MOD_WINDOW_NOTIF_ENABLED, true)
    }

    fun setBedtimeModWindowNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_BEDTIME_MOD_WINDOW_NOTIF_ENABLED, enabled).apply()
        if (enabled) {
            scheduleBedtimeModWindowAlarm(context)
            evaluateAndTriggerBedtimeModWindowNotification(context)
        }
    }

    private fun getLastNotifiedBedtimeModWindowDate(context: Context): String {
        return getPrefs(context).getString(KEY_LAST_NOTIFIED_BEDTIME_MOD_WINDOW_DATE, "") ?: ""
    }

    private fun setLastNotifiedBedtimeModWindowDate(context: Context, date: String) {
        getPrefs(context).edit().putString(KEY_LAST_NOTIFIED_BEDTIME_MOD_WINDOW_DATE, date).apply()
    }

    fun isUsageLimitNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_USAGE_LIMIT_NOTIF_ENABLED, true)
    }

    fun setUsageLimitNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_USAGE_LIMIT_NOTIF_ENABLED, enabled).apply()
    }

    fun isLaunchCountNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_LAUNCH_COUNT_NOTIF_ENABLED, true)
    }

    fun setLaunchCountNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_LAUNCH_COUNT_NOTIF_ENABLED, enabled).apply()
    }

    fun isRecordStreakNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_RECORD_STREAK_NOTIF_ENABLED, true)
    }

    fun setRecordStreakNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_RECORD_STREAK_NOTIF_ENABLED, enabled).apply()
    }

    fun isDopamineReceptorNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_DOPAMINE_RECEPTOR_ENABLED, true)
    }

    fun setDopamineReceptorNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_DOPAMINE_RECEPTOR_ENABLED, enabled).apply()
    }

    fun isCuriosityRadarNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_CURIOSITY_RADAR_ENABLED, false)
    }

    fun setCuriosityRadarNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_CURIOSITY_RADAR_ENABLED, enabled).apply()
    }

    fun getLastNotifiedDopamineReceptorDay(context: Context): Int {
        return getPrefs(context).getInt(KEY_LAST_NOTIFIED_DOPAMINE_RECEPTOR_DAY, 0)
    }

    fun setLastNotifiedDopamineReceptorDay(context: Context, day: Int) {
        getPrefs(context).edit().putInt(KEY_LAST_NOTIFIED_DOPAMINE_RECEPTOR_DAY, day).apply()
    }

    fun isNewTerrainNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_NEW_TERRAIN_NOTIF_ENABLED, true)
    }

    fun setNewTerrainNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_NEW_TERRAIN_NOTIF_ENABLED, enabled).apply()
    }

    fun isContentBlockNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_CONTENT_BLOCK_NOTIF_ENABLED, true)
    }

    fun setContentBlockNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_CONTENT_BLOCK_NOTIF_ENABLED, enabled).apply()
    }

    fun getLastNotifiedNewTerrainDay(context: Context): Int {
        return getPrefs(context).getInt(KEY_LAST_NOTIFIED_NEW_TERRAIN_DAY, 0)
    }

    fun setLastNotifiedNewTerrainDay(context: Context, day: Int) {
        getPrefs(context).edit().putInt(KEY_LAST_NOTIFIED_NEW_TERRAIN_DAY, day).apply()
    }

    data class ActiveScheduleSession(
        val ruleId: Long,
        val ruleName: String,
        val startHour: Int,
        val startMinute: Int,
        val endHour: Int,
        val endMinute: Int,
        val startTimeMillis: Long,
        val endTimeMillis: Long
    ) {
        fun toStorageString(): String = "$ruleId|$ruleName|$startHour|$startMinute|$endHour|$endMinute|$startTimeMillis|$endTimeMillis"

        companion object {
            fun fromStorageString(str: String?): ActiveScheduleSession? {
                if (str.isNullOrBlank()) return null
                val parts = str.split("|")
                if (parts.size < 8) return null
                return try {
                    ActiveScheduleSession(
                        ruleId = parts[0].toLong(),
                        ruleName = parts[1],
                        startHour = parts[2].toInt(),
                        startMinute = parts[3].toInt(),
                        endHour = parts[4].toInt(),
                        endMinute = parts[5].toInt(),
                        startTimeMillis = parts[6].toLong(),
                        endTimeMillis = parts[7].toLong()
                    )
                } catch (_: Throwable) {
                    null
                }
            }
        }
    }

    fun isModificationWindowNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_MODIFICATION_WINDOW_NOTIF_ENABLED, true)
    }

    fun setModificationWindowNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_MODIFICATION_WINDOW_NOTIF_ENABLED, enabled).apply()
        if (enabled) {
            scheduleModificationWindowAlarm(context)
        }
    }

    private fun getLastNotifiedModWindowDate(context: Context): String {
        return getPrefs(context).getString(KEY_LAST_NOTIFIED_MOD_WINDOW_DATE, "") ?: ""
    }

    private fun setLastNotifiedModWindowDate(context: Context, date: String) {
        getPrefs(context).edit().putString(KEY_LAST_NOTIFIED_MOD_WINDOW_DATE, date).apply()
    }

    fun isScheduledBlockNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_SCHEDULED_BLOCK_NOTIF_ENABLED, true)
    }

    fun setScheduledBlockNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SCHEDULED_BLOCK_NOTIF_ENABLED, enabled).apply()
        if (enabled) {
            scheduleScheduledBlockAlarms(context)
        } else {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.cancel(NOTIF_ID_SCHEDULED_BLOCK_ACTIVE)
            clearSavedActiveScheduleSession(context)
        }
    }

    fun getSavedActiveScheduleSession(context: Context): ActiveScheduleSession? {
        val str = getPrefs(context).getString(KEY_SAVED_ACTIVE_SCHEDULE_SESSION, null)
        return ActiveScheduleSession.fromStorageString(str)
    }

    fun saveActiveScheduleSession(context: Context, session: ActiveScheduleSession) {
        getPrefs(context).edit().putString(KEY_SAVED_ACTIVE_SCHEDULE_SESSION, session.toStorageString()).apply()
    }

    fun clearSavedActiveScheduleSession(context: Context) {
        getPrefs(context).edit().remove(KEY_SAVED_ACTIVE_SCHEDULE_SESSION).apply()
    }

    fun isProductivityGoalNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_PRODUCTIVITY_GOAL_NOTIF_ENABLED, true)
    }

    fun setProductivityGoalNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_PRODUCTIVITY_GOAL_NOTIF_ENABLED, enabled).apply()
    }

    fun isDailyBlockHarvestNotifEnabled(context: Context): Boolean {
        return false // Permanently cancelled per user request
    }

    fun setDailyBlockHarvestNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_DAILY_BLOCK_HARVEST_NOTIF_ENABLED, false).apply()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_DAILY_BLOCK_HARVEST_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            3010,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager?.cancel(pendingIntent)
            pendingIntent.cancel()
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.cancel(NOTIF_ID_DAILY_BLOCK_HARVEST)
    }

    fun getLastNotifiedDailyBlockHarvestDate(context: Context): String {
        return getPrefs(context).getString(KEY_LAST_NOTIFIED_DAILY_BLOCK_HARVEST_DATE, "") ?: ""
    }

    fun setLastNotifiedDailyBlockHarvestDate(context: Context, date: String) {
        getPrefs(context).edit().putString(KEY_LAST_NOTIFIED_DAILY_BLOCK_HARVEST_DATE, date).apply()
    }

    fun isTimeDelayNotifEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_TIME_DELAY_NOTIF_ENABLED, true)
    }

    fun setTimeDelayNotifEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_TIME_DELAY_NOTIF_ENABLED, enabled).apply()
        if (enabled) {
            scheduleTimeDelayExpirationAlarm(context)
        } else {
            cancelTimeDelayExpirationAlarm(context)
        }
    }

    fun getLastNotifiedTimeDelayTimestamp(context: Context): Long {
        return getPrefs(context).getLong(KEY_LAST_NOTIFIED_TIME_DELAY_TIMESTAMP, 0L)
    }

    fun setLastNotifiedTimeDelayTimestamp(context: Context, timestamp: Long) {
        getPrefs(context).edit().putLong(KEY_LAST_NOTIFIED_TIME_DELAY_TIMESTAMP, timestamp).apply()
    }

    fun getDopamineSurveyTime(context: Context): Pair<Int, Int> {
        val prefs = getPrefs(context)
        val h = prefs.getInt(KEY_DOPAMINE_HOUR, 22)
        val m = prefs.getInt(KEY_DOPAMINE_MINUTE, 0)
        return Pair(h, m)
    }

    fun setDopamineSurveyTime(context: Context, hour: Int, minute: Int) {
        getPrefs(context).edit()
            .putInt(KEY_DOPAMINE_HOUR, hour.coerceIn(0, 23))
            .putInt(KEY_DOPAMINE_MINUTE, minute.coerceIn(0, 59))
            .apply()
        scheduleAlarms(context)
    }

    fun getLastNotifiedCleanDay(context: Context): Int {
        return getPrefs(context).getInt(KEY_LAST_NOTIFIED_CLEAN_DAY, 0)
    }

    fun setLastNotifiedCleanDay(context: Context, day: Int) {
        getPrefs(context).edit().putInt(KEY_LAST_NOTIFIED_CLEAN_DAY, day).apply()
    }

    fun getLastNotifiedMapStation(context: Context): Int {
        return getPrefs(context).getInt(KEY_LAST_NOTIFIED_MAP_STATION, 0)
    }

    fun setLastNotifiedMapStation(context: Context, station: Int) {
        getPrefs(context).edit().putInt(KEY_LAST_NOTIFIED_MAP_STATION, station).apply()
    }

    fun getLastNotifiedDopamineDate(context: Context): String {
        return getPrefs(context).getString(KEY_LAST_NOTIFIED_DOPAMINE_DATE, "") ?: ""
    }

    fun setLastNotifiedDopamineDate(context: Context, date: String) {
        getPrefs(context).edit().putString(KEY_LAST_NOTIFIED_DOPAMINE_DATE, date).apply()
    }

    fun getNextBedtimeTip(context: Context): String {
        val prefs = getPrefs(context)
        val currentIndex = prefs.getInt(KEY_BEDTIME_TIP_INDEX, 0)
        val tip = BEDTIME_MOTIVATION_TEXTS[currentIndex % BEDTIME_MOTIVATION_TEXTS.size]
        val nextIndex = (currentIndex + 1) % BEDTIME_MOTIVATION_TEXTS.size
        prefs.edit().putInt(KEY_BEDTIME_TIP_INDEX, nextIndex).apply()
        return tip
    }

    fun getCurrentBedtimeTipPreview(context: Context): String {
        val prefs = getPrefs(context)
        val currentIndex = prefs.getInt(KEY_BEDTIME_TIP_INDEX, 0)
        return BEDTIME_MOTIVATION_TEXTS[currentIndex % BEDTIME_MOTIVATION_TEXTS.size]
    }

    // --- Statistical Danger Window Analysis ---

    data class DangerWindowAnalysis(
        val hasSufficientData: Boolean,
        val totalRelevantLogs: Int,
        val topDayOfWeek: Int, // Calendar.DAY_OF_WEEK (1 = Sunday ... 7 = Saturday)
        val topDayArabicName: String,
        val topHour: Int, // 0..23
        val attemptsInWindow: Int,
        val percentageOfTotal: Int
    )

    fun getDayArabicName(dayOfWeek: Int): String {
        return when (dayOfWeek) {
            Calendar.SUNDAY -> "الأحد"
            Calendar.MONDAY -> "الاثنين"
            Calendar.TUESDAY -> "الثلاثاء"
            Calendar.WEDNESDAY -> "الأربعاء"
            Calendar.THURSDAY -> "الخميس"
            Calendar.FRIDAY -> "الجمعة"
            Calendar.SATURDAY -> "السبت"
            else -> ""
        }
    }

    private fun parseLogTimestampToCalendar(entry: BlockLogEntry): Calendar? {
        val cal = Calendar.getInstance()
        if (entry.id > 1000000000000L) {
            cal.timeInMillis = entry.id
            return cal
        }
        val formats = arrayOf(
            "yyyy/MM/dd - HH:mm:ss",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy/MM/dd HH:mm:ss"
        )
        for (pattern in formats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.ENGLISH)
                val date = sdf.parse(entry.timestamp)
                if (date != null) {
                    cal.time = date
                    return cal
                }
            } catch (_: Exception) {}
        }
        return null
    }

    /**
     * Analyzes all keyword and website block logs to discover the peak recurring danger window (DayOfWeek + Hour).
     * Strictly requires a statistically sufficient volume of logs before declaring a danger window.
     */
    fun analyzeDangerWindow(context: Context): DangerWindowAnalysis {
        val allLogs = SaffahBlockRepository.getBlockLogs(context)
        // Filter strictly to blocked keywords and websites
        val relevantLogs = allLogs.filter { it.type.contains("كلمة") || it.type.contains("موقع") }

        if (relevantLogs.size < MIN_DANGER_LOGS_THRESHOLD) {
            return DangerWindowAnalysis(
                hasSufficientData = false,
                totalRelevantLogs = relevantLogs.size,
                topDayOfWeek = Calendar.TUESDAY,
                topDayArabicName = "الثلاثاء",
                topHour = 23,
                attemptsInWindow = 0,
                percentageOfTotal = 0
            )
        }

        // Pair<DayOfWeek, Hour> -> count
        val bucketCounts = mutableMapOf<Pair<Int, Int>, Int>()
        for (log in relevantLogs) {
            val cal = parseLogTimestampToCalendar(log) ?: continue
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val key = Pair(dayOfWeek, hour)
            bucketCounts[key] = (bucketCounts[key] ?: 0) + 1
        }

        if (bucketCounts.isEmpty()) {
            return DangerWindowAnalysis(
                hasSufficientData = false,
                totalRelevantLogs = relevantLogs.size,
                topDayOfWeek = Calendar.TUESDAY,
                topDayArabicName = "الثلاثاء",
                topHour = 23,
                attemptsInWindow = 0,
                percentageOfTotal = 0
            )
        }

        val maxEntry = bucketCounts.maxByOrNull { it.value }
        val maxCount = maxEntry?.value ?: 0

        // Requires at least MIN_WINDOW_OCCURRENCE_THRESHOLD in the specific hour
        if (maxCount < MIN_WINDOW_OCCURRENCE_THRESHOLD) {
            return DangerWindowAnalysis(
                hasSufficientData = false,
                totalRelevantLogs = relevantLogs.size,
                topDayOfWeek = maxEntry?.key?.first ?: Calendar.TUESDAY,
                topDayArabicName = getDayArabicName(maxEntry?.key?.first ?: Calendar.TUESDAY),
                topHour = maxEntry?.key?.second ?: 23,
                attemptsInWindow = maxCount,
                percentageOfTotal = if (relevantLogs.isNotEmpty()) (maxCount * 100) / relevantLogs.size else 0
            )
        }

        val topDay = maxEntry!!.key.first
        val topHour = maxEntry.key.second
        val percentage = (maxCount * 100) / relevantLogs.size

        return DangerWindowAnalysis(
            hasSufficientData = true,
            totalRelevantLogs = relevantLogs.size,
            topDayOfWeek = topDay,
            topDayArabicName = getDayArabicName(topDay),
            topHour = topHour,
            attemptsInWindow = maxCount,
            percentageOfTotal = percentage
        )
    }

    // --- Evaluators & Alarm Scheduling ---

    fun evaluateAllNotifications(context: Context) {
        val now = System.currentTimeMillis()
        if (now - lastEvaluationTimeMs < 15_000L) return
        lastEvaluationTimeMs = now

        evaluateAndTriggerCleanDayAndMapNotifications(context)
        evaluateAndTriggerDopamineSurveyNotification(context)
        evaluateAndTriggerDangerWindowNotification(context)
        evaluateAndTriggerBedtimeNotifications(context)
        evaluateAndTriggerBedtimeModWindowNotification(context)
        evaluateAndTriggerUsageAndLaunchNotifications(context)
        evaluateAndTriggerRecordBreakingStreakNotification(context)
        evaluateAndTriggerDopamineReceptorNotification(context)
        evaluateAndTriggerNewTerrainNotification(context)
        evaluateAndTriggerModificationWindowNotification(context)
        evaluateAndTriggerScheduledBlockNotifications(context)
        evaluateAndTriggerProductivityGoalNotifications(context)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager)?.cancel(NOTIF_ID_DAILY_BLOCK_HARVEST)
        evaluateAndTriggerTimeDelayExpirationNotification(context)
    }

    /**
     * Helper to get application user-friendly label.
     */
    fun getAppLabel(context: Context, packageName: String): String {
        if (packageName.isBlank()) return "تطبيق محمي"
        if (!packageName.contains('.') || packageName.contains(' ')) {
            return packageName
        }
        return try {
            val pm = context.packageManager
            val ai = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(ai).toString()
        } catch (_: Throwable) {
            AppListHelper.resolveAppLabelFast(context, packageName)
        }
    }

    /**
     * Evaluates daily usage duration and launch counts for all restricted apps under UsageBlockRule.
     * Triggers warning notification at 80% time, 100% time, and maximum launch count.
     */
    fun evaluateAndTriggerUsageAndLaunchNotifications(context: Context) {
        val rules = SaffahBlockRepository.getUsageRules(context).filter { it.isEnabled }
        if (rules.isEmpty()) return

        val todayDateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val prefs = getPrefs(context)

        for (rule in rules) {
            when (rule.limitType) {
                UsageLimitType.DURATION -> {
                    if (!isUsageLimitNotifEnabled(context)) continue
                    for (pkg in rule.selectedPackages) {
                        val canonical = pkg.trim().lowercase()
                        val consumedMillis = SaffahBlockRepository.getUsageRuleConsumedMillis(context, rule, pkg)
                        val limitMillis = rule.limitValue * 60_000L
                        if (limitMillis <= 0L) continue

                        val key80 = "last_notif_usage_80_${rule.id}_$canonical"
                        val key100 = "last_notif_usage_100_${rule.id}_$canonical"
                        val appLabel = getAppLabel(context, pkg)
                        val currentToken = "${todayDateKey}_${rule.limitValue}_${rule.limitType.name}"

                        // 100% Limit Check
                        if (consumedMillis >= limitMillis) {
                            val last100Token = prefs.getString(key100, "")
                            if (last100Token != currentToken) {
                                dispatchUsageLimitNotification(
                                    context = context,
                                    packageName = pkg,
                                    appName = appLabel,
                                    limitMinutes = rule.limitValue,
                                    percentage = 100,
                                    consumedMinutes = (consumedMillis / 60_000L).toInt()
                                )
                                prefs.edit().putString(key100, currentToken).apply()
                            }
                        }
                    }
                }
                UsageLimitType.LAUNCH_COUNT -> {
                    if (!isLaunchCountNotifEnabled(context)) continue
                    for (pkg in rule.selectedPackages) {
                        val canonical = pkg.trim().lowercase()
                        val consumedLaunches = SaffahBlockRepository.getUsageRuleConsumedLaunches(context, rule, pkg)
                        val limitLaunches = rule.limitValue
                        if (limitLaunches <= 0) continue

                        val keyLaunch = "last_notif_launch_${rule.id}_$canonical"
                        val appLabel = getAppLabel(context, pkg)
                        val currentToken = "${todayDateKey}_${rule.limitValue}_${rule.limitType.name}"
                        if (consumedLaunches >= limitLaunches) {
                            val lastLaunchToken = prefs.getString(keyLaunch, "")
                            if (lastLaunchToken != currentToken) {
                                dispatchLaunchCountLimitNotification(
                                    context = context,
                                    packageName = pkg,
                                    appName = appLabel,
                                    limitLaunches = limitLaunches,
                                    consumedLaunches = consumedLaunches
                                )
                                prefs.edit().putString(keyLaunch, currentToken).apply()
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Resets stored notification tokens when a rule's ceiling/limit is modified or raised.
     */
    fun resetUsageNotificationForRule(context: Context, ruleId: Long, packages: Collection<String>? = null) {
        try {
            val prefs = getPrefs(context)
            val editor = prefs.edit()
            val allKeys = prefs.all.keys.toList()
            for (k in allKeys) {
                if ((k.startsWith("last_notif_usage_") || k.startsWith("last_notif_launch_")) &&
                    (k.contains("_$ruleId") || k.contains("${ruleId}_"))
                ) {
                    editor.remove(k)
                }
            }
            packages?.forEach { pkg ->
                val canonical = pkg.trim().lowercase()
                editor.remove("last_notif_usage_generic_$canonical")
                editor.remove("last_notif_usage_generic_$pkg")
                editor.remove("last_notif_usage_100_${ruleId}_$canonical")
                editor.remove("last_notif_usage_100_${ruleId}_$pkg")
                editor.remove("last_notif_launch_${ruleId}_$canonical")
                editor.remove("last_notif_launch_${ruleId}_$pkg")
            }
            editor.apply()
            Log.i(TAG, "Reset usage notifications for rule $ruleId")
        } catch (e: Exception) {
            Log.e(TAG, "Error resetting usage notification for rule $ruleId: ${e.message}")
        }
    }

    /**
     * Immediately and in real-time dispatches the usage limit or launch count notification
     * when a package reaches its ceiling and is blocked.
     */
    fun notifyAppBlockedByUsageImmediately(context: Context, packageName: String) {
        if (packageName.isBlank()) return
        val canonical = packageName.trim().lowercase()
        val rules = SaffahBlockRepository.getUsageRules(context).filter { it.isEnabled }
        val matchingRules = rules.filter { r ->
            r.selectedPackages.any { it.trim().lowercase() == canonical || it.trim().equals(packageName, ignoreCase = true) }
        }

        val appLabel = getAppLabel(context, packageName)
        val todayDateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val prefs = getPrefs(context)

        if (matchingRules.isEmpty()) {
            // General usage limit reached fallback notification
            if (isUsageLimitNotifEnabled(context)) {
                val keyGeneric = "last_notif_usage_generic_$canonical"
                val lastDate = prefs.getString(keyGeneric, "")
                if (lastDate != todayDateKey) {
                    dispatchUsageLimitNotification(
                        context = context,
                        packageName = packageName,
                        appName = appLabel,
                        limitMinutes = 0,
                        percentage = 100,
                        consumedMinutes = 0
                    )
                    prefs.edit().putString(keyGeneric, todayDateKey).apply()
                }
            }
            return
        }

        for (rule in matchingRules) {
            val currentToken = "${todayDateKey}_${rule.limitValue}_${rule.limitType.name}"
            when (rule.limitType) {
                UsageLimitType.DURATION -> {
                    if (isUsageLimitNotifEnabled(context)) {
                        val key100 = "last_notif_usage_100_${rule.id}_$canonical"
                        val last100Token = prefs.getString(key100, "")
                        if (last100Token != currentToken) {
                            val consumedMillis = SaffahBlockRepository.getUsageRuleConsumedMillis(context, rule, packageName)
                            val consumedMinutes = maxOf(rule.limitValue, (consumedMillis / 60_000L).toInt())
                            dispatchUsageLimitNotification(
                                context = context,
                                packageName = packageName,
                                appName = appLabel,
                                limitMinutes = rule.limitValue,
                                percentage = 100,
                                consumedMinutes = consumedMinutes
                            )
                            prefs.edit().putString(key100, currentToken).apply()
                        }
                    }
                }
                UsageLimitType.LAUNCH_COUNT -> {
                    if (isLaunchCountNotifEnabled(context)) {
                        val keyLaunch = "last_notif_launch_${rule.id}_$canonical"
                        val lastLaunchToken = prefs.getString(keyLaunch, "")
                        if (lastLaunchToken != currentToken) {
                            val consumedLaunches = SaffahBlockRepository.getUsageRuleConsumedLaunches(context, rule, packageName)
                            dispatchLaunchCountLimitNotification(
                                context = context,
                                packageName = packageName,
                                appName = appLabel,
                                limitLaunches = rule.limitValue,
                                consumedLaunches = maxOf(rule.limitValue, consumedLaunches)
                            )
                            prefs.edit().putString(keyLaunch, currentToken).apply()
                        }
                    }
                }
            }
        }
    }

    /**
     * Checks if current recovery streak has exceeded the previous historical record.
     * Triggers immediately when user breaks their all-time longest streak.
     */
    fun evaluateAndTriggerRecordBreakingStreakNotification(context: Context) {
        if (!isRecordStreakNotifEnabled(context)) return

        val stats = SaffahRecoveryManager.getRecoveryStats(context)
        val startTimestamp = stats.startTimestamp
        if (startTimestamp <= 0L) return

        val now = System.currentTimeMillis()
        if (now < startTimestamp) return

        val currentCleanDays = ((now - startTimestamp) / 86400000L).toInt()
        if (currentCleanDays < 1) return

        val prevLongest = SaffahRecoveryManager.getPreviousLongestStreakDays(context)
        if (prevLongest > 0 && currentCleanDays > prevLongest) {
            val lastNotifiedDays = getPrefs(context).getInt(KEY_LAST_NOTIFIED_RECORD_BREAKING_DAYS, 0)
            if (currentCleanDays > lastNotifiedDays) {
                dispatchRecordBreakingStreakNotification(
                    context = context,
                    currentStreakDays = currentCleanDays,
                    previousLongestDays = prevLongest
                )
                getPrefs(context).edit().putInt(KEY_LAST_NOTIFIED_RECORD_BREAKING_DAYS, currentCleanDays).apply()
            }
        }
    }

    /**
     * Evaluates dopamine receptor biological changes based on recovery milestones.
     * Dispatches scientific notifications explaining neurobiological recovery when hitting key milestone days.
     */
    fun evaluateAndTriggerDopamineReceptorNotification(context: Context) {
        if (!isDopamineReceptorNotifEnabled(context)) return

        val stats = SaffahRecoveryManager.getRecoveryStats(context)
        val startTimestamp = stats.startTimestamp
        if (startTimestamp <= 0L) return

        val now = System.currentTimeMillis()
        if (now < startTimestamp) return

        val currentCleanDays = ((now - startTimestamp) / 86400000L).toInt()
        if (currentCleanDays < 1) return

        // Find the latest achieved milestone up to the current clean day
        val reachedMilestone = DopamineReceptorDataProvider.milestones
            .filter { it.day <= currentCleanDays }
            .maxByOrNull { it.day } ?: return

        val lastNotifiedDay = getLastNotifiedDopamineReceptorDay(context)
        if (reachedMilestone.day > lastNotifiedDay) {
            dispatchDopamineReceptorNotification(context, reachedMilestone)
            setLastNotifiedDopamineReceptorDay(context, reachedMilestone.day)
        }
    }

    /**
     * Preventive Escalating Curiosity Radar:
     * Triggers an immediate preventive warning when 3 blocked keywords/sites are detected in less than 5 minutes.
     */
    fun onCuriosityBlockEvent(context: Context, isWebsite: Boolean) {
        if (!isCuriosityRadarNotifEnabled(context)) return

        val prefs = getPrefs(context)
        val now = System.currentTimeMillis()

        val rawJson = prefs.getString(KEY_CURIOSITY_BURST_ITEMS, "[]") ?: "[]"
        val recentItems = mutableListOf<Pair<Long, Boolean>>()

        try {
            val arr = JSONArray(rawJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val t = obj.optLong("time", 0L)
                val w = obj.optBoolean("isWebsite", false)
                if (now - t in 0..CURIOSITY_WINDOW_MS) {
                    recentItems.add(Pair(t, w))
                }
            }
        } catch (_: Throwable) {}

        recentItems.add(Pair(now, isWebsite))

        // Save sliding window
        try {
            val newArr = JSONArray()
            for (item in recentItems) {
                val obj = JSONObject().apply {
                    put("time", item.first)
                    put("isWebsite", item.second)
                }
                newArr.put(obj)
            }
            prefs.edit().putString(KEY_CURIOSITY_BURST_ITEMS, newArr.toString()).apply()
        } catch (_: Throwable) {}

        // Check threshold: 3 attempts in < 5 minutes
        if (recentItems.size >= CURIOSITY_BURST_THRESHOLD) {
            val lastAlertTime = prefs.getLong(KEY_CURIOSITY_LAST_ALERT_TIME, 0L)
            if (now - lastAlertTime >= CURIOSITY_ALERT_COOLDOWN_MS) {
                val hasKeywords = recentItems.any { !it.second }
                val hasSites = recentItems.any { it.second }

                val targetPhrase = when {
                    hasKeywords && hasSites -> "كلمات ومواقع حساسة"
                    hasSites -> "مواقع حساسة"
                    else -> "كلمات حساسة"
                }

                dispatchCuriosityRadarNotification(context, targetPhrase)
                prefs.edit().putLong(KEY_CURIOSITY_LAST_ALERT_TIME, now).apply()
            }
        }
    }

    /**
     * Checks if a new clean day or a new map station has been achieved, and triggers notification.
     */
    fun evaluateAndTriggerCleanDayAndMapNotifications(context: Context) {
        val stats = SaffahRecoveryManager.getRecoveryStats(context)
        val startTimestamp = stats.startTimestamp
        if (startTimestamp <= 0L) return

        val now = System.currentTimeMillis()
        if (now < startTimestamp) return

        val currentCleanDays = ((now - startTimestamp) / 86400000L).toInt()

        // 1. Clean Day Notification
        if (isCleanDayNotifEnabled(context) && currentCleanDays >= 1) {
            val lastDay = getLastNotifiedCleanDay(context)
            if (currentCleanDays > lastDay) {
                dispatchCleanDayNotification(context, currentCleanDays)
                setLastNotifiedCleanDay(context, currentCleanDays)
            }
        }

        // 2. Map Milestone Notification
        if (isMapMilestoneNotifEnabled(context) && currentCleanDays >= 7) {
            val allMilestones = RecoveryJourneyDataProvider.getAllMilestones()
            val reachedMilestones = allMilestones.filter { it.day <= currentCleanDays }
            val highest = reachedMilestones.maxByOrNull { it.stationNumber }
            if (highest != null) {
                val lastStation = getLastNotifiedMapStation(context)
                if (highest.stationNumber > lastStation) {
                    dispatchMapMilestoneNotification(context, highest.stationNumber, highest.day)
                    setLastNotifiedMapStation(context, highest.stationNumber)
                }
            }
        }
    }

    /**
     * Checks if user is 1 day before entering a new map biome/terrain and triggers warning.
     */
    fun evaluateAndTriggerNewTerrainNotification(context: Context) {
        if (!isNewTerrainNotifEnabled(context)) return

        val stats = SaffahRecoveryManager.getRecoveryStats(context)
        val startTimestamp = stats.startTimestamp
        if (startTimestamp <= 0L) return

        val now = System.currentTimeMillis()
        if (now < startTimestamp) return

        val currentCleanDays = ((now - startTimestamp) / 86400000L).toInt()
        if (currentCleanDays < 1) return

        val biomes = BiomeType.entries
        for (i in 0 until biomes.size - 1) {
            val currentBiome = biomes[i]
            val nextBiome = biomes[i + 1]
            val transitionEveDay = nextBiome.dayStart - 1

            if (currentCleanDays == transitionEveDay) {
                val lastNotifiedDay = getLastNotifiedNewTerrainDay(context)
                if (currentCleanDays > lastNotifiedDay) {
                    dispatchNewTerrainNotification(
                        context = context,
                        currentBiome = currentBiome,
                        nextBiome = nextBiome
                    )
                    setLastNotifiedNewTerrainDay(context, currentCleanDays)
                }
                break
            }
        }
    }

    /**
     * Checks if current time is at or after evening survey time and survey hasn't been notified or filled today.
     */
    fun evaluateAndTriggerDopamineSurveyNotification(context: Context) {
        if (!isDopamineSurveyNotifEnabled(context)) return

        val (targetH, targetM) = getDopamineSurveyTime(context)
        val cal = Calendar.getInstance()
        val nowH = cal.get(Calendar.HOUR_OF_DAY)
        val nowM = cal.get(Calendar.MINUTE)

        val isTargetTimeOrLater = (nowH > targetH) || (nowH == targetH && nowM >= targetM)
        if (!isTargetTimeOrLater) return

        val todayDateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val lastDate = getLastNotifiedDopamineDate(context)
        if (lastDate == todayDateKey) return

        // If user already answered today's check-in, do not disturb
        val todayCheckIn = SaffahRecoveryManager.getTodayBaselineCheckIn(context)
        if (todayCheckIn != null) {
            setLastNotifiedDopamineDate(context, todayDateKey)
            return
        }

        dispatchDopamineSurveyNotification(context)
        setLastNotifiedDopamineDate(context, todayDateKey)
    }

    /**
     * Checks if current time falls within the pre-danger window (30-45 mins before the danger hour on that specific day)
     */
    fun evaluateAndTriggerDangerWindowNotification(context: Context) {
        if (!isDangerWindowNotifEnabled(context)) return

        val analysis = analyzeDangerWindow(context)
        if (!analysis.hasSufficientData) return

        val cal = Calendar.getInstance()
        val currentDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val currentHour = cal.get(Calendar.HOUR_OF_DAY)
        val currentMinute = cal.get(Calendar.MINUTE)

        if (currentDayOfWeek != analysis.topDayOfWeek) return

        // Danger window triggers 30 to 45 minutes prior to the danger hour
        val isWindowPrior = (currentHour == (analysis.topHour - 1 + 24) % 24 && currentMinute >= 15) ||
                (currentHour == analysis.topHour && currentMinute < 10)

        if (!isWindowPrior) return

        // Only once per week for this specific danger window occurrence
        val weekKey = SimpleDateFormat("yyyy-ww", Locale.US).format(cal.time) + "_day${analysis.topDayOfWeek}_h${analysis.topHour}"
        val lastKey = getPrefs(context).getString(KEY_LAST_NOTIFIED_DANGER_WINDOW_KEY, "")
        if (lastKey == weekKey) return

        dispatchDangerWindowNotification(context, analysis)
        getPrefs(context).edit().putString(KEY_LAST_NOTIFIED_DANGER_WINDOW_KEY, weekKey).apply()
    }

    /**
     * Checks bedtime start notification with zero-second precision.
     * (30-minute pre-bedtime notification has been cancelled and deleted per user request).
     */
    fun evaluateAndTriggerBedtimeNotifications(context: Context) {
        if (!isBedtimeReminderNotifEnabled(context)) return
        if (!SaffahBlockRepository.isBedtimeModeEnabled(context)) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        // Ensure 30-min pre-bedtime notification is completely dismissed
        manager?.cancel(NOTIF_ID_BEDTIME_PRE)

        // Bedtime Started Notification (Zero delay upon entering bedtime)
        val isBedtimeNow = SaffahBlockRepository.isCurrentlyBedtime(context)
        val todayDateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val lastStartDate = getPrefs(context).getString(KEY_LAST_NOTIFIED_BEDTIME_START_DATE, "")
        if (isBedtimeNow && lastStartDate != todayDateKey) {
            dispatchBedtimeStartedNotification(context)
            getPrefs(context).edit().putString(KEY_LAST_NOTIFIED_BEDTIME_START_DATE, todayDateKey).apply()
        }
    }

    /**
     * Safely schedules a zero-delay exact alarm using AlarmClockInfo to bypass Doze, with fallback.
     */
    private fun setAlarmSafely(alarmManager: AlarmManager, triggerAtMillis: Long, pendingIntent: PendingIntent) {
        if (triggerAtMillis <= System.currentTimeMillis()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerAtMillis, pendingIntent)
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
        } catch (se: SecurityException) {
            Log.w(TAG, "Exact alarm permission restricted, falling back: ${se.message}")
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                }
            } catch (fallbackEx: Exception) {
                Log.e(TAG, "Fallback alarm failed: ${fallbackEx.message}", fallbackEx)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scheduling alarm safely: ${e.message}", e)
        }
    }

    /**
     * Schedules Exact Alarms for all notification services.
     */
    fun scheduleAlarms(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        // 1. Dopamine Survey Alarm
        if (isDopamineSurveyNotifEnabled(context)) {
            val (targetH, targetM) = getDopamineSurveyTime(context)
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, targetH)
                set(Calendar.MINUTE, targetM)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
                action = ACTION_DOPAMINE_SURVEY_ALARM
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                3001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            setAlarmSafely(alarmManager, cal.timeInMillis, pendingIntent)
            Log.i(TAG, "Dopamine survey alarm scheduled at ${cal.time}")
        }

        // 2. Next Clean Day Alarm
        if (isCleanDayNotifEnabled(context) || isMapMilestoneNotifEnabled(context)) {
            val stats = SaffahRecoveryManager.getRecoveryStats(context)
            val start = stats.startTimestamp
            if (start > 0L) {
                val now = System.currentTimeMillis()
                val currentDays = ((now - start) / 86400000L).toInt()
                var targetDays = currentDays + 1
                var nextDayTargetMillis = start + targetDays * 86400000L
                while (nextDayTargetMillis <= now) {
                    targetDays++
                    nextDayTargetMillis = start + targetDays * 86400000L
                }

                val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
                    action = ACTION_CLEAN_DAY_ALARM
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    3002,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                setAlarmSafely(alarmManager, nextDayTargetMillis, pendingIntent)
                Log.i(TAG, "Next clean day alarm scheduled at ${Date(nextDayTargetMillis)}")
            }
        }

        // 3. Danger Window Alarm
        scheduleDangerWindowAlarm(context)

        // 4. Bedtime Reminders Alarms
        scheduleBedtimeReminderAlarms(context)

        // 4.1. Bedtime Modification Window Alarm (11:30 AM - 30m before 12:00)
        scheduleBedtimeModWindowAlarm(context)

        // 5. Modification Window Alarm
        scheduleModificationWindowAlarm(context)

        // 6. Scheduled Block Alarms
        scheduleScheduledBlockAlarms(context)

        // 7. Daily Block Harvest Alarm (Cancelled per user request)
        scheduleDailyBlockHarvestAlarm(context)

        // 8. Time Delay Expiration Alarm
        scheduleTimeDelayExpirationAlarm(context)
    }

    /**
     * Schedules weekly recurring alarm for the identified danger window (30 minutes prior to the peak hour).
     */
    fun scheduleDangerWindowAlarm(context: Context) {
        if (!isDangerWindowNotifEnabled(context)) return

        val analysis = analyzeDangerWindow(context)
        if (!analysis.hasSufficientData) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        // Calculate next occurrence: (topHour - 1):30
        var targetH = analysis.topHour - 1
        var targetM = 30
        if (targetH < 0) {
            targetH += 24
        }

        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, analysis.topDayOfWeek)
            set(Calendar.HOUR_OF_DAY, targetH)
            set(Calendar.MINUTE, targetM)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.WEEK_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_DANGER_WINDOW_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            3003,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        setAlarmSafely(alarmManager, cal.timeInMillis, pendingIntent)
        Log.i(TAG, "Danger window alarm scheduled for ${analysis.topDayArabicName} at ${cal.time}")
    }

    /**
     * Schedules Bedtime Exact Start Alarm with zero delay.
     * (Pre-bedtime 30-min alarm has been cancelled and deleted per user request).
     */
    fun scheduleBedtimeReminderAlarms(context: Context) {
        if (!isBedtimeReminderNotifEnabled(context)) return
        if (!SaffahBlockRepository.isBedtimeModeEnabled(context)) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val schedule = SaffahBlockRepository.getBedtimeSchedule(context)
        val startH = schedule.first.first
        val startM = schedule.first.second

        // Cancel old 30-min pre-bedtime alarm if exists
        val oldPreIntent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_BEDTIME_REMINDER_ALARM
        }
        val oldPrePendingIntent = PendingIntent.getBroadcast(
            context,
            3004,
            oldPreIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (oldPrePendingIntent != null) {
            alarmManager.cancel(oldPrePendingIntent)
            oldPrePendingIntent.cancel()
        }
        val notifManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        notifManager?.cancel(NOTIF_ID_BEDTIME_PRE)

        // Bedtime exact start alarm
        val startCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, startH)
            set(Calendar.MINUTE, startM)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val startIntent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_BEDTIME_REMINDER_ALARM
        }
        val startPendingIntent = PendingIntent.getBroadcast(
            context,
            3005,
            startIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        setAlarmSafely(alarmManager, startCal.timeInMillis, startPendingIntent)
        Log.i(TAG, "Bedtime start alarm scheduled for ${startCal.time}")
    }

    // --- Dispatches ---

    /**
     * Dispatch Clean Day Completion Notification
     */
    fun dispatchCleanDayNotification(context: Context, dayCompleted: Int, isTest: Boolean = false) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val rawName = SaffahRecoveryManager.getUserName(context)
        val name = if (rawName.isNotBlank()) rawName else "المتعافي"

        val title = "إتمام اليوم $dayCompleted بنجاح"
        val message = "أحسنت يا $name، أتممت اليوم $dayCompleted من التعافي والنقاء بنجاح."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_RECOVERY_COUNTER"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_RECOVERY_COUNTER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            2001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_CLEAN_DAY)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_CLEAN_DAY, notification)
        Log.i(TAG, "Clean day notification dispatched for day $dayCompleted")
    }

    /**
     * Dispatch Map Milestone Opened Notification
     */
    fun dispatchMapMilestoneNotification(context: Context, stationNumber: Int, day: Int, isTest: Boolean = false) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val milestone = RecoveryJourneyDataProvider.getMilestoneForDay(day)
        val title = "فتح المحطة $stationNumber: ${milestone.title}"
        val message = "بلغت المحطة $stationNumber (اليوم $day) في بيئة ${milestone.biome.arabicName}."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_RECOVERY_MAP"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_RECOVERY_MAP)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            2002,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_MAP_MILESTONE)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_MAP_MILESTONE, notification)
        Log.i(TAG, "Map milestone notification dispatched for station $stationNumber (Day $day)")
    }

    /**
     * Dispatch Dopamine Survey Reminder Notification
     */
    fun dispatchDopamineSurveyNotification(context: Context, isTest: Boolean = false) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "استبيان التوازن الدوباميني"
        val message = "حان وقت تقييم مؤشراتك اليومية: صفاء الذهن، المزاج، النوم، والطاقة."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_DOPAMINE_SURVEY"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_DOPAMINE_SURVEY)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            2003,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_DOPAMINE_SURVEY)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_DOPAMINE_SURVEY, notification)
        Log.i(TAG, "Dopamine survey notification dispatched")
    }

    /**
     * Dispatch Danger Window Notification
     */
    fun dispatchDangerWindowNotification(
        context: Context,
        analysis: DangerWindowAnalysis,
        isTest: Boolean = false
    ) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val formattedHour = String.format(Locale.US, "%02d:00", analysis.topHour)
        val title = "تحذير نافذة الخطر ($formattedHour)"
        val message = "هذا التوقيت يمثل ذروة محاولات الاندفاع السابقة، توخَّ الحذر وتجنب العزلة."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BLOCK_LOGS"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BLOCK_LOGS)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            2004,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_DANGER_WINDOW)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_DANGER_WINDOW, notification)
        Log.i(TAG, "Danger window notification dispatched for ${analysis.topDayArabicName} $formattedHour")
    }

    /**
     * Dispatch Pre-Bedtime Reminder Notification (30 mins before sleep time)
     */
    fun dispatchBedtimePreReminderNotification(context: Context, isTest: Boolean = false) {
        // Feature cancelled and deleted per user request
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.cancel(NOTIF_ID_BEDTIME_PRE)
    }

    /**
     * Dispatch Bedtime Started Notification (When bedtime begins)
     */
    fun dispatchBedtimeStartedNotification(context: Context, isTest: Boolean = false) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val schedule = SaffahBlockRepository.getBedtimeSchedule(context)
        val formattedEnd = String.format(Locale.US, "%02d:%02d", schedule.second.first, schedule.second.second)

        val title = "بدء وقت النوم"
        val message = "بدأ وقت النوم حتى $formattedEnd. تم تفعيل الحماية وتعليق التطبيقات المحددة."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BEDTIME"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BEDTIME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            2006,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_BEDTIME)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_BEDTIME_START, notification)
        Log.i(TAG, "Bedtime started notification dispatched")
    }

    /**
     * Helper to get application icon as Bitmap for rich notifications.
     */
    private fun getAppIconBitmap(context: Context, packageNameOrLabel: String): Bitmap? {
        if (packageNameOrLabel.isBlank()) return null
        return try {
            val raw = packageNameOrLabel.trim()
            val drawable = AppListHelper.resolveIconFast(context, raw)
                ?: try { context.packageManager.getApplicationIcon(raw) } catch (_: Throwable) { null }

            if (drawable == null) return null

            if (drawable is BitmapDrawable && drawable.bitmap != null && !drawable.bitmap.isRecycled) {
                drawable.bitmap
            } else {
                val density = context.resources.displayMetrics.density
                val w = (drawable.intrinsicWidth.takeIf { it > 0 } ?: (48 * density).toInt()).coerceIn(48, 192)
                val h = (drawable.intrinsicHeight.takeIf { it > 0 } ?: (48 * density).toInt()).coerceIn(48, 192)
                val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bitmap
            }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Dispatch Usage Limit Notification (100%)
     */
    fun dispatchUsageLimitNotification(
        context: Context,
        packageName: String,
        appName: String,
        limitMinutes: Int,
        percentage: Int = 100,
        consumedMinutes: Int = limitMinutes,
        isTest: Boolean = false
    ) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "استنفاد وقت الاستخدام: $appName"
        val message = "استهلكت كامل الوقت اليومي المسموح ($limitMinutes دقيقة) وتم تعليق التطبيق."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_USAGE_RULES"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_USAGE_RULES)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val notifId = NOTIF_ID_USAGE_LIMIT_100 + (packageName.hashCode() % 50).let { if (it < 0) -it else it }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_USAGE_LIMIT)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setColor(0xFFDC2626.toInt())
            .setContentIntent(pendingIntent)

        val appIcon = getAppIconBitmap(context, packageName)
        if (appIcon != null) {
            builder.setLargeIcon(appIcon)
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(notifId, builder.build())
        Log.i(TAG, "Usage limit notification (100%) dispatched for $appName ($packageName)")
    }

    /**
     * Dispatch Launch Count Limit Notification
     */
    fun dispatchLaunchCountLimitNotification(
        context: Context,
        packageName: String,
        appName: String,
        limitLaunches: Int,
        consumedLaunches: Int = limitLaunches,
        isTest: Boolean = false
    ) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "سقف مرات الفتح: $appName"
        val message = "بلغت الحد الأقصى لمرات فتح التطبيق ($limitLaunches مرة) وتم تعليقه لليوم."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_USAGE_RULES"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_USAGE_RULES)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val notifId = NOTIF_ID_LAUNCH_COUNT_LIMIT + (packageName.hashCode() % 50).let { if (it < 0) -it else it }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_USAGE_LIMIT)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setColor(0xFFDC2626.toInt())
            .setContentIntent(pendingIntent)

        val appIcon = getAppIconBitmap(context, packageName)
        if (appIcon != null) {
            builder.setLargeIcon(appIcon)
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(notifId, builder.build())
        Log.i(TAG, "Launch count limit notification dispatched for $appName ($packageName)")
    }

    /**
     * Dispatch Record-Breaking Streak Notification
     */
    fun dispatchRecordBreakingStreakNotification(
        context: Context,
        currentStreakDays: Int,
        previousLongestDays: Int,
        isTest: Boolean = false
    ) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "رقم قياسي جديد: $currentStreakDays يوماً"
        val message = "تجاوزت أطول سلسلة سابقة ($previousLongestDays يوماً) لتصل إلى $currentStreakDays يوماً من التعافي."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_RECOVERY_COUNTER"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_RECOVERY_COUNTER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_RECORD_BREAKING_STREAK,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_RECORD_STREAK)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setColor(0xFF10B981.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_RECORD_BREAKING_STREAK, notification)
        Log.i(TAG, "Record breaking streak notification dispatched ($currentStreakDays days > $previousLongestDays)")
    }

    /**
     * Dispatch Dopamine Receptor Biological Change Notification
     */
    fun dispatchDopamineReceptorNotification(
        context: Context,
        milestone: DopamineReceptorMilestone,
        isTest: Boolean = false
    ) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "استشفاء الدوبامين: اليوم ${milestone.day} (${milestone.phaseTitle})"
        val message = "${milestone.biologicalTitle}: ${milestone.biologicalChange}"
        val bigText = "${milestone.biologicalTitle}\n\n${milestone.biologicalChange}\n\nتوجيه علمي: ${milestone.practicalAdvice}"

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_RECOVERY_COUNTER"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_RECOVERY_COUNTER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_DOPAMINE_RECEPTOR,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_DOPAMINE_RECEPTOR)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_DOPAMINE_RECEPTOR, notification)
        Log.i(TAG, "Dopamine receptor milestone notification dispatched for day ${milestone.day}")
    }

    /**
     * Dispatch Escalating Curiosity Radar Notification
     */
    fun dispatchCuriosityRadarNotification(
        context: Context,
        targetType: String,
        isTest: Boolean = false
    ) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val rawName = SaffahRecoveryManager.getUserName(context)
        val displayName = if (rawName.isNotBlank()) rawName else "المتعافي"

        val title = "إنذار رادار الفضول"
        val message = "رُصدت محاولات بحث متقاربة حول $targetType. تراجع وحافظ على تركيزك يا $displayName."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BLOCK_LOGS"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BLOCK_LOGS)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_CURIOSITY_RADAR,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_CURIOSITY_RADAR)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_CURIOSITY_RADAR, notification)
        Log.i(TAG, "Curiosity radar notification dispatched ($targetType)")
    }

    /**
     * Dispatches pre-emptive New Terrain approaching notification 1 day before entry.
     */
    fun dispatchNewTerrainNotification(
        context: Context,
        currentBiome: BiomeType,
        nextBiome: BiomeType,
        isTest: Boolean = false
    ) {
        if (!isNewTerrainNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val rawName = SaffahRecoveryManager.getUserName(context)
        val displayName = if (rawName.isNotBlank()) rawName else "المتعافي"

        val title = "تضاريس جديدة: ${nextBiome.arabicName}"
        val message = "تستعد غداً لدخول منطقة '${nextBiome.arabicName}' (اليوم ${nextBiome.dayStart}). كن مستعداً يا $displayName."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_MAP"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_RECOVERY_MAP)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_NEW_TERRAIN,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_NEW_TERRAIN)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_NEW_TERRAIN, notification)
        Log.i(TAG, "New terrain approaching notification dispatched (Eve of day ${nextBiome.dayStart})")
    }

    /**
     * Dispatches immediate Content Block notification containing blocked item, app name, and app icon.
     */
    fun dispatchContentBlockNotification(
        context: Context,
        blockedItem: String,
        isWebsite: Boolean,
        sourceApp: String,
        isTest: Boolean = false
    ) {
        if (!isContentBlockNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val appName = getAppLabel(context, sourceApp)
        val appIcon = getAppIconBitmap(context, sourceApp)

        val title = if (isWebsite) {
            "تم حظر موقع محظور"
        } else {
            "تم حظر كلمة محظورة"
        }

        val message = "تم منع '$blockedItem' في $appName."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BLOCK_LOGS"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BLOCK_LOGS)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_CONTENT_BLOCK,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_CONTENT_BLOCK)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)

        if (appIcon != null) {
            builder.setLargeIcon(appIcon)
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_CONTENT_BLOCK, builder.build())
        Log.i(TAG, "Content block notification dispatched for '$blockedItem' in $sourceApp")
    }

    /**
     * Schedules daily alarm for the modification window (06:00 AM).
     */
    fun scheduleModificationWindowAlarm(context: Context) {
        if (!isModificationWindowNotifEnabled(context)) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 6)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_MODIFICATION_WINDOW_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            3006,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        setAlarmSafely(alarmManager, cal.timeInMillis, pendingIntent)
        Log.i(TAG, "Modification window alarm scheduled for ${cal.time}")
    }

    /**
     * Schedules alarms for the next upcoming start or end time across all enabled scheduled block rules.
     */
    fun scheduleScheduledBlockAlarms(context: Context) {
        if (!isScheduledBlockNotifEnabled(context)) return
        if (!SaffahBlockRepository.isAppScheduleMasterEnabled(context)) return

        val rules = SaffahBlockRepository.getAppScheduleRules(context).filter { it.isEnabled }
        if (rules.isEmpty()) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = System.currentTimeMillis()
        var nextTargetMillis = Long.MAX_VALUE

        val baseCal = Calendar.getInstance()
        for (dayOffset in 0..2) {
            val dayCal = (baseCal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, dayOffset) }
            val dayOfWeek = dayCal.get(Calendar.DAY_OF_WEEK)

            for (rule in rules) {
                if (!rule.activeDays.contains(dayOfWeek)) continue
                for (range in rule.getEffectiveTimeRanges()) {
                    val startCal = (dayCal.clone() as Calendar).apply {
                        set(Calendar.HOUR_OF_DAY, range.startHour)
                        set(Calendar.MINUTE, range.startMinute)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    val endCal = (dayCal.clone() as Calendar).apply {
                        set(Calendar.HOUR_OF_DAY, range.endHour)
                        set(Calendar.MINUTE, range.endMinute)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                        if (range.endHour * 60 + range.endMinute <= range.startHour * 60 + range.startMinute) {
                            add(Calendar.DAY_OF_YEAR, 1)
                        }
                    }

                    if (startCal.timeInMillis > now && startCal.timeInMillis < nextTargetMillis) {
                        nextTargetMillis = startCal.timeInMillis
                    }
                    if (endCal.timeInMillis > now && endCal.timeInMillis < nextTargetMillis) {
                        nextTargetMillis = endCal.timeInMillis
                    }
                }
            }
        }

        if (nextTargetMillis != Long.MAX_VALUE) {
            val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
                action = ACTION_SCHEDULED_BLOCK_ALARM
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                3007,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            setAlarmSafely(alarmManager, nextTargetMillis, pendingIntent)
            Log.i(TAG, "Scheduled block alarm scheduled for ${Date(nextTargetMillis)}")
        }
    }

    /**
     * Checks if current time is within modification window (06:00 - 07:00 AM) and triggers notification if not done today.
     */
    fun evaluateAndTriggerModificationWindowNotification(context: Context) {
        if (!isModificationWindowNotifEnabled(context)) return

        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        if (hour == 6) {
            val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            val lastNotifiedDate = getLastNotifiedModWindowDate(context)
            if (todayDate != lastNotifiedDate) {
                dispatchModificationWindowNotification(context, isTest = false)
                setLastNotifiedModWindowDate(context, todayDate)
            }
        }
    }

    /**
     * Dispatches notification for the daily modification window start.
     */
    fun dispatchModificationWindowNotification(context: Context, isTest: Boolean = false) {
        if (!isModificationWindowNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "نافذة السماح بالتعديل (06:00 - 07:00)"
        val message = "يمكنك الآن تعديل قواعد الحظر وحدود الاستخدام حتى الساعة 07:00."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BLOCK_RULES"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BLOCK_RULES)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_MODIFICATION_WINDOW,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_MODIFICATION_WINDOW)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_MODIFICATION_WINDOW, builder.build())
        Log.i(TAG, "Modification window notification dispatched (isTest=$isTest)")
    }

    /**
     * Schedules daily alarm for the bedtime modification window reminder (11:30 AM - 30 minutes before 12:00 PM).
     */
    fun scheduleBedtimeModWindowAlarm(context: Context) {
        if (!isBedtimeModWindowNotifEnabled(context)) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 11)
            set(Calendar.MINUTE, 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_BEDTIME_MOD_WINDOW_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            3014,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        setAlarmSafely(alarmManager, cal.timeInMillis, pendingIntent)
        Log.i(TAG, "Bedtime modification window reminder alarm scheduled for ${cal.time}")
    }

    /**
     * Checks if current time is 11:30 AM (30 minutes before 12:00 PM close) and triggers notification if not done today.
     */
    fun evaluateAndTriggerBedtimeModWindowNotification(context: Context) {
        if (!isBedtimeModWindowNotifEnabled(context)) return

        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        // Trigger at 11:30 AM (30 minutes before 12:00 PM bedtime modification window close)
        if (hour == 11 && minute >= 30) {
            val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            val lastNotifiedDate = getLastNotifiedBedtimeModWindowDate(context)
            if (todayDate != lastNotifiedDate) {
                dispatchBedtimeModWindowNotification(context, isTest = false)
                setLastNotifiedBedtimeModWindowDate(context, todayDate)
            }
        }
    }

    /**
     * Dispatches notification for the daily bedtime modification window reminder (30 minutes before 12:00 PM).
     */
    fun dispatchBedtimeModWindowNotification(context: Context, isTest: Boolean = false) {
        if (!isBedtimeModWindowNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "تنبيه ضبط وقت النوم (متبقي 30 دقيقة)"
        val message = "متبقي 30 دقيقة على إغلاق نافذة تعديل وقت النوم (تنتهي 12:00 ظهراً). اضبط الجدول والتطبيقات المسموحة الآن قبل القفل."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BEDTIME"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BEDTIME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_BEDTIME_MOD_WINDOW,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_BEDTIME_MOD_WINDOW)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_BEDTIME_MOD_WINDOW, builder.build())
        Log.i(TAG, "Bedtime modification window reminder notification dispatched (isTest=$isTest)")
    }

    /**
     * Finds currently active scheduled block rule session.
     */
    fun findCurrentActiveScheduleSession(context: Context): ActiveScheduleSession? {
        if (!SaffahBlockRepository.isAppScheduleMasterEnabled(context)) return null
        val rules = SaffahBlockRepository.getAppScheduleRules(context).filter { it.isEnabled }
        if (rules.isEmpty()) return null

        val cal = Calendar.getInstance()
        val todayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val yesterdayOfWeek = if (todayOfWeek == Calendar.SUNDAY) Calendar.SATURDAY else todayOfWeek - 1
        val nowMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val nowMillis = cal.timeInMillis

        for (rule in rules) {
            if (rule.activeDays.isEmpty()) continue
            val ranges = rule.getEffectiveTimeRanges()
            for (range in ranges) {
                val startMinutes = range.startHour * 60 + range.startMinute
                val endMinutes = range.endHour * 60 + range.endMinute

                var isActive = false
                var startMillis = 0L
                var endMillis = 0L

                if (startMinutes == endMinutes) {
                    // Full 24-hour block for today
                    if (rule.activeDays.contains(todayOfWeek)) {
                        isActive = true
                        val sCal = (cal.clone() as Calendar).apply {
                            set(Calendar.HOUR_OF_DAY, 0)
                            set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        val eCal = (cal.clone() as Calendar).apply {
                            set(Calendar.HOUR_OF_DAY, 23)
                            set(Calendar.MINUTE, 59)
                            set(Calendar.SECOND, 59)
                            set(Calendar.MILLISECOND, 999)
                        }
                        startMillis = sCal.timeInMillis
                        endMillis = eCal.timeInMillis
                    }
                } else if (startMinutes < endMinutes) {
                    // Normal daytime range, e.g. 09:00 to 17:00
                    if (rule.activeDays.contains(todayOfWeek) && nowMinutes in startMinutes until endMinutes) {
                        isActive = true
                        val sCal = (cal.clone() as Calendar).apply {
                            set(Calendar.HOUR_OF_DAY, range.startHour)
                            set(Calendar.MINUTE, range.startMinute)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        val eCal = (cal.clone() as Calendar).apply {
                            set(Calendar.HOUR_OF_DAY, range.endHour)
                            set(Calendar.MINUTE, range.endMinute)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        startMillis = sCal.timeInMillis
                        endMillis = eCal.timeInMillis
                    }
                } else {
                    // Overnight range, e.g. 22:00 to 06:00
                    if (nowMinutes >= startMinutes && rule.activeDays.contains(todayOfWeek)) {
                        isActive = true
                        val sCal = (cal.clone() as Calendar).apply {
                            set(Calendar.HOUR_OF_DAY, range.startHour)
                            set(Calendar.MINUTE, range.startMinute)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        val eCal = (cal.clone() as Calendar).apply {
                            add(Calendar.DAY_OF_YEAR, 1)
                            set(Calendar.HOUR_OF_DAY, range.endHour)
                            set(Calendar.MINUTE, range.endMinute)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        startMillis = sCal.timeInMillis
                        endMillis = eCal.timeInMillis
                    } else if (nowMinutes < endMinutes && rule.activeDays.contains(yesterdayOfWeek)) {
                        isActive = true
                        val sCal = (cal.clone() as Calendar).apply {
                            add(Calendar.DAY_OF_YEAR, -1)
                            set(Calendar.HOUR_OF_DAY, range.startHour)
                            set(Calendar.MINUTE, range.startMinute)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        val eCal = (cal.clone() as Calendar).apply {
                            set(Calendar.HOUR_OF_DAY, range.endHour)
                            set(Calendar.MINUTE, range.endMinute)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        startMillis = sCal.timeInMillis
                        endMillis = eCal.timeInMillis
                    }
                }

                if (isActive && endMillis > nowMillis) {
                    val displayName = if (rule.name.isNotBlank()) rule.name else "الحظر المجدول"
                    return ActiveScheduleSession(
                        ruleId = rule.id,
                        ruleName = displayName,
                        startHour = range.startHour,
                        startMinute = range.startMinute,
                        endHour = range.endHour,
                        endMinute = range.endMinute,
                        startTimeMillis = startMillis,
                        endTimeMillis = endMillis
                    )
                }
            }
        }
        return null
    }

    /**
     * Evaluates scheduled block status and dispatches ongoing active notification or completion notification.
     */
    fun evaluateAndTriggerScheduledBlockNotifications(context: Context) {
        if (!isScheduledBlockNotifEnabled(context)) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        val currentActive = findCurrentActiveScheduleSession(context)
        val savedActive = getSavedActiveScheduleSession(context)

        if (currentActive != null) {
            if (savedActive == null || savedActive.ruleId != currentActive.ruleId || savedActive.endTimeMillis != currentActive.endTimeMillis) {
                saveActiveScheduleSession(context, currentActive)
                dispatchScheduledBlockActiveNotification(context, currentActive, isTest = false)
            }
        } else {
            if (savedActive != null) {
                clearSavedActiveScheduleSession(context)
                manager?.cancel(NOTIF_ID_SCHEDULED_BLOCK_ACTIVE)

                val now = System.currentTimeMillis()
                if (now >= savedActive.endTimeMillis - 60_000L) {
                    dispatchScheduledBlockCompletedNotification(context, savedActive, isTest = false)
                }
            }
        }
    }

    /**
     * Dispatches ongoing, non-dismissible notification for active scheduled block with live countdown and 24H times.
     */
    fun dispatchScheduledBlockActiveNotification(
        context: Context,
        session: ActiveScheduleSession,
        isTest: Boolean = false
    ) {
        if (!isScheduledBlockNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val startStr = String.format(Locale.US, "%02d:%02d", session.startHour, session.startMinute)
        val endStr = String.format(Locale.US, "%02d:%02d", session.endHour, session.endMinute)

        val remainingMillis = (session.endTimeMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val totalMinutes = (remainingMillis / 60000L).coerceAtLeast(0L)
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        val remainingStr = if (h > 0) "$h س و $m د" else "$m دقيقة"

        val title = "بدء الحظر المجدول: ${session.ruleName}"
        val message = "فترة الحظر من $startStr إلى $endStr • المتبقي: $remainingStr"

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BLOCK_RULES"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BLOCK_RULES)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_SCHEDULED_BLOCK_ACTIVE,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_SCHEDULED_BLOCK)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setWhen(session.endTimeMillis)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true) // CRITICAL: Non-dismissible by user swipe until end
            .setAutoCancel(false)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_SCHEDULED_BLOCK_ACTIVE, builder.build())
        Log.i(TAG, "Scheduled block active notification dispatched for '${session.ruleName}' (isTest=$isTest)")
    }

    /**
     * Dispatches notification when scheduled block window ends and restrictions are lifted.
     */
    fun dispatchScheduledBlockCompletedNotification(
        context: Context,
        session: ActiveScheduleSession,
        isTest: Boolean = false
    ) {
        if (!isScheduledBlockNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val startStr = String.format(Locale.US, "%02d:%02d", session.startHour, session.startMinute)
        val endStr = String.format(Locale.US, "%02d:%02d", session.endHour, session.endMinute)

        val title = "انتهاء الحظر: ${session.ruleName}"
        val message = "انتهت فترة الحظر المجدول ($startStr - $endStr) وتم رفع القيود."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BLOCK_RULES"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BLOCK_RULES)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_SCHEDULED_BLOCK_COMPLETE,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_SCHEDULED_BLOCK)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setOngoing(false)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_SCHEDULED_BLOCK_COMPLETE, builder.build())
        Log.i(TAG, "Scheduled block completed notification dispatched for '${session.ruleName}' (isTest=$isTest)")
    }

    // --- Productivity Goal Achievement Notification ---

    /**
     * Evaluates active productivity discipline rules and triggers congratulatory notification
     * when a target app reaches its daily target minutes, or when the user increases the target ceiling
     * and subsequently achieves the new higher target.
     */
    fun evaluateAndTriggerProductivityGoalNotifications(context: Context) {
        if (!isProductivityGoalNotifEnabled(context)) return

        val rule = SaffahBlockRepository.getProductivityRule(context) ?: return
        if (!rule.isEnabled || rule.targetApps.isEmpty()) return

        val cal = Calendar.getInstance()
        val currentDay = cal.get(Calendar.DAY_OF_WEEK)
        if (!rule.activeDays.contains(currentDay)) return

        val todayDateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val prefs = getPrefs(context)

        for (target in rule.targetApps) {
            if (target.targetMinutes <= 0) continue
            val canonicalPkg = target.packageName.trim().lowercase()
            val spentMinutes = SaffahBlockRepository.getProductivityAppSpentMinutes(context, target.packageName)
            if (spentMinutes >= target.targetMinutes) {
                val notifDateKey = "last_notified_prod_goal_date_$canonicalPkg"
                val rawDateKey = "last_notified_prod_goal_date_${target.packageName}"
                val notifMinsKey = "last_notified_prod_goal_mins_$canonicalPkg"
                val rawMinsKey = "last_notified_prod_goal_mins_${target.packageName}"
                val legacyNotifKey = "last_notified_prod_goal_$canonicalPkg"
                val legacyRawKey = "last_notified_prod_goal_${target.packageName}"

                val lastDate = prefs.getString(notifDateKey, null)
                    ?: prefs.getString(rawDateKey, null)
                    ?: prefs.getString(legacyNotifKey, null)
                    ?: prefs.getString(legacyRawKey, "") ?: ""

                val lastNotifiedMins = if (lastDate == todayDateKey) {
                    if (prefs.contains(notifMinsKey)) {
                        prefs.getInt(notifMinsKey, 0)
                    } else if (prefs.contains(rawMinsKey)) {
                        prefs.getInt(rawMinsKey, 0)
                    } else {
                        0
                    }
                } else {
                    0
                }

                val isNewDay = (lastDate != todayDateKey)
                val isIncreasedTargetAchieved = (target.targetMinutes > lastNotifiedMins)

                if (isNewDay || isIncreasedTargetAchieved) {
                    dispatchProductivityGoalNotification(
                        context = context,
                        packageName = target.packageName,
                        targetMinutes = target.targetMinutes,
                        spentMinutes = spentMinutes,
                        isTest = false
                    )
                    prefs.edit()
                        .putString(notifDateKey, todayDateKey)
                        .putString(rawDateKey, todayDateKey)
                        .putString(legacyNotifKey, todayDateKey)
                        .putString(legacyRawKey, todayDateKey)
                        .putInt(notifMinsKey, target.targetMinutes)
                        .putInt(rawMinsKey, target.targetMinutes)
                        .apply()
                }
            }
        }
    }

    /**
     * Resets notification tracking state when a target app is deleted or newly added.
     */
    fun resetProductivityGoalNotificationState(context: Context, packageName: String) {
        try {
            val prefs = getPrefs(context)
            val canonicalPkg = packageName.trim().lowercase()
            prefs.edit()
                .remove("last_notified_prod_goal_$packageName")
                .remove("last_notified_prod_goal_$canonicalPkg")
                .remove("last_notified_prod_goal_date_$packageName")
                .remove("last_notified_prod_goal_date_$canonicalPkg")
                .remove("last_notified_prod_goal_mins_$packageName")
                .remove("last_notified_prod_goal_mins_$canonicalPkg")
                .apply()
        } catch (_: Exception) {}
    }

    /**
     * Handles updates to a target app's ceiling duration.
     * When target minutes are increased (e.g. 20 -> 25), ensures that reaching the new target
     * triggers a fresh congratulatory notification.
     */
    fun onProductivityTargetMinutesUpdated(context: Context, packageName: String, oldMinutes: Int, newMinutes: Int) {
        try {
            val prefs = getPrefs(context)
            val canonicalPkg = packageName.trim().lowercase()
            val minsKey = "last_notified_prod_goal_mins_$canonicalPkg"
            val rawMinsKey = "last_notified_prod_goal_mins_$packageName"
            val notifDateKey = "last_notified_prod_goal_date_$canonicalPkg"
            val rawDateKey = "last_notified_prod_goal_date_$packageName"
            val todayDateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)

            if (newMinutes > oldMinutes) {
                // Target was raised! (e.g. 20 -> 25)
                // Set recorded notified minutes to oldMinutes so that when user achieves newMinutes,
                // target.targetMinutes > lastNotifiedMins will be TRUE and trigger the new notification.
                val stored = if (prefs.contains(minsKey)) {
                    prefs.getInt(minsKey, 0)
                } else if (prefs.contains(rawMinsKey)) {
                    prefs.getInt(rawMinsKey, 0)
                } else {
                    oldMinutes
                }
                val baseline = minOf(stored, oldMinutes)
                prefs.edit()
                    .putString(notifDateKey, todayDateKey)
                    .putString(rawDateKey, todayDateKey)
                    .putInt(minsKey, baseline)
                    .putInt(rawMinsKey, baseline)
                    .apply()
            } else if (newMinutes < oldMinutes) {
                val spent = SaffahBlockRepository.getProductivityAppSpentMinutes(context, packageName)
                if (spent < newMinutes) {
                    prefs.edit()
                        .putInt(minsKey, 0)
                        .putInt(rawMinsKey, 0)
                        .apply()
                }
            }
            evaluateAndTriggerProductivityGoalNotifications(context)
        } catch (_: Exception) {}
    }

    /**
     * Dispatches congratulatory and motivational notification when daily productivity target is achieved.
     * Displays target app icon, app label, completed duration, and personal prestigious greeting for the user.
     */
    fun dispatchProductivityGoalNotification(
        context: Context,
        packageName: String,
        targetMinutes: Int,
        spentMinutes: Int,
        isTest: Boolean = false
    ) {
        if (!isProductivityGoalNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val rawName = SaffahRecoveryManager.getUserName(context)
        val displayName = if (rawName.isNotBlank()) rawName else "المتعافي"
        val appName = getAppLabel(context, packageName)
        val appIcon = getAppIconBitmap(context, packageName)

        val hours = spentMinutes / 60
        val mins = spentMinutes % 60
        val spentStr = when {
            hours > 0 && mins > 0 -> "$hours س و $mins د"
            hours > 0 -> "$hours ساعة"
            else -> "$mins دقيقة"
        }

        val title = "تحقيق الهدف اليومي: $appName"
        val message = "أحسنت يا $displayName، حققت هدفك لتطبيق $appName بإتمام $spentStr."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_BLOCK_RULES"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_BLOCK_RULES)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val canonicalPkg = packageName.trim().lowercase()
        val notifId = NOTIF_ID_PRODUCTIVITY_GOAL_BASE + ((canonicalPkg.hashCode() and 0x7FFFFFFF) % 1000)

        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_PRODUCTIVITY_GOAL)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setOnlyAlertOnce(false)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)

        if (appIcon != null) {
            builder.setLargeIcon(appIcon)
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        try {
            manager?.cancel(notifId)
        } catch (_: Exception) {}
        manager?.notify(notifId, builder.build())
        Log.i(TAG, "Productivity goal notification dispatched for $appName ($packageName), spent=$spentStr (isTest=$isTest)")
    }

    // --- Daily Block Harvest Notification (21:00) ---

    /**
     * Retrieves today's blocked attempt logs.
     */
    fun getTodayBlockedAttempts(context: Context): List<com.example.model.BlockLogEntry> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfDay = cal.timeInMillis
        return SaffahBlockRepository.getBlockLogs(context).filter { it.id >= startOfDay }
    }

    /**
     * Daily block harvest notification has been cancelled and deleted per user request.
     */
    fun scheduleDailyBlockHarvestAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_DAILY_BLOCK_HARVEST_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            3010,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.cancel(NOTIF_ID_DAILY_BLOCK_HARVEST)
    }

    /**
     * Daily block harvest notification has been cancelled and deleted per user request.
     */
    fun evaluateAndTriggerDailyBlockHarvestNotification(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.cancel(NOTIF_ID_DAILY_BLOCK_HARVEST)
    }

    /**
     * Daily block harvest notification has been cancelled and deleted per user request.
     */
    fun dispatchDailyBlockHarvestNotification(
        context: Context,
        testCount: Int? = null,
        isTest: Boolean = false
    ) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.cancel(NOTIF_ID_DAILY_BLOCK_HARVEST)
    }

    // --- Time Delay Expiration Notification ---

    /**
     * Schedules Exact Alarm for Time Delay Expiration.
     */
    fun scheduleTimeDelayExpirationAlarm(context: Context) {
        if (!isTimeDelayNotifEnabled(context)) return
        if (com.example.util.SaffahQrKeyManager.isQrKeyProtectionActive(context)) return

        val until = SaffahBlockRepository.getTimeDelayUntilTimestamp(context)
        val now = System.currentTimeMillis()
        if (until <= now) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
            action = ACTION_TIME_DELAY_EXPIRATION_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            3012,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        setAlarmSafely(alarmManager, until, pendingIntent)
        Log.i(TAG, "Time delay expiration alarm scheduled at ${Date(until)}")
    }

    /**
     * Cancels scheduled alarm for Time Delay Expiration.
     */
    fun cancelTimeDelayExpirationAlarm(context: Context) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, SaffahNotificationReceiver::class.java).apply {
                action = ACTION_TIME_DELAY_EXPIRATION_ALARM
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                3012,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling time delay expiration alarm: ${e.message}", e)
        }
    }

    /**
     * Evaluates and triggers notification when time delay expires.
     */
    fun evaluateAndTriggerTimeDelayExpirationNotification(context: Context) {
        if (!isTimeDelayNotifEnabled(context)) return
        if (com.example.util.SaffahQrKeyManager.isQrKeyProtectionActive(context)) return

        val until = SaffahBlockRepository.getTimeDelayUntilTimestamp(context)
        if (until <= 0L) return

        val now = System.currentTimeMillis()
        if (now >= until) {
            val lastNotified = getLastNotifiedTimeDelayTimestamp(context)
            if (lastNotified != until) {
                setLastNotifiedTimeDelayTimestamp(context, until)
                dispatchTimeDelayExpirationNotification(context, isTest = false)
            }
        }
    }

    /**
     * Dispatches notification alerting the user that time delay has expired and settings are modifiable.
     */
    fun dispatchTimeDelayExpirationNotification(
        context: Context,
        isTest: Boolean = false
    ) {
        if (!isTimeDelayNotifEnabled(context) && !isTest) return

        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val title = "انتهاء مدة التأخير الزمني"
        val message = "انتهت مدة التأخير الزمني المحددة، يمكنك الآن إجراء التعديلات على إعدادات الحماية."

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_PROTECTION"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_PROTECTION)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_TIME_DELAY_EXPIRATION,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_TIME_DELAY)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setOngoing(false)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIF_ID_TIME_DELAY_EXPIRATION, builder.build())
        Log.i(TAG, "Time delay expiration notification dispatched (isTest=$isTest)")
    }

    /**
     * إرسال إشعار اقتراح التقنية الأكثر نجاحاً عند تفعيل زر الـ 15 دقيقة لطرد الرغبة
     */
    fun dispatchUrgeSessionRecommendationNotification(context: Context, durationMinutes: Int = 15) {
        initChannels(context)
        ensureNotificationPermissionGranted(context)

        val recommendationText = SaffahRecoveryManager.getTopUrgeDefenseRecommendation(context)
        val title = "قاعدة الـ $durationMinutes دقيقة لدحر الرغبة"

        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.example.ACTION_OPEN_URGE_SESSION"
            putExtra(EXTRA_NAV_DESTINATION, NAV_DEST_URGE_SESSION)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_URGE_SUPPRESSION,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_URGE_SUPPRESSION)
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentTitle(title)
            .setContentText(recommendationText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(recommendationText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setOnlyAlertOnce(false)
            .setAutoCancel(true)
            .setColor(0xFF0166FF.toInt())
            .setContentIntent(pendingIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        try {
            manager?.cancel(NOTIF_ID_URGE_SUPPRESSION)
        } catch (_: Exception) {}
        manager?.notify(NOTIF_ID_URGE_SUPPRESSION, builder.build())
        Log.i(TAG, "Urge session recommendation notification dispatched: $recommendationText")
    }

    /**
     * إلغاء إشعار جلسة دحر الرغبة عند الانتهاء أو الإيقاف
     */
    fun cancelUrgeSessionRecommendationNotification(context: Context) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.cancel(NOTIF_ID_URGE_SUPPRESSION)
        } catch (_: Exception) {}
    }
}
