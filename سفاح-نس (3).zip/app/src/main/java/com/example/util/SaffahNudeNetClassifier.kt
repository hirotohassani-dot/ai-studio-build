package com.example.util

import ai.onnxruntime.OrtEnvironment
import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Singleton wrapper around NudeNetDetector managing lifecycle, configuration persistence,
 * and live debug state for the settings/debug panel.
 */
object SaffahNudeNetClassifier {
    private const val TAG = "SaffahNudeNetClassifier"
    private const val MODEL_NAME = "nudenet.onnx"

    private var detector: NudeNetDetector? = null
    private var ortEnv: OrtEnvironment? = null
    private val isInitializing = AtomicBoolean(false)
    private val lock = Any()

    data class LiveDebugState(
        val summary: List<String> = emptyList(),
        val inferences: Int = 0,
        val ms: Long = 0L,
        val historyCount: Int = 0,
        val historyTotal: Int = 0,
        val sweepPending: Boolean = false,
        val tilesDone: Int = 0,
        val cueActive: Boolean = false,
        val framePositive: Boolean = false,
        val trigger: Boolean = false,
        val timestamp: Long = 0L
    )

    private val _debugState = MutableStateFlow(LiveDebugState())
    val debugState: StateFlow<LiveDebugState> = _debugState.asStateFlow()

    fun initialize(context: Context): Boolean {
        synchronized(lock) {
            if (detector != null) return true
        }
        if (isInitializing.getAndSet(true)) return false

        try {
            val env = OrtEnvironment.getEnvironment()
            val modelBytes = context.assets.open(MODEL_NAME).use { it.readBytes() }
            val cfg = SaffahBlockRepository.getNudeConfig(context)

            synchronized(lock) {
                ortEnv = env
                detector = NudeNetDetector(env, modelBytes, cfg)
            }
            Log.i(TAG, "NudeNetDetector initialized successfully with modelBytes=${modelBytes.size}")
            return true
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to initialize NudeNetDetector: ${e.message}", e)
            return false
        } finally {
            isInitializing.set(false)
        }
    }

    fun isReady(): Boolean = synchronized(lock) { detector != null }

    fun getDetector(): NudeNetDetector? = synchronized(lock) { detector }

    fun updateConfig(newCfg: NudeCfg) {
        synchronized(lock) {
            val d = detector ?: return
            d.cfg.tFemaleGenExp = newCfg.tFemaleGenExp
            d.cfg.tMaleGenExp = newCfg.tMaleGenExp
            d.cfg.tAnusExp = newCfg.tAnusExp
            d.cfg.tFemaleBreastExp = newCfg.tFemaleBreastExp
            d.cfg.tButtExp = newCfg.tButtExp
            d.cfg.tButtIsolated = newCfg.tButtIsolated
            d.cfg.strong = newCfg.strong
            d.cfg.strongButt = newCfg.strongButt
            d.cfg.sexyEnabled = newCfg.sexyEnabled
            d.cfg.tBreastCov = newCfg.tBreastCov
            d.cfg.tLowerCov = newCfg.tLowerCov
            d.cfg.tBellyExp = newCfg.tBellyExp
            d.cfg.confirm = newCfg.confirm
            d.cfg.minLumaStd = newCfg.minLumaStd
            d.cfg.maxWindows = newCfg.maxWindows
            d.cfg.tileFrac = newCfg.tileFrac
            d.cfg.tilesPerTickGallery = newCfg.tilesPerTickGallery
            d.cfg.tilesPerTickIdle = newCfg.tilesPerTickIdle
            d.cfg.idleSweepEvery = newCfg.idleSweepEvery
            d.cfg.galleryCue = newCfg.galleryCue
        }
    }

    fun clearHistory() {
        synchronized(lock) {
            detector?.resetHistory()
        }
    }

    fun updateLiveDebug(out: NudeNetDetector.NudeOut, d: NudeNetDetector, nowMs: Long) {
        _debugState.value = LiveDebugState(
            summary = out.summary,
            inferences = out.inferences,
            ms = out.ms,
            historyCount = d.getHistoryCount(),
            historyTotal = d.getHistoryTotal(),
            sweepPending = out.sweepPending,
            tilesDone = d.getTilesDone(),
            cueActive = d.getCueActive(),
            framePositive = out.framePositive,
            trigger = out.trigger,
            timestamp = nowMs
        )
    }

    fun close() {
        synchronized(lock) {
            try {
                detector?.close()
                ortEnv?.close()
            } catch (_: Exception) {}
            detector = null
            ortEnv = null
        }
    }
}
