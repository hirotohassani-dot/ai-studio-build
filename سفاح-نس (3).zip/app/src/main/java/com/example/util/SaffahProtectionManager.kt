package com.example.util

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.receiver.SaffahBootReceiver
import com.example.receiver.SaffahDeviceAdminReceiver
import com.example.service.SaffahAccessibilityService
import com.example.worker.ServiceWatchdogWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

object SaffahProtectionManager {

    private const val WATCHDOG_WORK_NAME = "SaffahServiceWatchdogWork"
    private var lastDeviceOwnerRestrictionsApplyTime = 0L
    private var lastKeepAliveAlarmScheduleTime = 0L
    private var lastSystemImmunityApplyTime = 0L
    private var lastHeavyShellImmunityApplyTime = 0L
    private val protectionScope = CoroutineScope(Dispatchers.IO)

    /**
     * التحصين الشامل للسفاح في النظام (System-Level Comprehensive Immunity):
     * يعمل بشكل غير متزامن تماماً في الخلفية (Background Thread) لتفادي أي تجميد للواجهة (ANR).
     * 1. فرض وتأكيد إعفاء البطارية وتجاوز قيود Doze Mode و App Standby.
     * 2. جدولة منبه إيقاظ دوري متكرر عالي الدقة عبر AlarmManager لضمان العمل.
     * 3. تطبيق قيود Device Owner وربط خدمة إمكانية الوصول.
     */
    fun applyAllSystemImmunity(context: Context, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && (now - lastSystemImmunityApplyTime < 30_000L)) {
            return // Throttled to prevent redundant executions
        }
        lastSystemImmunityApplyTime = now

        protectionScope.launch {
            try {
                // 1 & 2. Battery optimization bypass & OEM freeze exemption via shell commands
                // Throttled to run at most once per hour (or on force) to eliminate excessive shell process forks & battery drain
                if (force || (now - lastHeavyShellImmunityApplyTime > 3_600_000L)) {
                    lastHeavyShellImmunityApplyTime = now
                    enforceBatteryOptimizationBypass(context)
                    enforceAppFreezeExemption(context)
                }

                // 3. Keep-Alive Alarm registration (relaxed 30-minute safety-net interval)
                scheduleKeepAliveAlarm(context)

                // 4. WorkManager watchdog
                scheduleWatchdog(context)

                // 5. Device Owner & Accessibility binding
                applyDeviceOwnerRestrictions(context)
                ensureAccessibilityServiceEnabled(context)

                // 6. Continuous Foreground Keeper Service (Active Apps immunity without VPN)
                startKeeperService(context)
            } catch (t: Throwable) {
                Log.e("SaffahProtection", "Error in applyAllSystemImmunity: ${t.message}", t)
            }
        }
    }

    const val PREF_KEY_KEEPER_SERVICE_ENABLED = "keeper_service_enabled"
    private const val DE_PREFS_NAME = "saffah_de_prefs"

    fun getDirectBootSafeContext(context: Context): Context {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val um = context.getSystemService(Context.USER_SERVICE) as? UserManager
            if (um != null && !um.isUserUnlocked) {
                context.createDeviceProtectedStorageContext()
            } else {
                context
            }
        } else {
            context
        }
    }

    fun isKeeperServiceEnabled(context: Context): Boolean {
        return try {
            val safeContext = getDirectBootSafeContext(context)
            val isDeOnly = (safeContext !== context)
            if (isDeOnly) {
                val dePrefs = safeContext.getSharedPreferences(DE_PREFS_NAME, Context.MODE_PRIVATE)
                dePrefs.getBoolean(PREF_KEY_KEEPER_SERVICE_ENABLED, true)
            } else {
                val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
                val value = prefs.getBoolean(PREF_KEY_KEEPER_SERVICE_ENABLED, true)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    try {
                        val deContext = context.createDeviceProtectedStorageContext()
                        deContext.getSharedPreferences(DE_PREFS_NAME, Context.MODE_PRIVATE)
                            .edit().putBoolean(PREF_KEY_KEEPER_SERVICE_ENABLED, value).apply()
                    } catch (_: Exception) {}
                }
                value
            }
        } catch (_: Exception) {
            true // Default to enabled for uninterrupted protection
        }
    }

    fun setKeeperServiceEnabled(context: Context, enabled: Boolean) {
        try {
            val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean(PREF_KEY_KEEPER_SERVICE_ENABLED, enabled).apply()
        } catch (_: Exception) {}

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                val deContext = context.createDeviceProtectedStorageContext()
                deContext.getSharedPreferences(DE_PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(PREF_KEY_KEEPER_SERVICE_ENABLED, enabled).apply()
            } catch (_: Exception) {}
        }

        if (enabled) {
            startKeeperService(context)
            com.example.service.SaffahKeeperService.ensureKeeperNotification(context)
        } else {
            stopKeeperService(context)
        }
    }

    fun startKeeperService(context: Context) {
        if (!isKeeperServiceEnabled(context)) return
        try {
            val intent = Intent(context, com.example.service.SaffahKeeperService::class.java).apply {
                action = com.example.service.SaffahKeeperService.ACTION_START_KEEPER
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            Log.i("SaffahProtection", "SaffahKeeperService launched in foreground.")
        } catch (e: Exception) {
            Log.e("SaffahProtection", "startKeeperService direct launch error: ${e.message}, scheduling emergency revival immediately")
            scheduleEmergencyRevival(context, delayMillis = 50L)
        }
    }

    fun stopKeeperService(context: Context) {
        try {
            val intent = Intent(context, com.example.service.SaffahKeeperService::class.java).apply {
                action = com.example.service.SaffahKeeperService.ACTION_STOP_KEEPER
            }
            context.startService(intent)
            Log.i("SaffahProtection", "SaffahKeeperService stop signal sent.")
        } catch (e: Exception) {
            Log.e("SaffahProtection", "stopKeeperService error: ${e.message}")
        }
    }

    /**
     * Checks if SaffahKeeperService is recognized by the OS as an active Foreground Service
     * ensuring it is not missing from the system's "Active apps" task manager.
     */
    fun isKeeperServiceForeground(context: Context): Boolean {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return false
            @Suppress("DEPRECATION")
            val runningServices = am.getRunningServices(128) ?: return false
            val targetName = com.example.service.SaffahKeeperService::class.java.name
            for (serviceInfo in runningServices) {
                if (serviceInfo.service.className == targetName) {
                    return serviceInfo.foreground
                }
            }
        } catch (_: Exception) {}
        return false
    }

    fun enforceBatteryOptimizationBypass(context: Context) {
        try {
            val pkg = context.packageName
            val cr = context.contentResolver

            // 1. System PowerManager check & direct request if not ignoring
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (pm != null && !pm.isIgnoringBatteryOptimizations(pkg)) {
                    Log.i("SaffahProtection", "Requesting ignore battery optimizations bypass...")
                }
            }

            // 2. Direct system shell & service commands for comprehensive battery shield
            try {
                // DeviceIdle whitelist (Doze mode complete exemption)
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd deviceidle whitelist +$pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "dumpsys deviceidle whitelist +$pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd deviceidle except-idle-whitelist +$pkg"))

                // App Standby Bucket to ACTIVE (Bucket 10) - Highest system priority
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "am set-standby-bucket $pkg active"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "am set-standby-bucket $pkg 10"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd usage-stats set-state $pkg active"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd usage-stats set-state $pkg 10"))

                // AppOps full privileges
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg RUN_IN_BACKGROUND allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg WAKE_LOCK allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg START_FOREGROUND allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg REQUEST_IGNORE_BATTERY_OPTIMIZATIONS allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg ACCESS_NOTIFICATIONS allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg BIND_NOTIFICATION_LISTENER_SERVICE allow"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg FOREGROUND_SERVICE_SPECIAL_USE allow"))

                // Disable global forced standby
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put global forced_app_standby_for_small_battery_during_charging 0"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put global app_standby_enabled 0"))
            } catch (_: Exception) {}

            // 3. Android 14+ (API 34) Device Owner Application Exemptions
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
                    if (dpm != null && dpm.isDeviceOwnerApp(pkg)) {
                        val setMethod = dpm.javaClass.getMethod("setApplicationExemptions", Set::class.java)
                        setMethod.invoke(dpm, setOf(1, 2, 3)) // BATTERY_OPTIMIZATION (1), DISK_IO (2), PROHIBIT_MANUAL_SUSPENSION (3)
                    }
                }
            } catch (_: Exception) {}

            // 4. Write directly into System Settings ContentResolver if WRITE_SECURE_SETTINGS or Device Owner
            try {
                Settings.Global.putInt(cr, "forced_app_standby_for_small_battery_during_charging", 0)
            } catch (_: Exception) {}
        } catch (e: Exception) {
            Log.w("SaffahProtection", "enforceBatteryOptimizationBypass error: ${e.message}")
        }
    }

    fun enforceAppFreezeExemption(context: Context) {
        try {
            val pkg = context.packageName
            val cr = context.contentResolver

            // 1. Force App Standby Bucket to ACTIVE (10)
            try {
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd usage-stats set-state $pkg active"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd usage-stats set-state $pkg 10"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "am set-standby-bucket $pkg active"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "am set-standby-bucket $pkg 10"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $pkg WAKE_LOCK allow"))
            } catch (_: Exception) {}

            // 2. Shell execution for OEM Quick Freeze / App Freeze / Deep Sleep whitelisting
            try {
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system quick_freeze_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure quick_freeze_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system app_freeze_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure app_freeze_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system deep_sleep_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure deep_sleep_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system auto_launch_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure auto_launch_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system background_launch_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure background_launch_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system power_save_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure power_save_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system high_power_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure high_power_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system hw_power_freeze_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure hw_power_freeze_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system vivo_freeze_whitelist $pkg"))
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure vivo_freeze_whitelist $pkg"))
            } catch (_: Exception) {}

            // 3. Programmatic ContentResolver writes for OEM (Realme UI / ColorOS / Xiaomi / Samsung / Huawei / Vivo)
            try {
                val freezeKeys = listOf(
                    "quick_freeze_whitelist",
                    "app_freeze_whitelist",
                    "deep_sleep_whitelist",
                    "auto_launch_whitelist",
                    "background_launch_whitelist",
                    "power_save_whitelist",
                    "high_power_whitelist",
                    "hw_power_freeze_whitelist",
                    "vivo_freeze_whitelist"
                )
                for (key in freezeKeys) {
                    try {
                        val currentSys = Settings.System.getString(cr, key) ?: ""
                        if (!currentSys.contains(pkg)) {
                            val updated = if (currentSys.isBlank()) pkg else "$currentSys,$pkg"
                            Settings.System.putString(cr, key, updated)
                        }
                    } catch (_: Exception) {}
                    try {
                        val currentSec = Settings.Secure.getString(cr, key) ?: ""
                        if (!currentSec.contains(pkg)) {
                            val updated = if (currentSec.isBlank()) pkg else "$currentSec,$pkg"
                            Settings.Secure.putString(cr, key, updated)
                        }
                    } catch (_: Exception) {}
                }

                // Samsung auto_disabled_apps exclusion: Ensure Saffah is NOT in auto_disabled_apps
                try {
                    val disabledApps = Settings.Secure.getString(cr, "auto_disabled_apps") ?: ""
                    if (disabledApps.contains(pkg)) {
                        val updated = disabledApps.split(",").filter { it.trim() != pkg }.joinToString(",")
                        Settings.Secure.putString(cr, "auto_disabled_apps", updated)
                    }
                } catch (_: Exception) {}
            } catch (_: Exception) {}
        } catch (e: Exception) {
            Log.w("SaffahProtection", "enforceAppFreezeExemption error: ${e.message}")
        }
    }

    fun scheduleKeepAliveAlarm(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastKeepAliveAlarmScheduleTime < 300_000L) {
            return
        }
        lastKeepAliveAlarmScheduleTime = now
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, SaffahBootReceiver::class.java).apply {
                action = "com.example.ACTION_SAFFAH_KEEPALIVE_PING"
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                8891,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Relaxed interval: 30 minutes interval instead of 3 minutes.
            // With SaffahKeeperService (Foreground Service) and WorkManager running,
            // a 30-minute fallback ensures optimal battery preservation while guaranteeing revival.
            val triggerAtMillis = SystemClock.elapsedRealtime() + (30 * 60 * 1000L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtMillis, pendingIntent)
            } else {
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtMillis, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "scheduleKeepAliveAlarm error: ${e.message}")
        }
    }

    fun scheduleEmergencyRevival(context: Context, delayMillis: Long = 150L) {
        try {
            val appContext = context.applicationContext ?: context
            val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            // 1. Direct Foreground Service PendingIntent (Zero delay, completely bypasses background start restrictions)
            val keeperIntent = Intent(appContext, com.example.service.SaffahKeeperService::class.java).apply {
                action = com.example.service.SaffahKeeperService.ACTION_START_KEEPER
            }
            val requestCode = 8895 + (delayMillis % 100).toInt()
            val keeperPendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                PendingIntent.getForegroundService(
                    appContext,
                    requestCode,
                    keeperIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                PendingIntent.getService(
                    appContext,
                    requestCode,
                    keeperIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }

            val triggerWallClock = System.currentTimeMillis() + delayMillis
            val triggerElapsed = SystemClock.elapsedRealtime() + delayMillis

            // Priority 1: setAlarmClock on direct foreground service PendingIntent
            // Bypasses all Doze, App Standby, and Android 12+ background start limits!
            var scheduled = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                try {
                    val clockInfo = AlarmManager.AlarmClockInfo(triggerWallClock, keeperPendingIntent)
                    alarmManager.setAlarmClock(clockInfo, keeperPendingIntent)
                    scheduled = true
                    Log.i("SaffahProtection", "Emergency keeper revival scheduled via setAlarmClock in ${delayMillis}ms")
                } catch (e: Exception) {
                    Log.w("SaffahProtection", "setAlarmClock unavailable, falling back: ${e.message}")
                }
            }

            if (!scheduled) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerElapsed, keeperPendingIntent)
                    } else {
                        alarmManager.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerElapsed, keeperPendingIntent)
                    }
                    Log.i("SaffahProtection", "Emergency keeper revival scheduled via setExact in ${delayMillis}ms")
                } catch (e: Exception) {
                    Log.w("SaffahProtection", "setExact fallback error: ${e.message}")
                }
            }

            // 2. Secondary redundant broadcast alarm to SaffahBootReceiver for full system shield evaluation
            try {
                val pingIntent = Intent(appContext, SaffahBootReceiver::class.java).apply {
                    action = "com.example.ACTION_SAFFAH_KEEPALIVE_PING"
                }
                val broadcastPendingIntent = PendingIntent.getBroadcast(
                    appContext,
                    8892,
                    pingIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerElapsed + 400L, broadcastPendingIntent)
                } else {
                    alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerElapsed + 400L, broadcastPendingIntent)
                }
            } catch (_: Exception) {}

        } catch (e: Exception) {
            Log.e("SaffahProtection", "scheduleEmergencyRevival error: ${e.message}")
        }
    }

    fun scheduleVpnEmergencyRevival(context: Context, delayMillis: Long = 250L) {
        try {
            val appContext = context.applicationContext ?: context
            val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val vpnIntent = Intent(appContext, com.example.service.SaffahVpnService::class.java).apply {
                action = com.example.service.SaffahVpnService.ACTION_START_VPN
            }
            val vpnPendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                PendingIntent.getForegroundService(
                    appContext,
                    8896,
                    vpnIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                PendingIntent.getService(
                    appContext,
                    8896,
                    vpnIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }
            val triggerWallClock = System.currentTimeMillis() + delayMillis
            val triggerElapsed = SystemClock.elapsedRealtime() + delayMillis
            var vpnScheduled = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                try {
                    val clockInfo = AlarmManager.AlarmClockInfo(triggerWallClock, vpnPendingIntent)
                    alarmManager.setAlarmClock(clockInfo, vpnPendingIntent)
                    vpnScheduled = true
                    Log.i("SaffahProtection", "Emergency VPN revival scheduled via setAlarmClock in ${delayMillis}ms")
                } catch (_: Exception) {}
            }
            if (!vpnScheduled) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerElapsed, vpnPendingIntent)
                    } else {
                        alarmManager.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerElapsed, vpnPendingIntent)
                    }
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "scheduleVpnEmergencyRevival error: ${e.message}")
        }
    }

    fun triggerExpeditedWatchdog(context: Context) {
        try {
            val expeditedRequest = OneTimeWorkRequestBuilder<ServiceWatchdogWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
            WorkManager.getInstance(context).enqueue(expeditedRequest)
            Log.i("SaffahProtection", "Enqueued expedited ServiceWatchdogWorker successfully.")
        } catch (e: Exception) {
            Log.w("SaffahProtection", "triggerExpeditedWatchdog note: ${e.message}")
        }
    }

    /**
     * 1. Battery Optimization Bypass
     */
    fun checkAndRequestBatteryOptimizationBypass(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
                val packageName = context.packageName
                if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                    Log.i("SaffahProtection", "Requesting Battery Optimization Bypass...")
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } else {
                    Log.i("SaffahProtection", "App is already ignoring battery optimizations.")
                }
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error requesting battery optimization bypass: ${e.message}")
        }
    }

    /**
     * 4. Watchdog / Heartbeat mechanism via WorkManager
     */
    fun scheduleWatchdog(context: Context) {
        try {
            val watchdogRequest = PeriodicWorkRequestBuilder<ServiceWatchdogWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WATCHDOG_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                watchdogRequest
            )
            Log.i("SaffahProtection", "Service Watchdog scheduled successfully.")
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error scheduling Watchdog worker: ${e.message}")
        }
    }

    /**
     * 5. Device Owner Protection (Prevents Force Stop, Clear Data, Uninstall)
     */
    fun applyDeviceOwnerRestrictions(context: Context) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastDeviceOwnerRestrictionsApplyTime < 10_000L) {
            return // Debounce rapid calls to save IPC binder cycles
        }
        lastDeviceOwnerRestrictionsApplyTime = now
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            val packageName = context.packageName

            val isDeviceOwner = dpm.isDeviceOwnerApp(packageName)
            val isAdminActive = dpm.isAdminActive(adminComponent)

            Log.i("SaffahProtection", "DeviceAdmin Active: $isAdminActive, DeviceOwner: $isDeviceOwner")

            if (isDeviceOwner) {
                // Prevent uninstall for Saffah application itself
                dpm.setUninstallBlocked(adminComponent, packageName, true)
                dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_UNINSTALL_APPS)

                // Sync uninstall prevention for user-selected packages via Device Owner
                syncUninstallBlockedPackages(context)

                // Explicitly clear global DISALLOW_APPS_CONTROL so other apps (e.g. File Manager +)
                // can clear data without being blocked by work policy
                try {
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_APPS_CONTROL)
                    Log.i("SaffahProtection", "Device Owner cleared global DISALLOW_APPS_CONTROL restriction")
                } catch (e: Exception) {
                    Log.w("SaffahProtection", "clearUserRestriction DISALLOW_APPS_CONTROL note: ${e.message}")
                }

                // Configure Lock Task packages for Saffah and Settings
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    dpm.setLockTaskPackages(adminComponent, arrayOf(packageName, "com.android.settings"))
                    val criticalPermissions = listOf(
                        "android.permission.WRITE_SECURE_SETTINGS",
                        "android.permission.PACKAGE_USAGE_STATS",
                        "android.permission.POST_NOTIFICATIONS",
                        "android.permission.SYSTEM_ALERT_WINDOW",
                        "android.permission.ACCESS_FINE_LOCATION",
                        "android.permission.ACCESS_COARSE_LOCATION"
                    )
                    for (perm in criticalPermissions) {
                        try {
                            dpm.setPermissionGrantState(adminComponent, packageName, perm, DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED)
                        } catch (_: Exception) {}
                    }
                }

                // Android 14+ (API 34) Battery Optimization & App Standby Exemption
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        val setMethod = dpm.javaClass.getMethod("setApplicationExemptions", Set::class.java)
                        setMethod.invoke(dpm, setOf(1)) // 1 = APPLICATION_EXEMPTION_BATTERY_OPTIMIZATION
                    }
                } catch (_: Exception) {}

                // Explicitly permit all accessibility services (passing null) so other apps' accessibility
                // permissions are NOT disabled or greyed out, while keeping Saffah fully operational
                try {
                    dpm.setPermittedAccessibilityServices(adminComponent, null)
                    Log.i("SaffahProtection", "Permitted all accessibility services (null whitelist applied)")
                } catch (e: Exception) {
                    Log.w("SaffahProtection", "setPermittedAccessibilityServices note: ${e.message}")
                }

                Log.i("SaffahProtection", "Device Owner anti-force-stop and anti-uninstall restrictions applied!")
            } else if (isAdminActive) {
                // Device Admin Fallback: Prevent uninstall
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        dpm.setUninstallBlocked(adminComponent, packageName, true)
                    }
                } catch (e: Exception) {
                    Log.w("SaffahProtection", "DeviceAdmin setUninstallBlocked warning: ${e.message}")
                }
            }

            // Always enforce DISALLOW_ADD_USER permanently without any switch or disable toggle
            if (isDeviceOwner || isAdminActive) {
                try {
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_ADD_USER)
                    Log.i("SaffahProtection", "Permanently enforced DISALLOW_ADD_USER restriction (always active)")
                } catch (e: Exception) {
                    Log.w("SaffahProtection", "Could not apply DISALLOW_ADD_USER: ${e.message}")
                }
            }

            val shouldDisallowSafeBoot = isDisallowSafeBootEnabled(context)
            applySafeBootRestriction(context, shouldDisallowSafeBoot)

            val shouldDisallowDateTime = isDisallowConfigDateTimeEnabled(context)
            applyConfigDateTimeRestriction(context, shouldDisallowDateTime)

            val shouldDisallowPrivateDns = isDisallowConfigPrivateDnsEnabled(context)
            applyConfigPrivateDnsRestriction(context, shouldDisallowPrivateDns)

            val shouldDisallowDebuggingFeatures = isDisallowDebuggingFeaturesEnabled(context)
            applyDebuggingFeaturesRestriction(context, shouldDisallowDebuggingFeatures)

            // Instantly ensure Accessibility is permanently enabled and granted
            ensureAccessibilityServiceEnabled(context)
        } catch (t: Throwable) {
            Log.e("SaffahProtection", "Error applying Device Owner restrictions: ${t.message}")
        }
    }

    /**
     * DISALLOW_ADD_USER is permanently enforced inside Saffah to prevent bypasses.
     * Always returns true and permanently ensures the restriction is applied on device admin/owner.
     */
    fun enforceDisallowAddUser(context: Context): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent)) {
                dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_ADD_USER)
                Log.i("SaffahProtection", "Enforced permanent DISALLOW_ADD_USER restriction")
                return true
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error enforcing DISALLOW_ADD_USER: ${e.message}")
        }
        return false
    }

    fun setDisallowSafeBoot(context: Context, enable: Boolean): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("disallow_safe_boot", enable).apply()
        return applySafeBootRestriction(context, enable)
    }

    fun isDisallowSafeBootEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        val prefValue = prefs.getBoolean("disallow_safe_boot", false)

        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm != null && (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent))) {
                val userRestrictions = dpm.getUserRestrictions(adminComponent)
                if (userRestrictions.containsKey(UserManager.DISALLOW_SAFE_BOOT)) {
                    return userRestrictions.getBoolean(UserManager.DISALLOW_SAFE_BOOT)
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahProtection", "Error checking DISALLOW_SAFE_BOOT restriction: ${e.message}")
        }
        return prefValue
    }

    fun applySafeBootRestriction(context: Context, enable: Boolean): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent)) {
                if (enable) {
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_SAFE_BOOT)
                    Log.i("SaffahProtection", "Added DISALLOW_SAFE_BOOT restriction")
                } else {
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_SAFE_BOOT)
                    Log.i("SaffahProtection", "Cleared DISALLOW_SAFE_BOOT restriction")
                }
                return true
            } else {
                Log.w("SaffahProtection", "DeviceAdmin/Owner not active to set DISALLOW_SAFE_BOOT")
                return false
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error applying DISALLOW_SAFE_BOOT: ${e.message}")
            return false
        }
    }

    fun setDisallowConfigDateTime(context: Context, enable: Boolean): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("disallow_config_date_time", enable).apply()
        return applyConfigDateTimeRestriction(context, enable)
    }

    fun isDisallowConfigDateTimeEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        val prefValue = prefs.getBoolean("disallow_config_date_time", false)

        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm != null && (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent))) {
                val userRestrictions = dpm.getUserRestrictions(adminComponent)
                if (userRestrictions.containsKey(UserManager.DISALLOW_CONFIG_DATE_TIME)) {
                    return userRestrictions.getBoolean(UserManager.DISALLOW_CONFIG_DATE_TIME)
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahProtection", "Error checking DISALLOW_CONFIG_DATE_TIME restriction: ${e.message}")
        }
        return prefValue
    }

    fun applyConfigDateTimeRestriction(context: Context, enable: Boolean): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent)) {
                if (enable) {
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_CONFIG_DATE_TIME)
                    Log.i("SaffahProtection", "Added DISALLOW_CONFIG_DATE_TIME restriction")
                } else {
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_CONFIG_DATE_TIME)
                    Log.i("SaffahProtection", "Cleared DISALLOW_CONFIG_DATE_TIME restriction")
                }
                return true
            } else {
                Log.w("SaffahProtection", "DeviceAdmin/Owner not active to set DISALLOW_CONFIG_DATE_TIME")
                return false
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error applying DISALLOW_CONFIG_DATE_TIME: ${e.message}")
            return false
        }
    }

    fun setDisallowConfigPrivateDns(context: Context, enable: Boolean): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("disallow_config_private_dns", enable).apply()
        return applyConfigPrivateDnsRestriction(context, enable)
    }

    fun isDisallowConfigPrivateDnsEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        val prefValue = prefs.getBoolean("disallow_config_private_dns", false)

        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm != null && (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent))) {
                val userRestrictions = dpm.getUserRestrictions(adminComponent)
                val key = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    UserManager.DISALLOW_CONFIG_PRIVATE_DNS
                } else {
                    "disallow_config_private_dns"
                }
                if (userRestrictions.containsKey(key)) {
                    return userRestrictions.getBoolean(key)
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahProtection", "Error checking DISALLOW_CONFIG_PRIVATE_DNS restriction: ${e.message}")
        }
        return prefValue
    }

    fun applyConfigPrivateDnsRestriction(context: Context, enable: Boolean): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent)) {
                val key = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    UserManager.DISALLOW_CONFIG_PRIVATE_DNS
                } else {
                    "disallow_config_private_dns"
                }
                if (enable) {
                    dpm.addUserRestriction(adminComponent, key)
                    Log.i("SaffahProtection", "Added DISALLOW_CONFIG_PRIVATE_DNS restriction")
                } else {
                    dpm.clearUserRestriction(adminComponent, key)
                    Log.i("SaffahProtection", "Cleared DISALLOW_CONFIG_PRIVATE_DNS restriction")
                }
                return true
            } else {
                Log.w("SaffahProtection", "DeviceAdmin/Owner not active to set DISALLOW_CONFIG_PRIVATE_DNS")
                return false
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error applying DISALLOW_CONFIG_PRIVATE_DNS: ${e.message}")
            return false
        }
    }

    fun setDisallowDebuggingFeatures(context: Context, enable: Boolean): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("disallow_debugging_features", enable).apply()
        return applyDebuggingFeaturesRestriction(context, enable)
    }

    fun isDisallowDebuggingFeaturesEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences("saffah_prefs", Context.MODE_PRIVATE)
        val prefValue = prefs.getBoolean("disallow_debugging_features", false)

        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm != null && (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent))) {
                val userRestrictions = dpm.getUserRestrictions(adminComponent)
                if (userRestrictions.containsKey(UserManager.DISALLOW_DEBUGGING_FEATURES)) {
                    return userRestrictions.getBoolean(UserManager.DISALLOW_DEBUGGING_FEATURES)
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahProtection", "Error checking DISALLOW_DEBUGGING_FEATURES restriction: ${e.message}")
        }
        return prefValue
    }

    fun applyDebuggingFeaturesRestriction(context: Context, enable: Boolean): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent)) {
                if (enable) {
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_DEBUGGING_FEATURES)
                    Log.i("SaffahProtection", "Added DISALLOW_DEBUGGING_FEATURES restriction")
                } else {
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_DEBUGGING_FEATURES)
                    Log.i("SaffahProtection", "Cleared DISALLOW_DEBUGGING_FEATURES restriction")
                }
                return true
            } else {
                Log.w("SaffahProtection", "DeviceAdmin/Owner not active to set DISALLOW_DEBUGGING_FEATURES")
                return false
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error applying DISALLOW_DEBUGGING_FEATURES: ${e.message}")
            return false
        }
    }

    /**
     * Checks if WRITE_SECURE_SETTINGS permission is currently granted, or if the app is Device Owner.
     */
    fun hasWriteSecureSettings(context: Context): Boolean {
        return try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            if (dpm != null && dpm.isDeviceOwnerApp(context.packageName)) return true
            context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) {
            false
        }
    }

    @Volatile
    private var isRevivingAccessibility = false
    private var lastAccessibilityRevivalTimestamp = 0L

    fun isRevivingAccessibilityInProgress(): Boolean = isRevivingAccessibility

    /**
     * Checks if SaffahAccessibilityService is currently configured as enabled in Settings.Secure.
     */
    fun isAccessibilityConfiguredInSettings(context: Context): Boolean {
        return try {
            val cr = context.contentResolver
            val isGlobalEnabled = Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
            if (!isGlobalEnabled) return false

            val serviceComponent = ComponentName(context, SaffahAccessibilityService::class.java)
            val fullFlattened = serviceComponent.flattenToString()
            val shortFlattened = serviceComponent.flattenToShortString()

            val currentServices = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (currentServices.isBlank()) return false

            val servicesList = currentServices.split(":")
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            servicesList.any { s ->
                s.equals(fullFlattened, ignoreCase = true) ||
                s.equals(shortFlattened, ignoreCase = true) ||
                (s.contains(context.packageName, ignoreCase = true) && s.contains("SaffahAccessibilityService", ignoreCase = true))
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Completely revives the Accessibility Service by performing a fast re-bind cycle in Settings.Secure.
     * In Android 14 and ColorOS / Realme UI, if an accessibility service crashes or is killed,
     * the system marks it as "malfunctioning" / "Not working. Tap for info" and keeps it in Settings.Secure
     * without attempting to rebind.
     *
     * Cycling the entry in ENABLED_ACCESSIBILITY_SERVICES (removing and re-inserting with a 200ms delay)
     * clears the dead binder state and forces AccessibilityManagerService to immediately rebind
     * a fresh, working instance.
     */
    fun reviveAccessibilityService(context: Context, reason: String = "auto"): Boolean {
        if (!hasWriteSecureSettings(context)) {
            Log.w("SaffahProtection", "Cannot revive accessibility: WRITE_SECURE_SETTINGS not granted")
            return false
        }

        val now = android.os.SystemClock.elapsedRealtime()
        if (isRevivingAccessibility || (now - lastAccessibilityRevivalTimestamp < 4000L)) {
            Log.i("SaffahProtection", "Accessibility revival already in progress or debounced (reason=$reason)")
            return false
        }

        isRevivingAccessibility = true
        lastAccessibilityRevivalTimestamp = now

        return try {
            val appContext = context.applicationContext
            val cr = appContext.contentResolver
            val serviceComponent = ComponentName(appContext, SaffahAccessibilityService::class.java)
            val fullFlattened = serviceComponent.flattenToString()
            val shortFlattened = serviceComponent.flattenToShortString()

            val dpm = appContext.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(appContext, SaffahDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(appContext.packageName)) {
                try {
                    dpm.setPermissionGrantState(adminComponent, appContext.packageName, "android.permission.WRITE_SECURE_SETTINGS", DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED)
                } catch (_: Exception) {}
                try {
                    dpm.setPermittedAccessibilityServices(adminComponent, null)
                } catch (_: Exception) {}
            }

            val currentServices = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val servicesList = currentServices.split(":")
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            val otherServices = servicesList.filterNot { s ->
                s.equals(fullFlattened, ignoreCase = true) ||
                s.equals(shortFlattened, ignoreCase = true) ||
                (s.contains(appContext.packageName, ignoreCase = true) && s.contains("SaffahAccessibilityService", ignoreCase = true))
            }

            Log.i("SaffahProtection", "Executing Accessibility Re-bind Kick (Reason: $reason)...")

            // Step 1: Temporarily remove Saffah from ENABLED_ACCESSIBILITY_SERVICES
            // This immediately signals AccessibilityManagerService to clear the dead/malfunctioning ("Not working") binder state
            val clearedString = otherServices.joinToString(":")
            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, clearedString)

            // Step 2: After a brief delay (200ms), re-add Saffah to force AccessibilityManagerService to re-bind
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    val finalServices = if (clearedString.isBlank()) fullFlattened else "$clearedString:$fullFlattened"
                    Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, finalServices)
                    Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)

                    try {
                        Settings.Secure.putString(cr, "accessibility_shortcut_target_service", fullFlattened)
                    } catch (_: Exception) {}

                    Log.i("SaffahProtection", "Accessibility Service re-registered in Settings.Secure. Re-bind signal emitted successfully.")
                } catch (e: Exception) {
                    Log.e("SaffahProtection", "Error re-adding accessibility service during revival: ${e.message}")
                } finally {
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        isRevivingAccessibility = false
                    }, 400L)
                }
            }, 200L)

            true
        } catch (e: Exception) {
            isRevivingAccessibility = false
            Log.e("SaffahProtection", "Error during accessibility revival: ${e.message}")
            false
        }
    }

    /**
     * Instantly and automatically enables SaffahAccessibilityService in Settings.Secure.
     * Uses WRITE_SECURE_SETTINGS / Device Owner permission to ensure Saffah is in ENABLED_ACCESSIBILITY_SERVICES
     * and sets ACCESSIBILITY_ENABLED to 1.
     *
     * If the service is present in Settings but not bound (the "Not working. Tap for info" dead binder state),
     * it automatically triggers [reviveAccessibilityService] to clear the dead state and rebind immediately.
     */
    fun ensureAccessibilityServiceEnabled(context: Context): Boolean {
        if (!hasWriteSecureSettings(context)) {
            Log.w("SaffahProtection", "Cannot auto-enable accessibility: WRITE_SECURE_SETTINGS not granted")
            return false
        }

        if (isRevivingAccessibility) {
            return true
        }

        // If the service is NOT bound in memory, check if it is already configured in Settings.
        // If it IS in Settings but NOT bound, it is trapped in the "Not working. Tap for info" dead state!
        // We MUST cycle/revive it to re-bind!
        if (!SaffahAccessibilityService.isServiceBound) {
            val isConfigured = isAccessibilityConfiguredInSettings(context)
            if (isConfigured) {
                Log.w("SaffahProtection", "Service is configured in settings but unbound ('Not working' state detected). Initiating auto-revive kick...")
                return reviveAccessibilityService(context, reason = "stale_not_working")
            }
        }

        return try {
            val cr = context.contentResolver
            val serviceComponent = ComponentName(context, SaffahAccessibilityService::class.java)
            val fullFlattened = serviceComponent.flattenToString()
            val shortFlattened = serviceComponent.flattenToShortString()

            val currentServices = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val servicesList = currentServices.split(":")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toMutableList()

            val isAlreadyPresent = servicesList.any { s ->
                s.equals(fullFlattened, ignoreCase = true) ||
                s.equals(shortFlattened, ignoreCase = true) ||
                (s.contains(context.packageName, ignoreCase = true) && s.contains("SaffahAccessibilityService", ignoreCase = true))
            }

            var updated = false
            if (!isAlreadyPresent) {
                servicesList.add(fullFlattened)
                val newServicesString = servicesList.joinToString(":")
                val success = Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, newServicesString)
                Log.i("SaffahProtection", "Auto-re-enabled SaffahAccessibilityService in ENABLED_ACCESSIBILITY_SERVICES ($success)")
                updated = true
            }

            val isGlobalEnabled = Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0)
            if (isGlobalEnabled != 1) {
                val globalSuccess = Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                Log.i("SaffahProtection", "Auto-set ACCESSIBILITY_ENABLED to 1 ($globalSuccess)")
                updated = true
            }

            try {
                val shortcutService = Settings.Secure.getString(cr, "accessibility_shortcut_target_service") ?: ""
                if (!shortcutService.contains("SaffahAccessibilityService", ignoreCase = true)) {
                    Settings.Secure.putString(cr, "accessibility_shortcut_target_service", fullFlattened)
                }
            } catch (_: Exception) {}

            true
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error in ensureAccessibilityServiceEnabled: ${e.message}")
            false
        }
    }

    /**
     * Sets whether uninstalling a specific package is blocked via Device Owner privileges.
     */
    fun setPackageUninstallBlocked(context: Context, targetPackage: String, blocked: Boolean): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName)) {
                dpm.setUninstallBlocked(adminComponent, targetPackage, blocked)
                Log.i("SaffahProtection", "DeviceOwner setUninstallBlocked for $targetPackage = $blocked")
                return true
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error setUninstallBlocked for $targetPackage: ${e.message}")
        }
        return false
    }

    /**
     * Checks if a package is currently marked as uninstall-blocked in DevicePolicyManager.
     */
    fun isPackageUninstallBlocked(context: Context, targetPackage: String): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName)) {
                return dpm.isUninstallBlocked(adminComponent, targetPackage)
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error checking isUninstallBlocked for $targetPackage: ${e.message}")
        }
        return false
    }

    /**
     * Synchronizes all user-configured uninstall-blocked applications with DevicePolicyManager.
     */
    fun syncUninstallBlockedPackages(context: Context) {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (!dpm.isDeviceOwnerApp(context.packageName)) return

            // Always enforce uninstall block for Saffah application itself
            dpm.setUninstallBlocked(adminComponent, context.packageName, true)

            val uninstallBlocked = SaffahBlockRepository.getUninstallBlockedPackages(context)
            if (!uninstallBlocked.contains("droom.sleepIfUCan")) {
                try {
                    dpm.setUninstallBlocked(adminComponent, "droom.sleepIfUCan", false)
                } catch (_: Exception) {}
            }
            for (pkg in uninstallBlocked) {
                try {
                    dpm.setUninstallBlocked(adminComponent, pkg, true)
                } catch (e: Exception) {
                    Log.w("SaffahProtection", "Failed to block uninstall for $pkg: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e("SaffahProtection", "Error in syncUninstallBlockedPackages: ${e.message}")
        }
    }

    /**
     * Attempts to ensure Notification Listener Access via Device Owner or shell commands.
     */
    fun ensureNotificationListenerAccess(context: Context) {
        try {
            val cn = ComponentName(context, com.example.service.SaffahNotificationListenerService::class.java).flattenToString()
            val shortCn = ComponentName(context, com.example.service.SaffahNotificationListenerService::class.java).flattenToShortString()
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            val isDeviceOwner = dpm != null && dpm.isDeviceOwnerApp(context.packageName)

            val current = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: ""
            if (!current.contains(cn) && !current.contains(shortCn) && !current.contains(context.packageName)) {
                val updated = if (current.isBlank()) cn else "$current:$cn"
                if (isDeviceOwner && dpm != null) {
                    try {
                        dpm.setSecureSetting(adminComponent, "enabled_notification_listeners", updated)
                    } catch (e: Exception) {
                        Log.w("SaffahProtection", "dpm setSecureSetting enabled_notification_listeners error: ${e.message}")
                    }
                }
                try {
                    Settings.Secure.putString(context.contentResolver, "enabled_notification_listeners", updated)
                } catch (_: Exception) {}

                // Privileged / shell fallbacks (Realme UI / ColorOS / Android 14)
                try {
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd notification allow_listener $cn"))
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd notification allow_listener $shortCn"))
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set ${context.packageName} ACCESS_NOTIFICATIONS allow"))
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set ${context.packageName} BIND_NOTIFICATION_LISTENER_SERVICE allow"))
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure enabled_notification_listeners \"$updated\""))
                } catch (_: Exception) {}
            }

            // Request rebind if system dropped or unbound listener
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    android.service.notification.NotificationListenerService.requestRebind(
                        ComponentName(context, com.example.service.SaffahNotificationListenerService::class.java)
                    )
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.w("SaffahProtection", "ensureNotificationListenerAccess error: ${e.message}")
        }
    }
}
