package com.example.util

import ai.onnxruntime.*
import android.graphics.Bitmap
import android.util.Log
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class AnimeCfg(
    var tR18: Float = 0.90f,
    var tR15: Float = 0.88f,
    var tSum: Float = 0.95f,
    var confirm: Int = 2,          // positives needed among the last 3 frames
    var minLumaStd: Float = 5f,
    var maxWindows: Int = 3
)

class AnimeRatingDetector(
    private val env: OrtEnvironment,
    modelBytes: ByteArray,
    val cfg: AnimeCfg
) {
    private val size = 384
    private val session: OrtSession = env.createSession(modelBytes, OrtSession.SessionOptions())
    private val history = ArrayDeque<Boolean>()
    private var cooldownUntil = 0L

    class Out(
        val probs: List<FloatArray>,
        val framePositive: Boolean,
        val trigger: Boolean,
        val ms: Long
    )

    /** bmp: software ARGB_8888, system bars already cropped. Returns null when the frame is skipped or on error. */
    fun process(bmp: Bitmap, nowMs: Long): Out? {
        val t0 = System.nanoTime()
        try {
            if (isUniform(bmp)) return null
            val wins = squareWindows(bmp)
            val n = wins.size
            val hw = size * size
            val data = FloatBuffer.allocate(n * 3 * hw)
            val px = IntArray(hw)

            for (w in wins) {
                val sc = downscale(w, size)
                sc.getPixels(px, 0, size, 0, 0, size, size)
                // Planar CHW: all R, then all G, then all B
                for (i in 0 until hw) {
                    val p = px[i]
                    data.put(((p shr 16) and 0xFF) / 127.5f - 1f)
                }
                for (i in 0 until hw) {
                    val p = px[i]
                    data.put(((p shr 8) and 0xFF) / 127.5f - 1f)
                }
                for (i in 0 until hw) {
                    val p = px[i]
                    data.put((p and 0xFF) / 127.5f - 1f)
                }
                if (sc !== w) sc.recycle()
                if (w !== bmp) w.recycle()
            }
            data.flip()

            @Suppress("UNCHECKED_CAST")
            val probs = OnnxTensor.createTensor(
                env, data, longArrayOf(n.toLong(), 3L, size.toLong(), size.toLong())
            ).use { input ->
                session.run(mapOf("input" to input)).use { res ->
                    res.get(0).value as Array<FloatArray>      // already softmax: [safe, r15, r18]
                }
            }

            val sane = probs.all { r ->
                r.size == 3 && r.none { it.isNaN() } && abs(r.sum() - 1f) < 0.01f
            }
            if (!sane) {
                Log.w("AnimeRatingDetector", "Frame scores failed sanity checks (sum != 1 or NaN); failing open")
                return null                              // log it, fail-open
            }

            val pos = probs.any { isPositive(it) }
            history.addLast(pos)
            while (history.size > 3) history.removeFirst()

            var trigger = false
            if (nowMs >= cooldownUntil && history.count { it } >= cfg.confirm) {
                trigger = true
                history.clear()
                cooldownUntil = nowMs + 3000L
            }

            return Out(probs.toList(), pos, trigger, (System.nanoTime() - t0) / 1_000_000)
        } catch (e: Throwable) {
            Log.w("AnimeRatingDetector", "Fail-open exception during anime inference: ${e.message}")
            return null                                         // log e, fail-open
        }
    }

    private fun isPositive(p: FloatArray): Boolean =
        p[2] >= cfg.tR18 || p[1] >= cfg.tR15 || (p[1] + p[2]) >= cfg.tSum

    /** 1 to 3 square crops evenly spaced along the long axis. */
    private fun squareWindows(bmp: Bitmap): List<Bitmap> {
        val w = bmp.width
        val h = bmp.height
        val side = minOf(w, h)
        val n = ceil(maxOf(w, h).toFloat() / side - 0.15f).toInt().coerceIn(1, cfg.maxWindows)
        if (n == 1) {
            val x = (w - side) / 2
            val y = (h - side) / 2
            return listOf(Bitmap.createBitmap(bmp, x, y, side, side))
        }
        val out = ArrayList<Bitmap>(n)
        val step = (maxOf(w, h) - side).toFloat() / (n - 1)
        for (i in 0 until n) {
            val off = (i * step).roundToInt()
            val (x, y) = if (w >= h) off to 0 else 0 to off
            out.add(Bitmap.createBitmap(bmp, x, y, side, side))
        }
        return out
    }

    /** Repeated halving until < 768, then final scale. */
    private fun downscale(src: Bitmap, target: Int): Bitmap {
        var cur = src
        while (cur.width >= target * 2) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val fin = Bitmap.createScaledBitmap(cur, target, target, true)
        if (cur !== src && cur !== fin) cur.recycle()
        return fin
    }

    /** Rejects pure black/white/flat frames (std < 5). A 64x64 black frame scores r15=0.41 on this model. */
    private fun isUniform(bmp: Bitmap): Boolean {
        val s = Bitmap.createScaledBitmap(bmp, 64, 64, false)
        val px = IntArray(64 * 64)
        s.getPixels(px, 0, 64, 0, 0, 64, 64)
        if (s !== bmp) s.recycle()

        var sum = 0.0
        var sumSq = 0.0
        for (p in px) {
            val y = 0.299 * ((p shr 16) and 0xFF) + 0.587 * ((p shr 8) and 0xFF) + 0.114 * (p and 0xFF)
            sum += y
            sumSq += y * y
        }
        val mean = sum / px.size
        val variance = sumSq / px.size - mean * mean
        val std = sqrt(maxOf(0.0, variance))
        return std < cfg.minLumaStd
    }

    fun resetHistory() = clearHistory()
    fun clearHistory() {
        history.clear()
    }

    fun getHistoryCount(): Int = history.count { it }
    fun getHistoryTotal(): Int = history.size

    fun close() {
        try {
            session.close()
        } catch (_: Exception) {}
    }
}
