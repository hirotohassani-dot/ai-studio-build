package com.example.util

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import com.example.receiver.SaffahBedtimeReceiver
import com.example.receiver.SaffahDeviceAdminReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

object SaffahBedtimeManager {

    const val ACTION_BEDTIME_START = "com.example.ACTION_BEDTIME_START"
    const val ACTION_BEDTIME_END = "com.example.ACTION_BEDTIME_END"
    const val ACTION_BEDTIME_PRE_START = "com.example.ACTION_BEDTIME_PRE_START"

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isTestingGrayscaleActive = false

    @Volatile
    private var lastAppliedGrayscaleState: Boolean? = null
    @Volatile
    private var lastAppliedEyeComfortState: Boolean? = null

    /**
     * Check if app has permission to write system secure settings
     */
    fun hasWriteSecureSettingsPermission(context: Context): Boolean {
        return try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val isDeviceOwner = dpm != null && dpm.isDeviceOwnerApp(context.packageName)
            if (isDeviceOwner) return true

            context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Check if hardware grayscale is supported & active
     */
    fun isHardwareGrayscaleAvailable(context: Context): Boolean {
        if (hasWriteSecureSettingsPermission(context)) return true
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        return dpm != null && dpm.isDeviceOwnerApp(context.packageName)
    }

    fun evaluateBedtimeState(context: Context) {
        if (isTestingGrayscaleActive) return

        val isBedtimeEnabled = SaffahBlockRepository.isBedtimeModeEnabled(context)
        val isBedtimeActive = SaffahBlockRepository.isCurrentlyBedtime(context)
        val inBedtime = isBedtimeActive && isBedtimeEnabled

        // Automatic Grayscale: Turns on 30 minutes before bedtime starts and turns off when bedtime ends
        val shouldApplyGrayscale = SaffahBlockRepository.isCurrentlyInBedtimeGrayscaleWindow(context)
        applySystemGrayscale(context, shouldApplyGrayscale)

        // Automatic Eye Comfort: Turns on 30 minutes before bedtime starts and turns off when bedtime ends
        val shouldApplyEyeComfort = SaffahBlockRepository.isCurrentlyInBedtimeEyeComfortWindow(context)
        applySystemEyeComfort(context, shouldApplyEyeComfort)

        // Ensure OEM charging DND/Bedtime flags remain permanently disabled
        SaffahChargingManager.disableOemChargingDndTriggers(context)

        // Apply DevicePolicyManager package suspension for disallowed apps during bedtime
        updateBedtimePackageSuspension(context, inBedtime)

        // Re-schedule alarms
        scheduleBedtimeAlarms(context)
    }

    @Volatile private var lastBedtimeSuspensionState: Boolean? = null
    @Volatile private var lastScheduledBedtimeConfig: String = ""
    @Volatile private var lastAlarmScheduleTime: Long = 0L

    fun updateBedtimePackageSuspension(context: Context, isBedtimeActive: Boolean, force: Boolean = false) {
        if (force || lastBedtimeSuspensionState != isBedtimeActive) {
            lastBedtimeSuspensionState = isBedtimeActive
            SaffahBlockRepository.syncAllPackageSuspensions(context)
        }
    }

    fun scheduleBedtimeAlarms(context: Context, force: Boolean = false) {
        if (!SaffahBlockRepository.isBedtimeModeEnabled(context)) {
            cancelBedtimeAlarms(context)
            lastScheduledBedtimeConfig = "disabled"
            return
        }

        val schedule = SaffahBlockRepository.getBedtimeSchedule(context)
        val configKey = "enabled-${schedule.first.first}:${schedule.first.second}-${schedule.second.first}:${schedule.second.second}"
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && configKey == lastScheduledBedtimeConfig && (now - lastAlarmScheduleTime < 10_000L)) {
            return
        }
        lastScheduledBedtimeConfig = configKey
        lastAlarmScheduleTime = now

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val startH = schedule.first.first
        val startM = schedule.first.second
        val endH = schedule.second.first
        val endM = schedule.second.second

        val nextStartCal = getNextCalendarForTime(startH, startM)
        val nextEndCal = getNextCalendarForTime(endH, endM)

        // Calculate 30 minutes before bedtime start
        var preH = startH
        var preM = startM - 30
        if (preM < 0) {
            preM += 60
            preH -= 1
            if (preH < 0) {
                preH += 24
            }
        }
        val nextPreStartCal = getNextCalendarForTime(preH, preM)

        val preStartIntent = Intent(context, SaffahBedtimeReceiver::class.java).apply {
            action = ACTION_BEDTIME_PRE_START
        }
        val preStartPendingIntent = PendingIntent.getBroadcast(
            context,
            1003,
            preStartIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val startIntent = Intent(context, SaffahBedtimeReceiver::class.java).apply {
            action = ACTION_BEDTIME_START
        }
        val startPendingIntent = PendingIntent.getBroadcast(
            context,
            1001,
            startIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val endIntent = Intent(context, SaffahBedtimeReceiver::class.java).apply {
            action = ACTION_BEDTIME_END
        }
        val endPendingIntent = PendingIntent.getBroadcast(
            context,
            1002,
            endIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                alarmManager.setAlarmClock(
                    AlarmManager.AlarmClockInfo(nextPreStartCal.timeInMillis, preStartPendingIntent),
                    preStartPendingIntent
                )
                alarmManager.setAlarmClock(
                    AlarmManager.AlarmClockInfo(nextStartCal.timeInMillis, startPendingIntent),
                    startPendingIntent
                )
                alarmManager.setAlarmClock(
                    AlarmManager.AlarmClockInfo(nextEndCal.timeInMillis, endPendingIntent),
                    endPendingIntent
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    nextPreStartCal.timeInMillis,
                    preStartPendingIntent
                )
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    nextStartCal.timeInMillis,
                    startPendingIntent
                )
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    nextEndCal.timeInMillis,
                    endPendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    nextPreStartCal.timeInMillis,
                    preStartPendingIntent
                )
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    nextStartCal.timeInMillis,
                    startPendingIntent
                )
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    nextEndCal.timeInMillis,
                    endPendingIntent
                )
            }
            Log.i("SaffahBedtime", "Bedtime alarms scheduled: Pre-start at ${nextPreStartCal.time}, Start at ${nextStartCal.time}, End at ${nextEndCal.time}")
        } catch (e: SecurityException) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextPreStartCal.timeInMillis, preStartPendingIntent)
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextStartCal.timeInMillis, startPendingIntent)
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextEndCal.timeInMillis, endPendingIntent)
                } else {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, nextPreStartCal.timeInMillis, preStartPendingIntent)
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, nextStartCal.timeInMillis, startPendingIntent)
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, nextEndCal.timeInMillis, endPendingIntent)
                }
            } catch (_: Exception) {
                alarmManager.set(AlarmManager.RTC_WAKEUP, nextPreStartCal.timeInMillis, preStartPendingIntent)
                alarmManager.set(AlarmManager.RTC_WAKEUP, nextStartCal.timeInMillis, startPendingIntent)
                alarmManager.set(AlarmManager.RTC_WAKEUP, nextEndCal.timeInMillis, endPendingIntent)
            }
        } catch (e: Exception) {
            Log.e("SaffahBedtime", "Error scheduling alarms: ${e.message}")
        }
    }

    fun cancelBedtimeAlarms(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val preStartIntent = Intent(context, SaffahBedtimeReceiver::class.java).apply { action = ACTION_BEDTIME_PRE_START }
        val preStartPendingIntent = PendingIntent.getBroadcast(
            context, 1003, preStartIntent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (preStartPendingIntent != null) {
            alarmManager.cancel(preStartPendingIntent)
            preStartPendingIntent.cancel()
        }

        val startIntent = Intent(context, SaffahBedtimeReceiver::class.java).apply { action = ACTION_BEDTIME_START }
        val startPendingIntent = PendingIntent.getBroadcast(
            context, 1001, startIntent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (startPendingIntent != null) {
            alarmManager.cancel(startPendingIntent)
            startPendingIntent.cancel()
        }

        val endIntent = Intent(context, SaffahBedtimeReceiver::class.java).apply { action = ACTION_BEDTIME_END }
        val endPendingIntent = PendingIntent.getBroadcast(
            context, 1002, endIntent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (endPendingIntent != null) {
            alarmManager.cancel(endPendingIntent)
            endPendingIntent.cancel()
        }
        lastAppliedGrayscaleState = null
        lastAppliedEyeComfortState = null
        applySystemGrayscale(context, false, force = true)
        applySystemEyeComfort(context, false, force = true)
        SaffahChargingManager.disableOemChargingDndTriggers(context)
    }

    /**
     * Multi-Tier System-Level Hardware Grayscale & Adaptive Fallback
     * Handles Realme UI (ColorOS 14), Android 14 Daltonizer, Device Owner, ADB & Overlay fallback
     */
    fun applySystemGrayscale(context: Context, enable: Boolean, force: Boolean = false) {
        if (!force && lastAppliedGrayscaleState == enable) {
            return
        }
        lastAppliedGrayscaleState = enable
        var hardwareSuccess = false

        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            val isDeviceOwner = dpm != null && dpm.isDeviceOwnerApp(context.packageName)

            val daltonizerEnabledStr = if (enable) "1" else "0"
            val daltonizerModeStr = "0" // 0 = Monochromacy (Grayscale)

            // Method 1: DevicePolicyManager setSecureSetting (Device Owner standard mechanism)
            if (isDeviceOwner && dpm != null) {
                try {
                    dpm.setSecureSetting(adminComponent, "accessibility_display_daltonizer_enabled", daltonizerEnabledStr)
                    dpm.setSecureSetting(adminComponent, "accessibility_display_daltonizer", daltonizerModeStr)
                    hardwareSuccess = true
                    Log.i("SaffahBedtime", "Grayscale applied via DPM setSecureSetting: enabled=$enable")
                } catch (e: Exception) {
                    Log.w("SaffahBedtime", "DPM setSecureSetting error: ${e.message}")
                }
            }

            // Method 2: Direct Settings.Secure and Settings.System writes (WRITE_SECURE_SETTINGS)
            try {
                // Android standard Daltonizer
                Settings.Secure.putInt(
                    context.contentResolver,
                    "accessibility_display_daltonizer_enabled",
                    if (enable) 1 else 0
                )
                Settings.Secure.putInt(
                    context.contentResolver,
                    "accessibility_display_daltonizer",
                    0
                )
                // Color inversion safety
                Settings.Secure.putInt(
                    context.contentResolver,
                    "accessibility_display_inversion_enabled",
                    0
                )

                // Realme UI / ColorOS / Oppo / OxygenOS specific keys
                try {
                    Settings.Secure.putInt(context.contentResolver, "color_mode_grayscale", if (enable) 1 else 0)
                } catch (_: Exception) {}
                try {
                    // CRITICAL: NEVER set bedtime_mode_grayscale to 1. In ColorOS/Realme UI, this triggers
                    // native bedtime mode which turns on Do Not Disturb (DND) and displays the floating volume
                    // panel when plugging in the charger! Always force to 0.
                    Settings.Secure.putInt(context.contentResolver, "bedtime_mode_grayscale", 0)
                } catch (_: Exception) {}
                try {
                    Settings.System.putInt(context.contentResolver, "reading_mode_status", if (enable) 1 else 0)
                } catch (_: Exception) {}
                try {
                    Settings.System.putInt(context.contentResolver, "oppo_settings_grayscale", if (enable) 1 else 0)
                } catch (_: Exception) {}

                hardwareSuccess = true
                Log.i("SaffahBedtime", "Grayscale applied via Settings.Secure write: enabled=$enable")
            } catch (e: Exception) {
                Log.w("SaffahBedtime", "Settings.Secure write failed (permission needed): ${e.message}")
            }

            // Method 3: Direct Shell execution (if root or system UID)
            if (!hardwareSuccess) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        if (enable) {
                            Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure accessibility_display_daltonizer_enabled 1 && settings put secure accessibility_display_daltonizer 0"))
                            Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd color_display set-saturation-level 0"))
                        } else {
                            Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure accessibility_display_daltonizer_enabled 0"))
                            Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd color_display set-saturation-level 100"))
                        }
                    } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.e("SaffahBedtime", "Error applying system grayscale: ${e.message}")
        }
    }

    /**
     * Multi-Tier System-Level Hardware Eye Comfort & Adaptive Fallback
     * Handles Realme UI (ColorOS 14), Android 14 Night Light (night_display_activated), Device Owner, ADB & Overlay fallback
     */
    fun applySystemEyeComfort(context: Context, enable: Boolean, force: Boolean = false) {
        if (!force && lastAppliedEyeComfortState == enable) {
            return
        }
        lastAppliedEyeComfortState = enable
        var hardwareSuccess = false

        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            val isDeviceOwner = dpm != null && dpm.isDeviceOwnerApp(context.packageName)

            val activatedStr = if (enable) "1" else "0"

            // Method 1: DevicePolicyManager setSecureSetting (Device Owner standard mechanism)
            if (isDeviceOwner && dpm != null) {
                try {
                    dpm.setSecureSetting(adminComponent, "night_display_activated", activatedStr)
                    dpm.setSecureSetting(adminComponent, "night_display_auto_mode", "0")
                    hardwareSuccess = true
                    Log.i("SaffahBedtime", "Eye comfort applied via DPM setSecureSetting: enabled=$enable")
                } catch (e: Exception) {
                    Log.w("SaffahBedtime", "DPM setSecureSetting eye comfort error: ${e.message}")
                }
            }

            // Method 2: Direct Settings.Secure / System writes (WRITE_SECURE_SETTINGS)
            try {
                // Android standard Night Display
                Settings.Secure.putInt(
                    context.contentResolver,
                    "night_display_activated",
                    if (enable) 1 else 0
                )
                Settings.Secure.putInt(
                    context.contentResolver,
                    "night_display_auto_mode",
                    0
                )

                // Realme UI / ColorOS / Oppo / OxygenOS specific keys
                try {
                    Settings.Secure.putInt(context.contentResolver, "color_mode_comfort", if (enable) 1 else 0)
                } catch (_: Exception) {}
                try {
                    Settings.Secure.putInt(context.contentResolver, "color_mode_comfort_status", if (enable) 1 else 0)
                } catch (_: Exception) {}
                try {
                    Settings.System.putInt(context.contentResolver, "color_mode_comfort", if (enable) 1 else 0)
                } catch (_: Exception) {}
                try {
                    Settings.System.putInt(context.contentResolver, "color_mode_comfort_status", if (enable) 1 else 0)
                } catch (_: Exception) {}
                try {
                    Settings.System.putInt(context.contentResolver, "eyes_protect_mode", if (enable) 1 else 0)
                } catch (_: Exception) {}
                try {
                    Settings.System.putInt(context.contentResolver, "color_mode_night", if (enable) 1 else 0)
                } catch (_: Exception) {}

                hardwareSuccess = true
                Log.i("SaffahBedtime", "Eye comfort applied via Settings write: enabled=$enable")
            } catch (e: Exception) {
                Log.w("SaffahBedtime", "Settings write for eye comfort failed: ${e.message}")
            }

            // Method 3: Direct Shell execution (if root, system UID, or Shizuku)
            if (!hardwareSuccess) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val state = if (enable) "1" else "0"
                        Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd color_display set-night-display-activated $state"))
                        Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure night_display_activated $state"))
                        Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put secure color_mode_comfort $state"))
                        Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put system color_mode_comfort $state"))
                    } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.e("SaffahBedtime", "Error applying system eye comfort: ${e.message}")
        }
    }

    /**
     * Instant Grayscale Test for 5 seconds to verify functionality on user's device
     */
    fun testGrayscale(context: Context, durationSeconds: Int = 5, onFinished: (() -> Unit)? = null) {
        isTestingGrayscaleActive = true
        applySystemGrayscale(context, true, force = true)

        mainHandler.postDelayed({
            isTestingGrayscaleActive = false
            applySystemGrayscale(context, false, force = true)
            // Re-evaluate normal bedtime schedule state
            evaluateBedtimeState(context)
            onFinished?.invoke()
        }, durationSeconds * 1000L)
    }

    private fun getNextCalendarForTime(hour: Int, minute: Int): Calendar {
        val target = Calendar.getInstance()
        val nowMillis = target.timeInMillis
        target.set(Calendar.HOUR_OF_DAY, hour)
        target.set(Calendar.MINUTE, minute)
        target.set(Calendar.SECOND, 0)
        target.set(Calendar.MILLISECOND, 0)
        if (target.timeInMillis <= nowMillis) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target
    }
}
