package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class AppInfoItem(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val isSystemApp: Boolean = false,
    val isAllowed: Boolean = false
)

object AppListHelper {

    // Fast in-memory bounded LRU cache for app icons and items
    private val iconCache = android.util.LruCache<String, Drawable>(200)
    private val appNameCache = android.util.LruCache<String, String>(500)
    private val negativeIconCache = ConcurrentHashMap<String, Boolean>()

    private const val PREFS_PERSISTED_LABELS = "saffah_persisted_app_labels"
    private const val ICONS_DIR_NAME = "saffah_app_icons"

    @Volatile private var cachedFilteredApps: List<AppInfoItem>? = null
    @Volatile private var cacheTimestamp: Long = 0L
    private const val CACHE_TTL_MS = 10 * 60 * 1000L // 10 minutes cache TTL

    // Shared flow to broadcast real-time package installation/removal events
    private val _packageChangeEvents = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val packageChangeEvents: SharedFlow<String> = _packageChangeEvents.asSharedFlow()

    fun invalidateCache() {
        cachedFilteredApps = null
        cacheTimestamp = 0L
    }

    fun notifyPackageChanged(context: Context, packageName: String?) {
        invalidateCache()
        negativeIconCache.clear()
        if (!packageName.isNullOrBlank()) {
            _packageChangeEvents.tryEmit(packageName)
        } else {
            _packageChangeEvents.tryEmit("ALL")
        }
    }

    fun clearMemoryCaches() {
        synchronized(iconCache) { iconCache.evictAll() }
        synchronized(appNameCache) { appNameCache.evictAll() }
        negativeIconCache.clear()
        invalidateCache()
    }

    fun getCachedIcon(packageName: String): Drawable? {
        return synchronized(iconCache) { iconCache.get(packageName) }
    }

    fun cacheIcon(packageName: String, drawable: Drawable?) {
        if (drawable != null) {
            synchronized(iconCache) { iconCache.put(packageName, drawable) }
        }
    }

    fun getCachedAppName(packageName: String): String? {
        return synchronized(appNameCache) { appNameCache.get(packageName) }
    }

    fun cacheAppName(packageName: String, name: String) {
        if (name.isNotBlank()) {
            synchronized(appNameCache) { appNameCache.put(packageName, name) }
        }
    }

    fun cacheAppName(context: Context, packageName: String, name: String) {
        if (name.isNotBlank()) {
            synchronized(appNameCache) { appNameCache.put(packageName, name) }
            try {
                val prefs = context.getSharedPreferences(PREFS_PERSISTED_LABELS, Context.MODE_PRIVATE)
                prefs.edit().putString(packageName, name).apply()
            } catch (_: Exception) {}
        }
    }

    private fun saveIconToDisk(context: Context, packageName: String, drawable: Drawable) {
        try {
            val iconsDir = File(context.filesDir, ICONS_DIR_NAME)
            if (!iconsDir.exists()) iconsDir.mkdirs()
            val iconFile = File(iconsDir, "${packageName}.png")
            if (iconFile.exists()) return

            val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth.coerceIn(48, 144) else 96
            val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight.coerceIn(48, 144) else 96
            val bitmap = if (drawable is BitmapDrawable && drawable.bitmap != null) {
                drawable.bitmap
            } else {
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bmp
            }
            FileOutputStream(iconFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, out)
            }
        } catch (_: Exception) {}
    }

    private fun loadIconFromDisk(context: Context, packageName: String): Drawable? {
        try {
            val iconFile = File(context.filesDir, "$ICONS_DIR_NAME/${packageName}.png")
            if (iconFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(iconFile.absolutePath)
                if (bitmap != null) {
                    return BitmapDrawable(context.resources, bitmap)
                }
            }
        } catch (_: Exception) {}
        return null
    }

    private fun generateDynamicMonogramDrawable(context: Context, label: String, packageName: String): Drawable {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val colors = intArrayOf(
            0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFE53935.toInt(),
            0xFF8E24AA.toInt(), 0xFF00897B.toInt(), 0xFFF4511E.toInt(),
            0xFF5E35B1.toInt(), 0xFF039BE5.toInt(), 0xFFD81B60.toInt(),
            0xFF3949AB.toInt(), 0xFF00ACC1.toInt(), 0xFF7CB342.toInt()
        )
        val colorIndex = Math.abs(packageName.hashCode()) % colors.size
        val bgColor = colors[colorIndex]

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bgColor
            style = Paint.Style.FILL
        }
        val radius = size / 2f
        canvas.drawCircle(radius, radius, radius, bgPaint)

        val firstChar = label.trim().take(1).uppercase(Locale.getDefault()).ifEmpty {
            packageName.substringAfterLast('.').take(1).uppercase(Locale.getDefault())
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 40f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bounds = Rect()
        textPaint.getTextBounds(firstChar, 0, firstChar.length, bounds)
        val y = radius + bounds.height() / 2f - bounds.bottom
        canvas.drawText(firstChar, radius, y, textPaint)

        return BitmapDrawable(context.resources, bmp)
    }

    fun resolveIconFast(context: Context, sourceAppOrPkg: String): Drawable? {
        if (sourceAppOrPkg.isBlank()) return null
        val cached = synchronized(iconCache) { iconCache.get(sourceAppOrPkg) }
        if (cached != null) return cached

        val pm = context.packageManager
        // 1. Direct package lookup
        try {
            val icon = pm.getApplicationIcon(sourceAppOrPkg)
            synchronized(iconCache) { iconCache.put(sourceAppOrPkg, icon) }
            saveIconToDisk(context, sourceAppOrPkg, icon)
            return icon
        } catch (_: Exception) {}

        // 2. Disk cache for previously installed/selected apps
        val diskIcon = loadIconFromDisk(context, sourceAppOrPkg)
        if (diskIcon != null) {
            synchronized(iconCache) { iconCache.put(sourceAppOrPkg, diskIcon) }
            return diskIcon
        }

        // 3. Common package aliases
        val lower = sourceAppOrPkg.lowercase().trim()
        val aliasPkg = when {
            lower == "youtube" || lower.contains("youtube") -> "com.google.android.youtube"
            lower == "tor" || lower.contains("tor") -> "org.torproject.torbrowser"
            lower.contains("edge") -> "com.microsoft.emmx"
            lower.contains("brave") -> "com.brave.browser"
            lower.contains("opera") -> "com.opera.browser"
            lower.contains("duckduckgo") -> "com.duckduckgo.mobile.android"
            lower.contains("vivaldi") -> "com.vivaldi.browser"
            lower.contains("samsung") -> "com.sec.android.app.sbrowser"
            lower.contains("spin") -> "com.nationaledtech.spinbrowser"
            lower.contains("quetta") -> "net.quetta.browser"
            lower.contains("1dm") || lower.contains("idm.internet") -> "idm.internet.download.manager"
            lower == "chrome" || lower.contains("chrome") -> "com.android.chrome"
            lower == "browser" || lower.contains("browser") -> "com.android.chrome"
            lower == "telegram" || lower.contains("telegram") -> "org.telegram.messenger"
            lower == "whatsapp" || lower.contains("whatsapp") -> "com.whatsapp"
            lower == "instagram" || lower.contains("instagram") -> "com.instagram.android"
            lower == "tiktok" || lower.contains("tiktok") -> "com.zhiliaoapp.musically"
            lower == "facebook" || lower.contains("facebook") -> "com.facebook.katana"
            lower.contains("lite") && lower.contains("facebook") -> "com.facebook.lite"
            lower == "x" || lower == "twitter" -> "com.twitter.android"
            else -> null
        }
        if (aliasPkg != null) {
            try {
                val icon = pm.getApplicationIcon(aliasPkg)
                synchronized(iconCache) {
                    iconCache.put(sourceAppOrPkg, icon)
                    iconCache.put(aliasPkg, icon)
                }
                saveIconToDisk(context, sourceAppOrPkg, icon)
                return icon
            } catch (_: Exception) {}

            val aliasDiskIcon = loadIconFromDisk(context, aliasPkg)
            if (aliasDiskIcon != null) {
                synchronized(iconCache) { iconCache.put(sourceAppOrPkg, aliasDiskIcon) }
                return aliasDiskIcon
            }
        }

        // 4. Generate beautiful dynamic monogram icon for uninstalled apps
        val label = resolveAppLabelFast(context, sourceAppOrPkg)
        val monogram = generateDynamicMonogramDrawable(context, label, sourceAppOrPkg)
        synchronized(iconCache) { iconCache.put(sourceAppOrPkg, monogram) }
        return monogram
    }

    fun resolveAppLabelFast(context: Context, sourceAppOrPkg: String): String {
        if (sourceAppOrPkg.isBlank()) return "تطبيق محمي"
        synchronized(appNameCache) { appNameCache.get(sourceAppOrPkg) }?.let { return it }

        // 1. Direct PackageManager query
        val pm = context.packageManager
        try {
            val appInfo = pm.getApplicationInfo(sourceAppOrPkg, 0)
            val label = pm.getApplicationLabel(appInfo).toString()
            if (label.isNotBlank()) {
                cacheAppName(context, sourceAppOrPkg, label)
                return label
            }
        } catch (_: Exception) {}

        // 2. Check persistent SharedPreferences labels (preserves uninstalled app names)
        try {
            val prefs = context.getSharedPreferences(PREFS_PERSISTED_LABELS, Context.MODE_PRIVATE)
            val savedLabel = prefs.getString(sourceAppOrPkg, null)
            if (!savedLabel.isNullOrBlank()) {
                synchronized(appNameCache) { appNameCache.put(sourceAppOrPkg, savedLabel) }
                return savedLabel
            }
        } catch (_: Exception) {}

        // 3. Known package aliases
        val lower = sourceAppOrPkg.lowercase().trim()
        val aliasLabel = when {
            lower.contains("chrome") -> "Google Chrome"
            lower.contains("coloros.browser") || lower.contains("heytap.browser") -> "متصفح النظام الافتراضي"
            lower.contains("browser") -> "متصفح الإنترنت"
            lower.contains("youtube") -> "YouTube"
            lower.contains("instagram") -> "Instagram"
            lower.contains("tiktok") || lower.contains("musically") -> "TikTok"
            lower.contains("telegram") -> "Telegram"
            lower.contains("whatsapp") -> "WhatsApp"
            lower.contains("facebook") -> "Facebook"
            lower.contains("twitter") || lower.contains("com.twitter") -> "X (Twitter)"
            lower.contains("snapchat") -> "Snapchat"
            lower.contains("pubg") -> "PUBG Mobile"
            lower.contains("freefire") -> "Free Fire"
            lower.contains("roblox") -> "Roblox"
            lower.contains("clashofclans") -> "Clash of Clans"
            else -> null
        }
        if (aliasLabel != null) {
            cacheAppName(context, sourceAppOrPkg, aliasLabel)
            return aliasLabel
        }

        // 4. Clean package name fallback (e.g. "com.example.game" -> "Game")
        val cleanName = sourceAppOrPkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        val fallback = if (cleanName.isNotBlank() && cleanName != sourceAppOrPkg) cleanName else sourceAppOrPkg
        cacheAppName(context, sourceAppOrPkg, fallback)
        return fallback
    }

    fun getFilteredInstalledApps(context: Context, forceRefresh: Boolean = false): List<AppInfoItem> {
        val now = System.currentTimeMillis()
        val isCacheValid = !forceRefresh && cachedFilteredApps != null && (now - cacheTimestamp < CACHE_TTL_MS)
        if (isCacheValid) {
            val allowedApps = SaffahBlockRepository.getBedtimeAllowedApps(context)
            return cachedFilteredApps!!.map { it.copy(isAllowed = allowedApps.contains(it.packageName)) }
        }

        val pm = context.packageManager
        val allowedApps = SaffahBlockRepository.getBedtimeAllowedApps(context)
        val currentPkg = context.packageName

        val appMap = mutableMapOf<String, AppInfoItem>()

        // 1. Query all launcher intent activities (Apps with launcher icons)
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        try {
            val resolveInfos = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(mainIntent, 0)
            }
            for (info in resolveInfos) {
                val actInfo = info.activityInfo ?: continue
                val pkg = actInfo.packageName ?: continue
                if (pkg == currentPkg) continue

                val isSystem = (actInfo.applicationInfo?.flags?.and(ApplicationInfo.FLAG_SYSTEM) ?: 0) != 0 ||
                        (actInfo.applicationInfo?.flags?.and(ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) ?: 0) != 0

                val label = getCachedAppName(pkg) ?: try {
                    val l = info.loadLabel(pm).toString().trim()
                    if (l.isNotBlank()) {
                        cacheAppName(context, pkg, l)
                        l
                    } else {
                        val fallback = pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
                        cacheAppName(context, pkg, fallback)
                        fallback
                    }
                } catch (_: Exception) {
                    pkg
                }

                val icon = getCachedIcon(pkg) ?: try {
                    val ic = info.loadIcon(pm)
                    if (ic != null) {
                        cacheIcon(pkg, ic)
                        saveIconToDisk(context, pkg, ic)
                    }
                    ic
                } catch (_: Exception) { null }

                appMap[pkg] = AppInfoItem(
                    packageName = pkg,
                    appName = label,
                    icon = icon ?: resolveIconFast(context, pkg),
                    isSystemApp = isSystem,
                    isAllowed = allowedApps.contains(pkg)
                )
            }
        } catch (_: Exception) {}

        // 2. Query all installed applications to include ALL user-installed apps and background apps
        val installedApplications = try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
        } catch (e: Exception) {
            emptyList()
        }

        for (appInfo in installedApplications) {
            val pkg = appInfo.packageName ?: continue
            if (pkg == currentPkg) continue

            if (appMap.containsKey(pkg)) continue

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

            val label = getCachedAppName(pkg) ?: try {
                val loadedLabel = appInfo.loadLabel(pm).toString().trim()
                if (loadedLabel.isNotBlank()) {
                    cacheAppName(context, pkg, loadedLabel)
                    loadedLabel
                } else {
                    val fallbackName = pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
                    cacheAppName(context, pkg, fallbackName)
                    fallbackName
                }
            } catch (_: Exception) {
                pkg
            }

            val icon = getCachedIcon(pkg) ?: try {
                val loaded = appInfo.loadIcon(pm)
                if (loaded != null) {
                    cacheIcon(pkg, loaded)
                    saveIconToDisk(context, pkg, loaded)
                }
                loaded
            } catch (_: Exception) { null }

            appMap[pkg] = AppInfoItem(
                packageName = pkg,
                appName = label,
                icon = icon ?: resolveIconFast(context, pkg),
                isSystemApp = isSystem,
                isAllowed = allowedApps.contains(pkg)
            )
        }

        // 3. Fallback: Query all installed packages directly to catch split APKs
        try {
            val installedPackages = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(0)
            }
            for (pkgInfo in installedPackages) {
                val pkg = pkgInfo.packageName ?: continue
                if (pkg == currentPkg || appMap.containsKey(pkg)) continue

                val appInfo = pkgInfo.applicationInfo
                val isSystem = if (appInfo != null) {
                    (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                            (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                } else false

                val label = getCachedAppName(pkg) ?: try {
                    val loadedLabel = appInfo?.loadLabel(pm)?.toString()?.trim()
                    if (!loadedLabel.isNullOrBlank()) {
                        cacheAppName(context, pkg, loadedLabel)
                        loadedLabel
                    } else {
                        val fallbackName = pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
                        cacheAppName(context, pkg, fallbackName)
                        fallbackName
                    }
                } catch (_: Exception) {
                    pkg
                }

                val icon = getCachedIcon(pkg) ?: try {
                    val loaded = appInfo?.loadIcon(pm)
                    if (loaded != null) {
                        cacheIcon(pkg, loaded)
                        saveIconToDisk(context, pkg, loaded)
                    }
                    loaded
                } catch (_: Exception) { null }

                appMap[pkg] = AppInfoItem(
                    packageName = pkg,
                    appName = label,
                    icon = icon ?: resolveIconFast(context, pkg),
                    isSystemApp = isSystem,
                    isAllowed = allowedApps.contains(pkg)
                )
            }
        } catch (_: Exception) {}

        // 4. CRITICAL: Include all uninstalled apps that are configured in ANY Saffah feature
        // (Keyword exemptions, Permanent block, Bedtime allowed, App schedule rules, Usage limits, Uninstall block, VPN exclusions, Productivity)
        try {
            val configuredPackages = SaffahBlockRepository.getAllConfiguredPackagesAcrossAllFeatures(context)
            for (pkg in configuredPackages) {
                if (pkg.isBlank() || pkg == currentPkg || appMap.containsKey(pkg)) continue
                val label = resolveAppLabelFast(context, pkg)
                val icon = resolveIconFast(context, pkg)
                appMap[pkg] = AppInfoItem(
                    packageName = pkg,
                    appName = label,
                    icon = icon,
                    isSystemApp = false,
                    isAllowed = allowedApps.contains(pkg)
                )
            }
        } catch (_: Exception) {}

        // Sort by user apps first, then system apps, then alphabetically by name
        val sorted = appMap.values.sortedWith(
            compareBy<AppInfoItem> { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
        cachedFilteredApps = sorted
        cacheTimestamp = now
        return sorted
    }
}
