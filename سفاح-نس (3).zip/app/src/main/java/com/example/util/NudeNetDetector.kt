package com.example.util

import ai.onnxruntime.*
import android.graphics.Bitmap
import android.util.Log
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.sqrt

object NN {   // class ids, exactly as in the model metadata
    const val FEMALE_GENITALIA_COVERED = 0; const val FACE_FEMALE = 1; const val BUTTOCKS_EXPOSED = 2
    const val FEMALE_BREAST_EXPOSED = 3; const val FEMALE_GENITALIA_EXPOSED = 4; const val MALE_BREAST_EXPOSED = 5
    const val ANUS_EXPOSED = 6; const val FEET_EXPOSED = 7; const val BELLY_COVERED = 8; const val FEET_COVERED = 9
    const val ARMPITS_COVERED = 10; const val ARMPITS_EXPOSED = 11; const val FACE_MALE = 12; const val BELLY_EXPOSED = 13
    const val MALE_GENITALIA_EXPOSED = 14; const val ANUS_COVERED = 15; const val FEMALE_BREAST_COVERED = 16
    const val BUTTOCKS_COVERED = 17

    val NAMES = arrayOf(
        "FEMALE_GENITALIA_COVERED", "FACE_FEMALE", "BUTTOCKS_EXPOSED", "FEMALE_BREAST_EXPOSED",
        "FEMALE_GENITALIA_EXPOSED", "MALE_BREAST_EXPOSED", "ANUS_EXPOSED", "FEET_EXPOSED", "BELLY_COVERED",
        "FEET_COVERED", "ARMPITS_COVERED", "ARMPITS_EXPOSED", "FACE_MALE", "BELLY_EXPOSED",
        "MALE_GENITALIA_EXPOSED", "ANUS_COVERED", "FEMALE_BREAST_COVERED", "BUTTOCKS_COVERED"
    )
}

data class NudeCfg(
    var tFemaleGenExp: Float = 0.45f,
    var tMaleGenExp: Float = 0.45f,
    var tAnusExp: Float = 0.50f,
    var tFemaleBreastExp: Float = 0.50f,
    var tButtExp: Float = 0.60f,
    var tButtIsolated: Float = 0.80f,
    var strong: Float = 0.75f,
    var strongButt: Float = 0.85f,
    var sexyEnabled: Boolean = true,
    var tBreastCov: Float = 0.55f,
    var tLowerCov: Float = 0.55f,
    var tBellyExp: Float = 0.45f,
    var confirm: Int = 2,            // positives needed among the last 3 frames
    var minLumaStd: Float = 5f,
    var maxWindows: Int = 3,
    var tileFrac: Float = 0.60f,     // 0.50 = finer tiles for 4+ column grids (about 15 tiles, costs more)
    var tilesPerTickGallery: Int = 4,
    var tilesPerTickIdle: Int = 2,
    var idleSweepEvery: Int = 8,
    var galleryCue: Int = 6
)

class NudeNetDetector(
    private val env: OrtEnvironment,
    modelBytes: ByteArray,
    val cfg: NudeCfg
) {
    private val size = 320
    private val hw = size * size
    private val session: OrtSession = env.createSession(
        modelBytes, OrtSession.SessionOptions().apply { setIntraOpNumThreads(2) }
    )
    private val data = FloatArray(3 * hw)
    private val px = IntArray(hw)
    private val history = ArrayDeque<Boolean>()
    private var cooldownUntil = 0L
    private var tick = 0
    private var cursor = 0
    private var tilesDone = 0
    private var cueActive = false

    class Det(val cls: Int, val score: Float, val cx: Float, val cy: Float, val w: Float, val h: Float)
    class Verdict(val positive: Boolean, val strong: Boolean, val weak: Boolean, val why: String)
    class NudeOut(
        val framePositive: Boolean, val trigger: Boolean, val suspect: Boolean,
        val sweepPending: Boolean, val inferences: Int, val ms: Long, val summary: List<String>
    )

    fun resetHistory() = history.clear()
    fun clearHistory() = resetHistory()
    fun onContentChanged() { tilesDone = 0 }
    fun close() = session.close()
    fun getHistoryCount(): Int = history.count { it }
    fun getHistoryTotal(): Int = history.size
    fun getTilesDone(): Int = tilesDone
    fun getCueActive(): Boolean = cueActive

    /** bmp: software ARGB_8888, bars cropped. Never recycles bmp. Returns null when skipped or on error. */
    fun process(bmp: Bitmap, nowMs: Long, allowTiles: Boolean): NudeOut? {
        val t0 = System.nanoTime()
        try {
            if (isUniform(bmp)) return null
            tick++
            var positive = false; var strong = false; var weak = false; var small = 0; var runs = 0
            val summary = ArrayList<String>()

            fun consume(d: List<Det>, side: Int) {
                val v = evalView(d)
                positive = positive or v.positive; strong = strong or v.strong; weak = weak or v.weak
                small += d.count { it.score >= 0.15f && maxOf(it.w, it.h) < 0.35f * side }
                d.filter { it.score >= 0.20f && it.cls != NN.FACE_FEMALE && it.cls != NN.FACE_MALE }
                    .forEach { summary.add("${NN.NAMES[it.cls]} ${"%.2f".format(it.score)}") }
                if (v.why.isNotEmpty()) summary.add("=> ${v.why}")
            }

            for (r in squareWindows(bmp.width, bmp.height)) { consume(runView(bmp, r[0], r[1], r[2]), r[2]); runs++ }

            cueActive = weak || small >= cfg.galleryCue
            val tiles = tileRects(bmp.width, bmp.height)
            if (!strong && allowTiles) {
                val k = when {
                    cueActive -> cfg.tilesPerTickGallery
                    tick % cfg.idleSweepEvery == 0 -> cfg.tilesPerTickIdle
                    else -> 0
                }
                repeat(k) {
                    val r = tiles[cursor % tiles.size]; cursor++; tilesDone++
                    consume(runView(bmp, r[0], r[1], r[2]), r[2]); runs++
                }
            }

            history.addLast(positive)
            while (history.size > 3) history.removeFirst()
            var trigger = false
            if (nowMs >= cooldownUntil && (strong || history.count { it } >= cfg.confirm)) {
                trigger = true; history.clear(); cooldownUntil = nowMs + 3000L
            }
            val pending = cueActive && tilesDone < tiles.size
            return NudeOut(positive, trigger, positive, pending, runs, (System.nanoTime() - t0) / 1_000_000, summary)
        } catch (e: Throwable) {
            Log.w("NudeNetDetector", "Fail-open exception during NudeNet inference: ${e.message}")
            return null   // log e, fail-open
        }
    }

    private fun explicitThr(c: Int): Float? = when (c) {
        NN.FEMALE_GENITALIA_EXPOSED -> cfg.tFemaleGenExp
        NN.MALE_GENITALIA_EXPOSED -> cfg.tMaleGenExp
        NN.ANUS_EXPOSED -> cfg.tAnusExp
        NN.FEMALE_BREAST_EXPOSED -> cfg.tFemaleBreastExp
        NN.BUTTOCKS_EXPOSED -> cfg.tButtExp
        else -> null
    }

    private fun evalView(d: List<Det>): Verdict {
        val human = d.any { it.cls != NN.BUTTOCKS_EXPOSED && it.score >= 0.25f }
        var pos = false; var strong = false; var weak = false; var why = ""
        for (x in d) {
            val t = explicitThr(x.cls) ?: continue
            if (x.score < t) { if (x.score >= 0.20f) weak = true; continue }
            if (x.cls == NN.BUTTOCKS_EXPOSED && !human && x.score < cfg.tButtIsolated) { weak = true; continue }
            pos = true
            val s = if (x.cls == NN.BUTTOCKS_EXPOSED) cfg.strongButt else cfg.strong
            if (x.score >= s) strong = true
            why = "${NN.NAMES[x.cls]} ${"%.2f".format(x.score)}"
        }
        if (cfg.sexyEnabled && sexy(d)) { pos = true; why = "SEXY_S1" }
        return Verdict(pos, strong, weak, why)
    }

    private fun sexy(d: List<Det>): Boolean {
        val br = d.filter { it.cls == NN.FEMALE_BREAST_COVERED && it.score >= cfg.tBreastCov }
        val lo = d.filter {
            (it.cls == NN.FEMALE_GENITALIA_COVERED || it.cls == NN.BUTTOCKS_COVERED) && it.score >= cfg.tLowerCov
        }
        val be = d.filter { it.cls == NN.BELLY_EXPOSED && it.score >= cfg.tBellyExp }
        for (b in br) for (l in lo) for (e in be)
            if (b.cy < e.cy && e.cy < l.cy &&
                abs(e.cx - b.cx) < maxOf(e.w, b.w) && abs(e.cx - l.cx) < maxOf(e.w, l.w)) return true
        return false
    }

    private fun runView(src: Bitmap, x: Int, y: Int, side: Int): List<Det> {
        val crop = Bitmap.createBitmap(src, x, y, side, side)
        val sc = downscale(crop, size)
        sc.getPixels(px, 0, size, 0, 0, size, size)
        if (sc !== crop) sc.recycle()
        if (crop !== src) crop.recycle()
        for (i in 0 until hw) {
            val p = px[i]
            data[i] = ((p shr 16) and 0xFF) / 255f           // R plane
            data[hw + i] = ((p shr 8) and 0xFF) / 255f       // G plane
            data[2 * hw + i] = (p and 0xFF) / 255f           // B plane
        }
        @Suppress("UNCHECKED_CAST")
        val out = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(data), longArrayOf(1L, 3L, size.toLong(), size.toLong())
        ).use { t ->
            session.run(mapOf("images" to t)).use { r -> r.get(0).value as Array<Array<FloatArray>> }
        }
        return decode(out, side / size.toFloat())
    }

    private fun decode(out: Array<Array<FloatArray>>, scale: Float): List<Det> {
        val o = out[0]                                        // [22][2100]
        require(o.size == 22)
        val n = o[0].size
        val cand = ArrayList<Det>()
        for (i in 0 until n) {
            var best = -1; var bs = 0f
            for (c in 0 until 18) { val s = o[4 + c][i]; if (s > bs) { bs = s; best = c } }
            if (best >= 0 && bs >= 0.15f)
                cand.add(Det(best, bs, o[0][i] * scale, o[1][i] * scale, o[2][i] * scale, o[3][i] * scale))
        }
        val keep = ArrayList<Det>()
        for ((_, group) in cand.groupBy { it.cls }) {
            val kept = ArrayList<Det>()
            for (d in group.sortedByDescending { it.score }) if (kept.none { overlap(it, d) > 0.45f }) kept.add(d)
            keep.addAll(kept)
        }
        return keep
    }

    private fun overlap(a: Det, b: Det): Float {
        val ix = maxOf(0f, minOf(a.cx + a.w / 2, b.cx + b.w / 2) - maxOf(a.cx - a.w / 2, b.cx - b.w / 2))
        val iy = maxOf(0f, minOf(a.cy + a.h / 2, b.cy + b.h / 2) - maxOf(a.cy - a.h / 2, b.cy - b.h / 2))
        val inter = ix * iy
        val u = a.w * a.h + b.w * b.h - inter
        return if (u > 0f) inter / u else 0f
    }

    private fun squareWindows(w: Int, h: Int): List<IntArray> {
        val side = minOf(w, h)
        val long = maxOf(w, h)
        val n = ceil(long.toDouble() / side - 0.15).toInt().coerceIn(1, cfg.maxWindows)
        return List(n) { i ->
            val off = if (n == 1) (long - side) / 2 else (i * (long - side).toDouble() / (n - 1)).roundToInt()
            if (h >= w) intArrayOf(0, off, side) else intArrayOf(off, 0, side)   // [x, y, side]
        }
    }

    private fun tileRects(w: Int, h: Int): List<IntArray> {
        val side = (minOf(w, h) * cfg.tileFrac).roundToInt().coerceAtLeast(320)
        val stride = (side * 0.8f).toInt().coerceAtLeast(1)
        fun axis(len: Int): List<Int> {
            if (len <= side) return listOf(0)
            val l = ArrayList<Int>(); var p = 0
            while (p + side < len) { l.add(p); p += stride }
            l.add(len - side)
            return l.distinct()
        }
        val xs = axis(w); val ys = axis(h)
        return ys.flatMap { y -> xs.map { x -> intArrayOf(x, y, side) } }
    }

    private fun downscale(b: Bitmap, target: Int): Bitmap {
        var cur = b
        while (cur.width >= target * 2) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== b) cur.recycle()
            cur = next
        }
        val out = Bitmap.createScaledBitmap(cur, target, target, true)
        if (cur !== b && cur !== out) cur.recycle()
        return out
    }

    private fun isUniform(b: Bitmap): Boolean {
        val s = Bitmap.createScaledBitmap(b, 64, 64, true)
        val p64 = IntArray(64 * 64)
        s.getPixels(p64, 0, 64, 0, 0, 64, 64)
        if (s !== b) s.recycle()
        var sum = 0.0; var sum2 = 0.0
        for (p in p64) {
            val y = 0.299 * ((p shr 16) and 0xFF) + 0.587 * ((p shr 8) and 0xFF) + 0.114 * (p and 0xFF)
            sum += y; sum2 += y * y
        }
        val mean = sum / p64.size
        return sqrt((sum2 / p64.size - mean * mean).coerceAtLeast(0.0)) < cfg.minLumaStd
    }
}
