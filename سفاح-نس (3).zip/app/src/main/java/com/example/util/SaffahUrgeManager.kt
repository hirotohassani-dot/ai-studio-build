package com.example.util

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.SystemClock
import android.util.Log

/**
 * مدير ميزة "قاعدة الـ 15 دقيقة لدحر الرغبة" (Urge Suppression 15-Minute Rule)
 * معمارية فائقة الكفاءة والاستقرار، متوافقة مع متطلبات الجهاز المالك (Device Owner).
 * تخزين فوري ودائم لضمان استمرار العداد حتى بعد إعادة تشغيل الهاتف فوراً دون أي تأخير.
 */
object SaffahUrgeManager {

    private const val TAG = "SaffahUrgeManager"
    private const val PREFS_NAME = "saffah_urge_prefs"
    private const val KEY_IS_FEATURE_ENABLED = "is_urge_rule_enabled"
    private const val KEY_SESSION_END_TIMESTAMP = "urge_session_end_timestamp"
    private const val KEY_SESSION_START_TIMESTAMP = "urge_session_start_timestamp"
    private const val KEY_SESSION_ACTIVE = "urge_session_active"
    private const val KEY_LAST_COMPLETED_SESSION = "urge_last_completed_session_time"

    @Volatile
    private var cachedPrefs: SharedPreferences? = null
    @Volatile
    private var cachedIsSessionActive: Boolean? = null

    private fun getPrefs(context: Context): SharedPreferences {
        cachedPrefs?.let { return it }
        synchronized(this) {
            cachedPrefs?.let { return it }
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            cachedPrefs = prefs
            return prefs
        }
    }

    /**
     * التحقق من تفعيل الميزة (افتراضياً معطلة حتى يقوم المستخدم بتفعيلها يدوياً)
     */
    fun isUrgeFeatureEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_IS_FEATURE_ENABLED, false)
    }

    /**
     * تفعيل أو تعطيل الميزة
     */
    fun setUrgeFeatureEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_IS_FEATURE_ENABLED, enabled).apply()
    }

    /**
     * وقت آخر جلسة مكتملة بنجاح
     */
    fun getLastCompletedSessionTime(context: Context): Long {
        return getPrefs(context).getLong(KEY_LAST_COMPLETED_SESSION, 0L)
    }

    /**
     * التحقق من وجود جلسة دحر رغبة نشطة حالياً
     */
    fun isUrgeSessionActive(context: Context): Boolean {
        if (cachedIsSessionActive == false) return false

        val prefs = getPrefs(context)
        val isActiveFlag = prefs.getBoolean(KEY_SESSION_ACTIVE, false)
        if (!isActiveFlag) {
            cachedIsSessionActive = false
            return false
        }

        val endTime = prefs.getLong(KEY_SESSION_END_TIMESTAMP, 0L)
        val now = System.currentTimeMillis()
        if (now >= endTime) {
            // انتهى الوقت، إيقاف الجلسة وتوثيق الانتهاء
            cachedIsSessionActive = false
            completeUrgeSession(context)
            return false
        }
        cachedIsSessionActive = true
        return true
    }

    /**
     * الحصول على الوقت المتبقي للجلسة بالمللي ثانية
     */
    fun getUrgeSessionRemainingMs(context: Context): Long {
        val prefs = getPrefs(context)
        val endTime = prefs.getLong(KEY_SESSION_END_TIMESTAMP, 0L)
        val now = System.currentTimeMillis()
        return (endTime - now).coerceAtLeast(0L)
    }

    /**
     * الحصول على توقيت انتهاء الجلسة
     */
    fun getUrgeSessionEndTimeMs(context: Context): Long {
        return getPrefs(context).getLong(KEY_SESSION_END_TIMESTAMP, 0L)
    }

    /**
     * بدء جلسة مقاومة الرغبة لمدة 15 دقيقة (أو مدة محددة)
     * تخزين فوري باستخدام commit لضمان الصمود عند إعادة تشغيل الهاتف فوراً
     */
    fun startUrgeSession(context: Context, durationMinutes: Int = 15): Long {
        val now = System.currentTimeMillis()
        val durationMs = durationMinutes * 60 * 1000L
        val endTime = now + durationMs

        getPrefs(context).edit()
            .putBoolean(KEY_SESSION_ACTIVE, true)
            .putLong(KEY_SESSION_START_TIMESTAMP, now)
            .putLong(KEY_SESSION_END_TIMESTAMP, endTime)
            .apply()
        cachedIsSessionActive = true

        Log.i(TAG, "Urge suppression session started for $durationMinutes minutes. Ends at: $endTime")

        // Launch Saffah directly in Lock Task Mode with 15-minute urge window inside
        SaffahLockTaskManager.launchLockTaskApp(context, SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
        try {
            com.example.widget.SaffahUrgeWidgetProvider.updateAllWidgets(context)
            com.example.service.SaffahUrgeTileService.requestTileUpdate(context)
            com.example.util.SaffahNotificationManager.dispatchUrgeSessionRecommendationNotification(context, durationMinutes)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating widgets/tile/notification on start: ${e.message}")
        }
        return endTime
    }

    /**
     * إيقاف الجلسة يدوياً
     */
    fun stopUrgeSession(context: Context) {
        cachedIsSessionActive = false
        getPrefs(context).edit()
            .putBoolean(KEY_SESSION_ACTIVE, false)
            .putLong(KEY_SESSION_END_TIMESTAMP, 0L)
            .apply()
        try {
            com.example.widget.SaffahUrgeWidgetProvider.updateAllWidgets(context)
            com.example.service.SaffahUrgeTileService.requestTileUpdate(context)
            com.example.util.SaffahNotificationManager.cancelUrgeSessionRecommendationNotification(context)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating widgets/tile on stop: ${e.message}")
        }
    }

    /**
     * استكمال وإنهاء الجلسة تلقائياً بنجاح عند انتهاء الـ 15 دقيقة
     */
    fun completeUrgeSession(context: Context) {
        cachedIsSessionActive = false
        val now = System.currentTimeMillis()
        getPrefs(context).edit()
            .putBoolean(KEY_SESSION_ACTIVE, false)
            .putLong(KEY_SESSION_END_TIMESTAMP, 0L)
            .putLong(KEY_LAST_COMPLETED_SESSION, now)
            .apply()

        try {
            com.example.widget.SaffahUrgeWidgetProvider.updateAllWidgets(context)
            com.example.service.SaffahUrgeTileService.requestTileUpdate(context)
            com.example.util.SaffahNotificationManager.cancelUrgeSessionRecommendationNotification(context)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating widgets/tile on complete: ${e.message}")
        }
    }

    /**
     * قائمة الرسائل التحفيزية والسلوكية والإيمانية لجلسة الـ 15 دقيقة (بدون أي إيموجيات)
     */
    val motivationalMessages: List<UrgeMotivationalMessage> = listOf(
        UrgeMotivationalMessage(
            text = "﴿وَاصْبِرْ لِحُكْمِ رَبِّكَ فَإِنَّكَ بِأَعْيُنِنَا﴾",
            subtext = "أنت في معية الله ورعايته في كل ثانية تجاهد فيها نفسك وتصبر على طاعته.",
            category = "إيماني"
        ),
        UrgeMotivationalMessage(
            text = "الرغبة مجرد موجة كيميائية عابرة",
            subtext = "تبلغ ذروتها خلال دقائق ثم تنكسر وتنحسر تلقائياً. تنفس بهدوء ودع الموجة تعبر دون أن تستجيب لها.",
            category = "سلوكي"
        ),
        UrgeMotivationalMessage(
            text = "﴿إِنَّ الَّذِينَ اتَّقَوْا إِذَا مَسَّهُمْ طَائِفٌ مِّنَ الشَّيْطَانِ تَذَكَّرُوا فَإِذَا هُم مُّبْصِرُونَ﴾",
            subtext = "الاستبصار واليقظة هما سلاحك في مواجهة وسوسة اللحظة.",
            category = "إيماني"
        ),
        UrgeMotivationalMessage(
            text = "تمرين التنفس العميق (4 - 4 - 6)",
            subtext = "شهيق هادئ من الأنف لـ 4 ثوانٍ، احبس النفس لـ 4 ثوانٍ، ثم زفير بطيء من الفم لـ 6 ثوانٍ لتهدئة الجهاز العصبي.",
            category = "تنفس واسترخاء"
        ),
        UrgeMotivationalMessage(
            text = "﴿وَأَمَّا مَنْ خَافَ مَقَامَ رَبِّهِ وَنَهَى النَّفْسَ عَنِ الْهَوَىٰ ۝ فَإِنَّ الْجَنَّةَ هِيَ الْمَأْوَىٰ﴾",
            subtext = "نهي النفس عن الهوى هو طريق الفلاح والسكينة الدائمة.",
            category = "إيماني"
        ),
        UrgeMotivationalMessage(
            text = "كل دقيقة تصمد فيها تعيد بناء عقلك",
            subtext = "الصمود الآن يبني وصلات عصبية جديدة في الفص الجبهي، ويعيد حساسية مستقبلات الدوبامين الطبيعية.",
            category = "علمي"
        ),
        UrgeMotivationalMessage(
            text = "﴿وَالَّذِينَ جَاهَدُوا فِينَا لَنَهْدِيَنَّهُمْ سُبُلَنَا﴾",
            subtext = "الهداية والقوة ثمرة مجاهدة النفس في لحظات الشدة.",
            category = "إيماني"
        ),
        UrgeMotivationalMessage(
            text = "لذة الانتصار تدوم وحسرة الضعف تفنى",
            subtext = "تذكر الشعور بالاعتزاز والنقاء الذي ستشعر به بعد 15 دقيقة حين تتغلب على هذه الرغبة.",
            category = "تحفيزي"
        ),
        UrgeMotivationalMessage(
            text = "﴿إِنَّمَا يُوَفَّى الصَّابِرُونَ أَجْرَهُم بِغَيْرِ حِسَابٍ﴾",
            subtext = "الصبر على ترك المعصية من أعلى درجات الصبر وأعظمها أجراً.",
            category = "إيماني"
        ),
        UrgeMotivationalMessage(
            text = "أنت لست أفكارك ولا دوافعك اللحظية",
            subtext = "أنت المراقب الواعي القادر على اختيار ردة فعلك وتقرير مصيرك.",
            category = "سلوكي"
        )
    )
}

data class UrgeMotivationalMessage(
    val text: String,
    val subtext: String,
    val category: String
)
