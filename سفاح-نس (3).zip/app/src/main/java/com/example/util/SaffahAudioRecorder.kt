package com.example.util

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File

/**
 * مسجل الصوت فائق النقاء وخفيف الحجم
 * يستخدم تشفير AAC بتقنية LC وقناة أحادية Mono ومعدل ترميز 32kbps
 * للحصول على صوت نقي وواضح تماماً وبأقل حجم ممكن على الإطلاق (أقل من 250 كيلوبايت للدقيقة)
 */
class SaffahAudioRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var isRecording = false
    private var currentOutputFile: File? = null

    fun startRecording(outputFile: File): Boolean {
        return try {
            stopRecording()
            currentOutputFile = outputFile

            recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100) // نقاء صوتي استوديو عالي
                setAudioEncodingBitRate(32000) // 32 kbps لحجم ملف فائق الصغر مع الحفاظ على وضوح الصوت البشري
                setAudioChannels(1) // Mono
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }
            isRecording = true
            true
        } catch (e: Exception) {
            Log.e("SaffahAudioRecorder", "Error starting audio record: ${e.message}", e)
            recorder?.release()
            recorder = null
            isRecording = false
            false
        }
    }

    fun stopRecording(): File? {
        if (!isRecording) return null
        return try {
            recorder?.apply {
                try {
                    stop()
                } catch (e: Exception) {
                    Log.w("SaffahAudioRecorder", "Stop error: ${e.message}")
                }
                release()
            }
            recorder = null
            isRecording = false
            currentOutputFile
        } catch (e: Exception) {
            Log.e("SaffahAudioRecorder", "Error releasing recorder: ${e.message}")
            recorder = null
            isRecording = false
            null
        }
    }

    fun getAmplitude(): Int {
        return try {
            if (isRecording) {
                recorder?.maxAmplitude ?: 0
            } else 0
        } catch (e: Exception) {
            0
        }
    }

    fun isCurrentlyRecording(): Boolean = isRecording
}
