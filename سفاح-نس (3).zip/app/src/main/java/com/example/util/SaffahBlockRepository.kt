package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock
import android.util.Log
import com.example.model.BlockLogEntry
import com.example.model.BlockedKeyword
import com.example.model.BlockedSite
import com.example.model.CompiledKeywordRule
import com.example.model.CompiledSiteRule
import org.json.JSONArray
import org.json.JSONObject

object SaffahBlockRepository {

    private const val PREFS_NAME = "saffah_block_prefs"
    private const val KEY_KEYWORDS = "blocked_keywords_json"
    private const val KEY_SITES = "blocked_sites_json"
    private const val KEY_KEYWORDS_INITIALIZED = "has_initialized_keywords_flag_v2"
    private const val KEY_SITES_INITIALIZED = "has_initialized_sites_flag_v2"
    private const val KEY_LOGS = "block_logs_json"
    private const val KEY_EXCLUDED_VPN_APPS = "excluded_vpn_apps_set"
    private const val KEY_BLOCK_TELEGRAM_SEARCH = "block_telegram_search"
    private const val KEY_BLOCK_WHATSAPP_CHANNELS = "block_whatsapp_channels"
    private const val KEY_BLOCK_YOUTUBE_SHORTS = "block_youtube_shorts"
    private const val KEY_BLOCK_FACEBOOK_LITE_REELS = "block_facebook_lite_reels"
    private const val KEY_BLOCK_INSTAGRAM_REELS = "block_instagram_reels"
    private const val KEY_BLOCK_UNSUPPORTED_BROWSERS = "block_unsupported_browsers"
    private const val KEY_BLOCK_IN_APP_BROWSERS = "block_in_app_browsers"
    private const val KEY_HIDE_VPN_NOTIFICATION = "hide_vpn_notification"
    private const val KEY_AI_PROTECTION_ENABLED = "ai_protection_enabled"
    private const val KEY_AI_NUDENET_ENABLED = "ai_nudenet_enabled"
    private const val KEY_AI_ANIME_ENABLED = "ai_anime_enabled"

    // --- BEDTIME MODE KEYS ---
    private const val KEY_BEDTIME_ENABLED = "bedtime_enabled"
    private const val KEY_BEDTIME_START_HOUR = "bedtime_start_hour"
    private const val KEY_BEDTIME_START_MINUTE = "bedtime_start_minute"
    private const val KEY_BEDTIME_END_HOUR = "bedtime_end_hour"
    private const val KEY_BEDTIME_END_MINUTE = "bedtime_end_minute"
    private const val KEY_BEDTIME_ALLOWED_APPS = "bedtime_allowed_apps_set"
    private const val KEY_BEDTIME_GRAYSCALE = "bedtime_grayscale_enabled"
    private const val KEY_BEDTIME_EYE_COMFORT_ENABLED = "bedtime_eye_comfort_enabled"
    private const val KEY_BEDTIME_DAYS = "bedtime_days_set"

    private const val KEY_PERMANENT_BLOCKED_PACKAGES = "permanent_blocked_packages_set"
    private const val KEY_UNINSTALL_BLOCKED_PACKAGES = "uninstall_blocked_packages_set"
    private const val KEY_KEYWORD_EXEMPTED_APPS = "keyword_exempted_apps_set"

    // --- TIME DELAY (ميزة التأخير الزمني) KEYS ---
    private const val KEY_TIME_DELAY_ENABLED = "time_delay_enabled"
    private const val KEY_TIME_DELAY_UNTIL_TIMESTAMP = "time_delay_until_timestamp"
    private const val KEY_TIME_DELAY_CONFIGURED_HOURS = "time_delay_configured_hours"

    // In-memory thread-safe caches for ultra-fast, battery-efficient lookups without repeated JSON/Disk I/O
    @Volatile private var cachedStartOfDayMillis: Long = 0L
    @Volatile private var cachedEndOfDayMillis: Long = 0L
    @Volatile private var cachedPermanentBlockedPackages: Set<String>? = null
    @Volatile private var cachedUninstallBlockedPackages: Set<String>? = null
    @Volatile private var cachedBlockLogs: List<BlockLogEntry>? = null
    private val blockLogsLock = Any()
    @Volatile private var cachedKeywords: List<BlockedKeyword>? = null
    @Volatile private var cachedCompiledKeywords: List<CompiledKeywordRule>? = null
    @Volatile private var cachedFastKeywordMatcher: SaffahFastKeywordMatcher? = null
    @Volatile private var cachedSites: List<BlockedSite>? = null
    @Volatile private var cachedCompiledSites: List<CompiledSiteRule>? = null
    @Volatile private var cachedFastDomainMatcher: SaffahFastDomainMatcher? = null
    @Volatile private var cachedExcludedVpnApps: Set<String>? = null
    @Volatile private var cachedTelegramSearchBlocked: Boolean? = null
    @Volatile private var cachedWhatsAppChannelsBlocked: Boolean? = null
    @Volatile private var cachedYouTubeShortsBlocked: Boolean? = null
    @Volatile private var cachedFacebookLiteReelsBlocked: Boolean? = null
    @Volatile private var cachedInstagramReelsBlocked: Boolean? = null
    @Volatile private var cachedBlockUnsupportedBrowsers: Boolean? = null
    @Volatile private var cachedBlockInAppBrowsers: Boolean? = null
    @Volatile private var cachedHideVpnNotification: Boolean? = null
    @Volatile private var cachedAiProtectionEnabled: Boolean? = null
    @Volatile private var cachedAiNudeNetEnabled: Boolean? = null
    @Volatile private var cachedAiAnimeEnabled: Boolean? = null
    @Volatile private var cachedAiIncludedApps: Set<String>? = null
    @Volatile private var cachedBedtimeEnabled: Boolean? = null
    @Volatile private var cachedBedtimeSchedule: Pair<Pair<Int, Int>, Pair<Int, Int>>? = null
    @Volatile private var cachedBedtimeAllowedApps: Set<String>? = null
    @Volatile private var cachedKeywordExemptedApps: Set<String>? = null
    @Volatile private var cachedBedtimeGrayscale: Boolean? = null
    @Volatile private var cachedBedtimeEyeComfort: Boolean? = null
    @Volatile private var cachedBedtimeDays: Set<Int>? = null
    @Volatile private var cachedAppScheduleMasterEnabled: Boolean? = null
    @Volatile private var cachedAppScheduleRules: List<com.example.model.AppBlockScheduleRule>? = null
    @Volatile private var cachedUsageMasterEnabled: Boolean? = null
    @Volatile private var cachedUsageRules: List<com.example.model.UsageBlockRule>? = null
    @Volatile private var cachedUsageRuleTargetPackages: Set<String>? = null
    @Volatile private var cachedProductivityRule: com.example.model.ProductivityDisciplineRule? = null
    @Volatile private var isProductivityRuleLoaded: Boolean = false

    // Package query cache to eliminate heavy PackageManager IPC calls and maximize battery preservation
    @Volatile private var cachedInstalledPackages: List<String>? = null
    @Volatile private var cachedInstalledPackagesTimestamp: Long = 0L

    @Volatile private var cachedPrefs: SharedPreferences? = null
    @Volatile private var cachedResolvedSettingsPkg: String? = null
    @Volatile private var isResolvedSettingsPkgChecked: Boolean = false

    fun invalidateInstalledPackagesCache() {
        cachedInstalledPackages = null
        cachedInstalledPackagesTimestamp = 0L
    }

    private fun getSafeSharedPreferences(context: Context): SharedPreferences {
        cachedPrefs?.let { return it }
        synchronized(this) {
            cachedPrefs?.let { return it }
            val safeContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                if (!context.isDeviceProtectedStorage) {
                    context.createDeviceProtectedStorageContext()
                } else {
                    context
                }
            } else {
                context
            }
            val prefs = safeContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            cachedPrefs = prefs
            return prefs
        }
    }

    // --- ALWAYS EXEMPTED APPS & SYSTEM SETTINGS EXEMPTION HELPER ---

    val ALWAYS_EXEMPTED_PACKAGES: Set<String> = setOf(
        "com.google.android.gms",
        "com.google.android.providers.media.module",
        "com.coloros.alarmclock",
        "com.google.android.dialer",
        "com.android.providers.telephony",
        "com.android.server.telecom",
        "com.android.phone",
        "com.oplus.wirelesssettings",
        "com.reworewo.prayertimes",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.google.android.providers.media.module",
        "com.android.providers.telephony",
        "com.android.server.telecom",
        "com.android.phone",
        "com.oplus.wirelesssettings"
    )

    @Volatile private var cachedResolvedLauncherPkg: String? = null
    @Volatile private var isResolvedLauncherChecked: Boolean = false
    @Volatile private var cachedResolvedDialerPkg: String? = null
    @Volatile private var isResolvedDialerChecked: Boolean = false

    interface BlockEnforcementListener {
        fun onAppBlockedImmediately(packageName: String, reason: String, message: String)
    }

    @Volatile private var enforcementListener: BlockEnforcementListener? = null

    fun registerEnforcementListener(listener: BlockEnforcementListener) {
        enforcementListener = listener
    }

    fun unregisterEnforcementListener(listener: BlockEnforcementListener) {
        if (enforcementListener == listener) {
            enforcementListener = null
        }
    }

    fun isAlwaysExemptPackage(packageName: String): Boolean {
        if (packageName.isBlank()) return true
        val lower = packageName.lowercase().trim()
        if (lower.startsWith("com.aistudio.saffah") || lower == "com.example") return true
        if (ALWAYS_EXEMPTED_PACKAGES.contains(lower)) return true
        if (lower == "com.android.systemui" || lower == "android" ||
            lower.contains("permissioncontroller") ||
            lower.contains("packageinstaller") || lower.contains("autofill")
        ) {
            return true
        }
        return false
    }

    private val KNOWN_KEYBOARDS: Set<String> = setOf(
        "com.google.android.inputmethod.latin",
        "com.touchtype.swiftkey",
        "com.samsung.android.honeyboard",
        "com.oppo.keyboard", "com.coloros.keyboard", "com.heytap.keyboard",
        "com.oplus.keyboard", "com.coloros.safecenter", "com.oplus.safecenter",
        "com.oppo.safecenter", "com.baidu.input_oppo", "com.sohu.inputmethod.sogou.oem",
        "com.ziipin.softkeyboard.dz"
    )

    private val KNOWN_SYSTEM_LAUNCHERS: Set<String> = setOf(
        "com.oppo.launcher", "com.coloros.launcher", "com.realme.launcher",
        "com.oplus.launcher", "com.heytap.launcher", "com.coloros.home",
        "com.oppo.home", "com.oplus.home", "com.realme.home",
        "com.android.launcher3", "com.android.launcher",
        "com.google.android.apps.nexuslauncher", "com.sec.android.app.launcher",
        "com.miui.home", "com.huawei.android.launcher"
    )

    private val inputMethodCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val strictUnblockableCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    /**
     * Checks if the package is an active soft keyboard / input method.
     */
    fun isInputMethodPackage(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val lower = packageName.lowercase().trim()
        inputMethodCache[lower]?.let { return it }

        if (KNOWN_KEYBOARDS.contains(lower)) {
            inputMethodCache[lower] = true
            return true
        }
        if (lower.contains("keyboard") || lower.contains("inputmethod") || lower.contains("ime")) {
            inputMethodCache[lower] = true
            return true
        }
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            if (imm?.enabledInputMethodList?.any { it.packageName.equals(lower, ignoreCase = true) } == true) {
                inputMethodCache[lower] = true
                return true
            }
        } catch (_: Exception) {}
        inputMethodCache[lower] = false
        return false
    }

    /**
     * Checks if the package is a known Home Launcher.
     */
    fun isHomeLauncherPackage(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val ownPkg = context.packageName.lowercase()
        val lower = packageName.lowercase().trim()
        if (lower == ownPkg) return false

        if (KNOWN_SYSTEM_LAUNCHERS.contains(lower)) return true

        if (!isResolvedLauncherChecked) {
            try {
                val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
                    addCategory(android.content.Intent.CATEGORY_HOME)
                }
                val resolveInfo = context.packageManager.resolveActivity(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                cachedResolvedLauncherPkg = resolveInfo?.activityInfo?.packageName?.lowercase()
            } catch (_: Exception) {}
            isResolvedLauncherChecked = true
        }
        return cachedResolvedLauncherPkg != null && lower == cachedResolvedLauncherPkg
    }

    /**
     * Checks if the package is a transient system overlay/component (Keyboard, SystemUI, Permission Dialog, Autofill).
     * These components should never interrupt the active user application session.
     */
    fun isTransientSystemComponent(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return true
        val lower = packageName.lowercase().trim()
        val ownPkg = context.packageName.lowercase()

        if (lower == ownPkg) return true

        return lower == "com.android.systemui" ||
                lower == "android" ||
                isInputMethodPackage(context, packageName) ||
                lower == "com.google.android.permissioncontroller" ||
                lower == "com.android.permissioncontroller" ||
                lower == "com.android.packageinstaller" ||
                lower == "com.google.android.packageinstaller" ||
                lower == "com.google.android.gms" ||
                lower == "com.android.vending" ||
                lower == "com.google.android.documentsui" ||
                lower == "com.android.documentsui" ||
                lower == "com.google.android.providers.media.module" ||
                lower == "com.android.providers.media" ||
                lower == "com.android.certinstaller" ||
                lower == "com.google.android.feedback" ||
                // Realme / ColorOS / Oppo OS system components & overlays
                lower == "com.coloros.smartsidebar" || lower == "com.oplus.smartsidebar" ||
                lower == "com.coloros.floatassistant" || lower == "com.oplus.floatingwindow" ||
                lower == "com.coloros.gamespace" || lower == "com.oplus.games" ||
                lower == "com.coloros.screenshot" || lower == "com.oplus.screenshot" ||
                lower == "com.coloros.safecenter" || lower == "com.oplus.safecenter" ||
                lower == "com.oplus.battery" || lower == "com.coloros.battery" ||
                lower == "com.oplus.subsystem" || lower == "com.oplus.statusbar" ||
                lower == "com.coloros.securitykeyboard" || lower == "com.oplus.securitykeyboard" ||
                lower == "com.oplus.securitypermission" || lower == "com.oplus.notification" ||
                lower == "com.oplus.gesture" || lower == "com.oplus.screenrecorder" ||
                lower == "com.oplus.volume" || lower == "com.coloros.volume" ||
                lower == "com.oplus.charging" || lower == "com.coloros.charging" ||
                lower == "com.oplus.wirelesscharging" || lower == "com.coloros.wirelesscharging" ||
                lower == "com.oplus.quickcharging" || lower == "com.coloros.quickcharging" ||
                lower == "com.oplus.charge" || lower == "com.coloros.charge" ||
                lower.endsWith(".volume") || lower.endsWith(".charging") ||
                lower == "com.oplus.multiapp" || lower == "com.heytap.mcs" ||
                lower == "com.oplus.eyeprotect"
    }

    /**
     * Strict check for the absolute critical packages that MUST NEVER BE BLOCKED under any circumstance:
     * 1. Saffah app itself
     * 2. Active Home Launcher
     * 3. System UI & Android Core OS Framework
     * 4. Emergency Dialer / Telecom
     * 5. Active Keyboard
     * Any other app (system, preinstalled, or user) CAN be blocked if explicitly targeted by rules.
     */
    fun isStrictUnblockableSystemPackage(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return true
        val lower = packageName.lowercase().trim()
        strictUnblockableCache[lower]?.let { return it }

        val ownPkg = context.packageName.lowercase()
        if (lower == ownPkg || lower == "com.android.systemui" || lower == "android" ||
            lower == "com.oplus.volume" || lower == "com.coloros.volume" ||
            lower == "com.oplus.charging" || lower == "com.coloros.charging" ||
            lower == "com.oplus.battery" || lower == "com.coloros.battery" ||
            lower == "com.oplus.subsystem" || lower.endsWith(".volume") || lower.endsWith(".charging")
        ) {
            strictUnblockableCache[lower] = true
            return true
        }
        if (isHomeLauncherPackage(context, packageName)) {
            strictUnblockableCache[lower] = true
            return true
        }

        // Core telephony / dialer / emergency call
        if (lower == "com.android.phone" || lower == "com.android.server.telecom" || lower == "com.android.providers.telephony") {
            strictUnblockableCache[lower] = true
            return true
        }
        if (!isResolvedDialerChecked) {
            try {
                val dialIntent = android.content.Intent(android.content.Intent.ACTION_DIAL)
                val resolveInfo = context.packageManager.resolveActivity(dialIntent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                cachedResolvedDialerPkg = resolveInfo?.activityInfo?.packageName?.lowercase()
            } catch (_: Exception) {}
            isResolvedDialerChecked = true
        }
        if (cachedResolvedDialerPkg != null && lower == cachedResolvedDialerPkg) {
            strictUnblockableCache[lower] = true
            return true
        }

        // Active Soft Keyboard
        if (isInputMethodPackage(context, packageName)) {
            strictUnblockableCache[lower] = true
            return true
        }

        strictUnblockableCache[lower] = false
        return false
    }

    /**
     * General check for system-level helper components.
     */
    fun isCriticalSystemPackage(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return true
        if (isStrictUnblockableSystemPackage(context, packageName)) return true
        if (isAlwaysExemptPackage(packageName)) return true
        if (isSystemSettingsPackage(context, packageName)) return true
        if (isTransientSystemComponent(context, packageName)) return true
        return false
    }

    data class AppBlockDecision(
        val isBlocked: Boolean,
        val ruleType: String,
        val userMessage: String
    )

    @Volatile private var cachedTimeDataElapsed: Long = 0L
    @Volatile private var cachedDayOfWeek: Int = 1
    @Volatile private var cachedNowMinutes: Int = 0
    @Volatile private var cachedMinuteEpoch: Long = -1L

    fun getCachedTimeContext(): Pair<Int, Int> {
        val nowWall = System.currentTimeMillis()
        val currentMinuteEpoch = nowWall / 60_000L
        val nowElapsed = SystemClock.elapsedRealtime()
        if (currentMinuteEpoch == cachedMinuteEpoch && (nowElapsed - cachedTimeDataElapsed < 1000L) && cachedTimeDataElapsed != 0L) {
            return Pair(cachedDayOfWeek, cachedNowMinutes)
        }
        val cal = java.util.Calendar.getInstance()
        val dow = cal.get(java.util.Calendar.DAY_OF_WEEK)
        val mins = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        cachedDayOfWeek = dow
        cachedNowMinutes = mins
        cachedMinuteEpoch = currentMinuteEpoch
        cachedTimeDataElapsed = nowElapsed
        return Pair(dow, mins)
    }

    fun invalidateTimeCache() {
        cachedTimeDataElapsed = 0L
        cachedMinuteEpoch = -1L
        invalidateBedtimeActiveCache()
    }

    /**
     * Unified Priority Conflict-Resolution for all App Blocking systems:
     * Priority 0: Critical System / Exempt Packages (Allowed)
     * Priority 1: Permanent Block (الحظر المؤبد) -> Highest strictness
     * Priority 2: Bedtime Mode (وضع وقت النوم)
     * Priority 3: Scheduled Rules (جدول حظر التطبيقات)
     * Priority 4: Usage Limits (سقف الاستخدام ومرات الفتح)
     * Priority 5: Productivity Discipline (تحسين الإنتاجية)
     */
    fun evaluateAppBlockDecision(context: Context, packageName: String, appLabel: String = ""): AppBlockDecision? {
        if (packageName.isBlank()) return null
        val label = appLabel.ifBlank { packageName }
        val canonicalPkg = packageName.trim().lowercase()

        // Strict unblockable system apps (Saffah, Launcher, SystemUI/Android, Active Dialer, Active Keyboard) must NEVER be blocked
        if (isStrictUnblockableSystemPackage(context, packageName)) {
            return null
        }

        // Special check: System Settings
        val isSettings = isSystemSettingsPackage(context, packageName) || isSystemSettingsPackageName(packageName)
        if (isSettings) {
            if (isCurrentlyBedtime(context)) {
                val bedtimeAllowed = getBedtimeAllowedApps(context)
                if (!bedtimeAllowed.contains(packageName) && !bedtimeAllowed.contains(canonicalPkg)) {
                    val settingsLabel = if (appLabel.isNotBlank()) appLabel else "الإعدادات"
                    return AppBlockDecision(
                        isBlocked = true,
                        ruleType = "وضع وقت النوم",
                        userMessage = "تم حظر التطبيق ($settingsLabel) لأن وضع وقت النوم نشط حالياً"
                    )
                }
            }
            return null
        }

        // Priority 1: Permanent Block (الحظر المؤبد)
        if (isPackagePermanentlyBlocked(context, packageName)) {
            return AppBlockDecision(
                isBlocked = true,
                ruleType = "الحظر المؤبد",
                userMessage = "تم حظر وتعليق التطبيق ($label) نهائياً ضمن قائمة الحظر المؤبد"
            )
        }

        // Priority 2: Bedtime Mode (وضع وقت النوم)
        if (isCurrentlyBedtime(context)) {
            val bedtimeAllowed = getBedtimeAllowedApps(context)
            if (!bedtimeAllowed.contains(packageName) && !bedtimeAllowed.contains(canonicalPkg)) {
                return AppBlockDecision(
                    isBlocked = true,
                    ruleType = "وضع وقت النوم",
                    userMessage = "تم حظر التطبيق ($label) لأن وضع وقت النوم نشط حالياً"
                )
            }
        }

        // Priority 3: Scheduled App Rules (جدول حظر دوري)
        if (isAppScheduleMasterEnabled(context)) {
            val rules = getAppScheduleRules(context)
            if (rules.isNotEmpty()) {
                val (todayOfWeek, nowMinutes) = getCachedTimeContext()
                val yesterdayOfWeek = if (todayOfWeek == java.util.Calendar.SUNDAY) java.util.Calendar.SATURDAY else todayOfWeek - 1
                for (rule in rules) {
                    if (isRuleActiveNow(rule, todayOfWeek, nowMinutes, yesterdayOfWeek)) {
                        val isRuleBlocked = when (rule.blockType) {
                            com.example.model.AppBlockType.BLOCK_SPECIFIED -> rule.selectedPackages.contains(canonicalPkg) || rule.selectedPackages.contains(packageName) || rule.selectedPackages.any { it.trim().equals(canonicalPkg, ignoreCase = true) }
                            com.example.model.AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS -> !rule.selectedPackages.contains(canonicalPkg) && !rule.selectedPackages.contains(packageName) && !rule.selectedPackages.any { it.trim().equals(canonicalPkg, ignoreCase = true) }
                        }
                        if (isRuleBlocked) {
                            return AppBlockDecision(
                                isBlocked = true,
                                ruleType = "جدول حظر دوري",
                                userMessage = "تم حظر التطبيق ($label) وفق جدول الحظر الدوري"
                            )
                        }
                    }
                }
            }
        }

        // Priority 4: Usage Limits & Launch count limits (حد الاستخدام اليومي)
        if (isUsageMasterEnabled(context)) {
            val isDirectlyBlocked = isPackageDirectlyBlockedByUsage(context, packageName, canonicalPkg)
            if (isDirectlyBlocked) {
                return AppBlockDecision(
                    isBlocked = true,
                    ruleType = "حد الاستخدام اليومي",
                    userMessage = "تم حظر التطبيق ($label) لتجاوز حد الاستخدام اليومي المحدد"
                )
            }
            val usageBlocked = getCurrentlyBlockedPackagesByUsage(context)
            if (usageBlocked.contains(packageName) || usageBlocked.contains(canonicalPkg)) {
                return AppBlockDecision(
                    isBlocked = true,
                    ruleType = "حد الاستخدام اليومي",
                    userMessage = "تم حظر التطبيق ($label) لتجاوز حد الاستخدام اليومي المحدد"
                )
            }
        }

        // Priority 5: Productivity Discipline (تحسين الإنتاجية)
        if (isPackageBlockedByProductivity(context, packageName)) {
            return AppBlockDecision(
                isBlocked = true,
                ruleType = "تحسين الإنتاجية والإنظباط",
                userMessage = "تم حظر وتعليق التطبيق ($label) حتى إكمال سقف وقت التطبيقات المحددة للإنتاجية"
            )
        }

        return null
    }

    fun isSystemSettingsPackage(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        if (isSystemSettingsPackageName(packageName)) return true
        if (!isResolvedSettingsPkgChecked) {
            try {
                val settingsIntent = android.content.Intent(android.provider.Settings.ACTION_SETTINGS)
                val resolveInfo = context.packageManager.resolveActivity(settingsIntent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                cachedResolvedSettingsPkg = resolveInfo?.activityInfo?.packageName
            } catch (_: Exception) {}
            isResolvedSettingsPkgChecked = true
        }
        val resolved = cachedResolvedSettingsPkg
        return !resolved.isNullOrBlank() && resolved.equals(packageName, ignoreCase = true)
    }

    private val KNOWN_SETTINGS_PACKAGES = setOf(
        "com.android.settings",
        "com.google.android.settings",
        "com.coloros.settings",
        "com.oppo.settings",
        "com.realme.settings",
        "com.heytap.setting",
        "com.oplus.wirelesssettings",
        "com.oplus.securitypermission",
        "com.oplus.appdetail",
        "com.oplus.safe",
        "com.coloros.securitypermission",
        "com.coloros.oppoguardelf",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.samsung.android.settings",
        "com.samsung.android.app.telephonyui",
        "com.miui.securitycenter",
        "com.miui.cleanmaster",
        "com.miui.securityadd",
        "com.xiaomi.misettings",
        "com.vivo.settings",
        "com.bbk.settings",
        "com.transsion.settings",
        "com.transsion.phonemaster",
        "com.huawei.systemmanager",
        "com.huawei.android.launcher",
        "com.motorola.settings",
        "com.oneplus.settings",
        "com.lge.settings",
        "com.asus.settings",
        "com.sony.settings",
        "com.lenovo.settings"
    )

    fun isSystemSettingsPackageName(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val lower = packageName.lowercase().trim()
        return KNOWN_SETTINGS_PACKAGES.contains(lower) ||
                lower.endsWith(".settings") ||
                lower.endsWith(".setting") ||
                lower.contains("permissioncontroller") ||
                lower.contains("securitypermission")
    }

    // --- VPN EXCLUDED APPS ---

    fun getExcludedVpnApps(context: Context): Set<String> {
        cachedExcludedVpnApps?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val defaultSet = setOf("com.twitter.android", "com.whatsapp")
        val saved = prefs.getStringSet(KEY_EXCLUDED_VPN_APPS, null)
        val res = saved ?: defaultSet
        cachedExcludedVpnApps = res
        return res
    }

    fun saveExcludedVpnApps(context: Context, excludedSet: Set<String>) {
        cachedExcludedVpnApps = HashSet(excludedSet)
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putStringSet(KEY_EXCLUDED_VPN_APPS, HashSet(excludedSet)).apply()
    }

    fun toggleExcludedVpnApp(context: Context, packageName: String): Set<String> {
        val current = getExcludedVpnApps(context).toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            current.add(packageName)
        }
        saveExcludedVpnApps(context, current)
        return current
    }

    // --- KEYWORD EXEMPTED APPS (استثناء التطبيقات من الكلمات المحظورة) ---

    fun getKeywordExemptedApps(context: Context): Set<String> {
        cachedKeywordExemptedApps?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val saved = prefs.getStringSet(KEY_KEYWORD_EXEMPTED_APPS, null)
        val res = saved ?: emptySet()
        cachedKeywordExemptedApps = res
        return res
    }

    fun saveKeywordExemptedApps(context: Context, apps: Set<String>) {
        cachedKeywordExemptedApps = HashSet(apps)
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putStringSet(KEY_KEYWORD_EXEMPTED_APPS, HashSet(apps)).apply()
    }

    fun isAppExemptedFromKeywords(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val apps = getKeywordExemptedApps(context)
        return apps.contains(packageName)
    }

    fun toggleKeywordExemptedApp(context: Context, packageName: String): Set<String> {
        val current = getKeywordExemptedApps(context).toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            current.add(packageName)
        }
        saveKeywordExemptedApps(context, current)
        return current
    }

    fun removeKeywordExemptedApp(context: Context, packageName: String): Set<String> {
        val current = getKeywordExemptedApps(context).toMutableSet()
        current.remove(packageName)
        saveKeywordExemptedApps(context, current)
        return current
    }

    /**
     * Gathers all package names configured across any block or exemption rule
     * (e.g. Keyword exemptions, Permanent block, Bedtime allowed, App schedule rules,
     * Usage rules, Uninstall block, VPN exclusions, and Productivity targets).
     * Used by AppListHelper to guarantee that uninstalled apps remain visible in drawers and cards.
     */
    fun getAllConfiguredPackagesAcrossAllFeatures(context: Context): Set<String> {
        val result = LinkedHashSet<String>()
        try {
            result.addAll(getKeywordExemptedApps(context))
            result.addAll(getPermanentBlockedPackages(context))
            result.addAll(getBedtimeAllowedApps(context))
            result.addAll(getUninstallBlockedPackages(context))
            result.addAll(getExcludedVpnApps(context))
            for (rule in getAppScheduleRules(context)) {
                result.addAll(rule.selectedPackages)
            }
            for (rule in getUsageRules(context)) {
                result.addAll(rule.selectedPackages)
            }
            getProductivityRule(context)?.targetApps?.forEach {
                result.add(it.packageName)
            }
        } catch (_: Exception) {}
        return result
    }

    // --- PERMANENT BLOCKED APPS (الحظر المؤبد) ---

    fun getPermanentBlockedPackages(context: Context): Set<String> {
        cachedPermanentBlockedPackages?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getStringSet(KEY_PERMANENT_BLOCKED_PACKAGES, emptySet()) ?: emptySet()
        val filtered = res.map { it.trim().lowercase() }.filter {
            it.isNotBlank() && !isStrictUnblockableSystemPackage(context, it)
        }.toSet()
        cachedPermanentBlockedPackages = filtered
        return filtered
    }

    fun setPermanentBlockedPackages(context: Context, packages: Set<String>) {
        val normalized = packages.map { it.trim().lowercase() }.filter {
            it.isNotBlank() && !isStrictUnblockableSystemPackage(context, it)
        }.toSet()
        cachedPermanentBlockedPackages = normalized
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putStringSet(KEY_PERMANENT_BLOCKED_PACKAGES, HashSet(normalized)).apply()

        // Immediate suspension of newly added packages
        for (pkg in normalized) {
            applySinglePackageSuspension(context, pkg, true)
        }

        // Immediate kick-out if currently in foreground
        val currentActive = activeForegroundPackage?.trim()?.lowercase()
        if (!currentActive.isNullOrBlank() && normalized.contains(currentActive)) {
            val pkgToEvict = currentActive
            clearActiveForegroundPackage()
            enforcementListener?.onAppBlockedImmediately(
                pkgToEvict,
                "الحظر المؤبد",
                "تم حظر وتعليق التطبيق نهائياً ضمن قائمة الحظر المؤبد"
            )
        }

        syncAllPackageSuspensions(context)
    }

    fun addPermanentBlockedPackage(context: Context, packageName: String) {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName)) return
        val current = getPermanentBlockedPackages(context).toMutableSet()
        current.add(packageName.trim().lowercase())
        setPermanentBlockedPackages(context, current)
    }

    fun removePermanentBlockedPackage(context: Context, packageName: String) {
        if (packageName.isBlank()) return
        val current = getPermanentBlockedPackages(context).toMutableSet()
        current.remove(packageName.trim().lowercase())
        setPermanentBlockedPackages(context, current)
    }

    fun isPackagePermanentlyBlocked(context: Context, packageName: String): Boolean {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName)) return false
        val lower = packageName.trim().lowercase()
        val ownPkg = context.packageName.lowercase()
        if (lower == ownPkg) return false
        val blocked = getPermanentBlockedPackages(context)
        return blocked.contains(lower)
    }

    // --- UNINSTALL BLOCKED APPS (منع حذف التطبيقات - Device Owner) ---

    fun getUninstallBlockedPackages(context: Context): Set<String> {
        cachedUninstallBlockedPackages?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getStringSet(KEY_UNINSTALL_BLOCKED_PACKAGES, emptySet()) ?: emptySet()
        val ownPkg = context.packageName.lowercase()
        val filtered = res.map { it.trim().lowercase() }.filter {
            it.isNotBlank() && it != ownPkg && !isStrictUnblockableSystemPackage(context, it)
        }.toSet()
        cachedUninstallBlockedPackages = filtered
        return filtered
    }

    fun setUninstallBlockedPackages(context: Context, packages: Set<String>) {
        val oldSet = getUninstallBlockedPackages(context)
        val ownPkg = context.packageName.lowercase()
        val normalized = packages.map { it.trim().lowercase() }.filter {
            it.isNotBlank() && it != ownPkg && !isStrictUnblockableSystemPackage(context, it)
        }.toSet()
        cachedUninstallBlockedPackages = normalized
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putStringSet(KEY_UNINSTALL_BLOCKED_PACKAGES, HashSet(normalized)).apply()

        // Immediate Device Owner enforcement for removed and added packages
        val removed = oldSet - normalized
        for (pkg in removed) {
            SaffahProtectionManager.setPackageUninstallBlocked(context, pkg, false)
        }
        val added = normalized - oldSet
        for (pkg in added) {
            SaffahProtectionManager.setPackageUninstallBlocked(context, pkg, true)
        }
    }

    fun addUninstallBlockedPackage(context: Context, packageName: String) {
        if (packageName.isBlank() || packageName.trim().equals(context.packageName, ignoreCase = true)) return
        val current = getUninstallBlockedPackages(context).toMutableSet()
        current.add(packageName.trim().lowercase())
        setUninstallBlockedPackages(context, current)
    }

    fun removeUninstallBlockedPackage(context: Context, packageName: String) {
        if (packageName.isBlank()) return
        val current = getUninstallBlockedPackages(context).toMutableSet()
        current.remove(packageName.trim().lowercase())
        setUninstallBlockedPackages(context, current)
    }

    fun isPackageUninstallBlocked(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val lower = packageName.trim().lowercase()
        if (lower == context.packageName.lowercase()) return true
        val blocked = getUninstallBlockedPackages(context)
        return blocked.contains(lower)
    }

    // --- TIME DELAY (ميزة التأخير الزمني) ---

    fun isTimeDelayActive(context: Context): Boolean {
        // إذا كان قفل QR المادي مفعلاً كطريقة حماية، يتم تعطيل التأخير الزمني تلقائياً
        if (SaffahQrKeyManager.isQrKeyProtectionActive(context)) {
            return false
        }
        val prefs = getSafeSharedPreferences(context)
        val enabled = prefs.getBoolean(KEY_TIME_DELAY_ENABLED, false)
        if (!enabled) return false
        val until = prefs.getLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, 0L)
        val now = System.currentTimeMillis()
        if (now >= until) {
            prefs.edit().putBoolean(KEY_TIME_DELAY_ENABLED, false).putLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, 0L).apply()
            SaffahNotificationManager.evaluateAndTriggerTimeDelayExpirationNotification(context)
            return false
        }
        return true
    }

    fun getTimeDelayRemainingMs(context: Context): Long {
        if (SaffahQrKeyManager.isQrKeyProtectionActive(context)) return 0L
        val prefs = getSafeSharedPreferences(context)
        val enabled = prefs.getBoolean(KEY_TIME_DELAY_ENABLED, false)
        if (!enabled) return 0L
        val until = prefs.getLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, 0L)
        val now = System.currentTimeMillis()
        val diff = until - now
        if (diff <= 0L) {
            prefs.edit().putBoolean(KEY_TIME_DELAY_ENABLED, false).putLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, 0L).apply()
            SaffahNotificationManager.evaluateAndTriggerTimeDelayExpirationNotification(context)
            return 0L
        }
        return diff
    }

    fun getTimeDelayUntilTimestamp(context: Context): Long {
        if (SaffahQrKeyManager.isQrKeyProtectionActive(context)) return 0L
        return getSafeSharedPreferences(context).getLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, 0L)
    }

    fun getConfiguredTimeDelayHours(context: Context): Long {
        return getSafeSharedPreferences(context).getLong(KEY_TIME_DELAY_CONFIGURED_HOURS, 1L).coerceAtLeast(1L)
    }

    fun saveConfiguredTimeDelayHours(context: Context, hours: Long) {
        val validHours = if (hours < 1L) 1L else hours
        getSafeSharedPreferences(context).edit()
            .putLong(KEY_TIME_DELAY_CONFIGURED_HOURS, validHours)
            .apply()
    }

    fun startTimeDelay(context: Context, hours: Long): Boolean {
        // لا يُسمح بتفعيل التأخير الزمني إذا كان قفل QR مفعلاً كطريقة حماية
        if (SaffahQrKeyManager.isQrKeyProtectionActive(context)) {
            return false
        }
        val validHours = if (hours < 1L) 1L else hours
        val now = System.currentTimeMillis()
        val until = now + (validHours * 3600 * 1000L)
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putBoolean(KEY_TIME_DELAY_ENABLED, true)
            .putLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, until)
            .putLong(KEY_TIME_DELAY_CONFIGURED_HOURS, validHours)
            .apply()
        SaffahNotificationManager.scheduleTimeDelayExpirationAlarm(context)
        return true
    }

    fun stopTimeDelay(context: Context) {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putBoolean(KEY_TIME_DELAY_ENABLED, false)
            .putLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, 0L)
            .apply()
        SaffahNotificationManager.cancelTimeDelayExpirationAlarm(context)
    }

    fun extendTimeDelay(context: Context, additionalHours: Long): Boolean {
        if (SaffahQrKeyManager.isQrKeyProtectionActive(context)) {
            return false
        }
        if (additionalHours <= 0L) return false
        val currentUntil = getTimeDelayUntilTimestamp(context)
        val now = System.currentTimeMillis()
        val base = if (currentUntil > now) currentUntil else now
        val newUntil = base + (additionalHours * 3600 * 1000L)
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putBoolean(KEY_TIME_DELAY_ENABLED, true)
            .putLong(KEY_TIME_DELAY_UNTIL_TIMESTAMP, newUntil)
            .apply()
        SaffahNotificationManager.scheduleTimeDelayExpirationAlarm(context)
        return true
    }

    fun isBedtimeModificationAllowedWindow(): Boolean {
        // Allowed window: 07:00 AM to 12:00 PM (07:00 to 11:59).
        val hourOfDay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.LocalTime.now().hour
        } else {
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        }
        return hourOfDay in 7..11
    }

    fun isBedtimeModificationRestrictedByTimeDelay(context: Context): Boolean {
        if (!isTimeDelayActive(context)) return false
        return !isBedtimeModificationAllowedWindow()
    }

    fun calculateBedtimeDurationMinutes(startH: Int, startM: Int, endH: Int, endM: Int): Int {
        val startMin = startH * 60 + startM
        val endMin = endH * 60 + endM
        return if (endMin > startMin) {
            endMin - startMin
        } else if (endMin < startMin) {
            (1440 - startMin) + endMin
        } else {
            1440
        }
    }

    // --- TRIGGER BLOCKING (TELEGRAM & WHATSAPP) ---

    fun isTelegramSearchBlocked(context: Context): Boolean {
        cachedTelegramSearchBlocked?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BLOCK_TELEGRAM_SEARCH, false)
        cachedTelegramSearchBlocked = res
        return res
    }

    fun setTelegramSearchBlocked(context: Context, enabled: Boolean) {
        cachedTelegramSearchBlocked = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BLOCK_TELEGRAM_SEARCH, enabled).apply()
    }

    fun isWhatsAppChannelsBlocked(context: Context): Boolean {
        cachedWhatsAppChannelsBlocked?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BLOCK_WHATSAPP_CHANNELS, false)
        cachedWhatsAppChannelsBlocked = res
        return res
    }

    fun setWhatsAppChannelsBlocked(context: Context, enabled: Boolean) {
        cachedWhatsAppChannelsBlocked = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BLOCK_WHATSAPP_CHANNELS, enabled).apply()
    }

    fun isYouTubeShortsBlocked(context: Context): Boolean {
        cachedYouTubeShortsBlocked?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BLOCK_YOUTUBE_SHORTS, false)
        cachedYouTubeShortsBlocked = res
        return res
    }

    fun setYouTubeShortsBlocked(context: Context, enabled: Boolean) {
        cachedYouTubeShortsBlocked = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BLOCK_YOUTUBE_SHORTS, enabled).apply()
    }

    fun isFacebookLiteReelsBlocked(context: Context): Boolean {
        cachedFacebookLiteReelsBlocked?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BLOCK_FACEBOOK_LITE_REELS, false)
        cachedFacebookLiteReelsBlocked = res
        return res
    }

    fun setFacebookLiteReelsBlocked(context: Context, enabled: Boolean) {
        cachedFacebookLiteReelsBlocked = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BLOCK_FACEBOOK_LITE_REELS, enabled).apply()
    }

    fun isInstagramReelsBlocked(context: Context): Boolean {
        cachedInstagramReelsBlocked?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BLOCK_INSTAGRAM_REELS, false)
        cachedInstagramReelsBlocked = res
        return res
    }

    fun setInstagramReelsBlocked(context: Context, enabled: Boolean) {
        cachedInstagramReelsBlocked = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BLOCK_INSTAGRAM_REELS, enabled).apply()
    }

    fun isBlockUnsupportedBrowsers(context: Context): Boolean {
        cachedBlockUnsupportedBrowsers?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BLOCK_UNSUPPORTED_BROWSERS, false)
        cachedBlockUnsupportedBrowsers = res
        return res
    }

    fun setBlockUnsupportedBrowsers(context: Context, enabled: Boolean) {
        cachedBlockUnsupportedBrowsers = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BLOCK_UNSUPPORTED_BROWSERS, enabled).apply()
    }

    fun isBlockInAppBrowsers(context: Context): Boolean {
        cachedBlockInAppBrowsers?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BLOCK_IN_APP_BROWSERS, false)
        cachedBlockInAppBrowsers = res
        return res
    }

    fun setBlockInAppBrowsers(context: Context, enabled: Boolean) {
        cachedBlockInAppBrowsers = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BLOCK_IN_APP_BROWSERS, enabled).apply()
    }

    fun isHideVpnNotification(context: Context): Boolean {
        cachedHideVpnNotification?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_HIDE_VPN_NOTIFICATION, false)
        cachedHideVpnNotification = res
        return res
    }

    fun setHideVpnNotification(context: Context, enabled: Boolean) {
        cachedHideVpnNotification = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_HIDE_VPN_NOTIFICATION, enabled).apply()
        if (enabled) {
            com.example.service.SaffahNotificationListenerService.requestHideVpnNotification(context)
        }
    }

    fun isAiProtectionEnabled(context: Context): Boolean {
        return isAiNudeNetEnabled(context) || isAiAnimeEnabled(context)
    }

    fun isAiNudeNetEnabled(context: Context): Boolean {
        cachedAiNudeNetEnabled?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        // Default to true if general AI protection was previously enabled, or default true for first time
        val legacy = prefs.getBoolean(KEY_AI_PROTECTION_ENABLED, true)
        val res = prefs.getBoolean(KEY_AI_NUDENET_ENABLED, legacy)
        cachedAiNudeNetEnabled = res
        return res
    }

    fun setAiNudeNetEnabled(context: Context, enabled: Boolean) {
        cachedAiNudeNetEnabled = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_AI_NUDENET_ENABLED, enabled).apply()
        // Keep KEY_AI_PROTECTION_ENABLED in sync with overall active state
        val overall = enabled || isAiAnimeEnabled(context)
        cachedAiProtectionEnabled = overall
        prefs.edit().putBoolean(KEY_AI_PROTECTION_ENABLED, overall).apply()
        if (enabled) {
            try {
                com.example.util.SaffahProtectionManager.ensureAccessibilityServiceEnabled(context)
            } catch (_: Exception) {}
        }
        com.example.service.SaffahAccessibilityService.notifyAiProtectionChanged(context)
    }

    fun isAiAnimeEnabled(context: Context): Boolean {
        cachedAiAnimeEnabled?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val legacy = prefs.getBoolean(KEY_AI_PROTECTION_ENABLED, true)
        val res = prefs.getBoolean(KEY_AI_ANIME_ENABLED, legacy)
        cachedAiAnimeEnabled = res
        return res
    }

    fun setAiAnimeEnabled(context: Context, enabled: Boolean) {
        cachedAiAnimeEnabled = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_AI_ANIME_ENABLED, enabled).apply()
        // Keep KEY_AI_PROTECTION_ENABLED in sync with overall active state
        val overall = isAiNudeNetEnabled(context) || enabled
        cachedAiProtectionEnabled = overall
        prefs.edit().putBoolean(KEY_AI_PROTECTION_ENABLED, overall).apply()
        if (enabled) {
            try {
                com.example.util.SaffahProtectionManager.ensureAccessibilityServiceEnabled(context)
            } catch (_: Exception) {}
        }
        com.example.service.SaffahAccessibilityService.notifyAiProtectionChanged(context)
    }

    fun setAiProtectionEnabled(context: Context, enabled: Boolean) {
        cachedAiProtectionEnabled = enabled
        setAiNudeNetEnabled(context, enabled)
        setAiAnimeEnabled(context, enabled)
    }

    private const val KEY_AI_PROTECTION_INCLUDED_APPS = "ai_protection_included_apps"
    private val DEFAULT_AI_INCLUDED_APPS = setOf(
        "com.android.chrome",
        "com.chrome.beta",
        "com.chrome.dev",
        "com.chrome.canary"
    )

    fun getAiProtectionIncludedApps(context: Context): Set<String> {
        cachedAiIncludedApps?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val stringSet = prefs.getStringSet(KEY_AI_PROTECTION_INCLUDED_APPS, null)
        val res = if (stringSet == null) {
            DEFAULT_AI_INCLUDED_APPS
        } else {
            stringSet
        }
        cachedAiIncludedApps = res
        return res
    }

    fun setAiProtectionIncludedApps(context: Context, apps: Set<String>) {
        cachedAiIncludedApps = apps
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putStringSet(KEY_AI_PROTECTION_INCLUDED_APPS, apps).apply()
        com.example.service.SaffahAccessibilityService.notifyAiProtectionChanged(context)
    }

    fun toggleAiProtectionIncludedApp(context: Context, packageName: String): Boolean {
        val current = getAiProtectionIncludedApps(context).toMutableSet()
        val isNowIncluded = if (current.contains(packageName)) {
            current.remove(packageName)
            false
        } else {
            current.add(packageName)
            true
        }
        setAiProtectionIncludedApps(context, current)
        return isNowIncluded
    }

    // --- BEDTIME MODE METHODS ---

    fun isBedtimeModeEnabled(context: Context): Boolean {
        cachedBedtimeEnabled?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BEDTIME_ENABLED, false)
        cachedBedtimeEnabled = res
        return res
    }

    @Volatile private var cachedBedtimeActiveResult: Boolean? = null
    @Volatile private var cachedBedtimeActiveTimestamp: Long = 0L
    @Volatile private var cachedBedtimeMinuteEpoch: Long = -1L

    fun invalidateBedtimeActiveCache() {
        cachedBedtimeActiveResult = null
        cachedBedtimeActiveTimestamp = 0L
        cachedBedtimeMinuteEpoch = -1L
    }

    fun setBedtimeModeEnabled(context: Context, enabled: Boolean) {
        cachedBedtimeEnabled = enabled
        invalidateBedtimeActiveCache()
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BEDTIME_ENABLED, enabled).apply()
    }

    fun getBedtimeSchedule(context: Context): Pair<Pair<Int, Int>, Pair<Int, Int>> {
        cachedBedtimeSchedule?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val startH = prefs.getInt(KEY_BEDTIME_START_HOUR, 23)
        val startM = prefs.getInt(KEY_BEDTIME_START_MINUTE, 0)
        val endH = prefs.getInt(KEY_BEDTIME_END_HOUR, 5)
        val endM = prefs.getInt(KEY_BEDTIME_END_MINUTE, 0)
        val res = Pair(Pair(startH, startM), Pair(endH, endM))
        cachedBedtimeSchedule = res
        return res
    }

    fun saveBedtimeSchedule(context: Context, startHour: Int, startMinute: Int, endHour: Int, endMinute: Int) {
        cachedBedtimeSchedule = Pair(Pair(startHour, startMinute), Pair(endHour, endMinute))
        invalidateBedtimeActiveCache()
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putInt(KEY_BEDTIME_START_HOUR, startHour)
            .putInt(KEY_BEDTIME_START_MINUTE, startMinute)
            .putInt(KEY_BEDTIME_END_HOUR, endHour)
            .putInt(KEY_BEDTIME_END_MINUTE, endMinute)
            .apply()
    }

    fun getDefaultBedtimeAllowedApps(): Set<String> {
        return emptySet()
    }

    fun getBedtimeAllowedApps(context: Context): Set<String> {
        cachedBedtimeAllowedApps?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val saved = prefs.getStringSet(KEY_BEDTIME_ALLOWED_APPS, null)
        val res = saved ?: emptySet()
        cachedBedtimeAllowedApps = res
        return res
    }

    fun saveBedtimeAllowedApps(context: Context, apps: Set<String>) {
        cachedBedtimeAllowedApps = HashSet(apps)
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putStringSet(KEY_BEDTIME_ALLOWED_APPS, HashSet(apps)).apply()
    }

    fun toggleBedtimeAllowedApp(context: Context, packageName: String): Set<String> {
        val current = getBedtimeAllowedApps(context).toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            current.add(packageName)
        }
        saveBedtimeAllowedApps(context, current)
        return current
    }

    fun isBedtimeGrayscaleEnabled(context: Context): Boolean {
        cachedBedtimeGrayscale?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BEDTIME_GRAYSCALE, false)
        cachedBedtimeGrayscale = res
        return res
    }

    fun setBedtimeGrayscaleEnabled(context: Context, enabled: Boolean) {
        cachedBedtimeGrayscale = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BEDTIME_GRAYSCALE, enabled).apply()
    }

    fun isBedtimeEyeComfortEnabled(context: Context): Boolean {
        cachedBedtimeEyeComfort?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_BEDTIME_EYE_COMFORT_ENABLED, false)
        cachedBedtimeEyeComfort = res
        return res
    }

    fun setBedtimeEyeComfortEnabled(context: Context, enabled: Boolean) {
        cachedBedtimeEyeComfort = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_BEDTIME_EYE_COMFORT_ENABLED, enabled).apply()
    }

    fun getBedtimeDays(context: Context): Set<Int> {
        cachedBedtimeDays?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val saved = prefs.getStringSet(KEY_BEDTIME_DAYS, null)
        val res = if (saved == null) {
            setOf(
                java.util.Calendar.SUNDAY,
                java.util.Calendar.MONDAY,
                java.util.Calendar.TUESDAY,
                java.util.Calendar.WEDNESDAY,
                java.util.Calendar.THURSDAY,
                java.util.Calendar.FRIDAY,
                java.util.Calendar.SATURDAY
            )
        } else {
            saved.mapNotNull { it.toIntOrNull() }.toSet()
        }
        cachedBedtimeDays = res
        return res
    }

    fun saveBedtimeDays(context: Context, days: Set<Int>) {
        cachedBedtimeDays = HashSet(days)
        invalidateBedtimeActiveCache()
        val prefs = getSafeSharedPreferences(context)
        val stringSet = days.map { it.toString() }.toSet()
        prefs.edit().putStringSet(KEY_BEDTIME_DAYS, HashSet(stringSet)).apply()
    }

    fun toggleBedtimeDay(context: Context, dayOfWeek: Int): Set<Int> {
        val current = getBedtimeDays(context).toMutableSet()
        if (current.contains(dayOfWeek)) {
            current.remove(dayOfWeek)
        } else {
            current.add(dayOfWeek)
        }
        saveBedtimeDays(context, current)
        return current
    }

    fun isCurrentlyBedtime(context: Context): Boolean {
        if (!isBedtimeModeEnabled(context)) return false
        val nowWall = System.currentTimeMillis()
        val currentMinuteEpoch = nowWall / 60_000L
        val nowElapsed = android.os.SystemClock.elapsedRealtime()
        val cached = cachedBedtimeActiveResult
        if (cached != null && (nowElapsed - cachedBedtimeActiveTimestamp < 1500L) && currentMinuteEpoch == cachedBedtimeMinuteEpoch) {
            return cached
        }

        val activeDays = getBedtimeDays(context)
        if (activeDays.isEmpty()) {
            cachedBedtimeActiveResult = false
            cachedBedtimeActiveTimestamp = nowElapsed
            cachedBedtimeMinuteEpoch = currentMinuteEpoch
            return false
        }

        val schedule = getBedtimeSchedule(context)
        val (todayOfWeek, nowMinutes) = getCachedTimeContext()

        val startMinutes = schedule.first.first * 60 + schedule.first.second
        val endMinutes = schedule.second.first * 60 + schedule.second.second

        val res = if (startMinutes == endMinutes) {
            false
        } else if (startMinutes < endMinutes) {
            if (!activeDays.contains(todayOfWeek)) false
            else (nowMinutes in startMinutes until endMinutes)
        } else {
            // Overnight schedule, e.g. 23:00 to 05:00
            if (nowMinutes >= startMinutes) {
                activeDays.contains(todayOfWeek)
            } else if (nowMinutes < endMinutes) {
                val yesterdayOfWeek = if (todayOfWeek == java.util.Calendar.SUNDAY) java.util.Calendar.SATURDAY else todayOfWeek - 1
                activeDays.contains(yesterdayOfWeek)
            } else {
                false
            }
        }
        cachedBedtimeActiveResult = res
        cachedBedtimeActiveTimestamp = nowElapsed
        cachedBedtimeMinuteEpoch = currentMinuteEpoch
        return res
    }

    /**
     * Checks if current time is within the 30-minute pre-bedtime window through bedtime schedule end.
     * Starts automatically 30 minutes before bedtime begins, and continues until bedtime schedule ends.
     */
    fun isCurrentlyInBedtimePre30Window(context: Context): Boolean {
        if (!isBedtimeModeEnabled(context)) return false
        val activeDays = getBedtimeDays(context)
        if (activeDays.isEmpty()) return false

        val schedule = getBedtimeSchedule(context)
        val startH = schedule.first.first
        val startM = schedule.first.second
        val endH = schedule.second.first
        val endM = schedule.second.second

        if (startH == endH && startM == endM) return false

        val now = java.util.Calendar.getInstance()
        val nowMillis = now.timeInMillis

        // Iterate through yesterday, today, and tomorrow to handle all midnight & overnight crossovers
        for (dayOffset in listOf(-1, 0, 1)) {
            val baseCal = (now.clone() as java.util.Calendar).apply {
                add(java.util.Calendar.DAY_OF_YEAR, dayOffset)
            }
            val dayOfWeek = baseCal.get(java.util.Calendar.DAY_OF_WEEK)
            if (!activeDays.contains(dayOfWeek)) continue

            // Session scheduled start time on baseCal's day
            val sessionStart = (baseCal.clone() as java.util.Calendar).apply {
                set(java.util.Calendar.HOUR_OF_DAY, startH)
                set(java.util.Calendar.MINUTE, startM)
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }

            // 30 minutes prior to session start
            val sessionPreStart = (sessionStart.clone() as java.util.Calendar).apply {
                add(java.util.Calendar.MINUTE, -30)
            }

            // Session scheduled end time
            val sessionEnd = (baseCal.clone() as java.util.Calendar).apply {
                set(java.util.Calendar.HOUR_OF_DAY, endH)
                set(java.util.Calendar.MINUTE, endM)
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }

            val startMinutes = startH * 60 + startM
            val endMinutes = endH * 60 + endM
            if (endMinutes <= startMinutes) {
                // Overnight schedule: end is on next calendar day
                sessionEnd.add(java.util.Calendar.DAY_OF_YEAR, 1)
            }

            if (nowMillis in sessionPreStart.timeInMillis until sessionEnd.timeInMillis) {
                return true
            }
        }

        return false
    }

    /**
     * Checks if current time is within the Bedtime Grayscale window.
     * The window starts automatically 30 minutes before bedtime begins,
     * and continues until bedtime schedule ends.
     */
    fun isCurrentlyInBedtimeGrayscaleWindow(context: Context): Boolean {
        if (!isBedtimeGrayscaleEnabled(context)) return false
        return isCurrentlyInBedtimePre30Window(context)
    }

    /**
     * Checks if current time is within the Bedtime Eye Comfort window.
     * The window starts automatically 30 minutes before bedtime begins,
     * and continues until bedtime schedule ends.
     */
    fun isCurrentlyInBedtimeEyeComfortWindow(context: Context): Boolean {
        if (!isBedtimeEyeComfortEnabled(context)) return false
        return isCurrentlyInBedtimePre30Window(context)
    }

    fun ensureSwitchesDefaultOff(context: Context) {
        val prefs = getSafeSharedPreferences(context)
        if (!prefs.getBoolean("has_switches_defaulted_to_off_v1", false)) {
            val editor = prefs.edit()
            editor.putBoolean(KEY_BLOCK_TELEGRAM_SEARCH, false)
            editor.putBoolean(KEY_BLOCK_WHATSAPP_CHANNELS, false)
            editor.putBoolean(KEY_BLOCK_YOUTUBE_SHORTS, false)
            editor.putBoolean(KEY_BLOCK_FACEBOOK_LITE_REELS, false)
            editor.putBoolean(KEY_BLOCK_INSTAGRAM_REELS, false)
            editor.putBoolean(KEY_BLOCK_UNSUPPORTED_BROWSERS, false)
            editor.putBoolean(KEY_BEDTIME_GRAYSCALE, false)
            editor.putBoolean("app_schedule_master_enabled", false)
            editor.putBoolean("usage_master_enabled", false)
            editor.putBoolean("has_switches_defaulted_to_off_v1", true)
            editor.apply()
            cachedTelegramSearchBlocked = false
            cachedWhatsAppChannelsBlocked = false
            cachedYouTubeShortsBlocked = false
            cachedFacebookLiteReelsBlocked = false
            cachedInstagramReelsBlocked = false
            cachedBlockUnsupportedBrowsers = false
            cachedBedtimeGrayscale = false
            cachedAppScheduleMasterEnabled = false
            cachedUsageMasterEnabled = false
        }
    }

    // --- KEYWORDS ---

    private const val KEYWORDS_FILE_NAME = "saffah_blocked_keywords.tsv"

    private fun loadBlockedKeywordsFromFile(context: Context): List<BlockedKeyword>? {
        val file = java.io.File(context.filesDir, KEYWORDS_FILE_NAME)
        if (!file.exists() || file.length() == 0L) return null
        return try {
            val list = ArrayList<BlockedKeyword>()
            file.bufferedReader(Charsets.UTF_8, 65536).useLines { lines ->
                for (line in lines) {
                    if (line.isEmpty()) continue
                    val tab1 = line.indexOf('\t')
                    if (tab1 != -1) {
                        val tab2 = line.indexOf('\t', tab1 + 1)
                        if (tab2 != -1) {
                            val tab3 = line.indexOf('\t', tab2 + 1)
                            if (tab3 != -1) {
                                val id = line.substring(0, tab1).toLongOrNull() ?: 0L
                                val isEnabled = line[tab1 + 1] == '1'
                                val dateAdded = line.substring(tab2 + 1, tab3)
                                val keyword = line.substring(tab3 + 1)
                                list.add(BlockedKeyword(id, keyword, dateAdded, isEnabled))
                            }
                        }
                    }
                }
            }
            list
        } catch (e: Exception) {
            Log.e("SaffahBlockRepo", "Error reading keywords file: ${e.message}")
            null
        }
    }

    private fun saveBlockedKeywordsToFile(context: Context, list: List<BlockedKeyword>) {
        try {
            val file = java.io.File(context.filesDir, KEYWORDS_FILE_NAME)
            val tempFile = java.io.File(context.filesDir, "$KEYWORDS_FILE_NAME.tmp")
            tempFile.bufferedWriter(Charsets.UTF_8, 65536).use { writer ->
                for (item in list) {
                    writer.write(item.id.toString())
                    writer.write('\t'.code)
                    writer.write(if (item.isEnabled) '1'.code else '0'.code)
                    writer.write('\t'.code)
                    writer.write(item.dateAdded)
                    writer.write('\t'.code)
                    writer.write(item.keyword)
                    writer.write('\n'.code)
                }
            }
            if (!tempFile.renameTo(file)) {
                file.delete()
                tempFile.renameTo(file)
            }
        } catch (e: Exception) {
            Log.e("SaffahBlockRepo", "Error saving keywords file: ${e.message}")
        }
    }

    fun getBlockedKeywords(context: Context): List<BlockedKeyword> {
        cachedKeywords?.let { return it }
        val fromFile = loadBlockedKeywordsFromFile(context)
        if (fromFile != null) {
            cachedKeywords = fromFile
            return fromFile
        }

        val prefs = getSafeSharedPreferences(context)
        val isInitialized = prefs.getBoolean(KEY_KEYWORDS_INITIALIZED, false)
        val jsonStr = prefs.getString(KEY_KEYWORDS, null)

        if (!isInitialized && jsonStr == null) {
            val defaultList = getDefaultKeywords()
            prefs.edit().putBoolean(KEY_KEYWORDS_INITIALIZED, true).apply()
            saveBlockedKeywords(context, defaultList)
            return defaultList
        }

        if (!isInitialized) {
            prefs.edit().putBoolean(KEY_KEYWORDS_INITIALIZED, true).apply()
        }

        if (jsonStr.isNullOrEmpty()) {
            val empty = emptyList<BlockedKeyword>()
            cachedKeywords = empty
            return empty
        }

        val res = try {
            val array = JSONArray(jsonStr)
            val list = ArrayList<BlockedKeyword>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    BlockedKeyword(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        keyword = obj.optString("keyword", ""),
                        dateAdded = obj.optString("dateAdded", ""),
                        isEnabled = obj.optBoolean("isEnabled", true)
                    )
                )
            }
            list
        } catch (e: Exception) {
            Log.e("SaffahBlockRepo", "Error parsing legacy keywords: ${e.message}")
            emptyList()
        }
        cachedKeywords = res
        saveBlockedKeywordsToFile(context, res)
        try {
            prefs.edit().remove(KEY_KEYWORDS).apply()
        } catch (_: Exception) {}
        return res
    }

    fun addBlockedKeyword(context: Context, rawKeyword: String): List<BlockedKeyword> {
        val trimmed = rawKeyword.trim()
        if (trimmed.isEmpty()) return getBlockedKeywords(context)

        val current = getBlockedKeywords(context)
        if (current.none { it.keyword.equals(trimmed, ignoreCase = true) }) {
            val newEntry = BlockedKeyword(
                id = System.currentTimeMillis(),
                keyword = trimmed,
                dateAdded = getCurrentDateString(),
                isEnabled = true
            )
            val updated = ArrayList<BlockedKeyword>(current.size + 1)
            updated.add(newEntry)
            updated.addAll(current)
            saveBlockedKeywords(context, updated)
            return updated
        }
        return current
    }

    fun addBlockedKeywordsBulk(context: Context, rawKeywords: List<String>): Pair<List<BlockedKeyword>, Int> {
        val current = getBlockedKeywords(context)
        val existingSet = HashSet<String>((current.size + rawKeywords.size / 0.7f).toInt() + 16)
        for (k in current) {
            existingSet.add(k.keyword.lowercase().trim())
        }
        val dateStr = getCurrentDateString()
        var addedCount = 0
        var baseTime = System.currentTimeMillis()
        val newEntries = ArrayList<BlockedKeyword>(rawKeywords.size)

        for (raw in rawKeywords) {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) continue
            val lower = trimmed.lowercase()
            if (existingSet.add(lower)) {
                newEntries.add(
                    BlockedKeyword(
                        id = baseTime++,
                        keyword = trimmed,
                        dateAdded = dateStr,
                        isEnabled = true
                    )
                )
                addedCount++
            }
        }

        if (addedCount > 0) {
            newEntries.addAll(current)
            saveBlockedKeywords(context, newEntries)
            return Pair(newEntries, addedCount)
        }
        return Pair(current, 0)
    }

    fun removeBlockedKeyword(context: Context, id: Long, keywordText: String? = null): List<BlockedKeyword> {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_KEYWORDS_INITIALIZED, true).apply()
        val current = getBlockedKeywords(context).filterNot {
            it.id == id || (keywordText != null && it.keyword.equals(keywordText.trim(), ignoreCase = true))
        }
        saveBlockedKeywords(context, current)
        return current
    }

    fun clearAllBlockedKeywords(context: Context): List<BlockedKeyword> {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_KEYWORDS_INITIALIZED, true).apply()
        saveBlockedKeywords(context, emptyList())
        return emptyList()
    }

    fun saveBlockedKeywords(context: Context, list: List<BlockedKeyword>) {
        cachedKeywords = list
        cachedCompiledKeywords = null
        cachedFastKeywordMatcher = null
        saveBlockedKeywordsToFile(context, list)
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putBoolean(KEY_KEYWORDS_INITIALIZED, true)
            .remove(KEY_KEYWORDS)
            .apply()
    }

    fun normalizeArabicChars(input: CharSequence): String {
        var needsNormalization = false
        for (i in 0 until input.length) {
            val c = input[i]
            if (c == 'أ' || c == 'إ' || c == 'آ' || c == 'ٱ' || c == 'ة' || c == 'ى' || c == 'ئ' || c == 'ؤ' ||
                (c in '\u064B'..'\u0652') || c == '\u0640'
            ) {
                needsNormalization = true
                break
            }
        }
        if (!needsNormalization) {
            return input.toString()
        }

        val sb = StringBuilder(input.length)
        for (i in 0 until input.length) {
            when (val c = input[i]) {
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'ى' -> sb.append('ي')
                'ئ', 'ؤ' -> sb.append('ء')
                '\u064B', '\u064C', '\u064D', '\u064E', '\u064F', '\u0650', '\u0651', '\u0652', '\u0640' -> {
                    // Skip Arabic Tashkeel (diacritics) & Tatweel (_)
                }
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun containsArabicOrAlefVariants(s: CharSequence): Boolean {
        for (i in 0 until s.length) {
            val c = s[i]
            if (c in '\u0600'..'\u06FF' || c == 'أ' || c == 'إ' || c == 'آ' || c == 'ة' || c == 'ى') {
                return true
            }
        }
        return false
    }

    fun getCompiledBlockedKeywords(context: Context): List<com.example.model.CompiledKeywordRule> {
        cachedCompiledKeywords?.let { return it }
        val keywords = getBlockedKeywords(context).filter { it.isEnabled && it.keyword.isNotBlank() }
        val compiled = keywords.map { kw ->
            val trimmed = kw.keyword.trim()
            val isStar = trimmed.startsWith("*") && trimmed.endsWith("*") && trimmed.length > 2
            val target = if (isStar) trimmed.substring(1, trimmed.length - 1).trim() else trimmed
            val lowerTarget = target.lowercase()
            val isAr = containsArabicOrAlefVariants(lowerTarget)
            val normalizedTarget = if (isAr) normalizeArabicChars(lowerTarget) else lowerTarget
            com.example.model.CompiledKeywordRule(
                id = kw.id,
                keyword = kw.keyword,
                isStarBounded = isStar,
                targetWordLower = lowerTarget,
                targetWordNormalized = normalizedTarget,
                isArabicOrContainsAlef = isAr
            )
        }
        cachedCompiledKeywords = compiled
        cachedFastKeywordMatcher = SaffahFastKeywordMatcher(compiled)
        return compiled
    }

    fun getFastKeywordMatcher(context: Context): SaffahFastKeywordMatcher {
        cachedFastKeywordMatcher?.let { return it }
        val compiled = getCompiledBlockedKeywords(context)
        val matcher = SaffahFastKeywordMatcher(compiled)
        cachedFastKeywordMatcher = matcher
        return matcher
    }

    private fun getDefaultKeywords(): List<BlockedKeyword> {
        return listOf(
            BlockedKeyword(1, "*xxx*", "2026-08-01"),
            BlockedKeyword(2, "*porn*", "2026-08-02"),
            BlockedKeyword(3, "adult content", "2026-08-03")
        )
    }

    // --- SITES ---

    private const val SITES_FILE_NAME = "saffah_blocked_sites.tsv"

    private fun loadBlockedSitesFromFile(context: Context): List<BlockedSite>? {
        val file = java.io.File(context.filesDir, SITES_FILE_NAME)
        if (!file.exists() || file.length() == 0L) return null
        return try {
            val list = ArrayList<BlockedSite>()
            file.bufferedReader(Charsets.UTF_8, 65536).useLines { lines ->
                for (line in lines) {
                    if (line.isEmpty()) continue
                    val tab1 = line.indexOf('\t')
                    if (tab1 != -1) {
                        val tab2 = line.indexOf('\t', tab1 + 1)
                        if (tab2 != -1) {
                            val tab3 = line.indexOf('\t', tab2 + 1)
                            if (tab3 != -1) {
                                val id = line.substring(0, tab1).toLongOrNull() ?: 0L
                                val isEnabled = line[tab1 + 1] == '1'
                                val dateAdded = line.substring(tab2 + 1, tab3)
                                val domain = line.substring(tab3 + 1)
                                list.add(BlockedSite(id, domain, dateAdded, isEnabled))
                            }
                        }
                    }
                }
            }
            list
        } catch (e: Exception) {
            Log.e("SaffahBlockRepo", "Error reading sites file: ${e.message}")
            null
        }
    }

    private fun saveBlockedSitesToFile(context: Context, list: List<BlockedSite>) {
        try {
            val file = java.io.File(context.filesDir, SITES_FILE_NAME)
            val tempFile = java.io.File(context.filesDir, "$SITES_FILE_NAME.tmp")
            tempFile.bufferedWriter(Charsets.UTF_8, 65536).use { writer ->
                for (item in list) {
                    writer.write(item.id.toString())
                    writer.write('\t'.code)
                    writer.write(if (item.isEnabled) '1'.code else '0'.code)
                    writer.write('\t'.code)
                    writer.write(item.dateAdded)
                    writer.write('\t'.code)
                    writer.write(item.domain)
                    writer.write('\n'.code)
                }
            }
            if (!tempFile.renameTo(file)) {
                file.delete()
                tempFile.renameTo(file)
            }
        } catch (e: Exception) {
            Log.e("SaffahBlockRepo", "Error saving sites file: ${e.message}")
        }
    }

    fun getBlockedSites(context: Context): List<BlockedSite> {
        cachedSites?.let { return it }
        val fromFile = loadBlockedSitesFromFile(context)
        if (fromFile != null) {
            cachedSites = fromFile
            return fromFile
        }

        val prefs = getSafeSharedPreferences(context)
        val isInitialized = prefs.getBoolean(KEY_SITES_INITIALIZED, false)
        val jsonStr = prefs.getString(KEY_SITES, null)

        if (!isInitialized && jsonStr == null) {
            val defaultList = getDefaultSites()
            prefs.edit().putBoolean(KEY_SITES_INITIALIZED, true).apply()
            saveBlockedSites(context, defaultList)
            return defaultList
        }

        if (!isInitialized) {
            prefs.edit().putBoolean(KEY_SITES_INITIALIZED, true).apply()
        }

        if (jsonStr.isNullOrEmpty()) {
            val empty = emptyList<BlockedSite>()
            cachedSites = empty
            return empty
        }

        val res = try {
            val array = JSONArray(jsonStr)
            val list = ArrayList<BlockedSite>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    BlockedSite(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        domain = obj.optString("domain", ""),
                        dateAdded = obj.optString("dateAdded", ""),
                        isEnabled = obj.optBoolean("isEnabled", true)
                    )
                )
            }
            list
        } catch (e: Exception) {
            Log.e("SaffahBlockRepo", "Error parsing legacy sites: ${e.message}")
            emptyList()
        }
        cachedSites = res
        saveBlockedSitesToFile(context, res)
        try {
            prefs.edit().remove(KEY_SITES).apply()
        } catch (_: Exception) {}
        return res
    }

    /**
     * التحقق من صحة النطاق بحيث يقبل فقط النطاقات المكتملة (مثل example.com أو subdomain.example.co.uk)
     * ويرفض الكلمات المفردة مثل example أو facebook دون لاحقة نطاق صالحة
     */
    fun isValidDomain(domain: String): Boolean {
        val clean = domain.trim().lowercase(java.util.Locale.ROOT)
        if (clean.length < 3 || clean.length > 253) return false

        // فحص عناوين IPv4 المباشرة
        val ipv4Regex = Regex("^((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.){3}(25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)$")
        if (ipv4Regex.matches(clean)) return true

        // فحص النطاقات القياسية: يتطلب نقطة واحدة على الأقل وامتداد نطاق (TLD) بحرفين على الأقل
        val domainRegex = Regex("^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}$")
        if (domainRegex.matches(clean)) return true

        // دعم النطاقات الدولية (IDN) والنطاقات متعددة اللغات
        val idnRegex = Regex("^(?:[\\p{L}0-9](?:[\\p{L}0-9-]{0,61}[\\p{L}0-9])?\\.)+[\\p{L}]{2,63}$")
        return idnRegex.matches(clean)
    }

    /**
     * استخراج وتطهير النطاق من الروابط والبادئات، والتحقق الصارم من كونه نطاقاً مكتملاً
     * يُرجع null إذا كان النطاق غير مكتمل (مثل example أو facebook بدون .com) أو غير صالح
     */
    fun cleanAndExtractDomain(rawDomain: String): String? {
        var str = rawDomain.trim()
        if (str.isEmpty() || str.startsWith("#") || str.startsWith("//")) return null

        str = str.lowercase(java.util.Locale.ROOT)

        // إزالة بروتوكولات الويب إن وجدت
        if (str.startsWith("http://")) str = str.removePrefix("http://")
        else if (str.startsWith("https://")) str = str.removePrefix("https://")
        else if (str.startsWith("ftp://")) str = str.removePrefix("ftp://")

        // إزالة بيانات الاعتماد (user:pass@)
        val atIndex = str.indexOf('@')
        if (atIndex >= 0) {
            str = str.substring(atIndex + 1)
        }

        // إزالة المسار والمعاملات والوسوم (/path, ?query, #hash)
        val endHostIndex = str.indexOfAny(charArrayOf('/', '?', '#'))
        if (endHostIndex >= 0) {
            str = str.substring(0, endHostIndex)
        }

        // إزالة رقم المنفذ (:8080)
        val colonIndex = str.indexOf(':')
        if (colonIndex >= 0) {
            str = str.substring(0, colonIndex)
        }

        // إزالة النقاط والمسافات الزائدة في البداية والنهاية
        str = str.trim('.', ' ', '\t', '\r', '\n')

        // إزالة بادئة www. إن وجدت للوصول للنطاق الأساسي
        if (str.startsWith("www.")) {
            str = str.removePrefix("www.")
        } else if (Regex("^www\\d+\\.").containsMatchIn(str)) {
            str = str.replaceFirst(Regex("^www\\d+\\."), "")
        }

        str = str.trim('.', ' ', '\t', '\r', '\n')

        if (!isValidDomain(str)) {
            return null
        }

        return str
    }

    fun addBlockedSite(context: Context, rawDomain: String): List<BlockedSite> {
        val formatted = cleanAndExtractDomain(rawDomain) ?: return getBlockedSites(context)

        val current = getBlockedSites(context)
        if (current.none { it.domain.equals(formatted, ignoreCase = true) }) {
            val newEntry = BlockedSite(
                id = System.currentTimeMillis(),
                domain = formatted,
                dateAdded = getCurrentDateString(),
                isEnabled = true
            )
            val updated = ArrayList<BlockedSite>(current.size + 1)
            updated.add(newEntry)
            updated.addAll(current)
            saveBlockedSites(context, updated)
            return updated
        }
        return current
    }

    fun addBlockedSitesBulk(context: Context, rawSites: List<String>): Pair<List<BlockedSite>, Int> {
        val current = getBlockedSites(context)
        val existingSet = HashSet<String>((current.size + rawSites.size / 0.7f).toInt() + 16)
        for (s in current) {
            existingSet.add(s.domain.lowercase().trim())
        }
        val dateStr = getCurrentDateString()
        var addedCount = 0
        var baseTime = System.currentTimeMillis()
        val newEntries = ArrayList<BlockedSite>(rawSites.size)

        for (raw in rawSites) {
            // يتم استخراج النطاق وتجاهل النطاقات غير المكتملة (مثل example دون example.com)
            val formatted = cleanAndExtractDomain(raw) ?: continue

            if (existingSet.add(formatted)) {
                newEntries.add(
                    BlockedSite(
                        id = baseTime++,
                        domain = formatted,
                        dateAdded = dateStr,
                        isEnabled = true
                    )
                )
                addedCount++
            }
        }

        if (addedCount > 0) {
            newEntries.addAll(current)
            saveBlockedSites(context, newEntries)
            return Pair(newEntries, addedCount)
        }
        return Pair(current, 0)
    }

    fun removeBlockedSite(context: Context, id: Long, domainText: String? = null): List<BlockedSite> {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_SITES_INITIALIZED, true).apply()
        val current = getBlockedSites(context).filterNot {
            it.id == id || (domainText != null && it.domain.equals(domainText.trim(), ignoreCase = true))
        }
        saveBlockedSites(context, current)
        return current
    }

    fun clearAllBlockedSites(context: Context): List<BlockedSite> {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_SITES_INITIALIZED, true).apply()
        saveBlockedSites(context, emptyList())
        return emptyList()
    }

    fun saveBlockedSites(context: Context, list: List<BlockedSite>) {
        cachedSites = list
        cachedCompiledSites = null
        cachedFastDomainMatcher = null
        saveBlockedSitesToFile(context, list)
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putBoolean(KEY_SITES_INITIALIZED, true)
            .remove(KEY_SITES)
            .apply()
    }

    fun getCompiledBlockedSites(context: Context): List<com.example.model.CompiledSiteRule> {
        cachedCompiledSites?.let { return it }
        val sites = getBlockedSites(context).filter { it.isEnabled && it.domain.isNotBlank() }
        val compiled = sites.map { s ->
            val norm = s.domain.trim().lowercase()
                .removePrefix("http://")
                .removePrefix("https://")
                .removePrefix("www.")
                .removeSuffix("/")
            com.example.model.CompiledSiteRule(
                id = s.id,
                domain = s.domain,
                normalizedDomain = norm
            )
        }
        cachedCompiledSites = compiled
        cachedFastDomainMatcher = SaffahFastDomainMatcher(compiled)
        return compiled
    }

    fun getFastDomainMatcher(context: Context): SaffahFastDomainMatcher {
        cachedFastDomainMatcher?.let { return it }
        val compiled = getCompiledBlockedSites(context)
        val matcher = SaffahFastDomainMatcher(compiled)
        cachedFastDomainMatcher = matcher
        return matcher
    }

    private fun getDefaultSites(): List<BlockedSite> {
        return listOf(
            BlockedSite(1, "explicit-website-example.com", "2026-08-01"),
            BlockedSite(2, "adult-portal-test.net", "2026-08-02"),
            BlockedSite(3, "bad-content-domain.org", "2026-08-04")
        )
    }

    // --- LOGS ---

    private val timeFormatter24h by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.format.DateTimeFormatter.ofPattern("HH:mm", java.util.Locale.US)
        } else null
    }

    private val fullTimestampFormatter24h by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.format.DateTimeFormatter.ofPattern("HH:mm • yyyy/MM/dd", java.util.Locale.US)
        } else null
    }

    private val dateFormatter by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd", java.util.Locale.ENGLISH)
        } else null
    }

    fun getCurrentTimeString24h(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && timeFormatter24h != null) {
            java.time.LocalTime.now().format(timeFormatter24h)
        } else {
            val sdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US)
            sdf.format(java.util.Date())
        }
    }

    fun getCurrentFullTimestamp24h(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && fullTimestampFormatter24h != null) {
            java.time.LocalDateTime.now().format(fullTimestampFormatter24h)
        } else {
            val sdf = java.text.SimpleDateFormat("HH:mm • yyyy/MM/dd", java.util.Locale.US)
            sdf.format(java.util.Date())
        }
    }

    fun getBlockLogs(context: Context): List<BlockLogEntry> {
        cachedBlockLogs?.let { return it }
        synchronized(blockLogsLock) {
            cachedBlockLogs?.let { return it }
            val prefs = getSafeSharedPreferences(context)
            val jsonStr = prefs.getString(KEY_LOGS, null)
            if (jsonStr.isNullOrEmpty()) {
                val empty = emptyList<BlockLogEntry>()
                cachedBlockLogs = empty
                return empty
            }
            val list = try {
                val array = JSONArray(jsonStr)
                val mutable = mutableListOf<BlockLogEntry>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val typeStr = obj.optString("type", "")
                    // Exclude app/usage/schedule logs if any exist
                    if (typeStr.contains("استخدام") || typeStr.contains("جدول") || typeStr.contains("نوم")) {
                        continue
                    }
                    mutable.add(
                        BlockLogEntry(
                            id = obj.optLong("id", System.currentTimeMillis()),
                            blockedItem = obj.optString("blockedItem", ""),
                            type = if (typeStr.contains("موقع")) "موقع محظور" else "كلمة محظورة",
                            timestamp = obj.optString("timestamp", ""),
                            sourceApp = obj.optString("sourceApp", "")
                        )
                    )
                }
                mutable
            } catch (e: Exception) {
                emptyList()
            }
            cachedBlockLogs = list
            return list
        }
    }

    fun addBlockLog(context: Context, item: String, type: String, sourceApp: String) {
        // Only log keywords, websites, and image/AI blocks in this log
        if (!type.contains("كلمة") && !type.contains("موقع") && !type.contains("AI") && !type.contains("الذكاء") && !type.contains("صورة") && !type.contains("صور")) {
            return
        }

        val isWebsite = type.contains("موقع")
        val isImage = type.contains("صورة") || type.contains("صور") || type.contains("AI") || type.contains("الذكاء")
        val isAi = type.contains("AI") || type.contains("الذكاء")
        val newEntry = BlockLogEntry(
            id = System.currentTimeMillis(),
            blockedItem = item,
            type = if (isImage) (if (type.contains("صورة")) type else "صورة محظورة ($type)") else if (isWebsite) "موقع محظور" else "كلمة محظورة",
            timestamp = getCurrentFullTimestamp24h(),
            sourceApp = sourceApp
        )

        synchronized(blockLogsLock) {
            val current = (cachedBlockLogs ?: getBlockLogs(context)).toMutableList()
            current.add(0, newEntry)
            val trimmedList = if (current.size > 500) current.take(500) else current
            cachedBlockLogs = trimmedList

            try {
                val prefs = getSafeSharedPreferences(context)
                val array = JSONArray()
                for (entry in trimmedList) {
                    val obj = JSONObject().apply {
                        put("id", entry.id)
                        put("blockedItem", entry.blockedItem)
                        put("type", entry.type)
                        put("timestamp", entry.timestamp)
                        put("sourceApp", entry.sourceApp)
                    }
                    array.put(obj)
                }

                val editor = prefs.edit()
                if (isImage) {
                    val imgCounter = prefs.getInt("detected_images_counter", 0) + 1
                    editor.putInt("detected_images_counter", imgCounter)
                } else if (isWebsite) {
                    val siteCounter = prefs.getInt("detected_sites_counter", 0) + 1
                    editor.putInt("detected_sites_counter", siteCounter)
                } else {
                    val kwCounter = prefs.getInt("detected_keywords_counter", 0) + 1
                    editor.putInt("detected_keywords_counter", kwCounter)
                }

                val currentCounter = prefs.getInt("total_block_events_counter", 0) + 1
                editor.putInt("total_block_events_counter", currentCounter)
                editor.putString(KEY_LOGS, array.toString())
                editor.apply()

                // 1. Dispatch immediate Content Block Notification
                try {
                    SaffahNotificationManager.dispatchContentBlockNotification(
                        context = context,
                        blockedItem = item,
                        isWebsite = isWebsite,
                        sourceApp = sourceApp
                    )
                } catch (e: Throwable) {
                    Log.w("SaffahBlockRepo", "Error dispatching content block notification: ${e.message}")
                }

                // 2. Evaluate preventive Escalating Curiosity Radar (3 blocks in < 5 mins)
                try {
                    SaffahNotificationManager.onCuriosityBlockEvent(context, isWebsite = isWebsite)
                } catch (e: Throwable) {
                    Log.w("SaffahBlockRepo", "Error evaluating curiosity radar: ${e.message}")
                }
            } catch (t: Throwable) {
                Log.w("SaffahBlockRepo", "Error persisting block log entry: ${t.message}")
            }
        }
    }

    fun getDetectedKeywordsCount(context: Context): Int {
        val prefs = getSafeSharedPreferences(context)
        val storedCounter = prefs.getInt("detected_keywords_counter", 0)
        val currentLogsCount = getBlockLogs(context).count { it.type.contains("كلمة") }
        return maxOf(storedCounter, currentLogsCount)
    }

    fun getDetectedSitesCount(context: Context): Int {
        val prefs = getSafeSharedPreferences(context)
        val storedCounter = prefs.getInt("detected_sites_counter", 0)
        val currentLogsCount = getBlockLogs(context).count { it.type.contains("موقع") }
        return maxOf(storedCounter, currentLogsCount)
    }

    fun getDetectedImagesCount(context: Context): Int {
        val prefs = getSafeSharedPreferences(context)
        val storedCounter = prefs.getInt("detected_images_counter", 0)
        val currentLogsCount = getBlockLogs(context).count { it.type.contains("صورة") || it.type.contains("صور") || it.type.contains("AI") || it.type.contains("الذكاء") }
        return maxOf(storedCounter, currentLogsCount)
    }

    fun getTotalBlockEventsCount(context: Context): Int {
        val prefs = getSafeSharedPreferences(context)
        val storedCounter = prefs.getInt("total_block_events_counter", 0)
        val currentLogsCount = getBlockLogs(context).size
        return maxOf(storedCounter, currentLogsCount)
    }

    fun saveBlockLogs(context: Context, logs: List<BlockLogEntry>) {
        val trimmedList = if (logs.size > 500) logs.take(500) else logs
        synchronized(blockLogsLock) {
            cachedBlockLogs = trimmedList
        }
        val prefs = getSafeSharedPreferences(context)
        val array = JSONArray()
        for (entry in trimmedList) {
            val obj = JSONObject().apply {
                put("id", entry.id)
                put("blockedItem", entry.blockedItem)
                put("type", entry.type)
                put("timestamp", entry.timestamp)
                put("sourceApp", entry.sourceApp)
            }
            array.put(obj)
        }
        val kwCount = trimmedList.count { it.type.contains("كلمة") }
        val siteCount = trimmedList.count { it.type.contains("موقع") }
        val imgCount = trimmedList.count { it.type.contains("صورة") || it.type.contains("صور") || it.type.contains("AI") || it.type.contains("الذكاء") }
        prefs.edit()
            .putString(KEY_LOGS, array.toString())
            .putInt("total_block_events_counter", trimmedList.size)
            .putInt("detected_keywords_counter", kwCount)
            .putInt("detected_sites_counter", siteCount)
            .putInt("detected_images_counter", imgCount)
            .apply()
    }

    fun clearBlockLogs(context: Context) {
        synchronized(blockLogsLock) {
            cachedBlockLogs = emptyList()
        }
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .remove(KEY_LOGS)
            .putInt("total_block_events_counter", 0)
            .putInt("detected_keywords_counter", 0)
            .putInt("detected_sites_counter", 0)
            .putInt("detected_images_counter", 0)
            .apply()
    }

    // --- MATCHING HELPERS ---

    /**
     * Ultra-fast keyword matcher using Aho-Corasick automaton + O(1) word token HashSet lookup.
     * Guaranteed O(text.length) search time regardless of whether there are 10 or 100,000 keywords!
     */
    fun findMatchedBlockedKeywordFast(text: CharSequence, compiledKeywords: List<com.example.model.CompiledKeywordRule>? = null): String? {
        if (text.isEmpty()) return null
        var matcher = cachedFastKeywordMatcher
        if (matcher == null || (compiledKeywords != null && compiledKeywords.isNotEmpty() && compiledKeywords.size != matcher.totalRuleCount)) {
            val list = if (compiledKeywords != null && compiledKeywords.isNotEmpty()) compiledKeywords else cachedCompiledKeywords ?: emptyList()
            matcher = SaffahFastKeywordMatcher(list)
            cachedFastKeywordMatcher = matcher
        }
        return matcher.findMatch(text)
    }

    /**
     * Ultra-fast site/domain matcher using O(1) hash lookups and parent-domain walking.
     */
    fun findMatchedBlockedSiteFast(urlText: String, compiledSites: List<com.example.model.CompiledSiteRule>? = null): String? {
        if (urlText.isEmpty()) return null
        var matcher = cachedFastDomainMatcher
        if (matcher == null || (compiledSites != null && compiledSites.isNotEmpty() && compiledSites.size != matcher.totalRuleCount)) {
            val list = if (compiledSites != null && compiledSites.isNotEmpty()) compiledSites else cachedCompiledSites ?: emptyList()
            matcher = SaffahFastDomainMatcher(list)
            cachedFastDomainMatcher = matcher
        }
        return matcher.matchUrl(urlText)
    }

    /**
     * Ultra-fast site/domain matcher using pre-compiled, normalized domain rules.
     */
    fun findMatchedBlockedSiteFast(
        urlHostWithoutWww: String,
        urlHostPart: String,
        withoutScheme: String,
        compiledSites: List<com.example.model.CompiledSiteRule>? = null
    ): String? {
        if (urlHostWithoutWww.isEmpty() && urlHostPart.isEmpty() && withoutScheme.isEmpty()) return null
        var matcher = cachedFastDomainMatcher
        if (matcher == null || (compiledSites != null && compiledSites.isNotEmpty() && compiledSites.size != matcher.totalRuleCount)) {
            val list = if (compiledSites != null && compiledSites.isNotEmpty()) compiledSites else cachedCompiledSites ?: emptyList()
            matcher = SaffahFastDomainMatcher(list)
            cachedFastDomainMatcher = matcher
        }
        return matcher.matchHost(urlHostWithoutWww, urlHostPart, withoutScheme)
    }

    fun findMatchedBlockedSiteFast(domainOrUrl: String, context: Context): String? {
        if (domainOrUrl.isEmpty()) return null
        val matcher = getFastDomainMatcher(context)
        return matcher.isDomainBlocked(domainOrUrl) ?: matcher.matchUrl(domainOrUrl)
    }

    /**
     * Fast boundary check without string allocations.
     */
    fun matchesExactWordBoundaryLower(lowerText: String, lowerTarget: String): Boolean {
        return matchesExactWordBoundary(lowerText, lowerTarget)
    }

    /**
     * Checks whether [text] matches the keyword rule.
     */
    fun matchesKeyword(text: String, keywordRule: String): Boolean {
        if (text.isBlank() || keywordRule.isBlank()) return false

        val trimmedRule = keywordRule.trim()
        val isStarBounded = trimmedRule.startsWith("*") && trimmedRule.endsWith("*") && trimmedRule.length > 2

        val targetWord = if (isStarBounded) {
            trimmedRule.substring(1, trimmedRule.length - 1).trim()
        } else {
            trimmedRule
        }

        if (targetWord.isEmpty()) return false

        return if (isStarBounded) {
            matchesExactWordBoundary(text, targetWord)
        } else {
            text.contains(targetWord, ignoreCase = true)
        }
    }

    /**
     * Exact word boundary matcher on CharSequence:
     * Ensures targetWord is surrounded by non-letters and non-digits (or start/end of string).
     */
    fun matchesExactWordBoundary(text: CharSequence, targetWordLower: String): Boolean {
        var startIdx = 0
        val targetLen = targetWordLower.length
        val textLen = text.length
        while (startIdx <= textLen - targetLen) {
            val foundIdx = text.indexOf(targetWordLower, startIdx, ignoreCase = true)
            if (foundIdx == -1) break

            val endIdx = foundIdx + targetLen

            val isBeforeValid = (foundIdx == 0) || !Character.isLetterOrDigit(text[foundIdx - 1])
            val isAfterValid = (endIdx == textLen) || !Character.isLetterOrDigit(text[endIdx])

            if (isBeforeValid && isAfterValid) {
                return true
            }

            startIdx = foundIdx + 1
        }
        return false
    }

    @Volatile private var cachedDateString: String = ""
    @Volatile private var cachedDateStringTimestamp: Long = 0L

    private fun getCurrentDateString(): String {
        val now = System.currentTimeMillis()
        if (cachedDateString.isNotEmpty() && (now - cachedDateStringTimestamp < 10_000L)) {
            return cachedDateString
        }
        val res = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && dateFormatter != null) {
            java.time.LocalDate.now().format(dateFormatter)
        } else {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
            sdf.format(java.util.Date(now))
        }
        cachedDateString = res
        cachedDateStringTimestamp = now
        return res
    }

    private fun getCurrentTimeString(): String {
        return getCurrentTimeString24h()
    }

    // --- SCHEDULED APP BLOCKING RULES ---

    fun isAppScheduleRuleModificationAllowedWindow(): Boolean {
        // Allowed daily between 06:00 and 07:00 (hour == 6)
        val hour = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.LocalTime.now().hour
        } else {
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        }
        return hour == 6
    }

    fun isAppScheduleRuleModificationRestricted(context: Context): Boolean {
        val isQrActive = SaffahQrKeyManager.isQrKeyProtectionActive(context)
        val isDelayActive = isTimeDelayActive(context)
        val isAllowedWindow = isAppScheduleRuleModificationAllowedWindow()
        // Modifications are strictly restricted ONLY if BOTH RQ Lock AND Time Delay are active AND outside allowed window
        return isQrActive && isDelayActive && !isAllowedWindow
    }

    fun calculateScheduleSpanMinutes(startHour: Int, startMinute: Int, endHour: Int, endMinute: Int): Int {
        val start = startHour * 60 + startMinute
        val end = endHour * 60 + endMinute
        return if (start == end) {
            1440 // 24 hours full block
        } else if (start < end) {
            end - start
        } else {
            (1440 - start) + end
        }
    }

    /**
     * Validates whether a modification to an AppBlockScheduleRule is permissible.
     * Restricted ONLY when BOTH RQ Lock AND Time Delay are active outside daily 06:00 - 07:00 window:
     * - Cannot delete saved rules
     * - Cannot disable saved rules
     * - Cannot shrink block time range
     * - Cannot remove blocked apps (for BLOCK_SPECIFIED)
     * - Cannot add allowed apps (for ALLOW_SPECIFIED_BLOCK_OTHERS)
     * - Cannot exempt/remove active days
     * - Tightening (adding blocked apps, removing allowed apps, extending time range, adding days) is allowed.
     */
    fun validateAppScheduleRuleModification(context: Context, updatedRule: com.example.model.AppBlockScheduleRule): String? {
        if (!isAppScheduleRuleModificationRestricted(context)) {
            return null // Fully allowed modification
        }
        val currentRules = getAppScheduleRules(context)
        val existingRule = currentRules.find { it.id == updatedRule.id } ?: return null // Adding new rule is permitted

        // 1. Check if disabling an enabled rule
        if (existingRule.isEnabled && !updatedRule.isEnabled) {
            return "يمنع تعطيل عملية الحظر الدورية عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00)."
        }

        // 2. Check block type change
        if (existingRule.blockType != updatedRule.blockType) {
            return "يمنع تغيير نوع الحظر لعملية حظر دورية عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح."
        }

        // 3. Check selected packages based on block type
        if (existingRule.blockType == com.example.model.AppBlockType.BLOCK_SPECIFIED) {
            val removedPackages = existingRule.selectedPackages - updatedRule.selectedPackages
            if (removedPackages.isNotEmpty()) {
                return "يمنع إزالة التطبيقات المحظورة من عملية الحظر الدورية عند تفعيل قفل RQ والتأخير الزمني معاً. يسمح فقط بإضافة تطبيقات جديدة للحظر."
            }
        } else if (existingRule.blockType == com.example.model.AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS) {
            val addedAllowedPackages = updatedRule.selectedPackages - existingRule.selectedPackages
            if (addedAllowedPackages.isNotEmpty()) {
                return "يمنع إضافة تطبيقات مسموحة جديدة عند تفعيل قفل RQ والتأخير الزمني معاً. يسمح فقط بإزالة تطبيقات مسموحة لتشديد الحظر."
            }
        }

        // 4. Check active days (forbid exempting days)
        val removedDays = existingRule.activeDays - updatedRule.activeDays
        if (removedDays.isNotEmpty()) {
            return "يمنع استثناء أو إزالة أيام التفعيل لعملية الحظر الدورية عند تفعيل قفل RQ والتأخير الزمني معاً. يسمح فقط بإضافة أيام جديدة."
        }

        // 5. Check time span / duration (forbid shrinking the block time window)
        val existingSpan = existingRule.getEffectiveTimeRanges().sumOf {
            calculateScheduleSpanMinutes(it.startHour, it.startMinute, it.endHour, it.endMinute)
        }
        val updatedSpan = updatedRule.getEffectiveTimeRanges().sumOf {
            calculateScheduleSpanMinutes(it.startHour, it.startMinute, it.endHour, it.endMinute)
        }
        if (updatedSpan < existingSpan) {
            val hours = existingSpan / 60
            val mins = existingSpan % 60
            val durText = if (hours > 0 && mins > 0) "$hours س و $mins د" else if (hours > 0) "$hours ساعة" else "$mins دقيقة"
            return "يمنع تقليص إجمالي نطاق وقت الحظر الدوري عن المدة السابقة ($durText) عند تفعيل قفل RQ والتأخير الزمني معاً. يسمح فقط بتمديد نطاق الحظر لتشديده."
        }

        return null
    }

    fun isAppScheduleMasterEnabled(context: Context): Boolean {
        cachedAppScheduleMasterEnabled?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean("app_schedule_master_enabled", false)
        cachedAppScheduleMasterEnabled = res
        return res
    }

    fun setAppScheduleMasterEnabled(context: Context, enabled: Boolean) {
        cachedAppScheduleMasterEnabled = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean("app_schedule_master_enabled", enabled).apply()
        invalidateTimeCache()
        applyPackageSuspensionIfNeeded(context)
        try {
            com.example.service.SaffahAccessibilityService.notifyScheduleOrBedtimeChanged(context)
        } catch (_: Throwable) {}
        try {
            com.example.util.SaffahNotificationManager.evaluateAndTriggerScheduledBlockNotifications(context)
            com.example.util.SaffahNotificationManager.scheduleScheduledBlockAlarms(context)
            scheduleAppScheduleAlarms(context)
        } catch (_: Throwable) {}
    }

    fun getAppScheduleRules(context: Context): List<com.example.model.AppBlockScheduleRule> {
        cachedAppScheduleRules?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val jsonStr = prefs.getString("app_schedule_rules_json", null)
        if (jsonStr.isNullOrEmpty()) {
            cachedAppScheduleRules = emptyList()
            return emptyList()
        }
        val res = try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<com.example.model.AppBlockScheduleRule>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val activeDaysArray = obj.optJSONArray("activeDays")
                val activeDays = mutableSetOf<Int>()
                if (activeDaysArray != null) {
                    for (j in 0 until activeDaysArray.length()) {
                        activeDays.add(activeDaysArray.getInt(j))
                    }
                } else {
                    activeDays.addAll(setOf(1, 2, 3, 4, 5, 6, 7))
                }

                val pkgsArray = obj.optJSONArray("selectedPackages")
                val selectedPkgs = mutableSetOf<String>()
                if (pkgsArray != null) {
                    for (j in 0 until pkgsArray.length()) {
                        selectedPkgs.add(pkgsArray.getString(j))
                    }
                }

                val typeStr = obj.optString("blockType", "BLOCK_SPECIFIED")
                val blockType = if (typeStr == "ALLOW_SPECIFIED_BLOCK_OTHERS") {
                    com.example.model.AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS
                } else {
                    com.example.model.AppBlockType.BLOCK_SPECIFIED
                }

                val timeRangesArray = obj.optJSONArray("timeRanges")
                val timeRangesList = mutableListOf<com.example.model.ScheduleTimeRange>()
                if (timeRangesArray != null && timeRangesArray.length() > 0) {
                    for (trIdx in 0 until timeRangesArray.length()) {
                        val trObj = timeRangesArray.getJSONObject(trIdx)
                        timeRangesList.add(
                            com.example.model.ScheduleTimeRange(
                                startHour = trObj.optInt("startHour", 9),
                                startMinute = trObj.optInt("startMinute", 0),
                                endHour = trObj.optInt("endHour", 17),
                                endMinute = trObj.optInt("endMinute", 0)
                            )
                        )
                    }
                }
                val startHour = obj.optInt("startHour", 9)
                val startMinute = obj.optInt("startMinute", 0)
                val endHour = obj.optInt("endHour", 17)
                val endMinute = obj.optInt("endMinute", 0)
                if (timeRangesList.isEmpty()) {
                    timeRangesList.add(
                        com.example.model.ScheduleTimeRange(
                            startHour = startHour,
                            startMinute = startMinute,
                            endHour = endHour,
                            endMinute = endMinute
                        )
                    )
                }

                list.add(
                    com.example.model.AppBlockScheduleRule(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        name = obj.optString("name", ""),
                        isEnabled = obj.optBoolean("isEnabled", false),
                        timeRanges = timeRangesList,
                        startHour = timeRangesList.first().startHour,
                        startMinute = timeRangesList.first().startMinute,
                        endHour = timeRangesList.first().endHour,
                        endMinute = timeRangesList.first().endMinute,
                        activeDays = activeDays,
                        blockType = blockType,
                        selectedPackages = selectedPkgs
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
        cachedAppScheduleRules = res
        return res
    }

    fun saveAppScheduleRules(context: Context, rules: List<com.example.model.AppBlockScheduleRule>) {
        cachedAppScheduleRules = rules
        val prefs = getSafeSharedPreferences(context)
        val array = JSONArray()
        for (rule in rules) {
            val effectiveRanges = rule.getEffectiveTimeRanges()
            val timeRangesArr = JSONArray()
            for (tr in effectiveRanges) {
                val trObj = JSONObject().apply {
                    put("startHour", tr.startHour)
                    put("startMinute", tr.startMinute)
                    put("endHour", tr.endHour)
                    put("endMinute", tr.endMinute)
                }
                timeRangesArr.put(trObj)
            }
            val firstRange = effectiveRanges.firstOrNull() ?: com.example.model.ScheduleTimeRange()
            val obj = JSONObject().apply {
                put("id", rule.id)
                put("name", rule.name)
                put("isEnabled", rule.isEnabled)
                put("startHour", firstRange.startHour)
                put("startMinute", firstRange.startMinute)
                put("endHour", firstRange.endHour)
                put("endMinute", firstRange.endMinute)
                put("timeRanges", timeRangesArr)
                put("activeDays", JSONArray(rule.activeDays.toList()))
                put("blockType", rule.blockType.name)
                put("selectedPackages", JSONArray(rule.selectedPackages.toList()))
            }
            array.put(obj)
        }
        prefs.edit().putString("app_schedule_rules_json", array.toString()).apply()
        invalidateTimeCache()
        applyPackageSuspensionIfNeeded(context)
        try {
            com.example.service.SaffahAccessibilityService.notifyScheduleOrBedtimeChanged(context)
        } catch (_: Throwable) {}
        try {
            com.example.util.SaffahNotificationManager.evaluateAndTriggerScheduledBlockNotifications(context)
            com.example.util.SaffahNotificationManager.scheduleScheduledBlockAlarms(context)
            scheduleAppScheduleAlarms(context)
        } catch (_: Throwable) {}
    }

    fun upsertAppScheduleRule(context: Context, rule: com.example.model.AppBlockScheduleRule): List<com.example.model.AppBlockScheduleRule> {
        val current = getAppScheduleRules(context).toMutableList()
        val index = current.indexOfFirst { it.id == rule.id }
        if (index >= 0) {
            current[index] = rule
        } else {
            current.add(0, rule)
        }
        saveAppScheduleRules(context, current)
        return current
    }

    fun deleteAppScheduleRule(context: Context, id: Long): List<com.example.model.AppBlockScheduleRule> {
        if (isAppScheduleRuleModificationRestricted(context)) {
            val existing = getAppScheduleRules(context).find { it.id == id }
            if (existing != null) {
                Log.w("SaffahBlockRepo", "Blocked deletion of app schedule rule when RQ and Time Delay are active outside allowed window")
                return getAppScheduleRules(context)
            }
        }
        val current = getAppScheduleRules(context).filter { it.id != id }
        saveAppScheduleRules(context, current)
        return current
    }

    fun toggleAppScheduleRuleEnabled(context: Context, id: Long): List<com.example.model.AppBlockScheduleRule> {
        val current = getAppScheduleRules(context)
        val rule = current.find { it.id == id } ?: return current
        if (rule.isEnabled && isAppScheduleRuleModificationRestricted(context)) {
            Log.w("SaffahBlockRepo", "Blocked disabling app schedule rule when RQ and Time Delay are active outside allowed window")
            return current
        }
        val updated = current.map {
            if (it.id == id) it.copy(isEnabled = !it.isEnabled) else it
        }
        saveAppScheduleRules(context, updated)
        return updated
    }

    fun reorderAppScheduleRules(context: Context, newOrderRules: List<com.example.model.AppBlockScheduleRule>): List<com.example.model.AppBlockScheduleRule> {
        val currentSaved = getAppScheduleRules(context)
        val savedMap = currentSaved.associateBy { it.id }
        val mergedRules = newOrderRules.map { incoming ->
            val existing = savedMap[incoming.id]
            if (existing != null) {
                val effectivePackages = if (incoming.selectedPackages.isEmpty() && existing.selectedPackages.isNotEmpty()) {
                    existing.selectedPackages
                } else {
                    incoming.selectedPackages
                }
                val effectiveRanges = if (incoming.timeRanges.isEmpty() && existing.timeRanges.isNotEmpty()) {
                    existing.timeRanges
                } else {
                    incoming.timeRanges
                }
                incoming.copy(
                    selectedPackages = effectivePackages,
                    timeRanges = effectiveRanges
                )
            } else {
                incoming
            }
        }
        saveAppScheduleRules(context, mergedRules)
        return mergedRules
    }

    // --- USAGE BLOCKING RULES ---

    fun isUsageRuleModificationAllowedWindow(): Boolean {
        // Allowed daily between 06:00 AM and 07:00 AM (hour == 6)
        val hour = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.LocalTime.now().hour
        } else {
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        }
        return hour == 6
    }

    fun isUsageRuleModificationRestricted(context: Context): Boolean {
        val isQrActive = SaffahQrKeyManager.isQrKeyProtectionActive(context)
        val isDelayActive = isTimeDelayActive(context)
        val isAllowedWindow = isUsageRuleModificationAllowedWindow()
        // Modifications are strictly restricted ONLY if BOTH RQ Lock AND Time Delay are active AND outside allowed window
        return isQrActive && isDelayActive && !isAllowedWindow
    }

    /**
     * Validates whether a modification to a usage rule is permissible.
     * Restricted ONLY when BOTH RQ Lock AND Time Delay are active outside daily 06:00 - 07:00 AM window:
     * - Cannot delete saved rules
     * - Cannot disable saved rules
     * - Cannot raise duration ceiling
     * - Cannot raise launch count ceiling
     * - Cannot remove previously selected apps
     * - Tightening (adding apps, reducing limits) is allowed.
     */
    fun validateUsageRuleModification(context: Context, updatedRule: com.example.model.UsageBlockRule): String? {
        if (!isUsageRuleModificationRestricted(context)) {
            return null // Fully allowed modification
        }
        val currentRules = getUsageRules(context)
        val existingRule = currentRules.find { it.id == updatedRule.id } ?: return null // Adding new rule is permitted

        // 1. Check if disabling an enabled rule
        if (existingRule.isEnabled && !updatedRule.isEnabled) {
            return "يمنع تعطيل عملية الحظر بالاستخدام عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح (06:00 - 07:00)."
        }

        // 2. Check if removing already selected packages
        val removedPackages = existingRule.selectedPackages - updatedRule.selectedPackages
        if (removedPackages.isNotEmpty()) {
            return "يمنع إزالة التطبيقات المحددة مسبقاً عند تفعيل قفل RQ والتأخير الزمني معاً. يسمح بإضافة تطبيقات فقط."
        }

        // 3. Check if changing limit type or raising limit ceiling
        if (existingRule.limitType != updatedRule.limitType) {
            return "يمنع تغيير نوع حد الاستخدام عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح."
        }

        if (updatedRule.limitValue > existingRule.limitValue) {
            val limitName = if (existingRule.limitType == com.example.model.UsageLimitType.DURATION) "وقت الاستخدام" else "عدد مرات الفتح"
            val prevLimitStr = if (existingRule.limitType == com.example.model.UsageLimitType.DURATION) {
                formatUsageCeilingTime(existingRule.limitValue)
            } else {
                "${existingRule.limitValue} مرة"
            }
            return "يمنع رفع سقف $limitName عن الحد السابق ($prevLimitStr) عند تفعيل قفل RQ والتأخير الزمني معاً. يسمح بالتقليل فقط لتشديد الحظر."
        }

        // 4. Check if removing active days
        val removedDays = existingRule.activeDays - updatedRule.activeDays
        if (removedDays.isNotEmpty()) {
            return "يمنع إزالة أيام التفعيل لعملية الحظر عند تفعيل قفل RQ والتأخير الزمني معاً خارج فترة السماح."
        }

        return null
    }

    fun isUsageMasterEnabled(context: Context): Boolean {
        val rules = getUsageRules(context)
        if (rules.any { it.isEnabled }) return true
        cachedUsageMasterEnabled?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean("usage_master_enabled", false)
        cachedUsageMasterEnabled = res
        return res
    }

    fun setUsageMasterEnabled(context: Context, enabled: Boolean) {
        cachedUsageMasterEnabled = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean("usage_master_enabled", enabled).apply()
        if (!enabled) {
            synchronized(usageBlockLock) {
                prefs.edit().remove("usage_blocked_packages_set").apply()
            }
        }
        applyPackageSuspensionIfNeeded(context)
    }

    fun getUsageRules(context: Context): List<com.example.model.UsageBlockRule> {
        cachedUsageRules?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val jsonStr = prefs.getString("usage_rules_json", null)
        if (jsonStr.isNullOrEmpty()) {
            cachedUsageRules = emptyList()
            return emptyList()
        }
        val res = try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<com.example.model.UsageBlockRule>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val activeDaysArray = obj.optJSONArray("activeDays")
                val activeDays = mutableSetOf<Int>()
                if (activeDaysArray != null) {
                    for (j in 0 until activeDaysArray.length()) {
                        activeDays.add(activeDaysArray.getInt(j))
                    }
                } else {
                    activeDays.addAll(setOf(1, 2, 3, 4, 5, 6, 7))
                }

                val pkgsArray = obj.optJSONArray("selectedPackages")
                val selectedPkgs = mutableSetOf<String>()
                if (pkgsArray != null) {
                    for (j in 0 until pkgsArray.length()) {
                        selectedPkgs.add(pkgsArray.getString(j))
                    }
                }

                val typeStr = obj.optString("limitType", "DURATION")
                val limitType = if (typeStr == "LAUNCH_COUNT") {
                    com.example.model.UsageLimitType.LAUNCH_COUNT
                } else {
                    com.example.model.UsageLimitType.DURATION
                }

                val createdAt = obj.optLong("createdAt", 0L)
                val lastActivatedAt = obj.optLong("lastActivatedAt", createdAt)
                val pkgAddedAtMap = mutableMapOf<String, Long>()
                val pkgAddedAtObj = obj.optJSONObject("packageAddedAt")
                if (pkgAddedAtObj != null) {
                    val keys = pkgAddedAtObj.keys()
                    while (keys.hasNext()) {
                        val pkg = keys.next()
                        pkgAddedAtMap[pkg] = pkgAddedAtObj.optLong(pkg, createdAt)
                    }
                }
                for (pkg in selectedPkgs) {
                    if (!pkgAddedAtMap.containsKey(pkg)) {
                        pkgAddedAtMap[pkg] = lastActivatedAt
                    }
                }

                list.add(
                    com.example.model.UsageBlockRule(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        name = obj.optString("name", ""),
                        isEnabled = obj.optBoolean("isEnabled", false),
                        activeDays = activeDays,
                        limitType = limitType,
                        limitValue = obj.optInt("limitValue", 30),
                        selectedPackages = selectedPkgs,
                        createdAt = createdAt,
                        lastActivatedAt = lastActivatedAt,
                        packageAddedAt = pkgAddedAtMap
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
        cachedUsageRules = res
        cachedUsageRuleTargetPackages = res.filter { it.isEnabled }.flatMap { it.selectedPackages }.map { it.trim().lowercase() }.toSet()
        return res
    }

    fun saveUsageRules(context: Context, rules: List<com.example.model.UsageBlockRule>) {
        cachedUsageRules = rules
        cachedUsageRuleTargetPackages = rules.filter { it.isEnabled }.flatMap { it.selectedPackages }.map { it.trim().lowercase() }.toSet()
        val prefs = getSafeSharedPreferences(context)
        val array = JSONArray()
        for (rule in rules) {
            val obj = JSONObject().apply {
                put("id", rule.id)
                put("name", rule.name)
                put("isEnabled", rule.isEnabled)
                put("activeDays", JSONArray(rule.activeDays.toList()))
                put("limitType", rule.limitType.name)
                put("limitValue", rule.limitValue)
                put("selectedPackages", JSONArray(rule.selectedPackages.toList()))
                put("createdAt", rule.createdAt)
                put("lastActivatedAt", rule.lastActivatedAt)
                val pkgAddedAtObj = JSONObject()
                rule.packageAddedAt.forEach { (pkg, ts) -> pkgAddedAtObj.put(pkg, ts) }
                put("packageAddedAt", pkgAddedAtObj)
            }
            array.put(obj)
        }
        prefs.edit().putString("usage_rules_json", array.toString()).apply()

        // If there are active enabled rules, ensure master toggle is enabled!
        if (rules.any { it.isEnabled }) {
            cachedUsageMasterEnabled = true
            prefs.edit().putBoolean("usage_master_enabled", true).apply()
        }

        // Recalculate currently blocked packages immediately based on updated rules & current usage
        invalidateUsageCache()
        val oldBlocked = prefs.getStringSet("usage_blocked_packages_set", null)?.let { HashSet(it) } ?: HashSet<String>()
        val blocked = getCurrentlyBlockedPackagesByUsage(context)
        prefs.edit().putStringSet("usage_blocked_packages_set", HashSet(blocked)).apply()
        cachedUsageBlockedPackagesSet = blocked

        // Immediate un-suspension for packages that are no longer blocked after limit increase
        val newlyUnblocked = oldBlocked.filter { !blocked.contains(it) && !blocked.contains(it.lowercase()) }
        for (pkg in newlyUnblocked) {
            applySinglePackageSuspension(context, pkg, false)
        }
        for (pkg in blocked) {
            applySinglePackageSuspension(context, pkg, true)
        }

        val currentActive = activeForegroundPackage?.trim()?.lowercase()
        if (!currentActive.isNullOrBlank() && (blocked.contains(currentActive) || blocked.contains(activeForegroundPackage))) {
            val pkgToEvict = currentActive
            clearActiveForegroundPackage()
            enforcementListener?.onAppBlockedImmediately(
                pkgToEvict,
                "حد الاستخدام اليومي",
                "تم حظر التطبيق لتجاوز حد الاستخدام اليومي المحدد"
            )
        }

        applyPackageSuspensionIfNeeded(context)
    }

    fun reorderUsageRules(context: Context, newOrderRules: List<com.example.model.UsageBlockRule>): List<com.example.model.UsageBlockRule> {
        val currentSaved = getUsageRules(context)
        val savedMap = currentSaved.associateBy { it.id }
        val mergedRules = newOrderRules.map { incoming ->
            val existing = savedMap[incoming.id]
            if (existing != null) {
                val effectivePackages = if (incoming.selectedPackages.isEmpty() && existing.selectedPackages.isNotEmpty()) {
                    existing.selectedPackages
                } else {
                    incoming.selectedPackages
                }
                val effectivePackageMap = if (incoming.packageAddedAt.isEmpty() && existing.packageAddedAt.isNotEmpty()) {
                    existing.packageAddedAt
                } else {
                    incoming.packageAddedAt
                }
                incoming.copy(
                    selectedPackages = effectivePackages,
                    packageAddedAt = effectivePackageMap,
                    createdAt = if (incoming.createdAt > 0L) incoming.createdAt else existing.createdAt,
                    lastActivatedAt = if (incoming.lastActivatedAt > 0L) incoming.lastActivatedAt else existing.lastActivatedAt
                )
            } else {
                incoming
            }
        }
        saveUsageRules(context, mergedRules)
        return mergedRules
    }

    fun upsertUsageRule(context: Context, rule: com.example.model.UsageBlockRule): List<com.example.model.UsageBlockRule> {
        val error = validateUsageRuleModification(context, rule)
        if (error != null) {
            Log.w("SaffahBlockRepo", "Blocked unauthorized usage rule edit: $error")
            return getUsageRules(context)
        }
        val current = getUsageRules(context).toMutableList()
        val index = current.indexOfFirst { it.id == rule.id }
        val now = System.currentTimeMillis()
        val finalRule = if (index >= 0) {
            val existing = current[index]
            // Preserve tracking start time for existing apps in the rule so their accumulated usage is NOT lost!
            val updatedPackageMap = rule.selectedPackages.associateWith { pkg ->
                val canonical = pkg.trim().lowercase()
                existing.packageAddedAt[pkg] ?: existing.packageAddedAt[canonical] ?: existing.packageAddedAt.entries.find { it.key.equals(pkg, ignoreCase = true) }?.value ?: (if (existing.selectedPackages.any { it.equals(pkg, ignoreCase = true) }) {
                    if (existing.createdAt > 0L) existing.createdAt else now
                } else now)
            }
            rule.copy(
                createdAt = if (existing.createdAt > 0L) existing.createdAt else now,
                lastActivatedAt = if (existing.lastActivatedAt > 0L) existing.lastActivatedAt else now,
                packageAddedAt = updatedPackageMap
            )
        } else {
            // New rule created: all packages start tracking strictly from now
            val initialPackageMap = rule.selectedPackages.associateWith { now }
            rule.copy(
                createdAt = now,
                lastActivatedAt = now,
                packageAddedAt = initialPackageMap
            )
        }
        if (index >= 0) {
            current[index] = finalRule
        } else {
            current.add(0, finalRule)
        }
        saveUsageRules(context, current)
        invalidateUsageCache()
        SaffahNotificationManager.resetUsageNotificationForRule(context, finalRule.id, finalRule.selectedPackages)
        applyPackageSuspensionIfNeeded(context)
        return current
    }

    fun deleteUsageRule(context: Context, id: Long): List<com.example.model.UsageBlockRule> {
        if (isUsageRuleModificationRestricted(context)) {
            val existing = getUsageRules(context).find { it.id == id }
            if (existing != null) {
                Log.w("SaffahBlockRepo", "Blocked deletion of usage rule when RQ and Time Delay are active outside allowed window")
                return getUsageRules(context)
            }
        }
        val current = getUsageRules(context).filter { it.id != id }
        saveUsageRules(context, current)
        return current
    }

    fun toggleUsageRuleEnabled(context: Context, id: Long): List<com.example.model.UsageBlockRule> {
        val current = getUsageRules(context)
        val rule = current.find { it.id == id } ?: return current
        if (rule.isEnabled && isUsageRuleModificationRestricted(context)) {
            Log.w("SaffahBlockRepo", "Blocked disabling usage rule when RQ and Time Delay are active outside allowed window")
            return current
        }
        val now = System.currentTimeMillis()
        val updated = current.map {
            if (it.id == id) {
                val newEnabled = !it.isEnabled
                it.copy(
                    isEnabled = newEnabled,
                    lastActivatedAt = if (newEnabled) now else it.lastActivatedAt,
                    packageAddedAt = if (newEnabled) it.selectedPackages.associateWith { now } else it.packageAddedAt
                )
            } else it
        }
        saveUsageRules(context, updated)
        invalidateUsageCache()
        val changedRule = updated.find { it.id == id }
        if (changedRule != null && changedRule.isEnabled) {
            SaffahNotificationManager.resetUsageNotificationForRule(context, changedRule.id, changedRule.selectedPackages)
        }
        applyPackageSuspensionIfNeeded(context)
        return updated
    }

    // --- DAILY USAGE & MIDNIGHT RESET ---

    /**
     * Formats duration in minutes:
     * - If duration is less than 1 hour (< 60 minutes), omit hours: "59m", "00m", "15m".
     * - If duration is 1 hour or more (>= 60 minutes), format with hours: "01h:30m", "02h:00m".
     */
    fun formatUsageCeilingTime(totalMinutes: Int, forceIncludeHours: Boolean = false): String {
        val safeMinutes = totalMinutes.coerceAtLeast(0)
        val h = safeMinutes / 60
        val m = safeMinutes % 60
        return if (h == 0 && !forceIncludeHours) {
            String.format(java.util.Locale.US, "%02dm", m)
        } else {
            String.format(java.util.Locale.US, "%02dh:%02dm", h, m)
        }
    }

    /**
     * Formats usage pair (spent/target):
     * - If targetMinutes is less than 60 minutes, formats as "00m / 59m" or "15m / 30m".
     * - If targetMinutes is 60 minutes or more, formats as "00h:15m / 01h:30m".
     */
    fun formatUsagePair(spentMinutes: Int, targetMinutes: Int): String {
        val isUnderHour = targetMinutes < 60
        val spentFormatted = formatUsageCeilingTime(spentMinutes, forceIncludeHours = !isUnderHour)
        val targetFormatted = formatUsageCeilingTime(targetMinutes, forceIncludeHours = !isUnderHour)
        return "$spentFormatted / $targetFormatted"
    }

    // --- Saffah Dedicated High-Precision App Usage & Launch Engine ---
    private val saffahSpentTimeMillisMap = java.util.concurrent.ConcurrentHashMap<String, Long>()
    @Volatile private var isSaffahSpentTimeLoaded = false
    @Volatile private var lastSaffahSpentTimeFlushTime = 0L

    private val saffahLaunchCountsMap = java.util.concurrent.ConcurrentHashMap<String, Int>()
    @Volatile private var isSaffahLaunchCountsLoaded = false
    @Volatile private var lastSaffahLaunchCountsFlushTime = 0L

    // High-precision timestamped tracking for rules: only usage AFTER rule creation/activation is counted
    private val saffahTimeSlicesMap = java.util.concurrent.ConcurrentHashMap<String, MutableList<Pair<Long, Long>>>()
    private val saffahLaunchTimestampsMap = java.util.concurrent.ConcurrentHashMap<String, MutableList<Long>>()

    private val lastLaunchIncrementRealtimeMap = java.util.concurrent.ConcurrentHashMap<String, Long>()

    @Volatile private var activeForegroundPackage: String? = null
    @Volatile private var activeForegroundStartTime: Long = 0L
    @Volatile private var activeForegroundLastTickTime: Long = 0L
    private const val MAX_DELTA_CAP_MILLIS = 10_000L

    fun clearActiveForegroundPackage() {
        activeForegroundPackage = null
        activeForegroundStartTime = 0L
        activeForegroundLastTickTime = 0L
    }

    private val packageSuspensionLock = Any()
    private val usageBlockLock = Any()
    private val backgroundSyncExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()

    /**
     * Checks if current time is within the active productivity tracking window (06:00 to 22:00).
     */
    fun isProductivityTrackingWindowActive(): Boolean {
        val hour = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.LocalTime.now().hour
        } else {
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        }
        return hour in 6..21
    }

    private fun recordTimeSlice(context: Context, packageName: String, start: Long, end: Long) {
        if (end <= start || packageName.isBlank()) return
        ensureSaffahSpentTimeLoaded(context)
        val canonical = packageName.trim().lowercase()
        val pkgs = if (canonical != packageName) listOf(packageName, canonical) else listOf(packageName)
        for (pkg in pkgs) {
            val list = saffahTimeSlicesMap.getOrPut(pkg) {
                java.util.Collections.synchronizedList(mutableListOf())
            }
            synchronized(list) {
                val last = list.lastOrNull()
                if (last != null && start - last.second in 0L..3500L) {
                    list[list.size - 1] = Pair(last.first, end)
                } else {
                    list.add(Pair(start, end))
                }
                if (list.size > 200) {
                    val excess = list.size - 200
                    repeat(excess) { list.removeAt(0) }
                }
            }
        }
    }

    private fun recordLaunchTimestamp(context: Context, packageName: String, timestamp: Long) {
        if (packageName.isBlank()) return
        ensureSaffahLaunchCountsLoaded(context)
        val canonical = packageName.trim().lowercase()
        val pkgs = if (canonical != packageName) listOf(packageName, canonical) else listOf(packageName)
        for (pkg in pkgs) {
            val list = saffahLaunchTimestampsMap.getOrPut(pkg) {
                java.util.Collections.synchronizedList(mutableListOf())
            }
            synchronized(list) {
                list.add(timestamp)
                if (list.size > 200) {
                    val excess = list.size - 200
                    repeat(excess) { list.removeAt(0) }
                }
            }
        }
    }

    private fun ensureSaffahSpentTimeLoaded(context: Context) {
        if (!isSaffahSpentTimeLoaded) {
            synchronized(saffahSpentTimeMillisMap) {
                if (!isSaffahSpentTimeLoaded) {
                    val prefs = getSafeSharedPreferences(context)
                    val jsonStr = prefs.getString("saffah_custom_usage_time_json", null)
                        ?: prefs.getString("usage_live_uncommitted_json", null)
                    if (!jsonStr.isNullOrEmpty()) {
                        try {
                            val obj = JSONObject(jsonStr)
                            val keys = obj.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                saffahSpentTimeMillisMap[k] = obj.optLong(k, 0L)
                            }
                        } catch (_: Exception) {}
                    }

                    // Load timestamped time slices
                    val slicesJson = prefs.getString("saffah_custom_time_slices_json", null)
                    if (!slicesJson.isNullOrEmpty()) {
                        try {
                            val obj = JSONObject(slicesJson)
                            val keys = obj.keys()
                            while (keys.hasNext()) {
                                val pkg = keys.next()
                                val arr = obj.optJSONArray(pkg)
                                if (arr != null) {
                                    val list = mutableListOf<Pair<Long, Long>>()
                                    for (i in 0 until arr.length()) {
                                        val sliceArr = arr.optJSONArray(i)
                                        if (sliceArr != null && sliceArr.length() >= 2) {
                                            list.add(Pair(sliceArr.getLong(0), sliceArr.getLong(1)))
                                        }
                                    }
                                    saffahTimeSlicesMap[pkg] = java.util.Collections.synchronizedList(list)
                                }
                            }
                        } catch (_: Exception) {}
                    }
                    isSaffahSpentTimeLoaded = true
                }
            }
        }
    }

    private fun flushSaffahSpentTimeToDisk(context: Context) {
        try {
            val prefs = getSafeSharedPreferences(context)
            val obj = JSONObject()
            val seenSpentCanonical = mutableSetOf<String>()
            saffahSpentTimeMillisMap.forEach { (pkg, millis) ->
                val canonical = pkg.trim().lowercase()
                if (millis > 0L && seenSpentCanonical.add(canonical)) {
                    obj.put(canonical, millis)
                }
            }
            val slicesObj = JSONObject()
            val seenSlicesCanonical = mutableSetOf<String>()
            saffahTimeSlicesMap.forEach { (pkg, list) ->
                val canonical = pkg.trim().lowercase()
                if (seenSlicesCanonical.add(canonical)) {
                    val arr = JSONArray()
                    synchronized(list) {
                        val recent = if (list.size > 120) list.takeLast(120) else list
                        for (pair in recent) {
                            val sliceArr = JSONArray()
                            sliceArr.put(pair.first)
                            sliceArr.put(pair.second)
                            arr.put(sliceArr)
                        }
                    }
                    if (arr.length() > 0) {
                        slicesObj.put(canonical, arr)
                    }
                }
            }
            prefs.edit()
                .putString("saffah_custom_usage_time_json", obj.toString())
                .putString("saffah_custom_time_slices_json", slicesObj.toString())
                .apply()
            lastSaffahSpentTimeFlushTime = System.currentTimeMillis()
        } catch (_: Throwable) {}
    }

    private fun ensureSaffahLaunchCountsLoaded(context: Context) {
        if (!isSaffahLaunchCountsLoaded) {
            synchronized(saffahLaunchCountsMap) {
                if (!isSaffahLaunchCountsLoaded) {
                    val prefs = getSafeSharedPreferences(context)
                    val jsonStr = prefs.getString("saffah_custom_launch_counts_json", null)
                        ?: prefs.getString("usage_launch_counts_json", null)
                    if (!jsonStr.isNullOrEmpty()) {
                        try {
                            val obj = JSONObject(jsonStr)
                            val keys = obj.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                saffahLaunchCountsMap[k] = obj.optInt(k, 0)
                            }
                        } catch (_: Exception) {}
                    }

                    // Load timestamped launches
                    val launchesJson = prefs.getString("saffah_custom_launch_timestamps_json", null)
                    if (!launchesJson.isNullOrEmpty()) {
                        try {
                            val obj = JSONObject(launchesJson)
                            val keys = obj.keys()
                            while (keys.hasNext()) {
                                val pkg = keys.next()
                                val arr = obj.optJSONArray(pkg)
                                if (arr != null) {
                                    val list = mutableListOf<Long>()
                                    for (i in 0 until arr.length()) {
                                        list.add(arr.getLong(i))
                                    }
                                    saffahLaunchTimestampsMap[pkg] = java.util.Collections.synchronizedList(list)
                                }
                            }
                        } catch (_: Exception) {}
                    }
                    isSaffahLaunchCountsLoaded = true
                    reconcileAndFixInflatedLaunchCounts(context)
                }
            }
        }
    }

    private fun flushSaffahLaunchCountsToDisk(context: Context) {
        try {
            val prefs = getSafeSharedPreferences(context)
            val obj = JSONObject()
            saffahLaunchCountsMap.forEach { (pkg, count) ->
                if (count > 0) {
                    obj.put(pkg, count)
                }
            }
            val launchesObj = JSONObject()
            saffahLaunchTimestampsMap.forEach { (pkg, list) ->
                val arr = JSONArray()
                synchronized(list) {
                    val recent = if (list.size > 200) list.takeLast(200) else list
                    for (ts in recent) {
                        arr.put(ts)
                    }
                }
                if (arr.length() > 0) {
                    launchesObj.put(pkg, arr)
                }
            }
            prefs.edit()
                .putString("saffah_custom_launch_counts_json", obj.toString())
                .putString("saffah_custom_launch_timestamps_json", launchesObj.toString())
                .apply()
            lastSaffahLaunchCountsFlushTime = System.currentTimeMillis()
        } catch (_: Throwable) {}
    }

    /**
     * Resets usage time for all productivity target apps at 22:00 or when explicitly requested.
     */
    fun resetProductivityUsageData(context: Context) {
        val rule = getProductivityRule(context) ?: return
        val targetPkgs = rule.targetApps.map { it.packageName }.toSet()
        if (targetPkgs.isEmpty()) return

        synchronized(saffahSpentTimeMillisMap) {
            ensureSaffahSpentTimeLoaded(context)
            targetPkgs.forEach { pkg ->
                saffahSpentTimeMillisMap.remove(pkg)
                saffahSpentTimeMillisMap.remove(pkg.lowercase())
            }
            flushSaffahSpentTimeToDisk(context)
        }

        try {
            val prefs = getSafeSharedPreferences(context)
            val editor = prefs.edit()
            targetPkgs.forEach { pkg ->
                editor.remove("acc_spent_ms_$pkg")
                editor.remove("acc_spent_ms_${pkg.lowercase()}")
            }
            editor.apply()
        } catch (e: Exception) {
            Log.w("SaffahBlockRepo", "Error clearing productivity usage data: ${e.message}")
        }
    }

    @Volatile private var cachedPowerManager: android.os.PowerManager? = null
    private fun getPowerManager(context: Context): android.os.PowerManager? {
        var pm = cachedPowerManager
        if (pm == null) {
            pm = context.applicationContext.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            cachedPowerManager = pm
        }
        return pm
    }

    fun recordPeriodicForegroundTick(context: Context, packageName: String, tickMillis: Long = 1500L) {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName) || isSystemSettingsPackage(context, packageName) || isSystemSettingsPackageName(packageName)) return
        val pm = getPowerManager(context)
        if (pm?.isInteractive == false) return

        checkAndPerformMidnightReset(context)
        ensureSaffahSpentTimeLoaded(context)

        // If the package is part of productivity target apps, only accumulate usage between 06:00 and 22:00
        val prodRule = getProductivityRule(context)
        val isProdTarget = prodRule?.targetApps?.any { it.packageName.equals(packageName, ignoreCase = true) } == true
        if (isProdTarget && !isProductivityTrackingWindowActive()) {
            activeForegroundPackage = packageName
            activeForegroundStartTime = System.currentTimeMillis()
            activeForegroundLastTickTime = activeForegroundStartTime
            return
        }

        val now = System.currentTimeMillis()
        val sliceStart = if (activeForegroundPackage == packageName && activeForegroundLastTickTime > 0L) {
            activeForegroundLastTickTime
        } else {
            now - minOf(tickMillis, MAX_DELTA_CAP_MILLIS)
        }
        val rawDelta = now - sliceStart
        val delta = if (rawDelta > 0L) minOf(rawDelta, MAX_DELTA_CAP_MILLIS) else minOf(tickMillis, MAX_DELTA_CAP_MILLIS)

        if (delta > 0L) {
            val canonical = packageName.trim().lowercase()
            val current = saffahSpentTimeMillisMap[canonical] ?: (saffahSpentTimeMillisMap[packageName] ?: 0L)
            val updated = current + delta
            saffahSpentTimeMillisMap[canonical] = updated
            saffahSpentTimeMillisMap[packageName] = updated
            recordTimeSlice(context, packageName, sliceStart, now)
            if (isProdTarget || (now - lastSaffahSpentTimeFlushTime > 15_000L)) {
                flushSaffahSpentTimeToDisk(context)
            }
        }

        activeForegroundPackage = packageName
        if (activeForegroundStartTime == 0L) {
            activeForegroundStartTime = now
        }
        activeForegroundLastTickTime = now

        // Check if this tick causes any rule limit to be reached/exceeded and apply suspension immediately
        if (isUsageMasterEnabled(context)) {
            val targetPkgs = cachedUsageRuleTargetPackages ?: run {
                val rules = getUsageRules(context)
                val set = rules.filter { it.isEnabled }.flatMap { it.selectedPackages }.map { it.trim().lowercase() }.toSet()
                cachedUsageRuleTargetPackages = set
                set
            }
            val canonicalPkg = packageName.trim().lowercase()
            val hasRule = targetPkgs.contains(canonicalPkg) || targetPkgs.contains(packageName)
            if (hasRule) {
                invalidateUsageCache()
                val blocked = getCurrentlyBlockedPackagesByUsage(context)
                if (blocked.contains(packageName) || blocked.contains(canonicalPkg)) {
                    flushSaffahSpentTimeToDisk(context)
                    flushSaffahLaunchCountsToDisk(context)
                    applySinglePackageSuspension(context, packageName, true)
                    applyPackageSuspensionIfNeeded(context)
                    SaffahNotificationManager.notifyAppBlockedByUsageImmediately(context, packageName)
                    if (activeForegroundPackage.equals(packageName, ignoreCase = true) || activeForegroundPackage?.trim()?.lowercase() == canonicalPkg) {
                        clearActiveForegroundPackage()
                    }
                    enforcementListener?.onAppBlockedImmediately(packageName, "حد الاستخدام اليومي", "تم حظر التطبيق لتجاوز حد وقت الاستخدام المحدد")
                }
            }
        }

        // Live check for productivity targets
        if (isProdTarget && prodRule != null && prodRule.isEnabled && isProductivityTrackingWindowActive()) {
            val allCompleted = isProductivityAllTargetsCompleted(context, prodRule)
            if (allCompleted) {
                // All targets completed! Flush time immediately, lift the block and notify
                flushSaffahSpentTimeToDisk(context)
                syncAllPackageSuspensions(context, force = true)
                SaffahNotificationManager.evaluateAndTriggerProductivityGoalNotifications(context)
            } else {
                SaffahNotificationManager.evaluateAndTriggerProductivityGoalNotifications(context)
            }
        }
    }

    fun notifyAppForegroundChanged(context: Context, newPackageName: String) {
        val now = System.currentTimeMillis()
        val prevPkg = activeForegroundPackage
        val prevStart = activeForegroundStartTime
        val prevLastTick = activeForegroundLastTickTime

        if (!prevPkg.isNullOrEmpty()) {
            val baselineTime = if (prevLastTick > 0L) prevLastTick else prevStart
            if (baselineTime > 0L && now > baselineTime) {
                val rawDelta = now - baselineTime
                val deltaMillis = if (rawDelta > 0L) minOf(rawDelta, MAX_DELTA_CAP_MILLIS) else 0L
                if (deltaMillis > 0L && !isStrictUnblockableSystemPackage(context, prevPkg) && !isSystemSettingsPackage(context, prevPkg) && !isSystemSettingsPackageName(prevPkg)) {
                    val prodRule = getProductivityRule(context)
                    val isProdTarget = prodRule?.targetApps?.any { it.packageName.equals(prevPkg, ignoreCase = true) } == true
                    if (!isProdTarget || isProductivityTrackingWindowActive()) {
                        ensureSaffahSpentTimeLoaded(context)
                        val canonical = prevPkg.trim().lowercase()
                        val current = saffahSpentTimeMillisMap[canonical] ?: (saffahSpentTimeMillisMap[prevPkg] ?: 0L)
                        val updated = current + deltaMillis
                        saffahSpentTimeMillisMap[canonical] = updated
                        saffahSpentTimeMillisMap[prevPkg] = updated
                        recordTimeSlice(context, prevPkg, baselineTime, now)
                    }
                }
            }
        }

        if (newPackageName == prevPkg && !prevPkg.isNullOrEmpty()) {
            // Same app continuous session: keep start time intact, update last tick to now
            activeForegroundLastTickTime = now
        } else if (newPackageName.isNotBlank() && (isStrictUnblockableSystemPackage(context, newPackageName) || isSystemSettingsPackage(context, newPackageName) || isSystemSettingsPackageName(newPackageName))) {
            activeForegroundPackage = null
            activeForegroundStartTime = 0L
            activeForegroundLastTickTime = 0L
        } else {
            activeForegroundPackage = newPackageName.ifBlank { null }
            activeForegroundStartTime = if (newPackageName.isNotBlank()) now else 0L
            activeForegroundLastTickTime = if (newPackageName.isNotBlank()) now else 0L
        }

        flushSaffahSpentTimeToDisk(context)
        flushSaffahLaunchCountsToDisk(context)
    }

    fun getAccessibilityTrackedMillis(context: Context, packageName: String): Long {
        return getDailyForegroundTimeMillis(context, packageName)
    }

    fun notifyScreenOff(context: Context) {
        val now = System.currentTimeMillis()
        val prevPkg = activeForegroundPackage
        val prevLastTick = activeForegroundLastTickTime
        val prevStart = activeForegroundStartTime

        if (!prevPkg.isNullOrEmpty()) {
            val baseline = if (prevLastTick > 0L) prevLastTick else prevStart
            if (baseline > 0L && now > baseline) {
                val rawDelta = now - baseline
                val deltaMillis = if (rawDelta > 0L) minOf(rawDelta, MAX_DELTA_CAP_MILLIS) else 0L
                if (deltaMillis > 0L && !isStrictUnblockableSystemPackage(context, prevPkg) && !isSystemSettingsPackage(context, prevPkg) && !isSystemSettingsPackageName(prevPkg)) {
                    ensureSaffahSpentTimeLoaded(context)
                    val canonical = prevPkg.trim().lowercase()
                    val current = saffahSpentTimeMillisMap[canonical] ?: (saffahSpentTimeMillisMap[prevPkg] ?: 0L)
                    val updated = current + deltaMillis
                    saffahSpentTimeMillisMap[canonical] = updated
                    saffahSpentTimeMillisMap[prevPkg] = updated
                    recordTimeSlice(context, prevPkg, baseline, now)
                }
            }
        }
        activeForegroundPackage = null
        activeForegroundStartTime = 0L
        activeForegroundLastTickTime = 0L
        flushSaffahSpentTimeToDisk(context)
        flushSaffahLaunchCountsToDisk(context)
    }

    fun getLiveForegroundSessionMillis(context: Context, packageName: String): Long {
        val pm = getPowerManager(context)
        if (pm?.isInteractive == false) return 0L

        val currentActive = activeForegroundPackage
        val refTime = if (activeForegroundLastTickTime > 0L) activeForegroundLastTickTime else activeForegroundStartTime
        if (currentActive == packageName && refTime > 0L) {
            val now = System.currentTimeMillis()
            if (now > refTime) {
                val rawLive = now - refTime
                return minOf(rawLive, MAX_DELTA_CAP_MILLIS)
            }
        }
        return 0L
    }

    @Volatile private var lastMidnightCheckElapsed: Long = 0L
    @Volatile private var cachedLastSavedTrackingDate: String? = null
    private const val MIDNIGHT_CHECK_THROTTLE_MS = 30_000L

    fun checkAndPerformMidnightReset(context: Context, shouldSyncSuspension: Boolean = true) {
        val nowElapsed = SystemClock.elapsedRealtime()
        if (nowElapsed - lastMidnightCheckElapsed < MIDNIGHT_CHECK_THROTTLE_MS) return
        lastMidnightCheckElapsed = nowElapsed

        val todayStr = getCurrentDateString()
        val lastSavedDate = cachedLastSavedTrackingDate ?: run {
            val prefs = getSafeSharedPreferences(context)
            val d = prefs.getString("saffah_usage_tracking_date", "") ?: ""
            cachedLastSavedTrackingDate = d
            d
        }

        if (lastSavedDate != todayStr) {
            cachedLastSavedTrackingDate = todayStr
            val prefs = getSafeSharedPreferences(context)
            Log.d("SaffahBlockRepo", "Midnight Reset triggered for Saffah dedicated tracker! Resetting launch counts & usage time.")
            activeForegroundPackage = null
            activeForegroundStartTime = 0L
            activeForegroundLastTickTime = 0L
            lastLaunchIncrementRealtimeMap.clear()
            saffahSpentTimeMillisMap.clear()
            isSaffahSpentTimeLoaded = true
            saffahLaunchCountsMap.clear()
            isSaffahLaunchCountsLoaded = true
            saffahTimeSlicesMap.clear()
            saffahLaunchTimestampsMap.clear()

            prefs.edit()
                .putString("saffah_usage_tracking_date", todayStr)
                .remove("saffah_custom_usage_time_json")
                .remove("saffah_custom_launch_counts_json")
                .remove("saffah_custom_time_slices_json")
                .remove("saffah_custom_launch_timestamps_json")
                .remove("usage_launch_counts_json")
                .remove("usage_accessibility_time_json")
                .remove("usage_live_uncommitted_json")
                .remove("usage_system_baseline_json")
                .remove("usage_blocked_packages_set")
                .apply()

            com.example.util.SaffahPenaltyManager.onDateChanged(context)

            // Reset productivity target baselines for the new day
            val prodRule = getProductivityRule(context)
            if (prodRule != null && prodRule.targetApps.any { it.baselineMillis > 0L || it.addedAt > 0L }) {
                val resetTargets = prodRule.targetApps.map { it.copy(baselineMillis = 0L, addedAt = 0L) }
                saveProductivityRule(context, prodRule.copy(targetApps = resetTargets))
            }

            if (shouldSyncSuspension) {
                syncAllPackageSuspensions(context, force = true)
            }
            scheduleMidnightAlarm(context)
        }
    }

    /**
     * Efficiently returns the start of the current day in milliseconds.
     * Caches the value and recomputes only when the current day transitions.
     */
    fun getStartOfDayMillis(): Long {
        val now = System.currentTimeMillis()
        val cached = cachedStartOfDayMillis
        val cachedEnd = cachedEndOfDayMillis
        if (cached > 0L && now in cached until cachedEnd) {
            return cached
        }
        val cal = java.util.Calendar.getInstance().apply {
            timeInMillis = now
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        val end = cal.timeInMillis
        cachedStartOfDayMillis = start
        cachedEndOfDayMillis = end
        return start
    }

    /**
     * Session-Aware launch counter from Android UsageEvents.
     * Accurately counts distinct application launch sessions today.
     * Strictly ignores internal activity changes, fragment transitions, screen rotations,
     * sub-activities, back-presses, in-app ads, dialogs, and transient system overlays.
     */
    fun getSystemUsageEventsLaunchCount(context: Context, packageName: String): Int {
        if (packageName.isBlank()) return 0
        try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? android.app.usage.UsageStatsManager ?: return 0
            val startOfDay = getStartOfDayMillis()
            val end = System.currentTimeMillis()
            if (end <= startOfDay) return 0
            val events = usm.queryEvents(startOfDay, end) ?: return 0
            val event = android.app.usage.UsageEvents.Event()
            val target = packageName.trim()
            val targetLower = target.lowercase()

            var sessionCount = 0
            var isTargetActive = false
            var lastTargetActiveTimestamp = 0L
            var lastInterveningNonTransientPkg: String? = null

            val SESSION_GAP_THRESHOLD_MS = 30_000L // 30 seconds session gap

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val eventPkg = event.packageName?.trim() ?: continue
                val eventPkgLower = eventPkg.lowercase()
                val isTarget = (eventPkg.equals(target, ignoreCase = true) || eventPkgLower == targetLower)

                when (event.eventType) {
                    android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED -> {
                        if (isTarget) {
                            // If target was already active (e.g. moving between activities/screens/features inside the app),
                            // do NOT increment!
                            if (!isTargetActive) {
                                val timeSinceLastActive = event.timeStamp - lastTargetActiveTimestamp
                                val isGenuineNewSession = (lastTargetActiveTimestamp == 0L) ||
                                        (timeSinceLastActive >= SESSION_GAP_THRESHOLD_MS) ||
                                        (lastInterveningNonTransientPkg != null &&
                                                !lastInterveningNonTransientPkg.equals(targetLower, ignoreCase = true))

                                if (isGenuineNewSession) {
                                    sessionCount++
                                }
                            }
                            isTargetActive = true
                            lastTargetActiveTimestamp = event.timeStamp
                            lastInterveningNonTransientPkg = null
                        } else {
                            if (!isTransientSystemComponent(context, eventPkg)) {
                                if (isTargetActive) {
                                    isTargetActive = false
                                    lastTargetActiveTimestamp = event.timeStamp
                                }
                                lastInterveningNonTransientPkg = eventPkgLower
                            }
                        }
                    }
                    android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED,
                    android.app.usage.UsageEvents.Event.ACTIVITY_STOPPED -> {
                        if (isTarget) {
                            lastTargetActiveTimestamp = event.timeStamp
                            // Do not mark isTargetActive = false here because another activity in the same app
                            // resumes immediately during internal screen transitions (e.g. MainActivity -> DetailActivity).
                        }
                    }
                }
            }
            return sessionCount
        } catch (_: Exception) {
            return 0
        }
    }

    fun getDailyLaunchCount(context: Context, packageName: String): Int {
        if (packageName.isBlank()) return 0
        checkAndPerformMidnightReset(context)
        ensureSaffahLaunchCountsLoaded(context)
        val canonical = packageName.trim().lowercase()

        // Saffah's dedicated session-tracker is the primary authority
        val recordedCount = saffahLaunchCountsMap[canonical] ?: saffahLaunchCountsMap[packageName]
        if (recordedCount != null) {
            return recordedCount
        }

        // Only fallback to system events baseline if Saffah has never seen launches for this app today
        val systemCount = getSystemUsageEventsLaunchCount(context, packageName)
        saffahLaunchCountsMap[canonical] = systemCount
        saffahLaunchCountsMap[packageName] = systemCount
        return systemCount
    }

    fun incrementDailyLaunchCount(context: Context, packageName: String): Int {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName) || isHomeLauncherPackage(context, packageName)) return 0
        checkAndPerformMidnightReset(context)

        val nowRealtime = android.os.SystemClock.elapsedRealtime()
        val lastInc = lastLaunchIncrementRealtimeMap[packageName] ?: 0L
        // Minimal 800ms debounce to prevent duplicate event glitches while allowing responsive re-launches
        if (nowRealtime - lastInc < 800L) {
            return getDailyLaunchCount(context, packageName)
        }
        lastLaunchIncrementRealtimeMap[packageName] = nowRealtime

        ensureSaffahLaunchCountsLoaded(context)

        val currentCount = getDailyLaunchCount(context, packageName)
        val newCount = currentCount + 1
        val canonical = packageName.trim().lowercase()
        saffahLaunchCountsMap[canonical] = newCount
        saffahLaunchCountsMap[packageName] = newCount

        val now = System.currentTimeMillis()
        recordLaunchTimestamp(context, packageName, now)
        flushSaffahLaunchCountsToDisk(context)

        invalidateUsageCache()
        val blocked = getCurrentlyBlockedPackagesByUsage(context)
        val canonicalPkg = packageName.trim().lowercase()
        if (blocked.contains(packageName) || blocked.contains(canonicalPkg)) {
            applySinglePackageSuspension(context, packageName, true)
            applyPackageSuspensionIfNeeded(context)
            SaffahNotificationManager.notifyAppBlockedByUsageImmediately(context, packageName)
            if (activeForegroundPackage.equals(packageName, ignoreCase = true) || activeForegroundPackage?.trim()?.lowercase() == canonicalPkg) {
                clearActiveForegroundPackage()
            }
            enforcementListener?.onAppBlockedImmediately(packageName, "حد الاستخدام اليومي", "تم حظر التطبيق لتجاوز حد عدد مرات الفتح المحدد")
        }

        return newCount
    }

    /**
     * Reconciles baseline launch counts on first startup if Saffah has no counts recorded yet today.
     * Never overwrites or downgrades Saffah's real-time accessibility session tracking.
     */
    fun reconcileAndFixInflatedLaunchCounts(context: Context) {
        try {
            val allRules: List<com.example.model.UsageBlockRule> = getUsageRules(context)
            val rules = allRules.filter { it.isEnabled && it.limitType == com.example.model.UsageLimitType.LAUNCH_COUNT }
            if (rules.isEmpty()) return

            for (rule in rules) {
                for (pkg in rule.selectedPackages) {
                    val canonical = pkg.trim().lowercase()
                    val recordedCount = saffahLaunchCountsMap[canonical] ?: saffahLaunchCountsMap[pkg] ?: 0
                    // Only initialize from system if Saffah has zero recorded launches for this package today
                    if (recordedCount == 0) {
                        val trueSessionCount = getSystemUsageEventsLaunchCount(context, pkg)
                        if (trueSessionCount > 0) {
                            saffahLaunchCountsMap[canonical] = trueSessionCount
                            saffahLaunchCountsMap[pkg] = trueSessionCount
                        }
                    }
                }
            }
        } catch (_: Exception) {}
    }

    fun getDailyForegroundTimeMinutes(context: Context, packageName: String): Int {
        val totalMillis = getDailyForegroundTimeMillis(context, packageName)
        return (totalMillis / (1000 * 60)).toInt()
    }

    @Volatile
    private var cachedUsageStatsList: List<android.app.usage.UsageStats>? = null
    @Volatile
    private var cachedUsageStatsStart: Long = 0L
    @Volatile
    private var cachedUsageStatsTimestamp: Long = 0L
    private val usageStatsLock = Any()

    /**
     * Queries Android OS UsageStatsManager for absolute hardware-level foreground time of a package.
     * Guaranteed to work for all types of apps (media players, reading apps, games, separate processes).
     */
    fun getSystemUsageStatsForegroundMillis(context: Context, packageName: String, startTimestamp: Long = 0L): Long {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName)) return 0L
        try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? android.app.usage.UsageStatsManager ?: return 0L
            val startOfDay = getStartOfDayMillis()
            val start = if (startTimestamp > 0L) maxOf(startTimestamp, startOfDay) else startOfDay
            val end = System.currentTimeMillis()
            if (end <= start) return 0L

            val target = packageName.trim()
            val targetLower = target.lowercase()
            var totalFg = 0L

            // 1. Query aggregated usage stats
            try {
                val agg = usm.queryAndAggregateUsageStats(start, end)
                if (!agg.isNullOrEmpty()) {
                    val directStat = agg[target] ?: agg[targetLower]
                    if (directStat != null && directStat.totalTimeInForeground > 0L) {
                        totalFg = maxOf(totalFg, directStat.totalTimeInForeground)
                    }
                    if (totalFg == 0L) {
                        for ((k, v) in agg) {
                            if (k.equals(target, ignoreCase = true) || k.lowercase() == targetLower) {
                                totalFg = maxOf(totalFg, v.totalTimeInForeground)
                            }
                        }
                    }
                }
            } catch (_: Exception) {}

            if (totalFg > 0L) {
                return totalFg
            }

            // 2. Fallback to interval query
            val nowRealtime = android.os.SystemClock.elapsedRealtime()
            val stats = synchronized(usageStatsLock) {
                if (cachedUsageStatsList != null && cachedUsageStatsStart == start && (nowRealtime - cachedUsageStatsTimestamp < 2500L)) {
                    cachedUsageStatsList
                } else {
                    val freshStats = usm.queryUsageStats(android.app.usage.UsageStatsManager.INTERVAL_DAILY, start, end)
                    if (freshStats != null) {
                        cachedUsageStatsList = freshStats
                        cachedUsageStatsStart = start
                        cachedUsageStatsTimestamp = nowRealtime
                    }
                    freshStats
                }
            }

            if (!stats.isNullOrEmpty()) {
                for (stat in stats) {
                    val pkg = stat.packageName
                    if (pkg.equals(target, ignoreCase = true) || pkg.lowercase() == targetLower) {
                        totalFg = maxOf(totalFg, stat.totalTimeInForeground)
                    }
                }
                if (totalFg > 0L) {
                    return totalFg
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahBlockRepo", "UsageStats query error for $packageName: ${e.message}")
        }
        return 0L
    }

    fun getDailyForegroundTimeMillis(context: Context, packageName: String): Long {
        if (packageName.isBlank()) return 0L
        checkAndPerformMidnightReset(context)
        ensureSaffahSpentTimeLoaded(context)

        val canonical = packageName.trim().lowercase()
        val baseMillis = saffahSpentTimeMillisMap[canonical] ?: (saffahSpentTimeMillisMap[packageName] ?: 0L)

        val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        val active = activeForegroundPackage?.trim()?.lowercase()
        val liveBaseMillis = if (pm?.isInteractive != false && (active == canonical || activeForegroundPackage.equals(packageName, ignoreCase = true))) {
            val now = System.currentTimeMillis()
            val refTime = if (activeForegroundLastTickTime > 0L) activeForegroundLastTickTime else activeForegroundStartTime
            if (refTime > 0L && now > refTime) {
                val liveDelta = minOf(now - refTime, MAX_DELTA_CAP_MILLIS)
                baseMillis + liveDelta
            } else {
                baseMillis
            }
        } else {
            baseMillis
        }

        val systemMillis = getSystemUsageStatsForegroundMillis(context, packageName)
        return maxOf(liveBaseMillis, systemMillis)
    }

    /**
     * Determines the active starting baseline timestamp for a rule and specific package today.
     * Any usage or launch before this timestamp is strictly excluded.
     */
    fun getUsageRuleActiveWindowStartToday(rule: com.example.model.UsageBlockRule, packageName: String = ""): Long {
        val startOfDay = getStartOfDayMillis()
        val canonical = packageName.trim().lowercase()
        val pkgStart = if (packageName.isNotBlank()) {
            rule.packageAddedAt[packageName] ?: rule.packageAddedAt[canonical] ?: rule.packageAddedAt.entries.find { it.key.equals(packageName, ignoreCase = true) }?.value
        } else null
        val ruleStart = pkgStart ?: (if (rule.lastActivatedAt > 0L) rule.lastActivatedAt else rule.createdAt)
        return if (ruleStart > 0L) maxOf(startOfDay, ruleStart) else startOfDay
    }

    /**
     * High-Precision rule-specific minutes consumed strictly AFTER rule creation/activation today.
     */
    fun getUsageRuleConsumedMinutes(context: Context, rule: com.example.model.UsageBlockRule, packageName: String): Int {
        val millis = getUsageRuleConsumedMillis(context, rule, packageName)
        return (millis / (1000 * 60)).toInt()
    }

    /**
     * High-Precision rule-specific milliseconds consumed today.
     * Incorporates true daily foreground usage time, dedicated tracking, and persistent block floors.
     */
    fun getUsageRuleConsumedMillis(context: Context, rule: com.example.model.UsageBlockRule, packageName: String): Long {
        if (packageName.isBlank()) return 0L
        checkAndPerformMidnightReset(context)
        ensureSaffahSpentTimeLoaded(context)

        val canonical = packageName.trim().lowercase()
        val totalDailyMillis = getDailyForegroundTimeMillis(context, packageName)
        val windowStart = getUsageRuleActiveWindowStartToday(rule, packageName)
        val startOfDay = getStartOfDayMillis()

        // Calculate time from Saffah's timestamped slices that occurred after windowStart
        var saffahMillisSinceWindow = 0L
        val slices = saffahTimeSlicesMap[canonical] ?: saffahTimeSlicesMap[packageName]
        if (slices != null) {
            synchronized(slices) {
                for (slice in slices) {
                    if (slice.second > windowStart) {
                        val effectiveStart = maxOf(slice.first, windowStart)
                        val effectiveEnd = minOf(slice.second, System.currentTimeMillis())
                        if (effectiveEnd > effectiveStart) {
                            saffahMillisSinceWindow += (effectiveEnd - effectiveStart)
                        }
                    }
                }
            }
        }

        // Add live foreground delta if the app is currently active on screen right now
        val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        val active = activeForegroundPackage?.trim()?.lowercase()
        if (pm?.isInteractive != false && (active == canonical || activeForegroundPackage.equals(packageName, ignoreCase = true))) {
            val refTime = if (activeForegroundLastTickTime > 0L) activeForegroundLastTickTime else activeForegroundStartTime
            val effectiveRefTime = maxOf(refTime, windowStart)
            val now = System.currentTimeMillis()
            if (effectiveRefTime > 0L && now > effectiveRefTime) {
                val liveDelta = minOf(now - effectiveRefTime, MAX_DELTA_CAP_MILLIS)
                saffahMillisSinceWindow += liveDelta
            }
        }

        // System UsageStats delta since windowStart
        val systemMillisSinceWindow = getSystemUsageStatsForegroundMillis(context, packageName, windowStart)
        val effectiveSinceWindow = maxOf(saffahMillisSinceWindow, systemMillisSinceWindow)

        // Raw dedicated tracker recorded usage today
        val rawDedicatedSpent = saffahSpentTimeMillisMap[canonical] ?: (saffahSpentTimeMillisMap[packageName] ?: 0L)

        return maxOf(effectiveSinceWindow, totalDailyMillis, rawDedicatedSpent)
    }

    /**
     * High-Precision rule-specific launch count today.
     * Incorporates true daily launch count to prevent missing timestamps.
     */
    fun getUsageRuleConsumedLaunches(context: Context, rule: com.example.model.UsageBlockRule, packageName: String): Int {
        if (packageName.isBlank()) return 0
        checkAndPerformMidnightReset(context)
        ensureSaffahLaunchCountsLoaded(context)

        val canonical = packageName.trim().lowercase()
        val totalDailyLaunches = getDailyLaunchCount(context, packageName)
        val windowStart = getUsageRuleActiveWindowStartToday(rule, packageName)
        val startOfDay = getStartOfDayMillis()

        var saffahLaunchesSinceWindow = 0
        val timestamps = saffahLaunchTimestampsMap[canonical] ?: saffahLaunchTimestampsMap[packageName]
        if (timestamps != null) {
            synchronized(timestamps) {
                for (ts in timestamps) {
                    if (ts >= windowStart) {
                        saffahLaunchesSinceWindow++
                    }
                }
            }
        }

        val rawDedicatedLaunches = saffahLaunchCountsMap[canonical] ?: (saffahLaunchCountsMap[packageName] ?: 0)

        return maxOf(saffahLaunchesSinceWindow, totalDailyLaunches, rawDedicatedLaunches)
    }

    fun getUsageBlockedPackages(context: Context): Set<String> {
        checkAndPerformMidnightReset(context)
        if (!isUsageMasterEnabled(context)) return emptySet()
        synchronized(usageBlockLock) {
            val prefs = getSafeSharedPreferences(context)
            return prefs.getStringSet("usage_blocked_packages_set", null)?.toSet() ?: emptySet()
        }
    }

    @Volatile
    private var cachedCurrentlyBlockedByUsage: Set<String>? = null
    @Volatile
    private var cachedCurrentlyBlockedByUsageTimestamp: Long = 0L
    @Volatile
    private var cachedUsageBlockedPackagesSet: Set<String>? = null

    fun invalidateUsageCache() {
        synchronized(usageBlockLock) {
            cachedCurrentlyBlockedByUsage = null
            cachedCurrentlyBlockedByUsageTimestamp = 0L
            cachedUsageBlockedPackagesSet = null
        }
        synchronized(usageStatsLock) {
            cachedUsageStatsList = null
            cachedUsageStatsStart = 0L
            cachedUsageStatsTimestamp = 0L
        }
    }

    fun setUsageBlockedPackage(context: Context, packageName: String, blocked: Boolean) {
        synchronized(usageBlockLock) {
            val current = getUsageBlockedPackages(context).toMutableSet()
            val canonical = packageName.trim().lowercase()
            if (blocked) {
                current.add(packageName)
                current.add(canonical)
            } else {
                current.remove(packageName)
                current.remove(canonical)
            }
            cachedUsageBlockedPackagesSet = current
            val prefs = getSafeSharedPreferences(context)
            prefs.edit().putStringSet("usage_blocked_packages_set", HashSet(current)).apply()
            invalidateUsageCache()
            cachedUsageBlockedPackagesSet = current
        }
    }

    @Volatile
    private var isSyncingPackageSuspensions = false

    fun evaluateUsageBlockingForPackage(context: Context, packageName: String): Boolean {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName)) return false
        val canonicalPkg = packageName.trim().lowercase()
        if (isPackageDirectlyBlockedByUsage(context, packageName, canonicalPkg)) return true
        val currentlyBlocked = getCurrentlyBlockedPackagesByUsage(context)
        return currentlyBlocked.contains(packageName) || currentlyBlocked.contains(canonicalPkg) || currentlyBlocked.any { it.equals(canonicalPkg, ignoreCase = true) }
    }

    /**
     * Direct zero-latency check for a specific package to guarantee immediate blocking
     * without waiting for background loops or risking stale batch caches.
     */
    fun isPackageDirectlyBlockedByUsage(
        context: Context,
        packageName: String,
        canonicalPkg: String = packageName.trim().lowercase()
    ): Boolean {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName)) return false
        if (!isUsageMasterEnabled(context)) return false

        // 1. Thread-safe instant check from in-memory cache or persistent storage
        val stored = cachedUsageBlockedPackagesSet ?: run {
            val prefs = getSafeSharedPreferences(context)
            val raw = prefs.getStringSet("usage_blocked_packages_set", null) ?: emptySet()
            val mapped = raw.map { it.trim().lowercase() }.toSet()
            cachedUsageBlockedPackagesSet = mapped
            mapped
        }
        if (stored.contains(canonicalPkg) || stored.contains(packageName)) {
            return true
        }

        // 2. Direct rule evaluation for this specific package right now
        val rules = getUsageRules(context).filter { it.isEnabled }
        if (rules.isEmpty()) return false

        val (todayOfWeek, _) = getCachedTimeContext()
        val activeRulesToday = rules.filter { it.activeDays.isEmpty() || it.activeDays.contains(todayOfWeek) }
        val matchingRules = activeRulesToday.filter { r ->
            r.selectedPackages.any { it.trim().equals(canonicalPkg, ignoreCase = true) || it.trim().equals(packageName, ignoreCase = true) }
        }
        if (matchingRules.isEmpty()) return false

        ensureSaffahSpentTimeLoaded(context)
        ensureSaffahLaunchCountsLoaded(context)

        for (rule in matchingRules) {
            when (rule.limitType) {
                com.example.model.UsageLimitType.DURATION -> {
                    val usedMillis = getUsageRuleConsumedMillis(context, rule, packageName)
                    val usedMin = (usedMillis / (1000 * 60)).toInt()
                    val targetLimitMillis = rule.limitValue * 60 * 1000L
                    if (usedMillis >= targetLimitMillis || usedMin >= rule.limitValue) {
                        markPackageBlockedByUsageToday(context, packageName, canonicalPkg, targetLimitMillis, 0)
                        return true
                    }
                }
                com.example.model.UsageLimitType.LAUNCH_COUNT -> {
                    val launches = getUsageRuleConsumedLaunches(context, rule, packageName)
                    if (launches >= rule.limitValue) {
                        markPackageBlockedByUsageToday(context, packageName, canonicalPkg, 0L, rule.limitValue)
                        return true
                    }
                }
            }
        }
        return false
    }

    private fun markPackageBlockedByUsageToday(
        context: Context,
        packageName: String,
        canonicalPkg: String,
        targetLimitMillis: Long,
        targetLimitLaunches: Int
    ) {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName)) return
        synchronized(usageBlockLock) {
            val prefs = getSafeSharedPreferences(context)
            val currentSet = HashSet(cachedUsageBlockedPackagesSet ?: (prefs.getStringSet("usage_blocked_packages_set", null) ?: emptySet()))
            val isNew = !currentSet.contains(canonicalPkg) && !currentSet.contains(packageName)
            currentSet.add(packageName)
            currentSet.add(canonicalPkg)
            cachedUsageBlockedPackagesSet = currentSet
            prefs.edit().putStringSet("usage_blocked_packages_set", currentSet).apply()

            var needSpentFlush = false
            var needLaunchFlush = false

            if (targetLimitMillis > 0L) {
                val curSpent = saffahSpentTimeMillisMap[canonicalPkg] ?: 0L
                if (curSpent < targetLimitMillis) {
                    saffahSpentTimeMillisMap[canonicalPkg] = targetLimitMillis
                    saffahSpentTimeMillisMap[packageName] = targetLimitMillis
                    needSpentFlush = true
                }
            }
            if (targetLimitLaunches > 0) {
                val curLaunches = saffahLaunchCountsMap[canonicalPkg] ?: 0
                if (curLaunches < targetLimitLaunches) {
                    saffahLaunchCountsMap[canonicalPkg] = targetLimitLaunches
                    saffahLaunchCountsMap[packageName] = targetLimitLaunches
                    needLaunchFlush = true
                }
            }

            if (needSpentFlush) {
                flushSaffahSpentTimeToDisk(context)
            }
            if (needLaunchFlush) {
                flushSaffahLaunchCountsToDisk(context)
            }

            invalidateUsageCache()
            applySinglePackageSuspension(context, packageName, true)
            if (isNew) {
                addBlockLog(context, packageName, "حد الاستخدام اليومي", packageName)
                SaffahNotificationManager.notifyAppBlockedByUsageImmediately(context, packageName)
            }
        }
    }

    fun getCurrentlyBlockedPackagesByUsage(context: Context): Set<String> {
        checkAndPerformMidnightReset(context)
        val nowRealtime = android.os.SystemClock.elapsedRealtime()
        val cached = cachedCurrentlyBlockedByUsage
        if (cached != null && (nowRealtime - cachedCurrentlyBlockedByUsageTimestamp < 1500L)) {
            return cached
        }

        synchronized(usageBlockLock) {
            val prefs = getSafeSharedPreferences(context)

            val rules = getUsageRules(context).filter { it.isEnabled }
            if (rules.isEmpty()) {
                val rawStored = prefs.getStringSet("usage_blocked_packages_set", null) ?: emptySet()
                if (rawStored.isNotEmpty()) {
                    prefs.edit().remove("usage_blocked_packages_set").apply()
                    if (!isSyncingPackageSuspensions) {
                        applyPackageSuspensionIfNeeded(context)
                    }
                }
                cachedCurrentlyBlockedByUsage = emptySet()
                cachedCurrentlyBlockedByUsageTimestamp = nowRealtime
                return emptySet()
            }

            val (todayOfWeek, _) = getCachedTimeContext()

            val activeRulesToday = rules.filter { it.activeDays.isEmpty() || it.activeDays.contains(todayOfWeek) }
            if (activeRulesToday.isEmpty()) {
                cachedCurrentlyBlockedByUsage = emptySet()
                cachedCurrentlyBlockedByUsageTimestamp = nowRealtime
                return emptySet()
            }

            val activePackagesToday = activeRulesToday.flatMap { it.selectedPackages }.map { it.trim() }.filter {
                it.isNotBlank() && !isStrictUnblockableSystemPackage(context, it)
            }.toSet()

            val rawStoredBlocked = prefs.getStringSet("usage_blocked_packages_set", null)?.let { HashSet(it) } ?: HashSet<String>()
            val newBlockedPkgs = HashSet<String>()

            var needSpentFlush = false
            var needLaunchFlush = false

            for (pkg in activePackagesToday) {
                val normalizedPkg = pkg.lowercase()
                val rulesForPkg = activeRulesToday.filter { r ->
                    r.selectedPackages.any { it.trim().lowercase() == normalizedPkg }
                }
                var shouldBlock = false

                for (rule in rulesForPkg) {
                    when (rule.limitType) {
                        com.example.model.UsageLimitType.DURATION -> {
                            val usedMillis = getUsageRuleConsumedMillis(context, rule, pkg)
                            val usedMin = (usedMillis / (1000 * 60)).toInt()
                            val targetLimitMillis = rule.limitValue * 60 * 1000L
                            if (usedMillis >= targetLimitMillis || usedMin >= rule.limitValue) {
                                shouldBlock = true
                                val curSpent = saffahSpentTimeMillisMap[normalizedPkg] ?: 0L
                                if (curSpent < targetLimitMillis) {
                                    saffahSpentTimeMillisMap[normalizedPkg] = targetLimitMillis
                                    saffahSpentTimeMillisMap[pkg] = targetLimitMillis
                                    needSpentFlush = true
                                }
                                break
                            }
                        }
                        com.example.model.UsageLimitType.LAUNCH_COUNT -> {
                            val launches = getUsageRuleConsumedLaunches(context, rule, pkg)
                            if (launches >= rule.limitValue) {
                                shouldBlock = true
                                val curLaunches = saffahLaunchCountsMap[normalizedPkg] ?: 0
                                if (curLaunches < rule.limitValue) {
                                    saffahLaunchCountsMap[normalizedPkg] = rule.limitValue
                                    saffahLaunchCountsMap[pkg] = rule.limitValue
                                    needLaunchFlush = true
                                }
                                break
                            }
                        }
                    }
                }

                if (shouldBlock) {
                    newBlockedPkgs.add(pkg)
                    newBlockedPkgs.add(normalizedPkg)
                }
            }

            if (needSpentFlush) {
                flushSaffahSpentTimeToDisk(context)
            }
            if (needLaunchFlush) {
                flushSaffahLaunchCountsToDisk(context)
            }

            newBlockedPkgs.removeAll { isStrictUnblockableSystemPackage(context, it) }

            if (rawStoredBlocked != newBlockedPkgs) {
                val newlyBlocked = newBlockedPkgs.filter { !rawStoredBlocked.contains(it) }
                for (pkg in newlyBlocked) {
                    addBlockLog(context, pkg, "حد الاستخدام اليومي", pkg)
                    applySinglePackageSuspension(context, pkg, true)
                    SaffahNotificationManager.notifyAppBlockedByUsageImmediately(context, pkg)
                }
                val newlyUnblocked = rawStoredBlocked.filter { !newBlockedPkgs.contains(it) && !newBlockedPkgs.contains(it.lowercase()) }
                for (pkg in newlyUnblocked) {
                    applySinglePackageSuspension(context, pkg, false)
                }
                prefs.edit().putStringSet("usage_blocked_packages_set", HashSet(newBlockedPkgs)).apply()
                cachedUsageBlockedPackagesSet = newBlockedPkgs
                if (!isSyncingPackageSuspensions) {
                    applyPackageSuspensionIfNeeded(context)
                }
            }

            // Immediate kick-out if currently in foreground and blocked
            val currentActive = activeForegroundPackage?.trim()?.lowercase()
            if (!currentActive.isNullOrBlank() && (newBlockedPkgs.contains(currentActive) || newBlockedPkgs.contains(activeForegroundPackage))) {
                val pkgToEvict = currentActive
                clearActiveForegroundPackage()
                enforcementListener?.onAppBlockedImmediately(
                    pkgToEvict,
                    "حد الاستخدام اليومي",
                    "تم حظر التطبيق لتجاوز سقف الاستخدام المحدد"
                )
            }

            cachedCurrentlyBlockedByUsage = newBlockedPkgs
            cachedCurrentlyBlockedByUsageTimestamp = nowRealtime
            return newBlockedPkgs
        }
    }

    fun checkAndApplyUsageBlocksImmediately(context: Context) {
        invalidateUsageCache()
        val blocked = getCurrentlyBlockedPackagesByUsage(context)
        for (pkg in blocked) {
            applySinglePackageSuspension(context, pkg, true)
        }
        val currentActive = activeForegroundPackage?.trim()?.lowercase()
        if (!currentActive.isNullOrBlank() && (blocked.contains(currentActive) || blocked.contains(activeForegroundPackage))) {
            val pkgToEvict = currentActive
            clearActiveForegroundPackage()
            enforcementListener?.onAppBlockedImmediately(
                pkgToEvict,
                "حد الاستخدام اليومي",
                "تم حظر التطبيق لتجاوز سقف الاستخدام المحدد"
            )
        }
        applyPackageSuspensionIfNeeded(context)
    }

    fun isRuleActiveNow(
        rule: com.example.model.AppBlockScheduleRule,
        todayOfWeek: Int,
        nowMinutes: Int,
        yesterdayOfWeek: Int
    ): Boolean {
        if (!rule.isEnabled) return false
        if (rule.activeDays.isEmpty()) return false

        val ranges = rule.getEffectiveTimeRanges()
        for (range in ranges) {
            val startMinutes = range.startHour * 60 + range.startMinute
            val endMinutes = range.endHour * 60 + range.endMinute

            val isActive = if (startMinutes == endMinutes) {
                rule.activeDays.contains(todayOfWeek)
            } else if (startMinutes < endMinutes) {
                rule.activeDays.contains(todayOfWeek) && (nowMinutes in startMinutes until endMinutes)
            } else {
                if (nowMinutes >= startMinutes) {
                    rule.activeDays.contains(todayOfWeek)
                } else if (nowMinutes < endMinutes) {
                    rule.activeDays.contains(yesterdayOfWeek)
                } else {
                    false
                }
            }
            if (isActive) return true
        }
        return false
    }

    fun isRuleActiveNow(rule: com.example.model.AppBlockScheduleRule): Boolean {
        if (!rule.isEnabled) return false
        if (rule.activeDays.isEmpty()) return false

        val (todayOfWeek, nowMinutes) = getCachedTimeContext()
        val yesterdayOfWeek = if (todayOfWeek == java.util.Calendar.SUNDAY) java.util.Calendar.SATURDAY else todayOfWeek - 1

        return isRuleActiveNow(rule, todayOfWeek, nowMinutes, yesterdayOfWeek)
    }

    fun getCurrentlyBlockedPackagesBySchedule(context: Context, allInstalledPackages: List<String>): Set<String> {
        if (!isAppScheduleMasterEnabled(context)) return emptySet()
        val rules = getAppScheduleRules(context)
        if (rules.isEmpty()) return emptySet()

        val (todayOfWeek, nowMinutes) = getCachedTimeContext()
        val yesterdayOfWeek = if (todayOfWeek == java.util.Calendar.SUNDAY) java.util.Calendar.SATURDAY else todayOfWeek - 1

        val activeRules = rules.filter { isRuleActiveNow(it, todayOfWeek, nowMinutes, yesterdayOfWeek) }
        if (activeRules.isEmpty()) return emptySet()

        val ownPkg = context.packageName
        val blockedPackages = mutableSetOf<String>()

        for (rule in activeRules) {
            when (rule.blockType) {
                com.example.model.AppBlockType.BLOCK_SPECIFIED -> {
                    blockedPackages.addAll(rule.selectedPackages)
                }
                com.example.model.AppBlockType.ALLOW_SPECIFIED_BLOCK_OTHERS -> {
                    val allowedSet = rule.selectedPackages.toHashSet().apply { add(ownPkg) }
                    for (i in allInstalledPackages.indices) {
                        val pkg = allInstalledPackages[i]
                        if (!allowedSet.contains(pkg) && pkg != ownPkg) {
                            blockedPackages.add(pkg)
                        }
                    }
                }
            }
        }
        blockedPackages.removeAll { isStrictUnblockableSystemPackage(context, it) }
        blockedPackages.remove(ownPkg)
        return blockedPackages
    }

    fun getCachedInstalledPackages(context: Context): List<String> {
        val now = android.os.SystemClock.elapsedRealtime()
        val cached = cachedInstalledPackages
        if (cached != null && (now - cachedInstalledPackagesTimestamp < 300_000L)) { // 5 minutes TTL
            return cached
        }
        val pm = context.packageManager
        val installedPkgsSet = mutableSetOf<String>()
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            android.content.pm.PackageManager.MATCH_DISABLED_COMPONENTS or android.content.pm.PackageManager.MATCH_UNINSTALLED_PACKAGES
        } else {
            @Suppress("DEPRECATION")
            android.content.pm.PackageManager.GET_DISABLED_COMPONENTS
        }

        try {
            val packageInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(android.content.pm.PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(flags)
            }
            packageInfos.forEach { if (!it.packageName.isNullOrBlank()) installedPkgsSet.add(it.packageName) }
        } catch (_: Exception) { }

        val mainIntent = android.content.Intent(android.content.Intent.ACTION_MAIN, null).apply {
            addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(mainIntent, android.content.pm.PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(mainIntent, 0)
            }
        } catch (_: Exception) { null }
        resolveInfos?.forEach { if (!it.activityInfo.packageName.isNullOrBlank()) installedPkgsSet.add(it.activityInfo.packageName) }

        // Explicitly include Google Play Store, system Settings, and essential apps
        installedPkgsSet.add("com.android.vending")
        installedPkgsSet.add("com.google.android.vending")
        installedPkgsSet.add("com.android.settings")
        installedPkgsSet.add("com.google.android.settings")
        installedPkgsSet.add("com.coloros.settings")
        installedPkgsSet.add("com.oppo.settings")
        installedPkgsSet.add("com.realme.settings")
        installedPkgsSet.add("com.heytap.setting")
        installedPkgsSet.add("com.samsung.android.settings")
        installedPkgsSet.add("com.miui.securitycenter")
        installedPkgsSet.add("com.xiaomi.misettings")
        installedPkgsSet.add("com.vivo.settings")
        installedPkgsSet.add("com.huawei.systemmanager")

        try {
            val settingsIntent = android.content.Intent(android.provider.Settings.ACTION_SETTINGS)
            val resolvedSettings = pm.resolveActivity(settingsIntent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
            val resolvedPkg = resolvedSettings?.activityInfo?.packageName
            if (!resolvedPkg.isNullOrBlank()) installedPkgsSet.add(resolvedPkg)
        } catch (_: Exception) {}

        val result = installedPkgsSet.toList()
        cachedInstalledPackages = result
        cachedInstalledPackagesTimestamp = now
        return result
    }

    fun syncAllPackageSuspensions(context: Context, force: Boolean = false) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            backgroundSyncExecutor.execute {
                syncAllPackageSuspensions(context, force)
            }
            return
        }
        synchronized(packageSuspensionLock) {
            if (isSyncingPackageSuspensions) return
            try {
                isSyncingPackageSuspensions = true
                checkAndPerformMidnightReset(context, shouldSyncSuspension = false)

                val prefs = getSafeSharedPreferences(context)
                val ownPkg = context.packageName.lowercase()

                val installedPkgsSet = getCachedInstalledPackages(context).toMutableSet()

                // Include stored raw package sets to guarantee un-suspension if a rule was deleted
                val permanentBlocked = getPermanentBlockedPackages(context)
                installedPkgsSet.addAll(permanentBlocked)

                val rawUsageBlocked = prefs.getStringSet("usage_blocked_packages_set", null) ?: emptySet()
                installedPkgsSet.addAll(rawUsageBlocked)

                val storedSuspended = prefs.getStringSet("currently_suspended_pkgs", null) ?: emptySet()
                installedPkgsSet.addAll(storedSuspended)

                val scheduleRules = getAppScheduleRules(context)
                for (i in scheduleRules.indices) {
                    installedPkgsSet.addAll(scheduleRules[i].selectedPackages)
                }
                val usageRules = getUsageRules(context)
                for (i in usageRules.indices) {
                    installedPkgsSet.addAll(usageRules[i].selectedPackages)
                }
                installedPkgsSet.addAll(getBedtimeAllowedApps(context))
                getProductivityRule(context)?.let { prodRule ->
                    for (i in prodRule.targetApps.indices) {
                        installedPkgsSet.add(prodRule.targetApps[i].packageName)
                    }
                    installedPkgsSet.addAll(prodRule.allowedApps)
                }

                val installedPkgs = installedPkgsSet.toList()

                val isProtected = { pkg: String ->
                    isStrictUnblockableSystemPackage(context, pkg)
                }

                val scheduleBlocked = getCurrentlyBlockedPackagesBySchedule(context, installedPkgs)
                val usageBlocked = getCurrentlyBlockedPackagesByUsage(context)
                val productivityBlocked = getCurrentlyBlockedPackagesByProductivity(context, installedPkgs)

                val bedtimeBlocked = if (isCurrentlyBedtime(context) && isBedtimeModeEnabled(context)) {
                    val bedtimeAllowed = getBedtimeAllowedApps(context)
                    val allInstalled = getCachedInstalledPackages(context)
                    val result = HashSet<String>()
                    for (i in allInstalled.indices) {
                        val pkg = allInstalled[i]
                        if (!bedtimeAllowed.contains(pkg) && !isProtected(pkg)) {
                            result.add(pkg)
                        }
                    }
                    result
                } else {
                    emptySet()
                }

                val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? android.app.admin.DevicePolicyManager
                val adminComp = android.content.ComponentName(context, com.example.receiver.SaffahDeviceAdminReceiver::class.java)

                val totalToSuspend = HashSet<String>().apply {
                    addAll(permanentBlocked)
                    addAll(scheduleBlocked)
                    addAll(bedtimeBlocked)
                    addAll(usageBlocked)
                    addAll(productivityBlocked)
                    removeAll { isProtected(it) }
                }

                val newlyToSuspend = HashSet<String>()
                for (pkg in totalToSuspend) {
                    if (force || !storedSuspended.contains(pkg)) {
                        newlyToSuspend.add(pkg)
                    }
                }

                val newlyToUnsuspend = HashSet<String>()
                for (pkg in storedSuspended) {
                    if (!totalToSuspend.contains(pkg)) {
                        newlyToUnsuspend.add(pkg)
                    }
                }

                // If no changes needed and not forced, avoid expensive DevicePolicyManager IPC and disk commits!
                if (!force && newlyToSuspend.isEmpty() && newlyToUnsuspend.isEmpty()) {
                    return
                }

                if (dpm != null && (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComp))) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        try {
                            if (newlyToSuspend.isNotEmpty()) {
                                newlyToSuspend.chunked(25).forEach { batch ->
                                    try {
                                        dpm.setPackagesSuspended(adminComp, batch.toTypedArray(), true)
                                    } catch (e: Throwable) {
                                        Log.w("SaffahBlockRepo", "Chunked suspend failed: ${e.message}")
                                    }
                                }
                            }
                            if (newlyToUnsuspend.isNotEmpty()) {
                                newlyToUnsuspend.chunked(25).forEach { batch ->
                                    try {
                                        dpm.setPackagesSuspended(adminComp, batch.toTypedArray(), false)
                                    } catch (e: Throwable) {
                                        Log.w("SaffahBlockRepo", "Chunked unsuspend failed: ${e.message}")
                                    }
                                }
                            }
                            prefs.edit().putStringSet("currently_suspended_pkgs", HashSet(totalToSuspend)).apply()
                        } catch (e: Throwable) {
                            Log.w("SaffahBlockRepo", "DevicePolicyManager setPackagesSuspended failed: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("SaffahBlockRepo", "Error syncing all package suspensions: ${e.message}")
            } finally {
                isSyncingPackageSuspensions = false
            }
        }
    }

    fun applySinglePackageSuspension(context: Context, packageName: String, suspended: Boolean) {
        if (packageName.isBlank() || isStrictUnblockableSystemPackage(context, packageName)) return
        val ownPkg = context.packageName.lowercase()
        val lower = packageName.lowercase()
        if (lower == ownPkg) return

        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? android.app.admin.DevicePolicyManager ?: return
        val adminComp = android.content.ComponentName(context, com.example.receiver.SaffahDeviceAdminReceiver::class.java)

        if (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComp)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    dpm.setPackagesSuspended(adminComp, arrayOf(packageName), suspended)
                    val prefs = getSafeSharedPreferences(context)
                    val current = (prefs.getStringSet("currently_suspended_pkgs", null) ?: emptySet()).toMutableSet()
                    if (suspended) current.add(packageName) else current.remove(packageName)
                    prefs.edit().putStringSet("currently_suspended_pkgs", HashSet(current)).apply()
                } catch (e: Exception) {
                    Log.w("SaffahBlockRepo", "Error in applySinglePackageSuspension for $packageName: ${e.message}")
                }
            }
        }
    }

    fun scheduleAppScheduleAlarms(context: Context) {
        if (!isAppScheduleMasterEnabled(context)) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val rules = getAppScheduleRules(context).filter { it.isEnabled }
        if (rules.isEmpty()) return

        val cal = java.util.Calendar.getInstance()
        val nowMillis = cal.timeInMillis

        for (rule in rules) {
            val times = mutableListOf<Pair<Int, Int>>()
            for (range in rule.getEffectiveTimeRanges()) {
                times.add(Pair(range.startHour, range.startMinute))
                times.add(Pair(range.endHour, range.endMinute))
            }
            for ((idx, timePair) in times.withIndex()) {
                val (h, m) = timePair
                cal.timeInMillis = nowMillis
                cal.set(java.util.Calendar.HOUR_OF_DAY, h)
                cal.set(java.util.Calendar.MINUTE, m)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                if (cal.timeInMillis <= nowMillis) {
                    cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
                val alarmMillis = cal.timeInMillis

                val requestCode = (rule.id.hashCode() * 10) + idx
                val intent = android.content.Intent(context, com.example.receiver.SaffahBedtimeReceiver::class.java).apply {
                    action = "com.example.ACTION_SCHEDULE_TICK"
                }
                val pendingIntent = android.app.PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )

                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        val alarmClockInfo = android.app.AlarmManager.AlarmClockInfo(alarmMillis, pendingIntent)
                        alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, alarmMillis, pendingIntent)
                    } else {
                        alarmManager.setExact(android.app.AlarmManager.RTC_WAKEUP, alarmMillis, pendingIntent)
                    }
                } catch (e: SecurityException) {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            alarmManager.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, alarmMillis, pendingIntent)
                        } else {
                            alarmManager.setExact(android.app.AlarmManager.RTC_WAKEUP, alarmMillis, pendingIntent)
                        }
                    } catch (_: Exception) {
                        alarmManager.set(android.app.AlarmManager.RTC_WAKEUP, alarmMillis, pendingIntent)
                    }
                } catch (e: Exception) {
                    Log.w("SaffahBlockRepo", "Error setting schedule alarm: ${e.message}")
                }
            }
        }
    }

    fun scheduleMidnightAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val cal = java.util.Calendar.getInstance()
        val nowMillis = cal.timeInMillis
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 1)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= nowMillis) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        val midnightMillis = cal.timeInMillis

        val intent = android.content.Intent(context, com.example.receiver.SaffahBedtimeReceiver::class.java).apply {
            action = "com.example.ACTION_MIDNIGHT_RESET"
        }
        val pendingIntent = android.app.PendingIntent.getBroadcast(
            context,
            999888,
            intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, midnightMillis, pendingIntent)
            } else {
                alarmManager.setExact(android.app.AlarmManager.RTC_WAKEUP, midnightMillis, pendingIntent)
            }
        } catch (e: Exception) {
            Log.w("SaffahBlockRepo", "Error setting midnight alarm: ${e.message}")
        }
    }

    // --- PRODUCTIVITY & DISCIPLINE (تحسين الإنتاجية والإنظباط) ---

    private const val KEY_PRODUCTIVITY_RULE_JSON = "productivity_discipline_rule_json"

    fun getProductivityRule(context: Context): com.example.model.ProductivityDisciplineRule? {
        if (isProductivityRuleLoaded) {
            return cachedProductivityRule ?: com.example.model.ProductivityDisciplineRule(
                id = 1L,
                name = "تحسين الإنتاجية والإنظباط",
                isEnabled = false,
                activeDays = setOf(1, 2, 3, 4, 5, 6, 7),
                targetApps = emptyList(),
                allowedApps = emptySet()
            )
        }
        val prefs = getSafeSharedPreferences(context)
        val jsonStr = prefs.getString(KEY_PRODUCTIVITY_RULE_JSON, null)
        if (jsonStr.isNullOrBlank()) {
            val defaultRule = com.example.model.ProductivityDisciplineRule(
                id = 1L,
                name = "تحسين الإنتاجية والإنظباط",
                isEnabled = false,
                activeDays = setOf(1, 2, 3, 4, 5, 6, 7),
                targetApps = emptyList(),
                allowedApps = emptySet()
            )
            cachedProductivityRule = defaultRule
            isProductivityRuleLoaded = true
            return defaultRule
        }
        val rule = try {
            val obj = JSONObject(jsonStr)
            val daysArray = obj.optJSONArray("activeDays")
            val activeDays = mutableSetOf<Int>()
            if (daysArray != null) {
                for (j in 0 until daysArray.length()) {
                    activeDays.add(daysArray.getInt(j))
                }
            } else {
                activeDays.addAll(setOf(1, 2, 3, 4, 5, 6, 7))
            }

            val targetAppsArray = obj.optJSONArray("targetApps")
            val targetAppsList = mutableListOf<com.example.model.ProductivityTargetApp>()
            if (targetAppsArray != null) {
                for (j in 0 until targetAppsArray.length()) {
                    val targetObj = targetAppsArray.getJSONObject(j)
                    targetAppsList.add(
                        com.example.model.ProductivityTargetApp(
                            packageName = targetObj.getString("packageName"),
                            targetMinutes = targetObj.getInt("targetMinutes"),
                            baselineMillis = targetObj.optLong("baselineMillis", 0L),
                            addedAt = targetObj.optLong("addedAt", 0L)
                        )
                    )
                }
            }

            val allowedAppsArray = obj.optJSONArray("allowedApps")
            val allowedAppsSet = mutableSetOf<String>()
            if (allowedAppsArray != null) {
                for (j in 0 until allowedAppsArray.length()) {
                    allowedAppsSet.add(allowedAppsArray.getString(j))
                }
            }

            val ruleObj = com.example.model.ProductivityDisciplineRule(
                id = obj.optLong("id", 1L),
                name = obj.optString("name", "تحسين الإنتاجية والإنظباط"),
                isEnabled = obj.optBoolean("isEnabled", false),
                activeDays = activeDays,
                targetApps = targetAppsList,
                allowedApps = allowedAppsSet
            )

            ruleObj
        } catch (e: Exception) {
            Log.e("SaffahBlockRepo", "Error parsing productivity rule json: ${e.message}")
            com.example.model.ProductivityDisciplineRule(
                id = 1L,
                name = "تحسين الإنتاجية والإنظباط",
                isEnabled = false,
                activeDays = setOf(1, 2, 3, 4, 5, 6, 7),
                targetApps = emptyList(),
                allowedApps = emptySet()
            )
        }
        cachedProductivityRule = rule
        isProductivityRuleLoaded = true
        return rule
    }

    fun syncProductivityAppBaseline(context: Context, packageName: String, baselineMillis: Long) {
        // No-op: Baselines are stored in ProductivityTargetApp and must not mutate raw daily usage counters
    }

    fun saveProductivityRule(context: Context, rule: com.example.model.ProductivityDisciplineRule?) {
        val sanitizedRule = rule?.let { r ->
            val updatedTargets = r.targetApps.map { target ->
                val currentDaily = getDailyForegroundTimeMillis(context, target.packageName)
                val effectiveAddedAt = if (target.addedAt == 0L) System.currentTimeMillis() else target.addedAt
                val effectiveBaseline = if (target.addedAt == 0L) currentDaily else target.baselineMillis

                target.copy(
                    baselineMillis = effectiveBaseline,
                    addedAt = effectiveAddedAt
                )
            }
            r.copy(targetApps = updatedTargets)
        }
        cachedProductivityRule = sanitizedRule
        isProductivityRuleLoaded = true
        val prefs = getSafeSharedPreferences(context)
        if (sanitizedRule == null) {
            prefs.edit().remove(KEY_PRODUCTIVITY_RULE_JSON).apply()
        } else {
            val obj = JSONObject().apply {
                put("id", sanitizedRule.id)
                put("name", sanitizedRule.name)
                put("isEnabled", sanitizedRule.isEnabled)

                val daysArray = JSONArray()
                sanitizedRule.activeDays.forEach { daysArray.put(it) }
                put("activeDays", daysArray)

                val targetAppsArray = JSONArray()
                sanitizedRule.targetApps.forEach { targetApp ->
                    val targetObj = JSONObject().apply {
                        put("packageName", targetApp.packageName)
                        put("targetMinutes", targetApp.targetMinutes)
                        put("baselineMillis", targetApp.baselineMillis)
                        put("addedAt", targetApp.addedAt)
                    }
                    targetAppsArray.put(targetObj)
                }
                put("targetApps", targetAppsArray)

                val allowedArray = JSONArray()
                sanitizedRule.allowedApps.forEach { allowedArray.put(it) }
                put("allowedApps", allowedArray)
            }
            prefs.edit().putString(KEY_PRODUCTIVITY_RULE_JSON, obj.toString()).apply()
        }
        syncAllPackageSuspensions(context, force = true)
        scheduleProductivityAlarms(context)
    }

    fun isProductivityActiveNow(context: Context): Boolean {
        val rule = getProductivityRule(context) ?: return false
        if (!rule.isEnabled || rule.targetApps.isEmpty()) return false

        val cal = java.util.Calendar.getInstance()
        val currentDay = cal.get(java.util.Calendar.DAY_OF_WEEK)
        if (!rule.activeDays.contains(currentDay)) return false

        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        // Active from 06:00 (6 AM) to 22:00 (10 PM)
        if (hour < 6 || hour >= 22) return false

        // Check if ALL target apps have reached their target cap
        val allTargetsCompleted = isProductivityAllTargetsCompleted(context, rule)
        // If all targets are completed, the lock/suspension lifts
        return !allTargetsCompleted
    }

    fun isProductivityAllTargetsCompleted(context: Context, rule: com.example.model.ProductivityDisciplineRule): Boolean {
        if (rule.targetApps.isEmpty()) return false
        for (target in rule.targetApps) {
            val spentMinutes = getProductivityAppSpentMinutes(context, target.packageName)
            if (spentMinutes < target.targetMinutes) {
                return false
            }
        }
        return true
    }

    fun getProductivityAppSpentMillis(context: Context, packageName: String): Long {
        if (packageName.isBlank()) return 0L
        checkAndPerformMidnightReset(context)
        ensureSaffahSpentTimeLoaded(context)

        val rule = getProductivityRule(context)
        val target = rule?.targetApps?.find { it.packageName.equals(packageName, ignoreCase = true) }
        val canonical = packageName.trim().lowercase()

        val startOfDay = getStartOfDayMillis()

        val windowStart = if (target != null && target.addedAt > 0L) {
            maxOf(target.addedAt, startOfDay)
        } else {
            startOfDay
        }

        // 1. Calculate time from Saffah's timestamped slices that occurred after windowStart
        var sliceMillisSinceWindow = 0L
        val slices = saffahTimeSlicesMap[canonical] ?: saffahTimeSlicesMap[packageName]
        if (slices != null) {
            synchronized(slices) {
                for (slice in slices) {
                    if (slice.second > windowStart) {
                        val effectiveStart = maxOf(slice.first, windowStart)
                        val effectiveEnd = minOf(slice.second, System.currentTimeMillis())
                        if (effectiveEnd > effectiveStart) {
                            sliceMillisSinceWindow += (effectiveEnd - effectiveStart)
                        }
                    }
                }
            }
        }

        // Add live foreground delta if the app is currently active on screen right now
        val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        val active = activeForegroundPackage?.trim()?.lowercase()
        if (pm?.isInteractive != false && (active == canonical || activeForegroundPackage.equals(packageName, ignoreCase = true))) {
            val refTime = if (activeForegroundLastTickTime > 0L) activeForegroundLastTickTime else activeForegroundStartTime
            val effectiveRefTime = maxOf(refTime, windowStart)
            val now = System.currentTimeMillis()
            if (effectiveRefTime > 0L && now > effectiveRefTime) {
                val liveDelta = minOf(now - effectiveRefTime, MAX_DELTA_CAP_MILLIS)
                sliceMillisSinceWindow += liveDelta
            }
        }

        // 2. Difference between current total daily usage and baseline
        val totalDaily = getDailyForegroundTimeMillis(context, packageName)
        val baseline = target?.baselineMillis ?: 0L
        val dailyMinusBaseline = if (totalDaily >= baseline) totalDaily - baseline else 0L

        // 3. Raw dedicated tracker recorded usage today minus baseline
        val rawDedicatedSpent = saffahSpentTimeMillisMap[canonical] ?: (saffahSpentTimeMillisMap[packageName] ?: 0L)
        val dedicatedMinusBaseline = if (rawDedicatedSpent >= baseline) rawDedicatedSpent - baseline else 0L

        return maxOf(sliceMillisSinceWindow, dailyMinusBaseline, dedicatedMinusBaseline)
    }

    fun getProductivityAppSpentMinutes(context: Context, packageName: String): Int {
        val millis = getProductivityAppSpentMillis(context, packageName)
        return (millis / 60_000L).toInt()
    }

    fun isPackageBlockedByProductivity(context: Context, packageName: String): Boolean {
        val rule = getProductivityRule(context) ?: return false
        if (!isProductivityActiveNow(context)) return false

        val ownPkg = context.packageName.lowercase()
        val lower = packageName.lowercase().trim()
        if (lower == ownPkg) return false
        if (isAlwaysExemptPackage(packageName) || isSystemSettingsPackage(context, packageName) || isSystemSettingsPackageName(packageName)) return false

        // Allowed apps and target apps are exempt from suspension during productivity mode
        val isTargetApp = rule.targetApps.any { it.packageName.equals(packageName, ignoreCase = true) }
        if (isTargetApp) return false

        val isAllowedApp = rule.allowedApps.any { it.equals(packageName, ignoreCase = true) }
        if (isAllowedApp) return false

        // All other apps are suspended/blocked
        return true
    }

    fun getCurrentlyBlockedPackagesByProductivity(context: Context, installedPackages: List<String>): Set<String> {
        val rule = getProductivityRule(context) ?: return emptySet()
        if (!isProductivityActiveNow(context)) return emptySet()

        val ownPkg = context.packageName.lowercase()
        val targetPkgs = rule.targetApps.map { it.packageName.lowercase() }.toSet()
        val allowedPkgs = rule.allowedApps.map { it.lowercase() }.toSet()

        return installedPackages.filter { pkg ->
            val lower = pkg.lowercase().trim()
            lower != ownPkg &&
            !isAlwaysExemptPackage(pkg) &&
            !isSystemSettingsPackage(context, pkg) &&
            !isSystemSettingsPackageName(pkg) &&
            !targetPkgs.contains(lower) &&
            !allowedPkgs.contains(lower)
        }.toSet()
    }

    fun isProductivityModificationAllowedWindow(): Boolean {
        // Allowed modification window: 22:00 PM to 06:00 AM (22, 23, 0, 1, 2, 3, 4, 5)
        val hourOfDay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.LocalTime.now().hour
        } else {
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        }
        return hourOfDay !in 6..21
    }

    fun isProductivityModificationRestrictedByTimeDelay(context: Context): Boolean {
        if (!isTimeDelayActive(context)) return false
        return !isProductivityModificationAllowedWindow()
    }

    fun scheduleProductivityAlarms(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val rule = getProductivityRule(context)
        if (rule == null || !rule.isEnabled) return

        val cal = java.util.Calendar.getInstance()
        val nowMillis = cal.timeInMillis

        // 06:00 AM alarm
        cal.set(java.util.Calendar.HOUR_OF_DAY, 6)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= nowMillis) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        val startMillis = cal.timeInMillis

        // 22:00 PM alarm
        cal.timeInMillis = nowMillis
        cal.set(java.util.Calendar.HOUR_OF_DAY, 22)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= nowMillis) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        val endMillis = cal.timeInMillis

        val startIntent = android.content.Intent(context, com.example.receiver.SaffahBedtimeReceiver::class.java).apply {
            action = "com.example.ACTION_PRODUCTIVITY_STATE_CHANGE"
        }
        val startPending = android.app.PendingIntent.getBroadcast(
            context,
            777101,
            startIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val endIntent = android.content.Intent(context, com.example.receiver.SaffahBedtimeReceiver::class.java).apply {
            action = "com.example.ACTION_PRODUCTIVITY_STATE_CHANGE"
        }
        val endPending = android.app.PendingIntent.getBroadcast(
            context,
            777102,
            endIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, startMillis, startPending)
                alarmManager.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, endMillis, endPending)
            } else {
                alarmManager.setExact(android.app.AlarmManager.RTC_WAKEUP, startMillis, startPending)
                alarmManager.setExact(android.app.AlarmManager.RTC_WAKEUP, endMillis, endPending)
            }
        } catch (e: Exception) {
            Log.w("SaffahBlockRepo", "Error scheduling productivity alarms: ${e.message}")
        }
    }

    fun applyPackageSuspensionIfNeeded(context: Context) {
        checkAndPerformMidnightReset(context)
        syncAllPackageSuspensions(context)
        scheduleAppScheduleAlarms(context)
        scheduleProductivityAlarms(context)
        scheduleMidnightAlarm(context)
    }

    // --- Anime MobileNetV3 Rating Detector Config & Dry Run ---
    private const val KEY_AI_ANIME_TR18 = "ai_anime_tr18"
    private const val KEY_AI_ANIME_TR15 = "ai_anime_tr15"
    private const val KEY_AI_ANIME_TSUM = "ai_anime_tsum"
    private const val KEY_AI_ANIME_CONFIRM = "ai_anime_confirm"
    private const val KEY_AI_ANIME_MIN_LUMA_STD = "ai_anime_min_luma_std"
    private const val KEY_AI_ANIME_MAX_WINDOWS = "ai_anime_max_windows"
    private const val KEY_AI_DRY_RUN = "ai_dry_run"

    fun getAnimeConfig(context: Context): AnimeCfg {
        val prefs = getSafeSharedPreferences(context)
        return AnimeCfg(
            tR18 = prefs.getFloat(KEY_AI_ANIME_TR18, 0.90f),
            tR15 = prefs.getFloat(KEY_AI_ANIME_TR15, 0.88f),
            tSum = prefs.getFloat(KEY_AI_ANIME_TSUM, 0.95f),
            confirm = prefs.getInt(KEY_AI_ANIME_CONFIRM, 2),
            minLumaStd = prefs.getFloat(KEY_AI_ANIME_MIN_LUMA_STD, 5f),
            maxWindows = prefs.getInt(KEY_AI_ANIME_MAX_WINDOWS, 3)
        )
    }

    fun saveAnimeConfig(context: Context, cfg: AnimeCfg) {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putFloat(KEY_AI_ANIME_TR18, cfg.tR18)
            .putFloat(KEY_AI_ANIME_TR15, cfg.tR15)
            .putFloat(KEY_AI_ANIME_TSUM, cfg.tSum)
            .putInt(KEY_AI_ANIME_CONFIRM, cfg.confirm)
            .putFloat(KEY_AI_ANIME_MIN_LUMA_STD, cfg.minLumaStd)
            .putInt(KEY_AI_ANIME_MAX_WINDOWS, cfg.maxWindows)
            .apply()
        SaffahAnimeClassifier.updateConfig(cfg)
    }

    fun isAiDryRunEnabled(context: Context): Boolean {
        val prefs = getSafeSharedPreferences(context)
        return prefs.getBoolean(KEY_AI_DRY_RUN, false)
    }

    fun setAiDryRunEnabled(context: Context, enabled: Boolean) {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_AI_DRY_RUN, enabled).apply()
    }

    fun resetAnimeConfigToDefaults(context: Context) {
        saveAnimeConfig(context, AnimeCfg())
    }

    // --- NudeNet (Realistic) Classifier Config ---
    private const val KEY_AI_NUDE_T_FEMALE_GEN_EXP = "ai_nude_t_female_gen_exp"
    private const val KEY_AI_NUDE_T_MALE_GEN_EXP = "ai_nude_t_male_gen_exp"
    private const val KEY_AI_NUDE_T_ANUS_EXP = "ai_nude_t_anus_exp"
    private const val KEY_AI_NUDE_T_FEMALE_BREAST_EXP = "ai_nude_t_female_breast_exp"
    private const val KEY_AI_NUDE_T_BUTT_EXP = "ai_nude_t_butt_exp"
    private const val KEY_AI_NUDE_T_BUTT_ISOLATED = "ai_nude_t_butt_isolated"
    private const val KEY_AI_NUDE_STRONG = "ai_nude_strong"
    private const val KEY_AI_NUDE_STRONG_BUTT = "ai_nude_strong_butt"
    private const val KEY_AI_NUDE_SEXY_ENABLED = "ai_nude_sexy_enabled"
    private const val KEY_AI_NUDE_T_BREAST_COV = "ai_nude_t_breast_cov"
    private const val KEY_AI_NUDE_T_LOWER_COV = "ai_nude_t_lower_cov"
    private const val KEY_AI_NUDE_T_BELLY_EXP = "ai_nude_t_belly_exp"
    private const val KEY_AI_NUDE_CONFIRM = "ai_nude_confirm"
    private const val KEY_AI_NUDE_MIN_LUMA_STD = "ai_nude_min_luma_std"
    private const val KEY_AI_NUDE_MAX_WINDOWS = "ai_nude_max_windows"
    private const val KEY_AI_NUDE_TILE_FRAC = "ai_nude_tile_frac"
    private const val KEY_AI_NUDE_TILES_GALLERY = "ai_nude_tiles_gallery"
    private const val KEY_AI_NUDE_TILES_IDLE = "ai_nude_tiles_idle"
    private const val KEY_AI_NUDE_IDLE_SWEEP = "ai_nude_idle_sweep"
    private const val KEY_AI_NUDE_GALLERY_CUE = "ai_nude_gallery_cue"

    fun getNudeConfig(context: Context): NudeCfg {
        val prefs = getSafeSharedPreferences(context)
        return NudeCfg(
            tFemaleGenExp = prefs.getFloat(KEY_AI_NUDE_T_FEMALE_GEN_EXP, 0.45f),
            tMaleGenExp = prefs.getFloat(KEY_AI_NUDE_T_MALE_GEN_EXP, 0.45f),
            tAnusExp = prefs.getFloat(KEY_AI_NUDE_T_ANUS_EXP, 0.50f),
            tFemaleBreastExp = prefs.getFloat(KEY_AI_NUDE_T_FEMALE_BREAST_EXP, 0.50f),
            tButtExp = prefs.getFloat(KEY_AI_NUDE_T_BUTT_EXP, 0.60f),
            tButtIsolated = prefs.getFloat(KEY_AI_NUDE_T_BUTT_ISOLATED, 0.80f),
            strong = prefs.getFloat(KEY_AI_NUDE_STRONG, 0.75f),
            strongButt = prefs.getFloat(KEY_AI_NUDE_STRONG_BUTT, 0.85f),
            sexyEnabled = prefs.getBoolean(KEY_AI_NUDE_SEXY_ENABLED, true),
            tBreastCov = prefs.getFloat(KEY_AI_NUDE_T_BREAST_COV, 0.55f),
            tLowerCov = prefs.getFloat(KEY_AI_NUDE_T_LOWER_COV, 0.55f),
            tBellyExp = prefs.getFloat(KEY_AI_NUDE_T_BELLY_EXP, 0.45f),
            confirm = prefs.getInt(KEY_AI_NUDE_CONFIRM, 2),
            minLumaStd = prefs.getFloat(KEY_AI_NUDE_MIN_LUMA_STD, 5f),
            maxWindows = prefs.getInt(KEY_AI_NUDE_MAX_WINDOWS, 3),
            tileFrac = prefs.getFloat(KEY_AI_NUDE_TILE_FRAC, 0.60f),
            tilesPerTickGallery = prefs.getInt(KEY_AI_NUDE_TILES_GALLERY, 4),
            tilesPerTickIdle = prefs.getInt(KEY_AI_NUDE_TILES_IDLE, 2),
            idleSweepEvery = prefs.getInt(KEY_AI_NUDE_IDLE_SWEEP, 8),
            galleryCue = prefs.getInt(KEY_AI_NUDE_GALLERY_CUE, 6)
        )
    }

    fun saveNudeConfig(context: Context, cfg: NudeCfg) {
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putFloat(KEY_AI_NUDE_T_FEMALE_GEN_EXP, cfg.tFemaleGenExp)
            .putFloat(KEY_AI_NUDE_T_MALE_GEN_EXP, cfg.tMaleGenExp)
            .putFloat(KEY_AI_NUDE_T_ANUS_EXP, cfg.tAnusExp)
            .putFloat(KEY_AI_NUDE_T_FEMALE_BREAST_EXP, cfg.tFemaleBreastExp)
            .putFloat(KEY_AI_NUDE_T_BUTT_EXP, cfg.tButtExp)
            .putFloat(KEY_AI_NUDE_T_BUTT_ISOLATED, cfg.tButtIsolated)
            .putFloat(KEY_AI_NUDE_STRONG, cfg.strong)
            .putFloat(KEY_AI_NUDE_STRONG_BUTT, cfg.strongButt)
            .putBoolean(KEY_AI_NUDE_SEXY_ENABLED, cfg.sexyEnabled)
            .putFloat(KEY_AI_NUDE_T_BREAST_COV, cfg.tBreastCov)
            .putFloat(KEY_AI_NUDE_T_LOWER_COV, cfg.tLowerCov)
            .putFloat(KEY_AI_NUDE_T_BELLY_EXP, cfg.tBellyExp)
            .putInt(KEY_AI_NUDE_CONFIRM, cfg.confirm)
            .putFloat(KEY_AI_NUDE_MIN_LUMA_STD, cfg.minLumaStd)
            .putInt(KEY_AI_NUDE_MAX_WINDOWS, cfg.maxWindows)
            .putFloat(KEY_AI_NUDE_TILE_FRAC, cfg.tileFrac)
            .putInt(KEY_AI_NUDE_TILES_GALLERY, cfg.tilesPerTickGallery)
            .putInt(KEY_AI_NUDE_TILES_IDLE, cfg.tilesPerTickIdle)
            .putInt(KEY_AI_NUDE_IDLE_SWEEP, cfg.idleSweepEvery)
            .putInt(KEY_AI_NUDE_GALLERY_CUE, cfg.galleryCue)
            .apply()
        SaffahNudeNetClassifier.updateConfig(cfg)
    }

    fun resetNudeConfigToDefaults(context: Context) {
        saveNudeConfig(context, NudeCfg())
    }
}
