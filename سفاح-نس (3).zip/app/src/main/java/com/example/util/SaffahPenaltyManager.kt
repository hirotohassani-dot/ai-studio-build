package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

object SaffahPenaltyManager {

    private const val PREFS_NAME = "saffah_penalty_prefs"
    private const val KEY_PENALTY_ENABLED = "is_penalty_enabled"
    private const val KEY_PENALTY_DURATION_MINUTES = "penalty_duration_minutes"
    private const val KEY_PENALTY_ACTIVE = "is_penalty_active"
    private const val KEY_PENALTY_END_TIME = "penalty_end_time_ms"
    private const val KEY_PENALTY_START_TIME = "penalty_start_time_ms"
    private const val KEY_PENALTY_REASON = "penalty_reason"
    private const val KEY_PENALTY_DETECTED_ITEM = "penalty_detected_item"
    private const val KEY_PENALTY_DETECTED_TYPE = "penalty_detected_type"
    private const val KEY_PENALTY_SOURCE_PACKAGE = "penalty_source_package"
    private const val KEY_PENALTY_SOURCE_APP_NAME = "penalty_source_app_name"

    // Keys for daily occurrence tracking
    private const val KEY_PENALTY_DAILY_DATE = "penalty_daily_date"
    private const val KEY_PENALTY_DAILY_KEYWORD_COUNTS = "penalty_daily_keyword_counts_json"
    private const val KEY_PENALTY_DAILY_SITE_COUNTS = "penalty_daily_site_counts_json"

    @Volatile
    private var cachedPrefs: SharedPreferences? = null
    @Volatile
    private var cachedIsPenaltyActive: Boolean? = null

    // Daily occurrences state
    private val dailyCountLock = Any()
    @Volatile private var cachedDailyDate: String = ""
    private val keywordDailyCounts = HashMap<String, Int>()
    private val siteDailyCounts = HashMap<String, Int>()
    @Volatile private var areDailyCountsLoaded = false

    private fun getSafeSharedPreferences(context: Context): SharedPreferences {
        cachedPrefs?.let { return it }
        synchronized(this) {
            cachedPrefs?.let { return it }
            val safeContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                if (!context.isDeviceProtectedStorage) {
                    context.createDeviceProtectedStorageContext()
                } else {
                    context
                }
            } else {
                context
            }
            val prefs = safeContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            cachedPrefs = prefs
            return prefs
        }
    }

    fun isPenaltyFeatureEnabled(context: Context): Boolean {
        return getSafeSharedPreferences(context).getBoolean(KEY_PENALTY_ENABLED, false)
    }

    fun setPenaltyFeatureEnabled(context: Context, enabled: Boolean) {
        getSafeSharedPreferences(context).edit().putBoolean(KEY_PENALTY_ENABLED, enabled).apply()
    }

    fun getPenaltyDurationMinutes(context: Context): Int {
        val duration = getSafeSharedPreferences(context).getInt(KEY_PENALTY_DURATION_MINUTES, 5)
        return duration.coerceIn(1, 15)
    }

    fun setPenaltyDurationMinutes(context: Context, minutes: Int) {
        val clamped = minutes.coerceIn(1, 15)
        getSafeSharedPreferences(context).edit().putInt(KEY_PENALTY_DURATION_MINUTES, clamped).apply()
    }

    // --- DAILY OCCURRENCE TRACKING LOGIC ---

    fun getTodayDateString(): String {
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)
        return String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
    }

    fun normalizeKeyword(raw: String): String {
        val trimmed = raw.trim()
        val withoutStar = if (trimmed.startsWith("*") && trimmed.endsWith("*") && trimmed.length > 2) {
            trimmed.substring(1, trimmed.length - 1).trim()
        } else {
            trimmed
        }
        val lower = withoutStar.lowercase()
        return SaffahBlockRepository.normalizeArabicChars(lower)
    }

    fun normalizeHost(raw: String): String {
        var str = raw.trim().lowercase()
        if (str.startsWith("http://")) str = str.removePrefix("http://")
        if (str.startsWith("https://")) str = str.removePrefix("https://")
        if (str.startsWith("www.")) str = str.removePrefix("www.")
        val slashIdx = str.indexOf('/')
        if (slashIdx != -1) str = str.substring(0, slashIdx)
        val colonIdx = str.indexOf(':')
        if (colonIdx != -1) str = str.substring(0, colonIdx)
        val qIdx = str.indexOf('?')
        if (qIdx != -1) str = str.substring(0, qIdx)
        val hIdx = str.indexOf('#')
        if (hIdx != -1) str = str.substring(0, hIdx)
        return str.trim()
    }

    private fun ensureDailyCountsLoaded(context: Context) {
        val today = getTodayDateString()
        if (cachedDailyDate == today && areDailyCountsLoaded) return

        synchronized(dailyCountLock) {
            if (cachedDailyDate == today && areDailyCountsLoaded) return

            val prefs = getSafeSharedPreferences(context)
            val storedDate = prefs.getString(KEY_PENALTY_DAILY_DATE, "") ?: ""
            if (storedDate != today) {
                // New day! Clear previous day counts
                keywordDailyCounts.clear()
                siteDailyCounts.clear()
                cachedDailyDate = today
                areDailyCountsLoaded = true
                prefs.edit()
                    .putString(KEY_PENALTY_DAILY_DATE, today)
                    .remove(KEY_PENALTY_DAILY_KEYWORD_COUNTS)
                    .remove(KEY_PENALTY_DAILY_SITE_COUNTS)
                    .apply()
            } else {
                if (!areDailyCountsLoaded) {
                    keywordDailyCounts.clear()
                    siteDailyCounts.clear()
                    val kwJson = prefs.getString(KEY_PENALTY_DAILY_KEYWORD_COUNTS, null)
                    if (!kwJson.isNullOrBlank()) {
                        try {
                            val obj = JSONObject(kwJson)
                            val keys = obj.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                keywordDailyCounts[k] = obj.optInt(k, 0)
                            }
                        } catch (_: Exception) {}
                    }
                    val siteJson = prefs.getString(KEY_PENALTY_DAILY_SITE_COUNTS, null)
                    if (!siteJson.isNullOrBlank()) {
                        try {
                            val obj = JSONObject(siteJson)
                            val keys = obj.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                siteDailyCounts[k] = obj.optInt(k, 0)
                            }
                        } catch (_: Exception) {}
                    }
                    cachedDailyDate = today
                    areDailyCountsLoaded = true
                }
            }
        }
    }

    /**
     * Called on midnight / date changes to reset counts.
     */
    fun onDateChanged(context: Context) {
        synchronized(dailyCountLock) {
            val today = getTodayDateString()
            cachedDailyDate = today
            keywordDailyCounts.clear()
            siteDailyCounts.clear()
            areDailyCountsLoaded = true
            try {
                getSafeSharedPreferences(context).edit()
                    .putString(KEY_PENALTY_DAILY_DATE, today)
                    .remove(KEY_PENALTY_DAILY_KEYWORD_COUNTS)
                    .remove(KEY_PENALTY_DAILY_SITE_COUNTS)
                    .apply()
            } catch (_: Exception) {}
        }
    }

    /**
     * Records occurrence of a blocked keyword or site for today,
     * and evaluates whether the locked penalty screen rule should be applied.
     *
     * Rules:
     * - Blocked Keyword:
     *   - 1st & 2nd detection of the same keyword today -> Returns false (penalty screen not triggered, standard block occurs).
     *   - 3rd detection of the same keyword today -> Returns true (locked penalty screen triggered!).
     *
     * - Blocked Website / URL:
     *   - 1st detection of the same website today -> Returns false (penalty screen not triggered, standard block occurs).
     *   - 2nd detection of the same website today -> Returns true (locked penalty screen triggered immediately!).
     *
     * - Daily Reset: Automatically resets when a new day begins.
     */
    fun recordAndCheckShouldTriggerPenalty(
        context: Context,
        isWebsite: Boolean,
        rawBlockedItem: String
    ): Boolean {
        if (!isPenaltyFeatureEnabled(context)) return false
        if (rawBlockedItem.isBlank()) return false

        ensureDailyCountsLoaded(context)

        var count = 0
        var shouldTrigger = false
        val prefs = getSafeSharedPreferences(context)

        synchronized(dailyCountLock) {
            val today = getTodayDateString()
            if (cachedDailyDate != today) {
                keywordDailyCounts.clear()
                siteDailyCounts.clear()
                cachedDailyDate = today
            }

            if (isWebsite) {
                val normHost = normalizeHost(rawBlockedItem)
                count = (siteDailyCounts[normHost] ?: 0) + 1
                siteDailyCounts[normHost] = count
                shouldTrigger = (count >= 2)

                val siteObj = JSONObject()
                siteDailyCounts.forEach { (k, v) -> siteObj.put(k, v) }
                prefs.edit()
                    .putString(KEY_PENALTY_DAILY_DATE, today)
                    .putString(KEY_PENALTY_DAILY_SITE_COUNTS, siteObj.toString())
                    .apply()
            } else {
                val normKeyword = normalizeKeyword(rawBlockedItem)
                count = (keywordDailyCounts[normKeyword] ?: 0) + 1
                keywordDailyCounts[normKeyword] = count
                shouldTrigger = (count >= 3)

                val kwObj = JSONObject()
                keywordDailyCounts.forEach { (k, v) -> kwObj.put(k, v) }
                prefs.edit()
                    .putString(KEY_PENALTY_DAILY_DATE, today)
                    .putString(KEY_PENALTY_DAILY_KEYWORD_COUNTS, kwObj.toString())
                    .apply()
            }
        }

        Log.i("SaffahPenalty", "Evaluated penalty trigger: isWebsite=$isWebsite, item='$rawBlockedItem', countToday=$count, shouldTrigger=$shouldTrigger")
        return shouldTrigger
    }

    /**
     * Returns today's occurrence count for the given blocked keyword or website.
     */
    fun getItemDailyCount(context: Context, isWebsite: Boolean, rawBlockedItem: String): Int {
        if (rawBlockedItem.isBlank()) return 0
        ensureDailyCountsLoaded(context)
        synchronized(dailyCountLock) {
            val today = getTodayDateString()
            if (cachedDailyDate != today) return 0
            return if (isWebsite) {
                val normHost = normalizeHost(rawBlockedItem)
                siteDailyCounts[normHost] ?: 0
            } else {
                val normKeyword = normalizeKeyword(rawBlockedItem)
                keywordDailyCounts[normKeyword] ?: 0
            }
        }
    }

    fun startPenalty(
        context: Context,
        reason: String,
        blockedItem: String = "",
        blockType: String = "",
        sourcePackage: String = "",
        sourceAppName: String = ""
    ) {
        if (!isPenaltyFeatureEnabled(context)) return

        val durationMinutes = getPenaltyDurationMinutes(context)
        val durationMs = durationMinutes * 60 * 1000L
        val now = System.currentTimeMillis()
        val targetEndTime = now + durationMs

        val resolvedAppName = if (sourceAppName.isNotBlank()) {
            sourceAppName
        } else if (sourcePackage.isNotBlank()) {
            AppListHelper.getCachedAppName(sourcePackage) ?: sourcePackage
        } else {
            ""
        }

        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putBoolean(KEY_PENALTY_ACTIVE, true)
            .putLong(KEY_PENALTY_START_TIME, now)
            .putLong(KEY_PENALTY_END_TIME, targetEndTime)
            .putString(KEY_PENALTY_REASON, reason)
            .putString(KEY_PENALTY_DETECTED_ITEM, blockedItem)
            .putString(KEY_PENALTY_DETECTED_TYPE, blockType)
            .putString(KEY_PENALTY_SOURCE_PACKAGE, sourcePackage)
            .putString(KEY_PENALTY_SOURCE_APP_NAME, resolvedAppName)
            .apply()
        cachedIsPenaltyActive = true

        Log.i("SaffahPenalty", "Penalty started! Duration: ${durationMinutes}m, Reason: $reason, Item: $blockedItem, App: $sourcePackage")
        SaffahLockTaskManager.launchLockTaskApp(context, SaffahLockTaskManager.LockReason.PENALTY_ACTIVE)
    }

    fun isPenaltyActive(context: Context): Boolean {
        if (cachedIsPenaltyActive == false) return false

        val prefs = getSafeSharedPreferences(context)
        val isActive = prefs.getBoolean(KEY_PENALTY_ACTIVE, false)
        if (!isActive) {
            cachedIsPenaltyActive = false
            return false
        }

        val endTime = prefs.getLong(KEY_PENALTY_END_TIME, 0L)
        val remaining = endTime - System.currentTimeMillis()
        if (remaining <= 0) {
            cachedIsPenaltyActive = false
            clearPenalty(context)
            return false
        }
        cachedIsPenaltyActive = true
        return true
    }

    fun getRemainingPenaltyTimeMs(context: Context): Long {
        val prefs = getSafeSharedPreferences(context)
        if (!prefs.getBoolean(KEY_PENALTY_ACTIVE, false)) return 0L

        val endTime = prefs.getLong(KEY_PENALTY_END_TIME, 0L)
        val remaining = endTime - System.currentTimeMillis()
        if (remaining <= 0) {
            clearPenalty(context)
            return 0L
        }
        return remaining
    }

    fun getTotalPenaltyDurationMs(context: Context): Long {
        val prefs = getSafeSharedPreferences(context)
        val startTime = prefs.getLong(KEY_PENALTY_START_TIME, 0L)
        val endTime = prefs.getLong(KEY_PENALTY_END_TIME, 0L)
        val diff = endTime - startTime
        return if (diff > 0) diff else (getPenaltyDurationMinutes(context) * 60 * 1000L)
    }

    fun getPenaltyStartTime(context: Context): Long {
        return getSafeSharedPreferences(context).getLong(KEY_PENALTY_START_TIME, System.currentTimeMillis())
    }

    fun getPenaltyReason(context: Context): String {
        return getSafeSharedPreferences(context).getString(KEY_PENALTY_REASON, "رصد كلمة أو موقع محظور") ?: "رصد كلمة أو موقع محظور"
    }

    fun getPenaltyDetectedItem(context: Context): String {
        return getSafeSharedPreferences(context).getString(KEY_PENALTY_DETECTED_ITEM, "") ?: ""
    }

    fun getPenaltyDetectedType(context: Context): String {
        return getSafeSharedPreferences(context).getString(KEY_PENALTY_DETECTED_TYPE, "") ?: ""
    }

    fun getPenaltySourcePackage(context: Context): String {
        return getSafeSharedPreferences(context).getString(KEY_PENALTY_SOURCE_PACKAGE, "") ?: ""
    }

    fun getPenaltySourceAppName(context: Context): String {
        return getSafeSharedPreferences(context).getString(KEY_PENALTY_SOURCE_APP_NAME, "") ?: ""
    }

    fun clearPenalty(context: Context) {
        cachedIsPenaltyActive = false
        val prefs = getSafeSharedPreferences(context)
        prefs.edit()
            .putBoolean(KEY_PENALTY_ACTIVE, false)
            .putLong(KEY_PENALTY_START_TIME, 0L)
            .putLong(KEY_PENALTY_END_TIME, 0L)
            .putString(KEY_PENALTY_REASON, "")
            .putString(KEY_PENALTY_DETECTED_ITEM, "")
            .putString(KEY_PENALTY_DETECTED_TYPE, "")
            .putString(KEY_PENALTY_SOURCE_PACKAGE, "")
            .putString(KEY_PENALTY_SOURCE_APP_NAME, "")
            .apply()
        Log.i("SaffahPenalty", "Penalty cleared.")
    }
}
