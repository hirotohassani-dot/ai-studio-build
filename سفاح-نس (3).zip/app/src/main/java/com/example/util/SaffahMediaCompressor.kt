package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.util.Log
import com.example.model.DiaryMediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * محرك ضغط وتأمين الوسائط فائق السرعة والخفة لتطبيق السفاح
 * - يضمن عدم تأثر التطبيق بحجم أو عدد الوسائط (صور، فيديو، صوت) وعدم حدوث أي بطء أو لاڨ نهائياً
 * - يعتمد توليد الصور المصغرة فائقة الخفة (Micro-Thumbnails) لمعاينة القوائم دون استهلاك الذاكرة
 * - يفرض العزل الأمني التام والمحكم (.nomedia وحظر الصلاحيات العامة) لمنع تسرب أي وسائط لهاتف المستخدم أو الاستوديو
 */
object SaffahMediaCompressor {

    private const val TAG = "SaffahMediaCompressor"
    private const val MAX_IMAGE_DIMENSION = 1280 // الحد الأقصى للهواتف الذكية مع جودة فائقة وصغر حجم استثنائي
    private const val THUMB_MAX_DIMENSION = 240 // أبعاد الصورة المصغرة للقوائم (حجم ~12-20 كيلوبايت فقط)
    private const val IMAGE_QUALITY = 78 // جودة ضغط متوازنة لصور شديدة النقاء وبحجم صغير
    private const val THUMB_QUALITY = 65

    /**
     * تهيئة الحماية والأمان لكافة مجلدات الوسائط داخل التطبيق
     * يمنع MediaScanner ومستكشف الملفات واستوديو النظام من الوصول للوسائط نهائياً
     */
    fun initSecurity(context: Context) {
        try {
            val secureDirs = listOf(
                File(context.filesDir, "recovery_diaries"),
                File(context.filesDir, "recovery_diaries/media"),
                File(context.filesDir, "recovery_diaries/thumbnails"),
                File(context.filesDir, "milestone_media"),
                File(context.filesDir, "milestone_media/thumbnails"),
                File(context.cacheDir, "saffah_coil_cache")
            )

            for (dir in secureDirs) {
                if (!dir.exists()) {
                    dir.mkdirs()
                }
                // فرض تصاريح وصول خاصة بتطبيق السفاح فقط
                dir.setReadable(true, true)
                dir.setWritable(true, true)
                dir.setExecutable(true, true)

                // ملف .nomedia يمنع ماسح الوسائط واستوديو الصور ومشغلات الموسيقى من التعرف على الملفات
                val noMediaFile = File(dir, ".nomedia")
                if (!noMediaFile.exists()) {
                    noMediaFile.createNewFile()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring media security: ${e.message}")
        }
    }

    /**
     * الحصول على مجلد الصور المصغرة مع ضمان وجود ملف .nomedia بداخله
     */
    fun getThumbnailsDirectory(parentDir: File): File {
        val thumbDir = File(parentDir, "thumbnails")
        if (!thumbDir.exists()) {
            thumbDir.mkdirs()
        }
        val noMedia = File(thumbDir, ".nomedia")
        if (!noMedia.exists()) {
            try { noMedia.createNewFile() } catch (_: Exception) {}
        }
        return thumbDir
    }

    /**
     * جلب ملف الصورة المصغرة الفائقة الخفة لأي ملف وسائط (صورة أو فيديو)
     * لتسريع العرض بنسبة 100% ومنع أي لاڨ في القوائم
     */
    fun getThumbnailFile(context: Context, originalFilePath: String): File {
        val origFile = File(originalFilePath)
        if (!origFile.exists()) return origFile

        val thumbDir = getThumbnailsDirectory(origFile.parentFile ?: context.filesDir)
        val thumbFile = File(thumbDir, "${origFile.nameWithoutExtension}_thumb.jpg")

        if (thumbFile.exists() && thumbFile.length() > 0) {
            return thumbFile
        }

        // إذا لم تكن موجودة بعد، نحاول استخراجها فوراً إذا أمكن
        try {
            val lowerName = origFile.name.lowercase()
            if (lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") || lowerName.endsWith(".png") || lowerName.endsWith(".webp")) {
                createImageThumbnail(origFile, thumbFile)
                if (thumbFile.exists()) return thumbFile
            } else if (lowerName.endsWith(".mp4") || lowerName.endsWith(".mkv") || lowerName.endsWith(".3gp") || lowerName.endsWith(".mov")) {
                createVideoThumbnail(origFile, thumbFile)
                if (thumbFile.exists()) return thumbFile
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to create on-demand thumbnail: ${e.message}")
        }

        return origFile
    }

    /**
     * إنشاء صورة مصغرة لصورة أصلية
     */
    private fun createImageThumbnail(origFile: File, thumbFile: File) {
        try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(origFile.absolutePath, boundsOpts)
            val w = boundsOpts.outWidth
            val h = boundsOpts.outHeight
            if (w <= 0 || h <= 0) return

            var sampleSize = 1
            while (w / sampleSize > THUMB_MAX_DIMENSION * 2 || h / sampleSize > THUMB_MAX_DIMENSION * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565 // خفيف جداً على الذاكرة
            }
            val bmp = BitmapFactory.decodeFile(origFile.absolutePath, decodeOpts) ?: return

            val maxDim = maxOf(bmp.width, bmp.height)
            val finalBmp = if (maxDim > THUMB_MAX_DIMENSION) {
                val scale = THUMB_MAX_DIMENSION.toFloat() / maxDim.toFloat()
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true).also {
                    if (it != bmp) bmp.recycle()
                }
            } else {
                bmp
            }

            FileOutputStream(thumbFile).use { out ->
                finalBmp.compress(Bitmap.CompressFormat.JPEG, THUMB_QUALITY, out)
                out.flush()
            }
            finalBmp.recycle()
            thumbFile.setReadable(true, true)
        } catch (t: Throwable) {
            Log.w(TAG, "Error generating image thumbnail: ${t.message}")
        }
    }

    /**
     * استخراج صورة مصغرة لفيديو
     */
    private fun createVideoThumbnail(videoFile: File, thumbFile: File) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(videoFile.absolutePath)
            // استخراج إطار عند ثانية واحدة أو البداية
            val rawBmp = retriever.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime ?: return

            val maxDim = maxOf(rawBmp.width, rawBmp.height)
            val finalBmp = if (maxDim > THUMB_MAX_DIMENSION) {
                val scale = THUMB_MAX_DIMENSION.toFloat() / maxDim.toFloat()
                Bitmap.createScaledBitmap(rawBmp, (rawBmp.width * scale).toInt(), (rawBmp.height * scale).toInt(), true).also {
                    if (it != rawBmp) rawBmp.recycle()
                }
            } else {
                rawBmp
            }

            FileOutputStream(thumbFile).use { out ->
                finalBmp.compress(Bitmap.CompressFormat.JPEG, THUMB_QUALITY, out)
                out.flush()
            }
            finalBmp.recycle()
            thumbFile.setReadable(true, true)
        } catch (t: Throwable) {
            Log.w(TAG, "Error generating video thumbnail: ${t.message}")
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    /**
     * حذف ملف وسائط مع صورته المصغرة بشكل نهائي وآمن
     */
    fun deleteMediaAndThumbnail(filePath: String) {
        try {
            val origFile = File(filePath)
            if (origFile.exists()) {
                origFile.delete()
            }
            val thumbDir = File(origFile.parentFile, "thumbnails")
            val thumbFile = File(thumbDir, "${origFile.nameWithoutExtension}_thumb.jpg")
            if (thumbFile.exists()) {
                thumbFile.delete()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error in deleteMediaAndThumbnail: ${e.message}")
        }
    }

    /**
     * ضغط ملف صورة مع الحفاظ على وضوحها وتقليص حجمها وتوليد صورة مصغرة
     */
    suspend fun compressImageFile(inputFile: File, targetFile: File? = null): File = withContext(Dispatchers.IO) {
        val dest = targetFile ?: File(inputFile.parentFile, "opt_${inputFile.name}")
        try {
            if (!inputFile.exists() || inputFile.length() == 0L) {
                return@withContext inputFile
            }

            // قراءة الأبعاد الأولية بدون تحميل في الذاكرة
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(inputFile.absolutePath, bounds)
            val origW = bounds.outWidth
            val origH = bounds.outHeight

            if (origW <= 0 || origH <= 0) {
                return@withContext inputFile
            }

            var sampleSize = 1
            while (origW / sampleSize > MAX_IMAGE_DIMENSION * 1.5 || origH / sampleSize > MAX_IMAGE_DIMENSION * 1.5) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565 // يوفر نصف استهلاك الرام تماماً
            }

            var bitmap = BitmapFactory.decodeFile(inputFile.absolutePath, decodeOpts) ?: return@withContext inputFile

            // قراءة وتعديل الاتجاه عبر EXIF
            try {
                val exif = ExifInterface(inputFile.absolutePath)
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                val matrix = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                }
                if (!matrix.isIdentity) {
                    val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                    if (rotated != bitmap) {
                        bitmap.recycle()
                        bitmap = rotated
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Exif orientation failed: ${e.message}")
            }

            // تقليص الحجم إذا كان أكبر من الحد الأقصى
            val curMax = maxOf(bitmap.width, bitmap.height)
            if (curMax > MAX_IMAGE_DIMENSION) {
                val scale = MAX_IMAGE_DIMENSION.toFloat() / curMax.toFloat()
                val targetW = (bitmap.width * scale).toInt()
                val targetH = (bitmap.height * scale).toInt()
                val scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
                if (scaled != bitmap) {
                    bitmap.recycle()
                    bitmap = scaled
                }
            }

            // حفظ الملف المضغوط
            FileOutputStream(dest).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, IMAGE_QUALITY, out)
                out.flush()
            }
            bitmap.recycle()

            val finalFile = if (targetFile == null) {
                if (dest.exists() && dest.length() > 0) {
                    inputFile.delete()
                    dest.renameTo(inputFile)
                    inputFile
                } else {
                    dest.delete()
                    inputFile
                }
            } else {
                dest
            }

            // تأمين حماية الملف
            finalFile.setReadable(true, true)
            finalFile.setWritable(true, true)

            // إنشاء صورة مصغرة فائقة الخفة للقوائم
            val thumbDir = getThumbnailsDirectory(finalFile.parentFile)
            val thumbFile = File(thumbDir, "${finalFile.nameWithoutExtension}_thumb.jpg")
            createImageThumbnail(finalFile, thumbFile)

            return@withContext finalFile
        } catch (t: Throwable) {
            Log.e(TAG, "Image compression failed: ${t.message}", t)
            return@withContext inputFile
        }
    }

    /**
     * استيراد وضغط صورة مباشرة من Uri إلى مجلد التطبيق الداخلي الآمن
     */
    suspend fun compressImageFromUri(context: Context, uri: Uri, destFile: File): Boolean = withContext(Dispatchers.IO) {
        try {
            // أولاً: قراءة الأبعاد بدون تخصيص ذاكرة
            var inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext false
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, bounds)
            inputStream.close()

            val origW = bounds.outWidth
            val origH = bounds.outHeight
            if (origW <= 0 || origH <= 0) return@withContext false

            var sampleSize = 1
            while (origW / sampleSize > MAX_IMAGE_DIMENSION * 1.5 || origH / sampleSize > MAX_IMAGE_DIMENSION * 1.5) {
                sampleSize *= 2
            }

            inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext false
            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565 // استهلاك ذاكرة منخفض جداً
            }
            val initialBitmap = BitmapFactory.decodeStream(inputStream, null, decodeOpts)
            inputStream.close()

            if (initialBitmap == null) return@withContext false
            var currentBitmap: Bitmap = initialBitmap

            // التحقق من اتجاه EXIF وتصحيحه
            try {
                var orientation = ExifInterface.ORIENTATION_NORMAL
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val exif = ExifInterface(stream)
                    orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }

                val matrix = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                }
                if (!matrix.isIdentity) {
                    val rotated = Bitmap.createBitmap(currentBitmap, 0, 0, currentBitmap.width, currentBitmap.height, matrix, true)
                    if (rotated != currentBitmap) {
                        currentBitmap.recycle()
                        currentBitmap = rotated
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Exif stream check failed: ${e.message}")
            }

            val curMax = maxOf(currentBitmap.width, currentBitmap.height)
            if (curMax > MAX_IMAGE_DIMENSION) {
                val scale = MAX_IMAGE_DIMENSION.toFloat() / curMax.toFloat()
                val targetW = (currentBitmap.width * scale).toInt()
                val targetH = (currentBitmap.height * scale).toInt()
                val scaled = Bitmap.createScaledBitmap(currentBitmap, targetW, targetH, true)
                if (scaled != currentBitmap) {
                    currentBitmap.recycle()
                    currentBitmap = scaled
                }
            }

            FileOutputStream(destFile).use { out ->
                currentBitmap.compress(Bitmap.CompressFormat.JPEG, IMAGE_QUALITY, out)
                out.flush()
            }
            currentBitmap.recycle()

            destFile.setReadable(true, true)
            destFile.setWritable(true, true)

            // إنشاء صورة مصغرة للملف
            val thumbDir = getThumbnailsDirectory(destFile.parentFile)
            val thumbFile = File(thumbDir, "${destFile.nameWithoutExtension}_thumb.jpg")
            createImageThumbnail(destFile, thumbFile)

            return@withContext true
        } catch (t: Throwable) {
            Log.e(TAG, "compressImageFromUri failed: ${t.message}", t)
            return@withContext false
        }
    }

    /**
     * معالجة وتأمين ملف الفيديو وتوليد صورة مصغرة له بدون أي استهلاك لذاكرة الواجهة
     */
    suspend fun compressVideoFile(inputFile: File, targetFile: File? = null): File = withContext(Dispatchers.IO) {
        val dest = targetFile ?: File(inputFile.parentFile, "opt_${inputFile.name}")
        try {
            if (!inputFile.exists() || inputFile.length() == 0L) {
                return@withContext inputFile
            }

            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(inputFile.absolutePath)
            } catch (e: Exception) {
                return@withContext inputFile
            }

            val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val rotationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            retriever.release()

            val origWidth = widthStr?.toIntOrNull() ?: 1280
            val origHeight = heightStr?.toIntOrNull() ?: 720
            val rotation = rotationStr?.toIntOrNull() ?: 0

            // استخراج وتوليد صورة مصغرة للفيديو فوراً لسرعة العرض في البطاقات
            val thumbDir = getThumbnailsDirectory(inputFile.parentFile)
            val thumbFile = File(thumbDir, "${inputFile.nameWithoutExtension}_thumb.jpg")
            createVideoThumbnail(inputFile, thumbFile)

            // معالجة ونقل الفيديو
            val success = transcodeVideo(
                inputPath = inputFile.absolutePath,
                outputPath = dest.absolutePath,
                origWidth = origWidth,
                origHeight = origHeight,
                rotation = rotation
            )

            val finalFile = if (success && dest.exists() && dest.length() > 0) {
                if (targetFile == null) {
                    inputFile.delete()
                    dest.renameTo(inputFile)
                    inputFile
                } else {
                    dest
                }
            } else {
                if (dest.exists() && dest != inputFile) {
                    dest.delete()
                }
                inputFile
            }

            finalFile.setReadable(true, true)
            finalFile.setWritable(true, true)
            return@withContext finalFile
        } catch (t: Throwable) {
            Log.e(TAG, "Video compression error: ${t.message}", t)
            return@withContext inputFile
        }
    }

    /**
     * إعادة تعبئة وتنسيق الفيديو بأمان لضمان سرعة القراءة وثبات معدل البث
     */
    private fun transcodeVideo(
        inputPath: String,
        outputPath: String,
        origWidth: Int,
        origHeight: Int,
        rotation: Int
    ): Boolean {
        var extractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null

        try {
            extractor = MediaExtractor().apply { setDataSource(inputPath) }
            val trackCount = extractor.trackCount

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var inputVideoFormat: MediaFormat? = null

            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") && videoTrackIndex < 0) {
                    videoTrackIndex = i
                    inputVideoFormat = format
                } else if (mime.startsWith("audio/") && audioTrackIndex < 0) {
                    audioTrackIndex = i
                }
            }

            if (videoTrackIndex < 0 || inputVideoFormat == null) {
                return false
            }

            muxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            if (rotation != 0) {
                muxer.setOrientationHint(rotation)
            }

            val muxerAudioTrack = if (audioTrackIndex >= 0) {
                val audioFormat = extractor.getTrackFormat(audioTrackIndex)
                muxer.addTrack(audioFormat)
            } else -1

            val muxerVideoTrack = muxer.addTrack(inputVideoFormat)
            muxer.start()

            val maxBufferSize = 1024 * 1024
            val buffer = ByteBuffer.allocate(maxBufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            extractor.selectTrack(videoTrackIndex)
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags

                muxer.writeSampleData(muxerVideoTrack, buffer, bufferInfo)
                extractor.advance()
            }
            extractor.unselectTrack(videoTrackIndex)

            if (audioTrackIndex >= 0 && muxerAudioTrack >= 0) {
                extractor.selectTrack(audioTrackIndex)
                while (true) {
                    val sampleSize = extractor.readSampleData(buffer, 0)
                    if (sampleSize < 0) break

                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    bufferInfo.flags = extractor.sampleFlags

                    muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                    extractor.advance()
                }
                extractor.unselectTrack(audioTrackIndex)
            }

            try {
                muxer.stop()
            } catch (e: Exception) {
                Log.w(TAG, "Muxer stop warning: ${e.message}")
            }
            try {
                muxer.release()
            } catch (e: Exception) {}
            muxer = null

            try {
                extractor.release()
            } catch (e: Exception) {}
            extractor = null

            return true
        } catch (t: Throwable) {
            Log.e(TAG, "Video transcode failed: ${t.message}", t)
            try { muxer?.release() } catch (_: Throwable) {}
            try { extractor?.release() } catch (_: Throwable) {}
            return false
        }
    }
}

