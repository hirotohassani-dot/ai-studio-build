package com.example.util

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.ActivityManager
import android.app.ActivityOptions
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityManager
import com.example.receiver.SaffahDeviceAdminReceiver
import com.example.service.SaffahAccessibilityService
import com.example.service.SaffahVpnService
import java.net.NetworkInterface

object SaffahLockTaskManager {

    private const val TAG = "SaffahLockTask"
    private const val PREFS_NAME = "saffah_lock_task_prefs"
    private const val KEY_WAS_ACCESSIBILITY_EVER_ENABLED = "was_accessibility_ever_enabled"
    private const val KEY_WAS_NOTIFICATION_ACCESS_EVER_ENABLED = "was_notification_access_ever_enabled"
    private const val KEY_IS_VPN_INTENDED_ACTIVE = "is_vpn_intended_active"
    private const val KEY_IS_LOCK_TASK_ACTIVE = "is_lock_task_active"
    private const val KEY_LOCK_TASK_REASON = "lock_task_reason"

    enum class LockReason {
        NONE,
        ACCESSIBILITY_DISABLED,
        VPN_DISABLED,
        NOTIFICATION_ACCESS_DISABLED,
        PENALTY_ACTIVE,
        URGE_SESSION_ACTIVE
    }

    @Volatile
    private var cachedWasAccessibilityEverEnabled: Boolean? = null
    @Volatile
    private var cachedWasNotificationAccessEverEnabled: Boolean? = null
    @Volatile
    private var cachedIsVpnIntendedActive: Boolean? = null
    @Volatile
    private var cachedIsLockTaskActive: Boolean? = null
    @Volatile
    private var cachedLockTaskReason: LockReason? = null

    // VPN activation timestamp to avoid triggering during the few milliseconds VPN takes to bind
    @Volatile
    private var vpnActivationTimestamp: Long = 0L

    @Volatile
    private var isVpnActiveOverrideForTesting: Boolean? = null
    @Volatile
    private var isColdBootBypassedForTesting: Boolean = false

    fun setVpnActiveOverrideForTesting(active: Boolean?) {
        isVpnActiveOverrideForTesting = active
    }

    fun resetVpnGracePeriodForTesting() {
        vpnActivationTimestamp = 0L
        isColdBootBypassedForTesting = true
    }

    fun isAccessibilityEnabled(context: Context): Boolean {
        // 1. In-memory bound check (instant & 100% accurate if service is running)
        if (SaffahAccessibilityService.isServiceBound) {
            return true
        }

        // 2. If revival cycle is in progress, treat as enabled to prevent false LockTask trips
        if (SaffahProtectionManager.isRevivingAccessibilityInProgress()) {
            return true
        }

        // 3. Check if configured in Settings.Secure (Configured means enabled by OS, even if temporarily uncoupled by OEM Secure Keyboard)
        val isConfiguredInSettings = try {
            val cr = context.contentResolver
            val isGlobalEnabled = Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
            if (!isGlobalEnabled) {
                false
            } else {
                val prefString = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                if (prefString.isNotBlank()) {
                    val pkgName = context.packageName
                    prefString.contains(pkgName, ignoreCase = true) ||
                            prefString.contains("com.example", ignoreCase = true) ||
                            prefString.contains("SaffahAccessibilityService", ignoreCase = true)
                } else {
                    false
                }
            }
        } catch (_: Exception) {
            false
        }

        // If configured in Settings.Secure but NOT bound, it's trapped in the "Not working. Tap for info" dead state!
        // Immediately kick off auto-revival and allow self-healing without disrupting the user
        if (isConfiguredInSettings && !SaffahAccessibilityService.isServiceBound) {
            SaffahProtectionManager.ensureAccessibilityServiceEnabled(context)
            return true
        }

        if (isConfiguredInSettings) {
            return true
        }

        // 3. Official Android AccessibilityManager check as secondary confirmation
        val isReportedByManager = try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
            val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            if (!enabledServices.isNullOrEmpty()) {
                val pkgName = context.packageName
                enabledServices.any { service ->
                    val id = service.id
                    id.contains(pkgName, ignoreCase = true) ||
                            id.contains("com.example", ignoreCase = true) ||
                            id.contains("SaffahAccessibilityService", ignoreCase = true) ||
                            service.resolveInfo?.serviceInfo?.packageName == pkgName
                }
            } else false
        } catch (_: Exception) {
            false
        }

        return isReportedByManager
    }

    fun isVpnActiveOrConnected(context: Context): Boolean {
        isVpnActiveOverrideForTesting?.let { return it }

        if (SaffahVpnService.isVpnActive.value) {
            return true
        }

        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            if (cm != null) {
                val activeNet = cm.activeNetwork
                val caps = cm.getNetworkCapabilities(activeNet)
                if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                    return true
                }
                val hasAnyVpn = cm.allNetworks.any { net ->
                    cm.getNetworkCapabilities(net)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
                }
                if (hasAnyVpn) return true
            }
        } catch (e: Exception) {
            Log.w(TAG, "ConnectivityManager VPN check error: ${e.message}")
        }

        // Only query low-level network interfaces if VPN was intended to be active as a last-resort fallback
        if (isVpnIntendedActive(context)) {
            try {
                val interfaces = NetworkInterface.getNetworkInterfaces()
                while (interfaces.hasMoreElements()) {
                    val iface = interfaces.nextElement()
                    val name = iface.name.lowercase()
                    if (iface.isUp && (name.contains("tun") || name.contains("ppp") || name.contains("pdp_ip"))) {
                        return true
                    }
                }
            } catch (e: Exception) {
                // Ignore interface query errors
            }
        }

        return false
    }

    fun wasAccessibilityEverEnabled(context: Context): Boolean {
        cachedWasAccessibilityEverEnabled?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_WAS_ACCESSIBILITY_EVER_ENABLED, false)
        cachedWasAccessibilityEverEnabled = res
        return res
    }

    fun wasNotificationAccessEverEnabled(context: Context): Boolean {
        cachedWasNotificationAccessEverEnabled?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_WAS_NOTIFICATION_ACCESS_EVER_ENABLED, false)
        cachedWasNotificationAccessEverEnabled = res
        return res
    }

    fun setNotificationAccessEverEnabled(context: Context, enabled: Boolean) {
        cachedWasNotificationAccessEverEnabled = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_WAS_NOTIFICATION_ACCESS_EVER_ENABLED, enabled).apply()
    }

    /**
     * Tracks whether VPN was intentionally activated from INSIDE the Saffah app.
     */
    fun isVpnIntendedActive(context: Context): Boolean {
        cachedIsVpnIntendedActive?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_IS_VPN_INTENDED_ACTIVE, false)
        cachedIsVpnIntendedActive = res
        return res
    }

    fun wasVpnEverActive(context: Context): Boolean {
        return isVpnIntendedActive(context)
    }

    /**
     * Called when the user toggles VPN from INSIDE the Saffah app.
     */
    fun setVpnEnabledByUser(context: Context, enabled: Boolean) {
        cachedIsVpnIntendedActive = enabled
        val prefs = getSafeSharedPreferences(context)
        prefs.edit().putBoolean(KEY_IS_VPN_INTENDED_ACTIVE, enabled).apply()

        if (enabled) {
            vpnActivationTimestamp = System.currentTimeMillis()
        } else {
            // User explicitly stopped VPN inside the app: clear all VPN lock states immediately
            vpnActivationTimestamp = 0L
            if (getLockReason(context) == LockReason.VPN_DISABLED) {
                setLockTaskActive(context, false, LockReason.NONE)
            }
        }
    }

    @Volatile
    private var cachedPrefs: SharedPreferences? = null

    private fun getSafeSharedPreferences(context: Context): SharedPreferences {
        cachedPrefs?.let { return it }
        synchronized(this) {
            cachedPrefs?.let { return it }
            val safeContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                if (!context.isDeviceProtectedStorage) {
                    context.createDeviceProtectedStorageContext()
                } else {
                    context
                }
            } else {
                context
            }
            val prefs = safeContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            cachedPrefs = prefs
            return prefs
        }
    }

    /**
     * Checks permission status and VPN state accurately:
     * - Triggers LockTask immediately if Accessibility or Overlay permissions are revoked.
     * - Triggers LockTask immediately if VPN was intentionally ON but was disconnected/revoked from OUTSIDE the app.
     * - Does NOT trigger LockTask if VPN was stopped from INSIDE the app.
     * - Absolutely zero delay (no 15s hysteresis) upon 100% confirmed real revocation.
     */
    fun updateStateAndCheck(context: Context): LockReason {
        // 1. First priority: Check if strict penalty or 15-minute urge rule is active
        val isPenaltyNow = SaffahPenaltyManager.isPenaltyActive(context)
        if (isPenaltyNow) {
            setLockTaskActive(context, true, LockReason.PENALTY_ACTIVE)
            return LockReason.PENALTY_ACTIVE
        }

        val isUrgeNow = SaffahUrgeManager.isUrgeSessionActive(context)
        if (isUrgeNow) {
            setLockTaskActive(context, true, LockReason.URGE_SESSION_ACTIVE)
            return LockReason.URGE_SESSION_ACTIVE
        }

        // Cold boot protection: Allow the first 8 seconds after device boot for services to bind
        if (!isColdBootBypassedForTesting && SystemClock.elapsedRealtime() < 8000L && !SaffahAccessibilityService.isServiceBound) {
            return LockReason.NONE
        }

        val isAccessNow = isAccessibilityEnabled(context)
        val isVpnIntended = isVpnIntendedActive(context)
        val isVpnNow = if (isVpnIntended) isVpnActiveOrConnected(context) else false

        var wasAccessEver = wasAccessibilityEverEnabled(context)

        // Record historical grant state as soon as permission is confirmed active
        if (isAccessNow && !wasAccessEver) {
            cachedWasAccessibilityEverEnabled = true
            getSafeSharedPreferences(context).edit().putBoolean(KEY_WAS_ACCESSIBILITY_EVER_ENABLED, true).apply()
            wasAccessEver = true
        }

        // Silent background restoration if anything is missing
        if (wasAccessEver && !isAccessNow) {
            SaffahProtectionManager.ensureAccessibilityServiceEnabled(context)
        }

        // VPN grace period check (only 2.5 seconds during the initial socket connection handshake)
        val now = System.currentTimeMillis()
        val isVpnInGracePeriod = (now - vpnActivationTimestamp < 2500L)
        val isVpnRevokedExternally = isVpnIntended && !isVpnNow && !isVpnInGracePeriod

        var isNotifAccessNow = com.example.service.SaffahNotificationListenerService.isNotificationAccessGranted(context)
        var wasNotifAccessEver = wasNotificationAccessEverEnabled(context)

        // Automatically record if Notification Access was active
        if (isNotifAccessNow && !wasNotifAccessEver) {
            setNotificationAccessEverEnabled(context, true)
            wasNotifAccessEver = true
        }

        // Silent background restoration via Device Owner / Secure Settings
        if (wasNotifAccessEver && !isNotifAccessNow) {
            SaffahProtectionManager.ensureNotificationListenerAccess(context)
            isNotifAccessNow = com.example.service.SaffahNotificationListenerService.isNotificationAccessGranted(context)
        }

        val isNotifAccessRevoked = wasNotifAccessEver && !isNotifAccessNow

        // Determine if any previously granted critical permission or active VPN was actually revoked with 100% certainty
        val confirmedReason = when {
            wasAccessEver && !isAccessNow -> {
                if (SaffahProtectionManager.isRevivingAccessibilityInProgress()) {
                    LockReason.NONE
                } else {
                    LockReason.ACCESSIBILITY_DISABLED
                }
            }
            isVpnRevokedExternally -> LockReason.VPN_DISABLED
            else -> LockReason.NONE
        }

        if (confirmedReason != LockReason.NONE) {
            Log.w(TAG, "IMMEDIATE CONFIRMED VIOLATION: $confirmedReason. Activating LockTask state immediately.")
            setLockTaskActive(context, true, confirmedReason)
            return confirmedReason
        } else {
            if (isLockTaskActive(context)) {
                setLockTaskActive(context, false, LockReason.NONE)
            }
            return LockReason.NONE
        }
    }

    fun setLockTaskActive(context: Context, active: Boolean, reason: LockReason) {
        cachedIsLockTaskActive = active
        cachedLockTaskReason = reason
        val prefs = getSafeSharedPreferences(context)
        val editor = prefs.edit()
        editor.putBoolean(KEY_IS_LOCK_TASK_ACTIVE, active)
        if (active) {
            editor.putString(KEY_LOCK_TASK_REASON, reason.name)
        } else {
            editor.putString(KEY_LOCK_TASK_REASON, LockReason.NONE.name)
        }
        editor.apply()
    }

    fun isLockTaskActive(context: Context): Boolean {
        cachedIsLockTaskActive?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val res = prefs.getBoolean(KEY_IS_LOCK_TASK_ACTIVE, false)
        cachedIsLockTaskActive = res
        return res
    }

    fun getLockReason(context: Context): LockReason {
        cachedLockTaskReason?.let { return it }
        val prefs = getSafeSharedPreferences(context)
        val reasonStr = prefs.getString(KEY_LOCK_TASK_REASON, LockReason.NONE.name) ?: LockReason.NONE.name
        val res = try {
            LockReason.valueOf(reasonStr)
        } catch (e: Exception) {
            LockReason.NONE
        }
        cachedLockTaskReason = res
        return res
    }

    fun isCurrentlyInLockTaskMode(context: Context): Boolean {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
        } catch (e: Exception) {
            false
        }
    }

    @Volatile
    private var lastOpenedReason: LockReason = LockReason.NONE
    @Volatile
    private var lastOpenedTimestamp: Long = 0L

    fun launchLockTaskApp(context: Context, reason: LockReason) {
        if (reason == LockReason.NONE) {
            // Never launch activity when no actual violation or lock exists
            return
        }

        val now = System.currentTimeMillis()
        val isSystemLocked = isCurrentlyInLockTaskMode(context)
        val isPenaltyOrUrge = (reason == LockReason.PENALTY_ACTIVE || reason == LockReason.URGE_SESSION_ACTIVE)

        // Prevent continuous startActivity hammering while still launching immediately
        if (!isPenaltyOrUrge) {
            if (isSystemLocked && now - lastOpenedTimestamp < 2000L) {
                return
            }
            if (!isSystemLocked && now - lastOpenedTimestamp < 300L) {
                return
            }
        }

        lastOpenedReason = reason
        lastOpenedTimestamp = now

        setLockTaskActive(context, true, reason)
        configureDeviceOwnerLockTaskPackages(context, isPenaltyOrUrge)

        val intent = Intent(context, com.example.MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or 
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or 
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or 
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra("EXTRA_LOCK_REASON", reason.name)
            if (reason == LockReason.PENALTY_ACTIVE) {
                putExtra("EXTRA_SHOW_PENALTY", true)
            } else if (reason == LockReason.URGE_SESSION_ACTIVE) {
                putExtra("EXTRA_SHOW_URGE", true)
            }
        }

        val optionsBundle = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                }.toBundle()
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }

        try {
            if (optionsBundle != null) {
                context.startActivity(intent, optionsBundle)
            } else {
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error launching MainActivity via startActivity: ${e.message}")
            try {
                val pendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                pendingIntent.send()
            } catch (e2: Exception) {
                Log.e(TAG, "Error launching MainActivity via PendingIntent: ${e2.message}")
            }
        }
    }

    fun launchLockTaskAndSettings(context: Context, reason: LockReason) {
        if (reason != LockReason.NONE) {
            launchLockTaskApp(context, reason)
        }
    }

    fun configureDeviceOwnerLockTaskPackages(context: Context, forPenaltyOrUrge: Boolean = false) {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return
            val adminComponent = ComponentName(context, SaffahDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(context.packageName) || dpm.isAdminActive(adminComponent)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val allowedPackages = if (forPenaltyOrUrge) {
                        arrayOf(context.packageName)
                    } else {
                        arrayOf(
                            context.packageName,
                            "com.android.settings",
                            "com.oplus.settings",
                            "com.coloros.settings",
                            "com.oppo.settings",
                            "com.realme.settings",
                            "com.heytap.setting",
                            "com.oplus.wirelesssettings",
                            "com.coloros.wirelesssettings",
                            "com.oplus.notificationmanager",
                            "com.coloros.notificationmanager",
                            "com.oplus.securitypermission",
                            "com.coloros.securitypermission",
                            "com.oplus.safecenter",
                            "com.coloros.safecenter",
                            "com.oplus.appdetail",
                            "com.coloros.appdetail",
                            "com.oplus.battery",
                            "com.coloros.battery",
                            "com.android.permissioncontroller",
                            "com.google.android.permissioncontroller",
                            "com.android.packageinstaller",
                            "com.google.android.packageinstaller",
                            "com.samsung.android.settings",
                            "com.miui.securitycenter",
                            "com.huawei.systemmanager"
                        )
                    }
                    dpm.setLockTaskPackages(adminComponent, allowedPackages)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        if (forPenaltyOrUrge) {
                            dpm.setLockTaskFeatures(adminComponent, DevicePolicyManager.LOCK_TASK_FEATURE_NONE)
                        } else {
                            // Allow system info and notifications so user can interact with Settings
                            dpm.setLockTaskFeatures(
                                adminComponent,
                                DevicePolicyManager.LOCK_TASK_FEATURE_SYSTEM_INFO or
                                DevicePolicyManager.LOCK_TASK_FEATURE_NOTIFICATIONS
                            )
                        }
                    }
                    Log.i(TAG, "Successfully configured LockTask packages (forPenaltyOrUrge=$forPenaltyOrUrge): ${allowedPackages.joinToString()}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring LockTask packages: ${e.message}")
        }
    }

    fun openAccessibilitySettings(context: Context) {
        lastOpenedReason = LockReason.ACCESSIBILITY_DISABLED
        lastOpenedTimestamp = System.currentTimeMillis()
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open accessibility settings: ${e.message}")
        }
    }

    fun openVpnSettings(context: Context) {
        lastOpenedReason = LockReason.VPN_DISABLED
        lastOpenedTimestamp = System.currentTimeMillis()

        try {
            val prepareIntent = android.net.VpnService.prepare(context)
            if (prepareIntent != null) {
                prepareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                context.startActivity(prepareIntent)
                Log.i(TAG, "Launched VpnService.prepare intent successfully")
                return
            }
        } catch (e: Exception) {
            Log.w(TAG, "VpnService.prepare failed: ${e.message}")
        }

        val intentsToTry = listOf(
            Intent(Settings.ACTION_VPN_SETTINGS),
            Intent("android.settings.VPN_SETTINGS"),
            Intent("com.coloros.settings.VPN_SETTINGS"),
            Intent("com.oppo.settings.VPN_SETTINGS"),
            Intent("com.realme.settings.VPN_SETTINGS"),
            Intent().apply { setClassName("com.coloros.settings", "com.coloros.settings.Settings\$VpnSettingsActivity") },
            Intent().apply { setClassName("com.realme.settings", "com.realme.settings.Settings\$VpnSettingsActivity") },
            Intent().apply { setClassName("com.oppo.settings", "com.oppo.settings.Settings\$VpnSettingsActivity") },
            Intent().apply { setClassName("com.android.settings", "com.android.settings.Settings\$VpnSettingsActivity") },
            Intent().apply { setClassName("com.coloros.wirelesssettings", "com.coloros.wirelesssettings.VpnSettings") },
            Intent().apply { setClassName("com.heytap.setting", "com.heytap.setting.VpnSettings") },
            Intent().apply { setClassName("com.coloros.settings", "com.coloros.settings.SubSettings") }.apply { putExtra(":settings:show_fragment", "com.android.settings.vpn2.VpnSettings") },
            Intent().apply { setClassName("com.android.settings", "com.android.settings.SubSettings") }.apply { putExtra(":settings:show_fragment", "com.android.settings.vpn2.VpnSettings") },
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )

        for (intent in intentsToTry) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                context.startActivity(intent)
                Log.i(TAG, "Successfully launched VPN settings with intent: ${intent.action ?: intent.component?.className}")
                return
            } catch (e: Exception) {
                Log.w(TAG, "Failed to launch VPN settings intent: ${e.message}")
            }
        }
    }

    fun openTargetSettings(context: Context, reason: LockReason, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && lastOpenedReason == reason && (now - lastOpenedTimestamp < 5000L)) {
            Log.d(TAG, "Throttling openTargetSettings for $reason (already opened recently)")
            return
        }

        // If context is an Activity and currently in LockTask mode, temporarily stopLockTask so the settings activity can open cleanly without OS blocking
        if (context is Activity && isCurrentlyInLockTaskMode(context)) {
            try {
                context.stopLockTask()
                Log.i(TAG, "Temporarily stopped LockTask mode to launch $reason settings activity cleanly")
            } catch (e: Exception) {
                Log.w(TAG, "stopLockTask exception before launching settings: ${e.message}")
            }
        }

        try {
            when (reason) {
                LockReason.ACCESSIBILITY_DISABLED -> {
                    openAccessibilitySettings(context)
                }
                LockReason.VPN_DISABLED -> {
                    openVpnSettings(context)
                }
                LockReason.NOTIFICATION_ACCESS_DISABLED -> {
                    lastOpenedReason = LockReason.NOTIFICATION_ACCESS_DISABLED
                    lastOpenedTimestamp = System.currentTimeMillis()
                    com.example.service.SaffahNotificationListenerService.openNotificationAccessSettings(context)
                }
                else -> {
                    lastOpenedReason = LockReason.NONE
                    lastOpenedTimestamp = 0L
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening settings for $reason: ${e.message}")
        }
    }
}
