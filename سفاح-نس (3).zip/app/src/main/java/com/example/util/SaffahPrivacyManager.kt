package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import kotlin.math.ceil

/**
 * مدير ميزة "حماية الخصوصية" وقفل الأقسام برمز PIN مكون من 4 أرقام
 */
object SaffahPrivacyManager {

    private const val TAG = "SaffahPrivacy"
    private const val PREFS_NAME = "saffah_privacy_prefs"
    private const val KEY_PIN_HASH = "privacy_pin_hash"
    private const val KEY_PROTECTED_SECTIONS = "protected_sections_set"

    // مفاتيح تجميد وإنذار مذكرات التعافي
    const val KEY_DIARY_FAILED_ATTEMPTS = "diary_pin_failed_attempts"
    const val KEY_DIARY_FROZEN_UNTIL = "diary_pin_frozen_until"
    const val DIARY_FREEZE_DURATION_MILLIS = 24L * 60 * 60 * 1000L // 24 ساعة
    const val MAX_DIARY_ATTEMPTS = 3
    const val SECURITY_FREEZE_MESSAGE = "تم إدخال رمز PIN بشكل خاطئ 3 مرات.. تم تجميد محاولات الفتح لمدة 24 ساعة لحماية مذكراتك"

    // مفاتيح الأقسام المحددة حسب طلب المستخدم
    const val SECTION_RECOVERY_PLEDGE = "recovery_pledge"
    const val SECTION_RECOVERY_COUNTER = "recovery_counter"
    const val SECTION_RECOVERY_DIARIES = "recovery_diaries"
    const val SECTION_RECOVERY_STATS = "recovery_stats"
    const val SECTION_RECOVERY_MAP = "recovery_map"
    const val SECTION_BLOCK_KEYWORDS_AND_SITES = "block_keywords_and_sites"
    const val SECTION_BLOCK_LOGS = "block_logs"
    const val SECTION_ENTIRE_APP = "entire_app"

    data class PrivacySectionInfo(
        val key: String,
        val title: String,
        val subtitle: String
    )

    val ALL_SECTIONS = listOf(
        PrivacySectionInfo(
            key = SECTION_RECOVERY_PLEDGE,
            title = "وثيقة تعهد التعافي",
            subtitle = "ميثاق الشرف والعهد المغلظ للنقاء والكرامة"
        ),
        PrivacySectionInfo(
            key = SECTION_RECOVERY_COUNTER,
            title = "عداد التعافي",
            subtitle = "عداد فترات الامتناع والأيام المنجزة وثبات العزيمة"
        ),
        PrivacySectionInfo(
            key = SECTION_RECOVERY_DIARIES,
            title = "مذكرات التعافي",
            subtitle = "الملاحظات والتدوينات الشخصية والمشاعر الحساسة"
        ),
        PrivacySectionInfo(
            key = SECTION_RECOVERY_STATS,
            title = "إحصائيات التعافي",
            subtitle = "الرسوم البيانية وأنماط الانتكاس وأوقات الخطر"
        ),
        PrivacySectionInfo(
            key = SECTION_RECOVERY_MAP,
            title = "خريطة رحلة التعافي",
            subtitle = "مسار المحطات والتحديات والإنجازات الشخصية"
        ),
        PrivacySectionInfo(
            key = SECTION_BLOCK_KEYWORDS_AND_SITES,
            title = "قائمة الحظر",
            subtitle = "الكلمات والمواقع المحظورة"
        ),
        PrivacySectionInfo(
            key = SECTION_BLOCK_LOGS,
            title = "سجل الحظر",
            subtitle = "سجل الأحداث ومحاولات الوصول والروابط المحجوبة"
        ),
        PrivacySectionInfo(
            key = SECTION_ENTIRE_APP,
            title = "تطبيق السفاح بالكامل",
            subtitle = "طلب رمز PIN فور فتح تطبيق السفاح قبل الوصول لأي قسم"
        )
    )

    data class PrivacyConfig(
        val isPinSet: Boolean,
        val protectedSections: Set<String>,
        val unlockedSections: Set<String> = emptySet(),
        val isSessionUnlocked: Boolean = false
    )

    sealed class VerifyPinResult {
        object Success : VerifyPinResult()
        data class WrongPin(val attemptsMade: Int, val attemptsRemaining: Int, val message: String) : VerifyPinResult()
        data class Frozen(val remainingMillis: Long, val formattedRemaining: String, val message: String) : VerifyPinResult()
    }

    // الأقسام المفتوحة حالياً في الجلسة (تبقى بالذاكرة وتُعاد إلى فارغة عند إغلاق التطبيق تماماً)
    private val _unlockedSections = MutableStateFlow<Set<String>>(emptySet())
    val unlockedSections: StateFlow<Set<String>> = _unlockedSections.asStateFlow()

    private val _isSessionUnlocked = MutableStateFlow(false)
    val isSessionUnlocked: StateFlow<Boolean> = _isSessionUnlocked.asStateFlow()

    private val _configFlow = MutableStateFlow(
        PrivacyConfig(
            isPinSet = false,
            protectedSections = emptySet(),
            unlockedSections = emptySet(),
            isSessionUnlocked = false
        )
    )
    val configFlow: StateFlow<PrivacyConfig> = _configFlow.asStateFlow()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun init(context: Context) {
        refreshConfig(context)
    }

    fun refreshConfig(context: Context) {
        val prefs = getPrefs(context)
        val hash = prefs.getString(KEY_PIN_HASH, null)
        val sections = prefs.getStringSet(KEY_PROTECTED_SECTIONS, emptySet()) ?: emptySet()
        _configFlow.value = PrivacyConfig(
            isPinSet = !hash.isNullOrBlank(),
            protectedSections = sections.toSet(),
            unlockedSections = _unlockedSections.value,
            isSessionUnlocked = _isSessionUnlocked.value
        )
    }

    fun isPinConfigured(context: Context): Boolean {
        val hash = getPrefs(context).getString(KEY_PIN_HASH, null)
        return !hash.isNullOrBlank()
    }

    fun getPinHash(context: Context): String? {
        return getPrefs(context).getString(KEY_PIN_HASH, null)
    }

    fun restorePrivacyConfig(context: Context, pinHash: String?, protectedSections: Set<String>) {
        val editor = getPrefs(context).edit()
        if (!pinHash.isNullOrBlank()) {
            editor.putString(KEY_PIN_HASH, pinHash)
        }
        editor.putStringSet(KEY_PROTECTED_SECTIONS, protectedSections)
        editor.apply()
        refreshConfig(context)
    }

    fun getProtectedSections(context: Context): Set<String> {
        return getPrefs(context).getStringSet(KEY_PROTECTED_SECTIONS, emptySet()) ?: emptySet()
    }

    /**
     * هل مذكرات التعافي مجمدة حالياً بسبب 3 محاولات PIN خاطئة متتالية؟
     */
    fun isDiaryFrozen(context: Context): Boolean {
        val freezeUntil = getPrefs(context).getLong(KEY_DIARY_FROZEN_UNTIL, 0L)
        if (freezeUntil == 0L) return false
        val now = System.currentTimeMillis()
        return if (now < freezeUntil) {
            true
        } else {
            // انقضت مدة التجميد الـ 24 ساعة، تصفير المحاولات تلقائياً
            getPrefs(context).edit()
                .putLong(KEY_DIARY_FROZEN_UNTIL, 0L)
                .putInt(KEY_DIARY_FAILED_ATTEMPTS, 0)
                .apply()
            false
        }
    }

    fun getDiaryFrozenRemainingMillis(context: Context): Long {
        val freezeUntil = getPrefs(context).getLong(KEY_DIARY_FROZEN_UNTIL, 0L)
        val now = System.currentTimeMillis()
        return if (freezeUntil > now) freezeUntil - now else 0L
    }

    fun getDiaryFailedAttempts(context: Context): Int {
        return if (isDiaryFrozen(context)) {
            MAX_DIARY_ATTEMPTS
        } else {
            getPrefs(context).getInt(KEY_DIARY_FAILED_ATTEMPTS, 0)
        }
    }

    /**
     * صياغة الوقت المتبقي بالإنجليزية فقط (Strict English digits rule)
     */
    fun formatRemainingHoursAndMinutes(millis: Long): String {
        if (millis <= 0L) return "0 دقيقة"
        val totalMinutes = ceil(millis / 60000.0).toLong()
        val hours = totalMinutes / 60
        val minutes = totalMinutes % 60
        return when {
            hours > 0 && minutes > 0 -> "$hours ساعة و $minutes دقيقة"
            hours > 0 -> "$hours ساعة"
            else -> "$minutes دقيقة"
        }
    }

    /**
     * إطلاق إنذار أمني صوتي واهتزاز فور ارتكاب 3 أخطاء متتالية
     */
    fun playSecurityAlarm(context: Context) {
        try {
            val alarmUri: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            if (alarmUri != null) {
                val ringtone = RingtoneManager.getRingtone(context.applicationContext, alarmUri)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ringtone.audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                }
                ringtone.play()
                // إيقاف نغمة الإنذار تلقائياً بعد 4 ثوانٍ
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    try {
                        if (ringtone.isPlaying) {
                            ringtone.stop()
                        }
                    } catch (_: Exception) {}
                }, 4000L)
            } else {
                val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                toneGen.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 3000)
            }
        } catch (e: Exception) {
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 2000)
            } catch (_: Exception) {}
        }

        try {
            // نمط اهتزاز إنذار أمني قوي
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val vibrator = vibratorManager?.defaultVibrator
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 600), -1))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 600), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 400, 200, 400, 200, 600), -1)
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * فحص هل قسم معين محمي ومقفل في الجلسة الحالية.
     * يظل كل قسم مقفلاً ومحمياً حتى يتم فتح هذا القسم بعينه برمز PIN.
     * إذا كانت مذكرات التعافي مجمدة (24 ساعة)، فإنها تكون مقفلة إجبارياً وبشكل غير قابل للفتح.
     */
    fun isSectionLocked(context: Context, sectionKey: String): Boolean {
        if (!isPinConfigured(context)) return false
        if (sectionKey == SECTION_RECOVERY_DIARIES && isDiaryFrozen(context)) {
            return true
        }
        val sections = getProtectedSections(context)
        if (!sections.contains(sectionKey)) return false
        return !_unlockedSections.value.contains(sectionKey)
    }

    /**
     * فحص هل تطبيق السفاح بالكامل مقفل في الجلسة الحالية
     */
    fun isEntireAppLocked(context: Context): Boolean {
        return isSectionLocked(context, SECTION_ENTIRE_APP)
    }

    /**
     * فتح قفل قسم محدد فقط في الجلسة الحالية
     */
    fun unlockSection(sectionKey: String) {
        val updated = _unlockedSections.value.toMutableSet()
        updated.add(sectionKey)
        _unlockedSections.value = updated
        _configFlow.value = _configFlow.value.copy(unlockedSections = updated)
    }

    /**
     * إعادة قفل قسم محدد
     */
    fun lockSection(sectionKey: String) {
        val updated = _unlockedSections.value.toMutableSet()
        updated.remove(sectionKey)
        _unlockedSections.value = updated
        _configFlow.value = _configFlow.value.copy(unlockedSections = updated)
    }

    /**
     * إعادة قفل جميع الأقسام
     */
    fun lockAllSections() {
        _unlockedSections.value = emptySet()
        _isSessionUnlocked.value = false
        _configFlow.value = _configFlow.value.copy(
            unlockedSections = emptySet(),
            isSessionUnlocked = false
        )
    }

    /**
     * فتح قفل الجلسة (اختياري، يفتح جميع الأقسام المحددة)
     */
    fun unlockSession() {
        _isSessionUnlocked.value = true
        _configFlow.value = _configFlow.value.copy(isSessionUnlocked = true)
    }

    /**
     * إعادة قفل الجلسة
     */
    fun lockSession() {
        lockAllSections()
    }

    fun normalizeDigits(input: String): String {
        val builder = StringBuilder()
        for (ch in input) {
            when (ch) {
                '0', '٠' -> builder.append('0')
                '1', '١' -> builder.append('1')
                '2', '٢' -> builder.append('2')
                '3', '٣' -> builder.append('3')
                '4', '٤' -> builder.append('4')
                '5', '٥' -> builder.append('5')
                '6', '٦' -> builder.append('6')
                '7', '٧' -> builder.append('7')
                '8', '٨' -> builder.append('8')
                '9', '٩' -> builder.append('9')
                else -> if (ch in '0'..'9') builder.append(ch)
            }
        }
        return builder.toString()
    }

    fun hashPin(pin: String): String {
        val normalized = normalizeDigits(pin)
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(normalized.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPin(context: Context, pin: String): Boolean {
        val storedHash = getPrefs(context).getString(KEY_PIN_HASH, null) ?: return false
        val inputHash = hashPin(pin)
        return storedHash == inputHash
    }

    /**
     * التحقق الأمني الشامل من رمز PIN مع تتبع الأخطاء والتجميد لـ 24 ساعة وإنذار الصوت والاهتزاز
     */
    fun verifyPinWithSecurity(context: Context, pin: String, sectionKey: String?): VerifyPinResult {
        if (sectionKey == SECTION_RECOVERY_DIARIES) {
            if (isDiaryFrozen(context)) {
                val remaining = getDiaryFrozenRemainingMillis(context)
                return VerifyPinResult.Frozen(
                    remainingMillis = remaining,
                    formattedRemaining = formatRemainingHoursAndMinutes(remaining),
                    message = SECURITY_FREEZE_MESSAGE
                )
            }

            val isCorrect = verifyPin(context, pin)
            if (isCorrect) {
                // تصفير المحاولات الخاطئة عند إدخال الرمز الصحيح
                getPrefs(context).edit().putInt(KEY_DIARY_FAILED_ATTEMPTS, 0).apply()
                return VerifyPinResult.Success
            } else {
                val currentAttempts = getPrefs(context).getInt(KEY_DIARY_FAILED_ATTEMPTS, 0) + 1
                if (currentAttempts >= MAX_DIARY_ATTEMPTS) {
                    val freezeUntil = System.currentTimeMillis() + DIARY_FREEZE_DURATION_MILLIS
                    getPrefs(context).edit()
                        .putInt(KEY_DIARY_FAILED_ATTEMPTS, currentAttempts)
                        .putLong(KEY_DIARY_FROZEN_UNTIL, freezeUntil)
                        .apply()

                    // قفل القسم فورياً بالذاكرة وإلغاء أي فتح سابق
                    lockSection(SECTION_RECOVERY_DIARIES)

                    // إطلاق الإنذار الصوتي والاهتزاز فور ارتكاب 3 أخطاء متتالية
                    playSecurityAlarm(context)

                    Log.w(TAG, "Security Alarm Triggered: 3 consecutive wrong PIN attempts on Recovery Diaries. Frozen for 24h.")
                    val remaining = DIARY_FREEZE_DURATION_MILLIS
                    return VerifyPinResult.Frozen(
                        remainingMillis = remaining,
                        formattedRemaining = formatRemainingHoursAndMinutes(remaining),
                        message = SECURITY_FREEZE_MESSAGE
                    )
                } else {
                    getPrefs(context).edit().putInt(KEY_DIARY_FAILED_ATTEMPTS, currentAttempts).apply()
                    val remainingAttempts = MAX_DIARY_ATTEMPTS - currentAttempts
                    val msg = "رمز PIN غير صحيح. متبقي $remainingAttempts محاولات قبل تجميد القفل لمدة 24 ساعة"
                    return VerifyPinResult.WrongPin(
                        attemptsMade = currentAttempts,
                        attemptsRemaining = remainingAttempts,
                        message = msg
                    )
                }
            }
        } else {
            val isCorrect = verifyPin(context, pin)
            return if (isCorrect) {
                VerifyPinResult.Success
            } else {
                VerifyPinResult.WrongPin(
                    attemptsMade = 1,
                    attemptsRemaining = 0,
                    message = "رمز PIN غير صحيح، يرجى المحاولة ثانية"
                )
            }
        }
    }

    /**
     * حفظ كود PIN جديد مكون من 4 أرقام
     */
    fun setPin(context: Context, newPin: String): Boolean {
        val normalized = normalizeDigits(newPin)
        if (normalized.length != 4) return false
        val hash = hashPin(normalized)
        getPrefs(context).edit().putString(KEY_PIN_HASH, hash).apply()
        refreshConfig(context)
        return true
    }

    /**
     * تغيير كود PIN مع التحقق الإجباري من الكود القديم
     */
    fun changePin(context: Context, currentPin: String, newPin: String): Boolean {
        if (!verifyPin(context, currentPin)) return false
        return setPin(context, newPin)
    }

    /**
     * حذف/إلغاء كود PIN مع التحقق الإجباري من الكود الحالي
     */
    fun removePin(context: Context, currentPin: String): Boolean {
        if (!verifyPin(context, currentPin)) return false
        getPrefs(context).edit()
            .remove(KEY_PIN_HASH)
            .remove(KEY_PROTECTED_SECTIONS)
            .remove(KEY_DIARY_FAILED_ATTEMPTS)
            .remove(KEY_DIARY_FROZEN_UNTIL)
            .apply()
        _unlockedSections.value = emptySet()
        _isSessionUnlocked.value = false
        refreshConfig(context)
        return true
    }

    /**
     * إضافة قسم لقائمة الأقسام المحمية
     */
    fun protectSection(context: Context, sectionKey: String) {
        val current = getProtectedSections(context).toMutableSet()
        current.add(sectionKey)
        getPrefs(context).edit().putStringSet(KEY_PROTECTED_SECTIONS, current).apply()
        val unlocked = _unlockedSections.value.toMutableSet()
        unlocked.remove(sectionKey)
        _unlockedSections.value = unlocked
        refreshConfig(context)
    }

    /**
     * إزالة قسم من الأقسام المحمية (تتطلب التحقق من الـ PIN قبل استدعائها)
     */
    fun unprotectSection(context: Context, sectionKey: String) {
        val current = getProtectedSections(context).toMutableSet()
        current.remove(sectionKey)
        getPrefs(context).edit().putStringSet(KEY_PROTECTED_SECTIONS, current).apply()
        val unlocked = _unlockedSections.value.toMutableSet()
        unlocked.remove(sectionKey)
        _unlockedSections.value = unlocked
        refreshConfig(context)
    }

    fun resetDiaryFreezeForTesting(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_DIARY_FAILED_ATTEMPTS)
            .remove(KEY_DIARY_FROZEN_UNTIL)
            .apply()
    }
}

