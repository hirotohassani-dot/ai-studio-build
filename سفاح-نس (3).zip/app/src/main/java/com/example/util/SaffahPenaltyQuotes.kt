package com.example.util

enum class QuoteCategory(val title: String) {
    SAFFAH_FORTRESS("درع وحصن السَّفاح"),
    SPIRITUAL_PURITY("طهارة القلب ومراقبة الله"),
    BRAIN_RECOVERY("ثورة الدماغ واستعادة الدوبامين"),
    HONOR_HEROISM("عزة النفس وقوة الإرادة")
}

data class PenaltyMotivationalQuote(
    val id: Int,
    val category: QuoteCategory,
    val text: String,
    val subText: String = ""
)

object SaffahPenaltyQuotes {

    val ALL_QUOTES: List<PenaltyMotivationalQuote> = listOf(
        // Category 1: درع وحصن السَّفاح (Aura, Power, and Protection)
        PenaltyMotivationalQuote(
            id = 1,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "السَّفاح لا ينكسر ولا يتهاون.. سدّك المنيع وحصنك الحديدي لقطع دابر القاذورات وحمايتك من عثرات النفس.",
            subText = "حماية فورية صارمة لصيانة كرامتك وعفتك"
        ),
        PenaltyMotivationalQuote(
            id = 2,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "أنت في حماية السَّفاح.. سيف مسلول يقطع سموم الظلمات ويقف سنداً صلباً لعزيمتك في أحلك اللحظات.",
            subText = "درع لا يكل ولا يمل للدفاع عن نقاء شاشتك"
        ),
        PenaltyMotivationalQuote(
            id = 3,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "حين تضعف لحظياً، تجد السَّفاح يقظاً كالفولاذ.. حارس شرفك الذي يقف أمام كل شهوة رخيصة.",
            subText = "قفل تأديبي ذكي لإنقاذك من ندم الانتكاسة"
        ),
        PenaltyMotivationalQuote(
            id = 4,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "لست وحدك في هذه المعركة الشرسة؛ السَّفاح جدارك العازل وسلاحك الفتاك ضد مستنقع الفتن والضياع.",
            subText = "أنت أقوى بوجود حليف لا يعرف التراجع"
        ),
        PenaltyMotivationalQuote(
            id = 5,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "درع صلب كالجبال سُخّر لحمايتك.. السَّفاح يُسقط أوهام الشهوات لتبقى شامخاً لا تُهزم أبداً.",
            subText = "ثبات، وقار، وانضباط لا تراجع فيه"
        ),
        PenaltyMotivationalQuote(
            id = 6,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "هيبة السَّفاح وقوته تنبع من رغبتك في الطهارة.. إغلاق صارم يطهر جهازك ليبقى عقلك صافياً متألقاً.",
            subText = "السفاح يحرسك لتصنع مستقبلك العظيم"
        ),
        PenaltyMotivationalQuote(
            id = 7,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "سيف الحماية الصارم لا يرحم السموم.. انتشالك من وحل الغفلة هو واجب السَّفاح الذي عاهدت عليه نفسك.",
            subText = "توقف وتنفس بعمق.. لقد تم إنقاذك في الوقت المناسب"
        ),
        PenaltyMotivationalQuote(
            id = 8,
            category = QuoteCategory.SAFFAH_FORTRESS,
            text = "مع السَّفاح، القيادة الحقيقية تعود إلى عقلك ووعيك.. لا سلطة لنزوة طائشة على رجل اختار طريق المجد.",
            subText = "عزيمة فولاذية لا تخترقها الرغبات الزائلة"
        ),

        // Category 2: طهارة القلب ومراقبة الله والوجدان (Spiritual Purity & Conscience)
        PenaltyMotivationalQuote(
            id = 9,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "«ما ترك عبد لله شيئاً إلا أبدله الله خيراً منه».. اثبت، فطهارة السريرة تورثك نوراً في الوجه وسكينة في الفؤاد.",
            subText = "عوض الله العظيم ينتظر كل من غض بصره وصبر"
        ),
        PenaltyMotivationalQuote(
            id = 10,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "قلبك خُلق ليكون محراباً للسكينة والوقار.. فلا تلوثه بقاذورات تموت لذتها في لحظة ويبقى ذلها وندمها.",
            subText = "طهارة الروح هي أثمن ما تملكه في هذه الدنيا"
        ),
        PenaltyMotivationalQuote(
            id = 11,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "عين تغض عن الحرام حياءً من الله، يُلزمها الله نعيماً وإيماناً يجد حلاوته في نبضات صدره إلى يوم القيامة.",
            subText = "لذة الانتصار على الشهوة أضعاف لذة الخضوع لها"
        ),
        PenaltyMotivationalQuote(
            id = 12,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "الله يراك في خلوتك.. اجعل خلوتك ميداناً لشجاعتك وصدقك، ولا تجعل ربك أهون الناظرين إليك.",
            subText = "استحضر معية الله وتذكر أنه يحبك طاهراً نقياً"
        ),
        PenaltyMotivationalQuote(
            id = 13,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "لحظة غض بصر وجهاد صادق في الخفاء ترتفع بك درجات في عليين.. العفة تاج الملوك لا يرتديه إلا العظماء.",
            subText = "أنت اليوم تجاهد لترضي خالقك وتبني وقارك"
        ),
        PenaltyMotivationalQuote(
            id = 14,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "طهارة السريرة رأس كل كرامة.. من خاف مقام ربه ونهى النفس عن الهوى، فإن الجنة هي المأوى.",
            subText = "اجعل ضميرك حياً ونقياً كصفحة السماء"
        ),
        PenaltyMotivationalQuote(
            id = 15,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "«اللهم إني أعوذ بك من شر سمعي ومن شر بصري ومن شر قلبي».. استغفر الآن وتوضأ، وافتح صفحة ناصعة.",
            subText = "باب التوبة والمغفرة مفتوح دائماً لقلبك التائب"
        ),
        PenaltyMotivationalQuote(
            id = 16,
            category = QuoteCategory.SPIRITUAL_PURITY,
            text = "كل نظرة محرمة سهم مسموم في صميم الروح، وكل كبح للشهوة يسقي قلبك حياءً وكرامة وبصيرة تنير دربك.",
            subText = "احمِ بصيرتك من سموم العمى والغفلة"
        ),

        // Category 3: ثورة الدماغ واستعادة الدوبامين (Brain Recovery & Vitality)
        PenaltyMotivationalQuote(
            id = 17,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "كل دقيقة تصمد فيها تعيد بناء مستقبلات الدوبامين في دماغك! استعد تركيزك الخارق وذكاءك المتوقد.",
            subText = "إعادة ضبط عصبية حقيقية لشفاء عقلك"
        ),
        PenaltyMotivationalQuote(
            id = 18,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "التعافي يضخ طاقة وحيوية في خلايا جسدك.. يزيل ضبابية الذهن ويعيد إليك الشغف الحقيقي بالحياة والإنجاز.",
            subText = "وداعاً للكسل والخمول وتشتت الذاكرة"
        ),
        PenaltyMotivationalQuote(
            id = 19,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "انظر لعينيك وملامحك.. الابتعاد عن السموم البصرية يعيد إلى وجهك بريق النضارة وجاذبية الحضور والمهابة.",
            subText = "إشراقة الوجه وثقة العينين ثمرة الطهارة"
        ),
        PenaltyMotivationalQuote(
            id = 20,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "دماغك يرمم مساراته العصبية الآن! كل رغبة تتجاوزها تزيد من قوة قشرة فصك الجبهي المسؤولة عن التحكم والقيادة.",
            subText = "أنت تصنع إرادة خارقة مع كل تحدٍ تجتازه"
        ),
        PenaltyMotivationalQuote(
            id = 21,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "راحة البال، وتلاشي القلق، وزوال نوبات تأنيب الضمير.. أعظم مكافأة يمنحها لك التعافي في كل إشراقة صباح.",
            subText = "سكينة داخلية ونوم عميق هادئ بلا كوابيس"
        ),
        PenaltyMotivationalQuote(
            id = 22,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "أنت تبني نسخة أسطورية من نفسك: ذاكرة فولاذية، حضور اجتماعي واثق، وتحرر كامل من قبضة الإدمان!",
            subText = "الاستثمار في عقلك هو أعظم استثمار في وجودك"
        ),
        PenaltyMotivationalQuote(
            id = 23,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "انتظام الهرمونات، زيادة القوة البدنية، وارتفاع هرمون التستوستيرون الطبيعي.. جسدك يولد من جديد!",
            subText = "استعد لياقتك وقوتك الحقيقية كرجل كامل"
        ),
        PenaltyMotivationalQuote(
            id = 24,
            category = QuoteCategory.BRAIN_RECOVERY,
            text = "حين تُطهر حواسك من المحفزات المسمومة، تعود لتتذوق جمال الأشياء البسيطة ولذة النجاح الواقعي من جديد.",
            subText = "العالم الواقعي أجمل بآلاف المرات من السراب الرقمي"
        ),

        // Category 4: عزة النفس وقوة الإرادة والبطولة (Honor, Willpower & Heroism)
        PenaltyMotivationalQuote(
            id = 25,
            category = QuoteCategory.HONOR_HEROISM,
            text = "الرجولة والكرامة لا تباع بثوان معدودة من سراب حقير يعقبه همّ وذلّ وحسرة تمزق الفؤاد!",
            subText = "أنت رجل صاحب رسالة وليس أسيراً لشهوة رخيصة"
        ),
        PenaltyMotivationalQuote(
            id = 26,
            category = QuoteCategory.HONOR_HEROISM,
            text = "المحارب الحقيقي لا يستسلم لنزوة فانية.. أنت أقوى بكثير من فكرة عابرة، وأشجع من أن تنكسر أمام شاشة صامتة!",
            subText = "الصمود في وجه العاصفة هو شيمة الأبطال"
        ),
        PenaltyMotivationalQuote(
            id = 27,
            category = QuoteCategory.HONOR_HEROISM,
            text = "عش حراً سيداً على غرائزك، ولا ترضَ أن تكون عبداً لنزوة تقودك كالأعمى نحو هاوية الندم والخذلان.",
            subText = "الحرية الحقيقية هي السيادة على النفس"
        ),
        PenaltyMotivationalQuote(
            id = 28,
            category = QuoteCategory.HONOR_HEROISM,
            text = "قيمتك وكرامتك أثمن من أن تهدرها في وحل الملذات الكاذبة.. اصمد فإن وراء الصبر فوزاً ومجداً لا ينتهي.",
            subText = "مكانك في القمة بين الشامخين والناجحين"
        ),
        PenaltyMotivationalQuote(
            id = 29,
            category = QuoteCategory.HONOR_HEROISM,
            text = "تذكر دائماً ألم الحسرة والندم والاحتراق النفسي بعد السقوط.. لا تعد لذلك السجن المظلم، فالنور ينتظرك!",
            subText = "لا تدع اللحظات الصعبة تسرق منك أيامك الجميلة"
        ),
        PenaltyMotivationalQuote(
            id = 30,
            category = QuoteCategory.HONOR_HEROISM,
            text = "كل ثانية تقضيها في هذا القفل التأديبي هي ولادة جديدة لإرادتك وخطوة جبارة نحو استعادة سيادتك على حياتك.",
            subText = "النهوض من الكبوة هو بداية المجد الحقيقي"
        ),
        PenaltyMotivationalQuote(
            id = 31,
            category = QuoteCategory.HONOR_HEROISM,
            text = "ركز على أهدافك العظمى وطموحاتك الكبرى.. لا تسمح للمستنقع الرقمي أن يسرق منك شبابك ومستقبلك المشرق.",
            subText = "أحلامك تنتظر عملك وإنجازك، لا خنوعك"
        ),
        PenaltyMotivationalQuote(
            id = 32,
            category = QuoteCategory.HONOR_HEROISM,
            text = "النصر صبر ساعة! ألم الامتناع والمجاهدة ينتهي سريعاً، ويبقى فخر الانتصار وشرف العفة إلى الأبد.",
            subText = "اصبر واثبت.. فأنت على وشك تحقيق انتصار عظيم"
        )
    )

    fun getRandomQuote(): PenaltyMotivationalQuote {
        return ALL_QUOTES.random()
    }

    fun getQuoteForIndex(index: Int): PenaltyMotivationalQuote {
        return ALL_QUOTES[Math.floorMod(index, ALL_QUOTES.size)]
    }
}

