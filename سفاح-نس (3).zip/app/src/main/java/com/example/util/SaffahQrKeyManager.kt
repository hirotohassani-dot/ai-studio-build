package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.EnumMap

/**
 * مدير نظام حماية المفتاح المادي (QR Code Physical Key)
 * 
 * المعمارية ومزايا الأداء:
 * 1. استهلاك 0% بطارية و 0% معالج: لا توجد أي خدمات خلفية أو معالجة مستمرة. الكاميرا تُفتح فقط عند طلب المسح.
 * 2. يعمل بالكامل دون الحاجة للإنترنت (Offline 100%) وبأعلى سرعة ممكنة عبر مكتبة ZXing فائقة الكفاءة.
 * 3. يدعم حصراً رموز الاستجابة السريعة (QR Code Only) بدقة وفورية بالغة.
 * 4. تشفير وحفظ بصمة الكود السري المشفر عبر SHA-256.
 */
object SaffahQrKeyManager {

    private const val TAG = "SaffahQrKeyManager"
    private const val PREFS_NAME = "saffah_qr_key_prefs"

    private const val KEY_ENABLED = "qr_key_enabled"
    private const val KEY_HASH = "qr_key_hash"
    private const val KEY_PREVIEW = "qr_key_preview"
    private const val KEY_REGISTERED_AT = "qr_key_registered_at"
    private const val KEY_KEY_LENGTH = "qr_key_length"
    private const val KEY_KEYS_JSON = "qr_keys_json"

    data class QrKeyItem(
        val id: String,
        val hash: String,
        val preview: String,
        val length: Int,
        val registeredAt: Long,
        val label: String
    )

    data class QrKeyConfig(
        val isEnabled: Boolean,
        val keys: List<QrKeyItem> = emptyList(),
        val isKeyRegistered: Boolean = keys.isNotEmpty(),
        val primaryKey: QrKeyItem? = keys.firstOrNull(),
        val keyHash: String = keys.firstOrNull()?.hash ?: "",
        val keyPreview: String = keys.firstOrNull()?.preview ?: "",
        val keyLength: Int = keys.firstOrNull()?.length ?: 0,
        val registeredAt: Long = keys.firstOrNull()?.registeredAt ?: 0L,
        val totalKeysCount: Int = keys.size
    )

    sealed class RegisterKeyResult {
        data class Success(val key: QrKeyItem) : RegisterKeyResult()
        object AlreadyExists : RegisterKeyResult()
        object InvalidCode : RegisterKeyResult()
        object TimeDelayActive : RegisterKeyResult()
    }

    sealed class VerificationResult {
        data class Success(val matchedKey: QrKeyItem, val isPrimary: Boolean) : VerificationResult()
        object InvalidCode : VerificationResult()
        object NotRegistered : VerificationResult()
        data class SecondaryKeyWhenPrimaryRequired(val scannedKey: QrKeyItem, val primaryKey: QrKeyItem) : VerificationResult()
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getAllKeys(context: Context): List<QrKeyItem> {
        val prefs = getPrefs(context)
        if (prefs.contains(KEY_KEYS_JSON)) {
            val jsonStr = prefs.getString(KEY_KEYS_JSON, null)
            if (!jsonStr.isNullOrBlank()) {
                try {
                    val jsonArray = org.json.JSONArray(jsonStr)
                    val list = mutableListOf<QrKeyItem>()
                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        val hash = obj.optString("hash", "")
                        if (hash.isNotBlank()) {
                            val rawPreview = obj.optString("preview", "")
                            val maskedPreview = formatMaskedPreview(if (rawPreview.isNotBlank()) rawPreview else hash)
                            list.add(
                                QrKeyItem(
                                    id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                                    hash = hash,
                                    preview = maskedPreview,
                                    length = obj.optInt("length", 0),
                                    registeredAt = obj.optLong("registeredAt", System.currentTimeMillis()),
                                    label = obj.optString("label", "كود ${i + 1}")
                                )
                            )
                        }
                    }
                    return list
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing qr_keys_json: ${e.message}")
                    return emptyList()
                }
            } else {
                return emptyList()
            }
        }

        // Auto-migration for legacy single key only if KEY_KEYS_JSON was never stored
        val legacyHash = prefs.getString(KEY_HASH, "") ?: ""
        if (legacyHash.isNotBlank()) {
            val legacyPreview = prefs.getString(KEY_PREVIEW, makePreviewSnippet(legacyHash)) ?: "****"
            val legacyLength = prefs.getInt(KEY_KEY_LENGTH, 0)
            val legacyReg = prefs.getLong(KEY_REGISTERED_AT, System.currentTimeMillis())
            val migratedItem = QrKeyItem(
                id = java.util.UUID.randomUUID().toString(),
                hash = legacyHash,
                preview = legacyPreview,
                length = legacyLength,
                registeredAt = legacyReg,
                label = "كود الحماية 1"
            )
            val migratedList = listOf(migratedItem)
            saveKeysList(context, migratedList)
            return migratedList
        }

        return emptyList()
    }

    private fun saveKeysList(context: Context, list: List<QrKeyItem>) {
        val jsonArray = org.json.JSONArray()
        list.forEach { item ->
            val obj = org.json.JSONObject().apply {
                put("id", item.id)
                put("hash", item.hash)
                put("preview", item.preview)
                put("length", item.length)
                put("registeredAt", item.registeredAt)
                put("label", item.label)
            }
            jsonArray.put(obj)
        }
        val editor = getPrefs(context).edit()
        editor.putString(KEY_KEYS_JSON, jsonArray.toString())
        if (list.isNotEmpty()) {
            editor.putBoolean(KEY_ENABLED, true)
            // Synchronize legacy keys
            editor.putString(KEY_HASH, list.first().hash)
            editor.putString(KEY_PREVIEW, list.first().preview)
            editor.putInt(KEY_KEY_LENGTH, list.first().length)
            editor.putLong(KEY_REGISTERED_AT, list.first().registeredAt)
        } else {
            editor.putBoolean(KEY_ENABLED, false)
            editor.remove(KEY_HASH)
            editor.remove(KEY_PREVIEW)
            editor.remove(KEY_KEY_LENGTH)
            editor.remove(KEY_REGISTERED_AT)
        }
        editor.apply()
    }

    /**
     * استعادة وحفظ مفاتيح QR المادية من النسخة الاحتياطية
     */
    fun restoreKeysList(context: Context, list: List<QrKeyItem>) {
        saveKeysList(context, list)
    }

    fun getQrKeyConfig(context: Context): QrKeyConfig {
        val prefs = getPrefs(context)
        val keys = getAllKeys(context)
        val isEnabled = prefs.getBoolean(KEY_ENABLED, false) && keys.isNotEmpty()

        return QrKeyConfig(
            isEnabled = isEnabled,
            keys = keys,
            isKeyRegistered = keys.isNotEmpty(),
            keyHash = keys.firstOrNull()?.hash ?: "",
            keyPreview = keys.firstOrNull()?.preview ?: "",
            keyLength = keys.firstOrNull()?.length ?: 0,
            registeredAt = keys.firstOrNull()?.registeredAt ?: 0L,
            totalKeysCount = keys.size
        )
    }

    fun isQrKeyProtectionActive(context: Context): Boolean {
        val config = getQrKeyConfig(context)
        return config.isEnabled && config.keys.isNotEmpty()
    }

    fun registerQrKey(context: Context, rawCode: String, customLabel: String? = null): RegisterKeyResult {
        // لا يُسمح بتفعيل قفل QR كحماية إلا بعد انتهاء الحماية عبر ميزة التأخير الزمني
        if (SaffahBlockRepository.isTimeDelayActive(context)) {
            Log.w(TAG, "Cannot register QR key while Time Delay is active")
            return RegisterKeyResult.TimeDelayActive
        }

        val clean = rawCode.trim()
        if (clean.isBlank()) return RegisterKeyResult.InvalidCode

        val hash = hashString(clean)
        val currentKeys = getAllKeys(context)
        if (currentKeys.any { it.hash.equals(hash, ignoreCase = true) }) {
            return RegisterKeyResult.AlreadyExists
        }

        val preview = makePreviewSnippet(clean)
        val now = System.currentTimeMillis()
        val nextNum = currentKeys.size + 1
        val label = if (!customLabel.isNullOrBlank()) customLabel.trim() else "كود الحماية $nextNum"

        val newItem = QrKeyItem(
            id = java.util.UUID.randomUUID().toString(),
            hash = hash,
            preview = preview,
            length = clean.length,
            registeredAt = now,
            label = label
        )

        val updatedList = currentKeys + newItem
        saveKeysList(context, updatedList)

        // عند تفعيل الحماية عبر قفل QR المادي يتم تعطيل الحماية عبر ميزة التأخير الزمني
        SaffahBlockRepository.stopTimeDelay(context)

        Log.i(TAG, "Successfully registered physical QR key '$label' (Total: ${updatedList.size}, Length: ${clean.length})")
        return RegisterKeyResult.Success(newItem)
    }

    fun findKeyByRawCode(context: Context, rawCode: String): QrKeyItem? {
        val clean = rawCode.trim()
        if (clean.isBlank()) return null
        val hash = hashString(clean)
        return getAllKeys(context).firstOrNull { it.hash.equals(hash, ignoreCase = true) }
    }

    fun deleteQrKeyByRawCode(context: Context, rawCode: String): Boolean {
        val clean = rawCode.trim()
        if (clean.isBlank()) return false
        val hash = hashString(clean)
        return deleteQrKey(context, hash)
    }

    fun deleteQrKey(context: Context, keyId: String): Boolean {
        val currentKeys = getAllKeys(context)
        val updatedList = currentKeys.filterNot { it.id == keyId || it.hash == keyId }
        if (updatedList.size == currentKeys.size) return false
        saveKeysList(context, updatedList)
        Log.i(TAG, "Deleted QR key $keyId (Remaining: ${updatedList.size})")
        return true
    }

    fun getPrimaryKey(context: Context): QrKeyItem? {
        return getAllKeys(context).firstOrNull()
    }

    fun verifyScannedCode(context: Context, scannedCode: String, requirePrimaryOnly: Boolean = false): Boolean {
        return when (verifyScannedCodeDetails(context, scannedCode, requirePrimaryOnly)) {
            is VerificationResult.Success -> true
            else -> false
        }
    }

    fun verifyScannedCodeDetails(
        context: Context,
        scannedCode: String,
        requirePrimaryOnly: Boolean = false
    ): VerificationResult {
        val clean = scannedCode.trim()
        if (clean.isBlank()) return VerificationResult.InvalidCode

        val keys = getAllKeys(context)
        if (keys.isEmpty()) return VerificationResult.NotRegistered

        val scannedHash = hashString(clean)
        val matchedKey = keys.find { it.hash.equals(scannedHash, ignoreCase = true) }
            ?: return VerificationResult.NotRegistered

        val primaryKey = keys.firstOrNull()
        val isPrimary = (primaryKey != null && matchedKey.id == primaryKey.id)

        if (requirePrimaryOnly && !isPrimary && primaryKey != null) {
            Log.w(TAG, "Scanned key '${matchedKey.label}' is secondary, but primary key '${primaryKey.label}' is required!")
            return VerificationResult.SecondaryKeyWhenPrimaryRequired(
                scannedKey = matchedKey,
                primaryKey = primaryKey
            )
        }

        Log.i(TAG, "QR Key verified successfully against key '${matchedKey.label}' (isPrimary: $isPrimary, total: ${keys.size})")
        return VerificationResult.Success(matchedKey, isPrimary)
    }

    fun setQrKeyProtectionEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    fun clearQrKey(context: Context) {
        getPrefs(context).edit()
            .putBoolean(KEY_ENABLED, false)
            .putString(KEY_KEYS_JSON, "[]")
            .remove(KEY_HASH)
            .remove(KEY_PREVIEW)
            .remove(KEY_KEY_LENGTH)
            .remove(KEY_REGISTERED_AT)
            .apply()
        Log.i(TAG, "Cleared all registered QR keys and disabled protection")
    }

    fun formatMaskedPreview(input: String): String {
        val clean = input.trim()
        if (clean.isBlank()) return "••••"
        if (clean.contains("••") || clean.contains("****")) {
            val parts = clean.split(Regex("[•\\*]+")).filter { it.isNotBlank() }
            val firstPart = parts.firstOrNull() ?: ""
            val lastPart = parts.lastOrNull() ?: ""
            val start = if (firstPart.isNotEmpty()) firstPart.take(2) else clean.take(2)
            val end = if (lastPart.isNotEmpty()) lastPart.takeLast(2) else clean.takeLast(2)
            return "$start••••$end"
        }
        return if (clean.length < 4) {
            val start = clean.take(1)
            val end = clean.takeLast(1)
            "$start••••$end"
        } else {
            val start = clean.take(2)
            val end = clean.takeLast(2)
            "$start••••$end"
        }
    }

    private fun makePreviewSnippet(raw: String): String {
        return formatMaskedPreview(raw)
    }

    fun hashString(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * محلل إطارات الكاميرا فائق السرعة والخفة لمسح QR Code عبر ZXing
     * يدعم حصراً رموز QR Code لتفادي أي التباس أو دعم لأنواع أخرى.
     */
    class ZxingQrBarcodeAnalyzer(
        private val onCodeScanned: (String) -> Unit
    ) : ImageAnalysis.Analyzer {

        private val reader = MultiFormatReader().apply {
            val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
                put(
                    DecodeHintType.POSSIBLE_FORMATS,
                    listOf(
                        BarcodeFormat.QR_CODE
                    )
                )
                put(DecodeHintType.TRY_HARDER, java.lang.Boolean.TRUE)
                put(DecodeHintType.CHARACTER_SET, "UTF-8")
            }
            setHints(hints)
        }

        @Volatile
        private var isScanningFinished = false

        override fun analyze(image: ImageProxy) {
            if (isScanningFinished) {
                try { image.close() } catch (_: Throwable) {}
                return
            }

            try {
                val planes = image.planes
                if (planes.isEmpty()) {
                    return
                }
                val plane = planes[0]
                val buffer: ByteBuffer = plane.buffer
                val data = ByteArray(buffer.remaining())
                buffer.get(data)

                val width = image.width
                val height = image.height

                try {
                    val source = PlanarYUVLuminanceSource(
                        data,
                        width,
                        height,
                        0,
                        0,
                        width,
                        height,
                        false
                    )
                    val bitmap = BinaryBitmap(HybridBinarizer(source))
                    val result = reader.decodeWithState(bitmap)
                    if (result != null && result.text.isNotBlank()) {
                        isScanningFinished = true
                        onCodeScanned(result.text)
                    }
                } catch (_: NotFoundException) {
                    // Try with rotated source if needed
                    try {
                        val rotatedSource = PlanarYUVLuminanceSource(
                            data,
                            width,
                            height,
                            0,
                            0,
                            width,
                            height,
                            false
                        ).invert()
                        val bitmap = BinaryBitmap(HybridBinarizer(rotatedSource))
                        val result = reader.decodeWithState(bitmap)
                        if (result != null && result.text.isNotBlank()) {
                            isScanningFinished = true
                            onCodeScanned(result.text)
                        }
                    } catch (_: Exception) {
                        // Ignore frame
                    }
                } catch (_: Exception) {
                    // Ignore decoding errors for intermediate blurry frames
                }
            } catch (_: Exception) {
                // Ignore plane extraction error
            } finally {
                try { reader.reset() } catch (_: Throwable) {}
                try { image.close() } catch (_: Throwable) {}
            }
        }
    }
}
