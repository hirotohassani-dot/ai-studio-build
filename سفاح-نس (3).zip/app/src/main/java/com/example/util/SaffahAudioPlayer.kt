package com.example.util

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

data class AudioPlaybackState(
    val isPlaying: Boolean = false,
    val currentFilePath: String? = null,
    val currentPositionMs: Int = 0,
    val durationMs: Int = 0
)

/**
 * مشغل صوتيات مدمج داخل التطبيق للاستماع الفوري للمذكرات والوسائط الصوتية
 */
class SaffahAudioPlayer(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private val _playbackState = MutableStateFlow(AudioPlaybackState())
    val playbackState: StateFlow<AudioPlaybackState> = _playbackState.asStateFlow()

    fun playAudio(filePath: String, onCompletion: () -> Unit = {}) {
        try {
            if (_playbackState.value.currentFilePath == filePath && mediaPlayer != null) {
                if (mediaPlayer?.isPlaying == true) {
                    pauseAudio()
                    return
                } else {
                    mediaPlayer?.start()
                    _playbackState.value = _playbackState.value.copy(isPlaying = true)
                    return
                }
            }

            stopAudio()
            val file = File(filePath)
            if (!file.exists()) {
                Log.e("SaffahAudioPlayer", "Audio file does not exist: $filePath")
                return
            }

            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, Uri.fromFile(file))
                prepare()
                setOnCompletionListener {
                    _playbackState.value = AudioPlaybackState(isPlaying = false, currentFilePath = null)
                    onCompletion()
                }
                start()
            }

            val duration = mediaPlayer?.duration ?: 0
            _playbackState.value = AudioPlaybackState(
                isPlaying = true,
                currentFilePath = filePath,
                currentPositionMs = 0,
                durationMs = duration
            )
        } catch (e: Exception) {
            Log.e("SaffahAudioPlayer", "Error playing audio: ${e.message}", e)
            stopAudio()
        }
    }

    fun pauseAudio() {
        try {
            mediaPlayer?.pause()
            _playbackState.value = _playbackState.value.copy(isPlaying = false)
        } catch (e: Exception) {
            Log.e("SaffahAudioPlayer", "Error pausing audio: ${e.message}")
        }
    }

    fun seekTo(positionMs: Int) {
        try {
            mediaPlayer?.seekTo(positionMs)
            _playbackState.value = _playbackState.value.copy(currentPositionMs = positionMs)
        } catch (e: Exception) {
            Log.e("SaffahAudioPlayer", "Error seeking audio: ${e.message}")
        }
    }

    fun updateProgress() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    _playbackState.value = _playbackState.value.copy(
                        currentPositionMs = it.currentPosition,
                        durationMs = it.duration
                    )
                }
            }
        } catch (e: Exception) {
            // Ignored
        }
    }

    fun stopAudio() {
        try {
            mediaPlayer?.apply {
                if (isPlaying) {
                    stop()
                }
                release()
            }
            mediaPlayer = null
            _playbackState.value = AudioPlaybackState()
        } catch (e: Exception) {
            Log.e("SaffahAudioPlayer", "Error stopping audio: ${e.message}")
            mediaPlayer = null
            _playbackState.value = AudioPlaybackState()
        }
    }
}
