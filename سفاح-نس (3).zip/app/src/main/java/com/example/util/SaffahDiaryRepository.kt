package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import com.example.model.DiaryMediaItem
import com.example.model.DiaryMediaSource
import com.example.model.DiaryMediaType
import com.example.model.RecoveryDiaryEntry
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

object SaffahDiaryRepository {

    private const val DIARIES_FILE = "recovery_diaries.json"
    private const val TRASH_FILE = "recovery_diaries_trash.json"

    private fun getMediaDirectory(context: Context): File {
        val dir = File(context.filesDir, "recovery_diaries/media")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        SaffahMediaCompressor.initSecurity(context)
        return dir
    }

    private fun getDiariesFile(context: Context): File {
        val parent = File(context.filesDir, "recovery_diaries")
        if (!parent.exists()) {
            parent.mkdirs()
        }
        return File(parent, DIARIES_FILE)
    }

    private fun getTrashFile(context: Context): File {
        val parent = File(context.filesDir, "recovery_diaries")
        if (!parent.exists()) {
            parent.mkdirs()
        }
        return File(parent, TRASH_FILE)
    }

    private fun parseEntriesFromFile(file: File): List<RecoveryDiaryEntry> {
        if (!file.exists()) return emptyList()

        return try {
            val jsonStr = file.readText()
            if (jsonStr.isBlank()) return emptyList()
            val array = JSONArray(jsonStr)
            val list = mutableListOf<RecoveryDiaryEntry>()

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.getString("id")
                val title = obj.optString("title", "")
                val content = obj.optString("content", "")
                val createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                val updatedAt = obj.optLong("updatedAt", createdAt)

                val mediaArray = obj.optJSONArray("mediaList") ?: JSONArray()
                val mediaList = mutableListOf<DiaryMediaItem>()

                for (j in 0 until mediaArray.length()) {
                    val mObj = mediaArray.getJSONObject(j)
                    val mId = mObj.getString("id")
                    val mTypeStr = mObj.getString("type")
                    val mSourceStr = mObj.getString("source")
                    val mPath = mObj.getString("filePath")
                    val mName = mObj.optString("fileName", "")
                    val mDuration = mObj.optInt("durationSeconds", 0)
                    val mSize = mObj.optLong("fileSizeBytes", 0L)
                    val mCreated = mObj.optLong("createdAt", createdAt)

                    val type = try {
                        DiaryMediaType.valueOf(mTypeStr)
                    } catch (e: Exception) {
                        DiaryMediaType.IMAGE
                    }

                    val source = try {
                        DiaryMediaSource.valueOf(mSourceStr)
                    } catch (e: Exception) {
                        DiaryMediaSource.UPLOADED_FROM_STORAGE
                    }

                    mediaList.add(
                        DiaryMediaItem(
                            id = mId,
                            type = type,
                            source = source,
                            filePath = mPath,
                            fileName = mName,
                            durationSeconds = mDuration,
                            fileSizeBytes = mSize,
                            createdAt = mCreated
                        )
                    )
                }

                val emotionsArray = obj.optJSONArray("emotions") ?: JSONArray()
                val emotionsList = mutableListOf<String>()
                for (k in 0 until emotionsArray.length()) {
                    val em = emotionsArray.optString(k, "")
                    if (em.isNotBlank()) {
                        emotionsList.add(em)
                    }
                }

                val entryType = obj.optString("type", "ملاحظة").ifBlank { "ملاحظة" }

                list.add(
                    RecoveryDiaryEntry(
                        id = id,
                        title = title,
                        content = content,
                        createdAt = createdAt,
                        updatedAt = updatedAt,
                        mediaList = mediaList,
                        emotions = emotionsList,
                        type = entryType
                    )
                )
            }
            list.sortedByDescending { it.createdAt }
        } catch (e: Exception) {
            Log.e("SaffahDiaryRepository", "Error reading diaries from ${file.name}: ${e.message}", e)
            emptyList()
        }
    }

    private fun writeEntriesToFile(file: File, list: List<RecoveryDiaryEntry>) {
        try {
            val array = JSONArray()
            for (entry in list) {
                val obj = JSONObject().apply {
                    put("id", entry.id)
                    put("title", entry.title)
                    put("content", entry.content)
                    put("createdAt", entry.createdAt)
                    put("updatedAt", entry.updatedAt)
                    put("type", entry.type.ifBlank { "ملاحظة" })

                    val mediaArray = JSONArray()
                    for (m in entry.mediaList) {
                        val mObj = JSONObject().apply {
                            put("id", m.id)
                            put("type", m.type.name)
                            put("source", m.source.name)
                            put("filePath", m.filePath)
                            put("fileName", m.fileName)
                            put("durationSeconds", m.durationSeconds)
                            put("fileSizeBytes", m.fileSizeBytes)
                            put("createdAt", m.createdAt)
                        }
                        mediaArray.put(mObj)
                    }
                    put("mediaList", mediaArray)

                    val emotionsArray = JSONArray()
                    for (em in entry.emotions) {
                        emotionsArray.put(em)
                    }
                    put("emotions", emotionsArray)
                }
                array.put(obj)
            }
            val tempFile = File(file.parentFile, "${file.name}.tmp")
            tempFile.writeText(array.toString(2))
            if (tempFile.exists()) {
                if (file.exists()) file.delete()
                tempFile.renameTo(file)
            }
        } catch (e: Exception) {
            Log.e("SaffahDiaryRepository", "Error saving diaries to ${file.name}: ${e.message}", e)
        }
    }

    /**
     * جلب كافة المذكرات النشطة مرتبة من الأحدث إلى الأقدم
     */
    @Synchronized
    fun getAllEntries(context: Context): List<RecoveryDiaryEntry> {
        return parseEntriesFromFile(getDiariesFile(context))
    }

    /**
     * استعادة أو حفظ قائمة المذكرات النشطة بالكامل من النسخة الاحتياطية
     */
    @Synchronized
    fun restoreAllEntries(context: Context, entries: List<RecoveryDiaryEntry>) {
        writeEntriesToFile(getDiariesFile(context), entries)
    }

    /**
     * استعادة مذكرات سلة المحذوفات بالكامل من النسخة الاحتياطية
     */
    @Synchronized
    fun restoreTrashEntries(context: Context, entries: List<RecoveryDiaryEntry>) {
        writeEntriesToFile(getTrashFile(context), entries)
    }

    /**
     * جلب مذكرات سلة المحذوفات
     */
    @Synchronized
    fun getTrashEntries(context: Context): List<RecoveryDiaryEntry> {
        return parseEntriesFromFile(getTrashFile(context)).sortedByDescending { it.updatedAt }
    }

    /**
     * حفظ أو تحديث مذكرة
     */
    @Synchronized
    fun saveEntry(context: Context, entry: RecoveryDiaryEntry) {
        val currentEntries = getAllEntries(context).toMutableList()
        val index = currentEntries.indexOfFirst { it.id == entry.id }

        if (index >= 0) {
            currentEntries[index] = entry.copy(updatedAt = System.currentTimeMillis())
        } else {
            currentEntries.add(0, entry)
        }

        writeEntriesToFile(getDiariesFile(context), currentEntries)
    }

    /**
     * نقل مذكرة إلى سلة المحذوفات مع الحفاظ على ملفات الوسائط
     */
    @Synchronized
    fun moveToTrash(context: Context, id: String) {
        val activeEntries = getAllEntries(context).toMutableList()
        val target = activeEntries.find { it.id == id } ?: return

        activeEntries.removeAll { it.id == id }
        writeEntriesToFile(getDiariesFile(context), activeEntries)

        val trashEntries = getTrashEntries(context).toMutableList()
        trashEntries.removeAll { it.id == id }
        trashEntries.add(0, target.copy(updatedAt = System.currentTimeMillis()))
        writeEntriesToFile(getTrashFile(context), trashEntries)
    }

    /**
     * استرجاع مذكرة من سلة المحذوفات إلى المذكرات النشطة
     */
    @Synchronized
    fun restoreEntry(context: Context, id: String) {
        val trashEntries = getTrashEntries(context).toMutableList()
        val target = trashEntries.find { it.id == id } ?: return

        trashEntries.removeAll { it.id == id }
        writeEntriesToFile(getTrashFile(context), trashEntries)

        val activeEntries = getAllEntries(context).toMutableList()
        activeEntries.removeAll { it.id == id }
        activeEntries.add(0, target.copy(updatedAt = System.currentTimeMillis()))
        writeEntriesToFile(getDiariesFile(context), activeEntries)
    }

    /**
     * حذف نهائي لمذكرة وحذف كافة ملفات الوسائط الخاصة بها من وحدة التخزين نهائياً بدون أي أثر
     */
    @Synchronized
    fun permanentlyDeleteEntry(context: Context, id: String) {
        val trashEntries = getTrashEntries(context).toMutableList()
        val activeEntries = getAllEntries(context).toMutableList()

        val target = trashEntries.find { it.id == id } ?: activeEntries.find { it.id == id }

        target?.mediaList?.forEach { media ->
            try {
                SaffahMediaCompressor.deleteMediaAndThumbnail(media.filePath)
            } catch (e: Exception) {
                Log.w("SaffahDiaryRepository", "Error deleting media file: ${e.message}")
            }
        }

        trashEntries.removeAll { it.id == id }
        writeEntriesToFile(getTrashFile(context), trashEntries)

        activeEntries.removeAll { it.id == id }
        writeEntriesToFile(getDiariesFile(context), activeEntries)
    }

    /**
     * إفراغ سلة المحذوفات بالكامل مع حذف كافة ملفات الوسائط التابعة لها نهائياً
     */
    @Synchronized
    fun emptyTrash(context: Context) {
        val trashEntries = getTrashEntries(context)
        trashEntries.forEach { entry ->
            entry.mediaList.forEach { media ->
                try {
                    SaffahMediaCompressor.deleteMediaAndThumbnail(media.filePath)
                } catch (e: Exception) {
                    Log.w("SaffahDiaryRepository", "Error deleting media file: ${e.message}")
                }
            }
        }
        writeEntriesToFile(getTrashFile(context), emptyList())
    }

    /**
     * حذف مذكرة (توجيهها إلى سلة المحذوفات افتراضياً)
     */
    @Synchronized
    fun deleteEntry(context: Context, id: String) {
        moveToTrash(context, id)
    }

    /**
     * إنشاء ملف جديد لالتقاط الصور داخل التطبيق
     */
    fun createInternalImageFile(context: Context): File {
        val dir = getMediaDirectory(context)
        return File(dir, "rec_image_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
    }

    /**
     * إنشاء ملف جديد لتسجيل الصوت داخل التطبيق
     */
    fun createInternalAudioFile(context: Context): File {
        val dir = getMediaDirectory(context)
        return File(dir, "rec_audio_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.m4a")
    }

    /**
     * إنشاء ملف جديد لتسجيل الفيديو داخل التطبيق
     */
    fun createInternalVideoFile(context: Context): File {
        val dir = getMediaDirectory(context)
        return File(dir, "rec_video_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.mp4")
    }

    /**
     * استيراد ملف خارجي ونسخه مع ضغطه بأقصى كفاءة إلى مجلد المذكرات الداخلي
     */
    suspend fun importMediaFromUri(
        context: Context,
        uri: Uri,
        type: DiaryMediaType,
        source: DiaryMediaSource = DiaryMediaSource.UPLOADED_FROM_STORAGE
    ): DiaryMediaItem? {
        return try {
            val contentResolver = context.contentResolver
            var fileName = "media_${System.currentTimeMillis()}"

            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) {
                    val name = cursor.getString(nameIndex)
                    if (!name.isNullOrBlank()) {
                        fileName = name
                    }
                }
            }

            val extension = when (type) {
                DiaryMediaType.AUDIO -> if (fileName.contains('.')) "" else ".mp3"
                DiaryMediaType.IMAGE -> ".jpg"
                DiaryMediaType.VIDEO -> if (fileName.contains('.')) "" else ".mp4"
            }

            val safeFileName = "${type.name.lowercase()}_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}${if (type != DiaryMediaType.IMAGE && fileName.contains('.')) fileName.substring(fileName.lastIndexOf('.')) else extension}"
            val destFile = File(getMediaDirectory(context), safeFileName)

            if (type == DiaryMediaType.IMAGE) {
                val compressed = SaffahMediaCompressor.compressImageFromUri(context, uri, destFile)
                if (!compressed) {
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(destFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                }
            } else {
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }

                if (type == DiaryMediaType.VIDEO) {
                    SaffahMediaCompressor.compressVideoFile(destFile)
                }
            }

            var durationSec = 0
            if (type == DiaryMediaType.VIDEO || type == DiaryMediaType.AUDIO) {
                try {
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(destFile.absolutePath)
                    val durStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                    retriever.release()
                    durationSec = ((durStr?.toLongOrNull() ?: 0L) / 1000L).toInt()
                } catch (_: Exception) {}
            }

            DiaryMediaItem(
                id = UUID.randomUUID().toString(),
                type = type,
                source = source,
                filePath = destFile.absolutePath,
                fileName = fileName,
                fileSizeBytes = destFile.length(),
                durationSeconds = durationSec,
                createdAt = System.currentTimeMillis()
            )
        } catch (e: Exception) {
            Log.e("SaffahDiaryRepository", "Error importing media: ${e.message}", e)
            null
        }
    }
}
