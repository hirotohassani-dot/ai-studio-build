package com.example.util

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Manages power/charging events, prevents unwanted system Do Not Disturb (DND) activations,
 * and eliminates floating volume panel popups triggered by charger connection.
 */
object SaffahChargingManager {

    private const val TAG = "SaffahCharging"

    @Volatile
    private var lastPowerConnectedTimestamp: Long = 0L

    @Volatile
    private var lastPowerDisconnectedTimestamp: Long = 0L

    /**
     * Called whenever a charger / power source is connected.
     */
    fun onPowerConnected(context: Context) {
        val now = SystemClock.elapsedRealtime()
        lastPowerConnectedTimestamp = now
        Log.i(TAG, "Charger connected. Enforcing DND neutrality and volume panel suppression...")

        // 1. Proactively disable OEM-specific triggers that force DND/Bedtime on charging
        disableOemChargingDndTriggers(context, force = true)

        // 2. Ensure system Do Not Disturb (zen_mode) is kept OFF unless intentionally scheduled
        ensureDndTurnedOffIfCharging(context)
    }

    /**
     * Called whenever charger / power source is disconnected.
     */
    fun onPowerDisconnected(context: Context) {
        lastPowerDisconnectedTimestamp = SystemClock.elapsedRealtime()
        Log.i(TAG, "Charger disconnected.")
        disableOemChargingDndTriggers(context, force = true)
    }

    /**
     * Returns true if charger was plugged in within the last 4 seconds.
     */
    fun isRecentPowerConnected(): Boolean {
        val diff = SystemClock.elapsedRealtime() - lastPowerConnectedTimestamp
        return diff in 0..4000L
    }

    @Volatile private var lastDisabledOemTriggersRealtime = 0L
    private const val OEM_TRIGGERS_THROTTLE_MS = 15 * 60 * 1000L // 15 minutes

    /**
     * Proactively cleans and disables any OEM (Realme UI / ColorOS / Samsung / Pixel) settings
     * that automatically turn on Bedtime Mode, Do Not Disturb, or mute sounds when the charger is connected.
     */
    fun disableOemChargingDndTriggers(context: Context, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && lastDisabledOemTriggersRealtime != 0L && (now - lastDisabledOemTriggersRealtime < OEM_TRIGGERS_THROTTLE_MS)) {
            return
        }
        lastDisabledOemTriggersRealtime = now
        val cr = context.contentResolver

        val secureKeys = arrayOf(
            "bedtime_mode_grayscale",
            "bedtime_mode_charging_state",
            "bedtime_mode_while_charging",
            "bedtime_mode_enabled",
            "bedtime_mode_activated",
            "oplus_customize_bedtime_charging",
            "coloros_bedtime_charging_enable",
            "zen_mode_charging"
        )

        for (key in secureKeys) {
            try {
                Settings.Secure.putInt(cr, key, 0)
            } catch (_: Exception) {}
        }

        val globalKeys = arrayOf(
            "zen_mode_charging",
            "dnd_when_charging",
            "bedtime_mode_charging_state",
            "bedtime_charging_trigger"
        )

        for (key in globalKeys) {
            try {
                Settings.Global.putInt(cr, key, 0)
            } catch (_: Exception) {}
        }

        val systemKeys = arrayOf(
            "coloros_bedtime_charging_enable",
            "oplus_bedtime_charging",
            "bedtime_mode_charging"
        )

        for (key in systemKeys) {
            try {
                Settings.System.putInt(cr, key, 0)
            } catch (_: Exception) {}
        }

        // Direct privileged/root/device-owner shell enforcement in background
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cmd = "settings put secure bedtime_mode_grayscale 0 && " +
                        "settings put secure bedtime_mode_charging_state 0 && " +
                        "settings put secure bedtime_mode_while_charging 0 && " +
                        "settings put global zen_mode_charging 0 && " +
                        "settings put secure oplus_customize_bedtime_charging 0"
                Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            } catch (_: Exception) {}
        }
    }

    /**
     * Checks if Do Not Disturb (zen_mode) was automatically enabled by the charger plug-in,
     * and forces it back to normal (ALL notifications / sound enabled).
     */
    fun ensureDndTurnedOffIfCharging(context: Context) {
        val cr = context.contentResolver

        try {
            val zenMode = Settings.Global.getInt(cr, "zen_mode", 0)
            if (zenMode != 0) {
                // System turned on DND automatically on charging! Turn it back off.
                try {
                    Settings.Global.putInt(cr, "zen_mode", 0)
                    Log.i(TAG, "Successfully reset unwanted zen_mode back to 0")
                } catch (_: Exception) {}

                try {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm?.isNotificationPolicyAccessGranted == true) {
                        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                    }
                } catch (_: Exception) {}

                // Execute shell command fallback
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put global zen_mode 0"))
                    } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking zen_mode: ${e.message}")
        }
    }

    /**
     * Smoothly dismisses the floating volume panel if it appeared automatically without user interaction
     * due to charging sound or ringer state switch.
     */
    fun dismissFloatingVolumePanelIfNeeded(service: AccessibilityService, eventPkg: String) {
        if (!isRecentPowerConnected()) return
        Log.i(TAG, "Suppressing unwanted floating volume panel from package: $eventPkg")

        // Gently dismiss by sending back action or letting it timeout without stealing focus
        try {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        } catch (e: Exception) {
            Log.w(TAG, "Could not dismiss volume panel: ${e.message}")
        }
    }
}
