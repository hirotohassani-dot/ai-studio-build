package com.example.util

import android.app.KeyguardManager
import android.content.Context
import android.graphics.Bitmap
import android.os.*
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

interface DetectorPrefs {
    val nudenetEnabled: Boolean
    val animeEnabled: Boolean
    val dryRun: Boolean
}

class LiveDetectorPrefs(private val context: Context) : DetectorPrefs {
    override val nudenetEnabled: Boolean get() = SaffahBlockRepository.isAiNudeNetEnabled(context)
    override val animeEnabled: Boolean get() = SaffahBlockRepository.isAiAnimeEnabled(context)
    override val dryRun: Boolean get() = SaffahBlockRepository.isAiDryRunEnabled(context)
}

// ---------------- shared scheduler (ONE loop for both models) ----------------
// Needs: android.content.Context, android.app.KeyguardManager, android.os.{Handler, HandlerThread, PowerManager, Process, SystemClock, Build}.
// capture wraps the app's EXISTING takeScreenshot code and must call back
// with a software ARGB_8888 bitmap with system bars cropped (or null on failure).
class FrameScheduler(
    ctx: Context,
    private val prefs: DetectorPrefs,        // existing settings holder: nudenetEnabled, animeEnabled, dryRun (Boolean, persisted)
    private val nudeProvider: () -> NudeNetDetector?,
    private val animeProvider: () -> AnimeRatingDetector?,
    private val capture: ((Bitmap?) -> Unit) -> Unit,
    private val isIgnoredForeground: () -> Boolean,
    private val onViolation: (reason: String, dryRun: Boolean) -> Unit
) {
    data class SchedulerDebugState(
        val mode: String = "IDLE", // ACTIVE / IDLE / SUSPECT
        val lastWorkMs: Long = 0L,
        val nextDelayMs: Long = 1000L,
        val unchangedTicks: Int = 0,
        val suspectLeft: Int = 0,
        val burstCooldown: Int = 0,
        val forceTicks: Int = 0,
        val sweepPending: Boolean = false,
        val timestamp: Long = 0L
    )

    companion object {
        private val _globalDebugState = MutableStateFlow(SchedulerDebugState())
        val globalDebugState: StateFlow<SchedulerDebugState> = _globalDebugState.asStateFlow()
    }

    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    private val thread = HandlerThread("frame-analyzer", Process.THREAD_PRIORITY_BACKGROUND).also { it.start() }
    private val handler = Handler(thread.looper)
    private var running = false
    private var lastThumb: ByteArray? = null
    private var unchanged = 0
    private var lastWorkMs = 0L
    private var suspectLeft = 0
    private var burstCooldown = 0
    private var forceTicks = 0
    private var sweepPending = false

    fun start() { if (!running) { running = true; handler.post { tick() } } }
    fun stop() { running = false; handler.removeCallbacksAndMessages(null) }

    private fun tick() {
        if (!running) return
        val idleOff = !(prefs.nudenetEnabled || prefs.animeEnabled) || !pm.isInteractive ||
            km.isKeyguardLocked || isIgnoredForeground()
        if (idleOff) {
            _globalDebugState.value = _globalDebugState.value.copy(
                mode = "PAUSED / IDLE",
                timestamp = SystemClock.elapsedRealtime()
            )
            handler.postDelayed({ tick() }, 1500L)
            return
        }      // no capture at all
        capture { bmp -> handler.post { analyze(bmp) } }
    }

    private fun analyze(bmp: Bitmap?) {
        val t0 = SystemClock.elapsedRealtime()
        var suspect = false
        var ranInference = false
        try {
            if (bmp != null) {
                val th = thumb(bmp)
                val changed = lastThumb?.let { diff(it, th) >= 2.0f } ?: true
                lastThumb = th
                unchanged = if (changed) 0 else unchanged + 1
                val nude = nudeProvider()
                if (changed) nude?.onContentChanged()
                val skip = !changed && suspectLeft == 0 && !sweepPending && forceTicks == 0
                if (!skip) {
                    if (forceTicks > 0) forceTicks--
                    val thermalOk = thermalStatus() < PowerManager.THERMAL_STATUS_MODERATE && !pm.isPowerSaveMode
                    var violated = false; var reason = ""
                    if (prefs.nudenetEnabled && nude != null) {
                        val o = nude.process(bmp, t0, thermalOk)
                        sweepPending = o?.sweepPending ?: false
                        if (o != null) {
                            ranInference = true
                            SaffahNudeNetClassifier.updateLiveDebug(o, nude, t0)
                            if (o.suspect) suspect = true
                            if (o.trigger) { violated = true; reason = "NUDENET " + o.summary.lastOrNull().orEmpty() }
                        }
                    } else {
                        sweepPending = false
                    }
                    val anime = animeProvider()
                    if (prefs.animeEnabled && !violated && anime != null) {
                        val o = SaffahAnimeClassifier.process(bmp, t0)
                        if (o != null) {
                            ranInference = true
                            if (o.framePositive || o.probs.any { it[1] + it[2] >= 0.60f }) suspect = true
                            if (o.trigger) {
                                violated = true
                                reason = "ANIME " + o.probs.joinToString { "r15=%.2f r18=%.2f".format(it[1], it[2]) }
                            }
                        }
                    }
                    if (violated) {
                        nude?.resetHistory(); anime?.resetHistory(); forceTicks = 2
                        onViolation(reason, prefs.dryRun)
                    }
                }
            }
        } catch (e: Throwable) {
            Log.w("FrameScheduler", "Fail-open exception in analyzer: ${e.message}", e)
        } finally {
            bmp?.recycle()      // scheduler owns the bitmap; detectors never recycle it
        }
        if (ranInference) lastWorkMs = SystemClock.elapsedRealtime() - t0
        if (burstCooldown > 0) burstCooldown--
        if (suspectLeft > 0) suspectLeft--
        else if (suspect && burstCooldown == 0) { suspectLeft = 3; burstCooldown = 10 }
        
        val delay = nextDelay()
        _globalDebugState.value = SchedulerDebugState(
            mode = when {
                suspectLeft > 0 -> "SUSPECT"
                unchanged >= 3 -> "IDLE"
                else -> "ACTIVE"
            },
            lastWorkMs = lastWorkMs,
            nextDelayMs = delay,
            unchangedTicks = unchanged,
            suspectLeft = suspectLeft,
            burstCooldown = burstCooldown,
            forceTicks = forceTicks,
            sweepPending = sweepPending,
            timestamp = SystemClock.elapsedRealtime()
        )
        if (running) handler.postDelayed({ tick() }, delay)
    }

    private fun nextDelay(): Long {
        var next = when {
            suspectLeft > 0 -> 400L
            unchanged >= 3 -> 2000L
            prefs.nudenetEnabled && prefs.animeEnabled -> 1000L
            else -> 800L
        }
        val factor = if (suspectLeft > 0) 1.5 else 3.0
        next = maxOf(next, (factor * lastWorkMs).toLong())
        val ts = thermalStatus()
        if (ts >= PowerManager.THERMAL_STATUS_SEVERE) next = 4000L
        else if (ts >= PowerManager.THERMAL_STATUS_MODERATE) next *= 2
        if (pm.isPowerSaveMode) next *= 2
        return next.coerceIn(400L, 8000L)
    }

    private fun thermalStatus(): Int =
        if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else 0

    private fun thumb(b: Bitmap): ByteArray {
        val s = Bitmap.createScaledBitmap(b, 32, 32, true)
        val p = IntArray(1024)
        s.getPixels(p, 0, 32, 0, 0, 32, 32)
        if (s !== b) s.recycle()
        return ByteArray(1024) { i ->
            val c = p[i]
            (0.299 * ((c shr 16) and 0xFF) + 0.587 * ((c shr 8) and 0xFF) + 0.114 * (c and 0xFF)).toInt().toByte()
        }
    }

    private fun diff(a: ByteArray, b: ByteArray): Float {
        var s = 0
        for (i in a.indices) s += abs((a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF))
        return s / a.size.toFloat()
    }
}
