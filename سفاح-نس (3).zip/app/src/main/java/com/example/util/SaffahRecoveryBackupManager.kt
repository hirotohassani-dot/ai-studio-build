package com.example.util

import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * محرك النسخ الاحتياطي والاستعادة الشامل لمركز التعافي (Recovery Center Full Backup Engine)
 * - يدمج ويحفظ كافة البيانات: الإحصائيات، سجل الانتكاسات، نوبات الشوق، اليوميات، الميثاق، الفحوصات
 * - يدمج ويؤرشف كافة الوسائط: الصور، مقاطع الفيديو، التسجيلات الصوتية (مذكرات، ميثاق، محطات، إلحاح)
 * - حزمة واحدة بصيغة ZIP مشفرة/مضغوطة خفيفة وسريعة مع معالجة ذكية للأخطاء وحماية ضد انهيار الذاكرة
 * - إعادة توجيه وتصحيح المسارات تلقائياً عند الاستيراد على أي هاتف أو بعد إعادة التثبيت
 */
object SaffahRecoveryBackupManager {

    private const val TAG = "SaffahRecoveryBackup"
    private const val PREFS_BACKUP = "saffah_recovery_backup_prefs"
    private const val KEY_LAST_BACKUP_TIME = "last_recovery_backup_timestamp"
    private const val KEY_LAST_BACKUP_DATE_STR = "last_recovery_backup_date_str"

    private const val BUFFER_SIZE = 65536 // 64 KB streaming buffer

    private fun getBackupPrefs(context: Context) =
        context.getSharedPreferences(PREFS_BACKUP, Context.MODE_PRIVATE)

    /**
     * استخراج ملخص شامل وإحصائيات دقيقة لمركز التعافي قبل النسخ الاحتياطي
     */
    fun getRecoveryBackupSummary(context: Context): RecoveryBackupSummary {
        val stats = SaffahRecoveryManager.getRecoveryStats(context)
        val analytics = SaffahRecoveryManager.getRecoveryAnalytics(context)
        val totalPureDays = analytics.purityMetrics.totalPureDays
        val relapses = SaffahRecoveryManager.getRelapseHistory(context)
        val urges = SaffahRecoveryManager.getUrgeHistory(context)
        val activeDiaries = SaffahDiaryRepository.getAllEntries(context)
        val trashDiaries = SaffahDiaryRepository.getTrashEntries(context)
        val pledge = SaffahRecoveryManager.getRecoveryPledge(context)

        var imagesCount = 0
        var videosCount = 0
        var audiosCount = 0
        var totalMediaSizeBytes = 0L

        fun inspectMedia(item: DiaryMediaItem) {
            when (item.type) {
                DiaryMediaType.IMAGE -> imagesCount++
                DiaryMediaType.VIDEO -> videosCount++
                DiaryMediaType.AUDIO -> audiosCount++
            }
            if (item.fileSizeBytes > 0L) {
                totalMediaSizeBytes += item.fileSizeBytes
            } else {
                try {
                    val f = File(item.filePath)
                    if (f.exists()) totalMediaSizeBytes += f.length()
                } catch (_: Exception) {}
            }
        }

        for (d in activeDiaries) {
            for (m in d.mediaList) inspectMedia(m)
        }
        for (d in trashDiaries) {
            for (m in d.mediaList) inspectMedia(m)
        }

        // Pledge video
        if (pledge.videoPath.isNotBlank()) {
            videosCount++
            try {
                val f = File(pledge.videoPath)
                if (f.exists()) totalMediaSizeBytes += f.length()
            } catch (_: Exception) {}
        }

        // Milestone media
        var milestoneMediaCount = 0
        val milestoneDir = File(context.filesDir, "milestone_media")
        if (milestoneDir.exists()) {
            val recordsFile = File(milestoneDir, "milestone_media_records.json")
            if (recordsFile.exists()) {
                try {
                    val root = JSONObject(recordsFile.readText())
                    val keys = root.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val arr = root.getJSONArray(k)
                        milestoneMediaCount += arr.length()
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            val typeStr = obj.optString("type", "AUDIO")
                            val size = obj.optLong("fileSizeBytes", 0L)
                            totalMediaSizeBytes += size
                            if (typeStr == DiaryMediaType.VIDEO.name) videosCount++ else audiosCount++
                        }
                    }
                } catch (_: Exception) {}
            }
        }

        // Urge recordings in filesDir
        try {
            val urgeAudioFiles = context.filesDir.listFiles { _, name ->
                name.startsWith("urge_rec_") && name.endsWith(".m4a")
            }
            if (urgeAudioFiles != null) {
                for (f in urgeAudioFiles) {
                    audiosCount++
                    totalMediaSizeBytes += f.length()
                }
            }
        } catch (_: Exception) {}

        val prefs = getBackupPrefs(context)
        val lastTimestamp = prefs.getLong(KEY_LAST_BACKUP_TIME, 0L)
        val lastFormatted = prefs.getString(KEY_LAST_BACKUP_DATE_STR, null)

        val currentStreakDays = ((System.currentTimeMillis() - stats.startTimestamp) / 86400000L).toInt().coerceAtLeast(0)

        val calendarHistory = SaffahRecoveryManager.getRecoveryCalendarHistory(context)
        val calendarDaysCount = calendarHistory.values.count { it != DailyCalendarStatus.NONE }

        return RecoveryBackupSummary(
            currentStreakDays = currentStreakDays,
            totalPureDays = totalPureDays,
            relapsesCount = relapses.size,
            urgesCount = urges.size,
            diariesCount = activeDiaries.size,
            diariesTrashCount = trashDiaries.size,
            imagesCount = imagesCount,
            videosCount = videosCount,
            audiosCount = audiosCount,
            milestoneMediaCount = milestoneMediaCount,
            calendarDaysCount = calendarDaysCount,
            isPledgeSigned = pledge.isSigned,
            totalMediaSizeBytes = totalMediaSizeBytes,
            lastBackupFormatted = lastFormatted,
            lastBackupTimestamp = lastTimestamp
        )
    }

    /**
     * تصدير النسخة الاحتياطية الشاملة الكاملة لمركز التعافي إلى ملف ZIP
     */
    fun exportRecoveryFullBackup(context: Context, destinationUri: Uri): Result<RecoveryBackupResult> {
        return try {
            val summary = getRecoveryBackupSummary(context)
            val now = System.currentTimeMillis()
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val formattedDate = sdf.format(Date(now))

            val outStream = context.contentResolver.openOutputStream(destinationUri)
                ?: return Result.failure(IOException("تعذر فتح مسار الحفظ المحدد على الهاتف."))

            var totalFilesArchived = 0
            var totalBytesWritten = 0L

            ZipOutputStream(BufferedOutputStream(outStream, BUFFER_SIZE)).use { zipOut ->
                zipOut.setLevel(Deflater.BEST_SPEED)

                val addedZipEntries = mutableSetOf<String>()

                fun addFileToZip(sourceFile: File, zipEntryPath: String): Boolean {
                    if (!sourceFile.exists() || !sourceFile.isFile || sourceFile.length() <= 0L) return false
                    if (addedZipEntries.contains(zipEntryPath)) return false

                    try {
                        val entry = ZipEntry(zipEntryPath).apply {
                            time = sourceFile.lastModified()
                        }
                        zipOut.putNextEntry(entry)
                        FileInputStream(sourceFile).use { input ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            var read: Int
                            while (input.read(buffer).also { read = it } != -1) {
                                zipOut.write(buffer, 0, read)
                                totalBytesWritten += read
                            }
                        }
                        zipOut.closeEntry()
                        addedZipEntries.add(zipEntryPath)
                        totalFilesArchived++
                        return true
                    } catch (e: Exception) {
                        Log.w(TAG, "Skipping file in backup: ${sourceFile.name} (${e.message})")
                        return false
                    }
                }

                // 1. الأرشفة الذكية لوسائط المذكرات (صور، فيديو، صوت)
                val activeDiaries = SaffahDiaryRepository.getAllEntries(context)
                val trashDiaries = SaffahDiaryRepository.getTrashEntries(context)
                val relapses = SaffahRecoveryManager.getRelapseHistory(context)

                fun processDiaryListForExport(list: List<RecoveryDiaryEntry>): JSONArray {
                    val array = JSONArray()
                    for (entry in list) {
                        val obj = JSONObject().apply {
                            put("id", entry.id)
                            put("title", entry.title)
                            put("content", entry.content)
                            put("createdAt", entry.createdAt)
                            put("updatedAt", entry.updatedAt)
                            put("type", entry.type.ifBlank { "ملاحظة" })

                            val mediaArray = JSONArray()
                            for (m in entry.mediaList) {
                                val originalFile = File(m.filePath)
                                val relativeZipPath = "media/diaries/${originalFile.name}"
                                if (originalFile.exists()) {
                                    addFileToZip(originalFile, relativeZipPath)
                                    // إذا وُجدت صورة مصغرة أضفها
                                    val thumbFile = SaffahMediaCompressor.getThumbnailFile(context, m.filePath)
                                    if (thumbFile.exists()) {
                                        addFileToZip(thumbFile, "media/diaries_thumbnails/${thumbFile.name}")
                                    }
                                }

                                val mObj = JSONObject().apply {
                                    put("id", m.id)
                                    put("type", m.type.name)
                                    put("source", m.source.name)
                                    put("filePath", relativeZipPath) // Relative path inside ZIP
                                    put("fileName", m.fileName)
                                    put("durationSeconds", m.durationSeconds)
                                    put("fileSizeBytes", if (originalFile.exists()) originalFile.length() else m.fileSizeBytes)
                                    put("createdAt", m.createdAt)
                                }
                                mediaArray.put(mObj)
                            }
                            put("mediaList", mediaArray)

                            val emotionsArray = JSONArray()
                            for (em in entry.emotions) emotionsArray.put(em)
                            put("emotions", emotionsArray)
                        }
                        array.put(obj)
                    }
                    return array
                }

                val activeDiariesJson = processDiaryListForExport(activeDiaries)
                val trashDiariesJson = processDiaryListForExport(trashDiaries)

                // 2. أرشفة وسائط محطات خريطة التعافي (Milestone Media)
                val milestoneMediaRoot = JSONObject()
                val milestoneDir = File(context.filesDir, "milestone_media")
                if (milestoneDir.exists()) {
                    val recordsFile = File(milestoneDir, "milestone_media_records.json")
                    if (recordsFile.exists()) {
                        try {
                            val originalRecords = JSONObject(recordsFile.readText())
                            val keys = originalRecords.keys()
                            while (keys.hasNext()) {
                                val dayKey = keys.next()
                                val arr = originalRecords.getJSONArray(dayKey)
                                val updatedArr = JSONArray()
                                for (i in 0 until arr.length()) {
                                    val mObj = arr.getJSONObject(i)
                                    val fPath = mObj.getString("filePath")
                                    val f = File(fPath)
                                    val relativePath = "media/milestones/${f.name}"
                                    if (f.exists()) {
                                        addFileToZip(f, relativePath)
                                        val thumbFile = SaffahMediaCompressor.getThumbnailFile(context, fPath)
                                        if (thumbFile.exists()) {
                                            addFileToZip(thumbFile, "media/milestones_thumbnails/${thumbFile.name}")
                                        }
                                    }
                                    val cloneObj = JSONObject(mObj.toString()).apply {
                                        put("filePath", relativePath)
                                    }
                                    updatedArr.put(cloneObj)
                                }
                                milestoneMediaRoot.put(dayKey, updatedArr)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error packaging milestone records: ${e.message}")
                        }
                    }
                }

                // 3. أرشفة فيديو ميثاق التعافي (Pledge Video)
                val pledge = SaffahRecoveryManager.getRecoveryPledge(context)
                var relativePledgeVideoPath = ""
                if (pledge.videoPath.isNotBlank()) {
                    val pFile = File(pledge.videoPath)
                    if (pFile.exists()) {
                        relativePledgeVideoPath = "media/pledge/${pFile.name}"
                        addFileToZip(pFile, relativePledgeVideoPath)
                    }
                }

                val pledgeJson = JSONObject().apply {
                    put("pledgeText", pledge.pledgeText)
                    put("isSigned", pledge.isSigned)
                    put("signedDate", pledge.signedDate)
                    put("signedTime", pledge.signedTime)
                    put("signedTimestamp", pledge.signedTimestamp)
                    put("signaturePointsJson", pledge.signaturePointsJson)
                    put("videoPath", relativePledgeVideoPath)
                    put("signerName", pledge.signerName)
                }

                // 4. أرشفة تسجيلات نوبات الرغبة والشوق الصوتية (Urge Audio Recordings)
                val urgeHistory = SaffahRecoveryManager.getUrgeHistory(context)
                val urgeHistoryJson = JSONArray()
                for (u in urgeHistory) {
                    var relativeAudioPath = ""
                    if (!u.audioPath.isNullOrBlank()) {
                        val aFile = File(u.audioPath)
                        if (aFile.exists()) {
                            relativeAudioPath = "media/urges/${aFile.name}"
                            addFileToZip(aFile, relativeAudioPath)
                        }
                    }
                    val uObj = JSONObject().apply {
                        put("id", u.id)
                        put("timestamp", u.timestamp)
                        put("intensity", u.intensity.id)
                        put("trigger", u.trigger.id)
                        put("technique", u.technique.id)
                        put("durationMinutes", u.durationMinutes)
                        put("resistedSuccessfully", u.resistedSuccessfully)
                        put("note", u.note)
                        put("customTechnique", u.customTechnique)
                        put("customTrigger", u.customTrigger)
                        if (relativeAudioPath.isNotBlank()) {
                            put("audioPath", relativeAudioPath)
                        }
                    }
                    urgeHistoryJson.put(uObj)
                }

                // Also archive any remaining urge recording files in filesDir
                try {
                    val urgeFiles = context.filesDir.listFiles { _, name ->
                        name.startsWith("urge_rec_") && name.endsWith(".m4a")
                    }
                    if (urgeFiles != null) {
                        for (uf in urgeFiles) {
                            addFileToZip(uf, "media/urges/${uf.name}")
                        }
                    }
                } catch (_: Exception) {}

                // 5. بناء ملف البيانات المركزي recovery_data.json
                val recoveryDataRoot = JSONObject().apply {
                    put("formatVersion", 2)
                    put("timestamp", now)
                    put("backupDate", formattedDate)

                    // Stats
                    val stats = SaffahRecoveryManager.getRecoveryStats(context)
                    val statsObj = JSONObject().apply {
                        put("startTimestamp", stats.startTimestamp)
                        put("firstEverStartTimestamp", SaffahRecoveryManager.getFirstEverStartTime(context))
                        put("relapseCount", stats.relapseCount)
                        put("longestStreakSeconds", stats.longestStreakSeconds)
                        put("userName", SaffahRecoveryManager.getUserName(context))
                    }
                    put("stats", statsObj)

                    // Relapse History
                    val relapseArray = JSONArray()
                    for (r in relapses) {
                        val rObj = JSONObject().apply {
                            put("id", r.id)
                            put("timestamp", r.timestamp)
                            put("note", r.note)
                            put("triggerId", r.triggerId)
                            put("defenseAction", r.defenseAction)
                            put("initialSpark", r.initialSpark)
                            put("loopholeType", r.loopholeType)
                            put("haltMoodState", r.haltMoodState)
                            put("preventiveDecision", r.preventiveDecision)
                        }
                        relapseArray.put(rObj)
                    }
                    put("relapseHistory", relapseArray)

                    // Urge History
                    put("urgeHistory", urgeHistoryJson)

                    // Custom Techniques & Triggers
                    put("customTechniques", JSONArray(SaffahRecoveryManager.getCustomDefenseTechniques(context)))
                    put("customTriggers", JSONArray(SaffahRecoveryManager.getCustomTriggers(context)))

                    // Dopamine Bio Checks
                    val bioChecks = SaffahRecoveryManager.getBioChecks(context)
                    val bioArray = JSONArray()
                    for (b in bioChecks) {
                        val bObj = JSONObject().apply {
                            put("id", b.id)
                            put("dateKey", b.dateKey)
                            put("timestamp", b.timestamp)
                            put("brainClarityScore", b.brainClarityScore)
                            put("moodStabilityScore", b.moodStabilityScore)
                            put("sleepQualityScore", b.sleepQualityScore)
                            put("vitalEnergyScore", b.vitalEnergyScore)
                            put("note", b.note)
                        }
                        bioArray.put(bObj)
                    }
                    put("dopamineBio", bioArray)

                    // Daily Baseline History
                    val baselineHistory = SaffahRecoveryManager.getDailyBaselineHistory(context)
                    val baselineArray = JSONArray()
                    for (base in baselineHistory) {
                        val baseObj = JSONObject().apply {
                            put("id", base.id)
                            put("timestamp", base.timestamp)
                            put("dateKey", base.dateKey)
                            put("clarityOfMind", base.clarityOfMind)
                            put("moodStability", base.moodStability)
                            put("sleepQuality", base.sleepQuality)
                            put("energyAndMotivation", base.energyAndMotivation)
                        }
                        baselineArray.put(baseObj)
                    }
                    put("dailyBaseline", baselineArray)

                    // Pledge
                    put("pledge", pledgeJson)

                    // Urge 15-Minute Rule Preferences
                    val urgePrefsObj = JSONObject().apply {
                        put("isUrgeFeatureEnabled", SaffahUrgeManager.isUrgeFeatureEnabled(context))
                    }
                    put("urgePrefs", urgePrefsObj)

                    // Diaries & Trash
                    put("diaries", activeDiariesJson)
                    put("diariesTrash", trashDiariesJson)

                    // Milestone Media Records
                    put("milestoneMedia", milestoneMediaRoot)

                    // Recovery Tracking Calendar
                    val calendarHistoryMap = SaffahRecoveryManager.getRecoveryCalendarHistory(context)
                    val calendarHistoryObj = JSONObject()
                    for ((k, v) in calendarHistoryMap) {
                        calendarHistoryObj.put(k, v.id)
                    }
                    put("calendarHistory", calendarHistoryObj)
                }

                // إضافة recovery_data.json للأرشيف
                val dataBytes = recoveryDataRoot.toString(2).toByteArray(Charsets.UTF_8)
                val dataEntry = ZipEntry("recovery_data.json").apply {
                    time = now
                    size = dataBytes.size.toLong()
                }
                zipOut.putNextEntry(dataEntry)
                zipOut.write(dataBytes)
                zipOut.closeEntry()
                totalBytesWritten += dataBytes.size
                totalFilesArchived++

                // إضافة recovery_manifest.json (بيانات الفهرسة السريعة)
                val manifestObj = JSONObject().apply {
                    put("type", "SAFFAH_RECOVERY_FULL_BACKUP")
                    put("version", 2)
                    put("appName", "السَّفاح (Saffah Protection)")
                    put("applicationId", context.packageName)
                    put("backupTimestamp", now)
                    put("backupDate", formattedDate)
                    put("deviceModel", "${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})")
                    put("diariesCount", activeDiaries.size)
                    put("diariesTrashCount", trashDiaries.size)
                    put("relapsesCount", relapses.size)
                    put("urgesCount", urgeHistory.size)
                    put("totalMediaFilesArchived", addedZipEntries.size)
                    put("isPledgeSigned", pledge.isSigned)
                }
                val manifestBytes = manifestObj.toString(2).toByteArray(Charsets.UTF_8)
                val manifestEntry = ZipEntry("recovery_manifest.json").apply {
                    time = now
                    size = manifestBytes.size.toLong()
                }
                zipOut.putNextEntry(manifestEntry)
                zipOut.write(manifestBytes)
                zipOut.closeEntry()
                totalBytesWritten += manifestBytes.size
                totalFilesArchived++

                zipOut.finish()
            }

            // تحديث بيانات آخر نسخة محفوظة
            getBackupPrefs(context).edit()
                .putLong(KEY_LAST_BACKUP_TIME, now)
                .putString(KEY_LAST_BACKUP_DATE_STR, formattedDate)
                .apply()

            Result.success(
                RecoveryBackupResult(
                    totalFilesArchived = totalFilesArchived,
                    totalBytesWritten = totalBytesWritten,
                    backupDateFormatted = formattedDate,
                    summary = summary
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error exporting full recovery backup: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * استيراد واستعادة النسخة الاحتياطية الشاملة بالكامل بكل أمان وسلاسة
     */
    fun importRecoveryFullBackup(context: Context, sourceUri: Uri): Result<RecoveryRestoreResult> {
        return try {
            val inStream = context.contentResolver.openInputStream(sourceUri)
                ?: return Result.failure(IOException("تعذر قراءة ملف النسخة الاحتياطية المحدد."))

            val bufferedIn = BufferedInputStream(inStream, BUFFER_SIZE)

            // فحص توقيع الملف (ZIP Magic: PK\x03\x04 vs JSON text)
            bufferedIn.mark(8)
            val header = ByteArray(4)
            val readLen = bufferedIn.read(header)
            bufferedIn.reset()

            val isZip = readLen == 4 &&
                    header[0] == 0x50.toByte() &&
                    header[1] == 0x4B.toByte() &&
                    header[2] == 0x03.toByte() &&
                    header[3] == 0x04.toByte()

            if (isZip) {
                restoreFromZipStream(context, bufferedIn)
            } else {
                restoreFromJsonStream(context, bufferedIn)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error importing recovery backup: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * استعادة حزمة ZIP كاملة (تحتوي على recovery_data.json وكافة مجلدات الوسائط)
     */
    private fun restoreFromZipStream(context: Context, inputStream: InputStream): Result<RecoveryRestoreResult> {
        var recoveryDataJsonStr: String? = null
        val extractedFiles = mutableListOf<File>()

        val mediaDir = File(context.filesDir, "recovery_diaries/media").apply { if (!exists()) mkdirs() }
        val thumbsDir = File(context.filesDir, "recovery_diaries/thumbnails").apply { if (!exists()) mkdirs() }
        val milestoneDir = File(context.filesDir, "milestone_media").apply { if (!exists()) mkdirs() }
        val milestoneThumbsDir = File(context.filesDir, "milestone_media/thumbnails").apply { if (!exists()) mkdirs() }
        val pledgeDir = File(context.filesDir, "recovery_pledge").apply { if (!exists()) mkdirs() }

        var imagesExtracted = 0
        var videosExtracted = 0
        var audiosExtracted = 0

        ZipInputStream(BufferedInputStream(inputStream, BUFFER_SIZE)).use { zipIn ->
            var entry: ZipEntry? = zipIn.nextEntry
            while (entry != null) {
                val entryName = entry.name

                // حماية أمنية لمنع ثغرة ZipSlip (عدم السماح بالخروج من مجلد التطبيق)
                if (entryName.contains("..") || entryName.startsWith("/") || entryName.startsWith("\\")) {
                    zipIn.closeEntry()
                    entry = zipIn.nextEntry
                    continue
                }

                if (entryName == "recovery_data.json") {
                    val bout = ByteArrayOutputStream()
                    val buffer = ByteArray(BUFFER_SIZE)
                    var count: Int
                    while (zipIn.read(buffer).also { count = it } != -1) {
                        bout.write(buffer, 0, count)
                    }
                    recoveryDataJsonStr = bout.toString(Charsets.UTF_8.name())
                } else if (entryName.startsWith("media/diaries/")) {
                    val fName = File(entryName).name
                    if (fName.isNotBlank() && !entry.isDirectory) {
                        val destFile = File(mediaDir, fName)
                        writeZipEntryToFile(zipIn, destFile)
                        extractedFiles.add(destFile)
                        classifyExtractedMedia(fName, { imagesExtracted++ }, { videosExtracted++ }, { audiosExtracted++ })
                    }
                } else if (entryName.startsWith("media/diaries_thumbnails/")) {
                    val fName = File(entryName).name
                    if (fName.isNotBlank() && !entry.isDirectory) {
                        val destFile = File(thumbsDir, fName)
                        writeZipEntryToFile(zipIn, destFile)
                        extractedFiles.add(destFile)
                    }
                } else if (entryName.startsWith("media/milestones/")) {
                    val fName = File(entryName).name
                    if (fName.isNotBlank() && !entry.isDirectory) {
                        val destFile = File(milestoneDir, fName)
                        writeZipEntryToFile(zipIn, destFile)
                        extractedFiles.add(destFile)
                        classifyExtractedMedia(fName, { imagesExtracted++ }, { videosExtracted++ }, { audiosExtracted++ })
                    }
                } else if (entryName.startsWith("media/milestones_thumbnails/")) {
                    val fName = File(entryName).name
                    if (fName.isNotBlank() && !entry.isDirectory) {
                        val destFile = File(milestoneThumbsDir, fName)
                        writeZipEntryToFile(zipIn, destFile)
                        extractedFiles.add(destFile)
                    }
                } else if (entryName.startsWith("media/pledge/")) {
                    val fName = File(entryName).name
                    if (fName.isNotBlank() && !entry.isDirectory) {
                        val destFile = File(pledgeDir, fName)
                        writeZipEntryToFile(zipIn, destFile)
                        extractedFiles.add(destFile)
                        videosExtracted++
                    }
                } else if (entryName.startsWith("media/urges/")) {
                    val fName = File(entryName).name
                    if (fName.isNotBlank() && !entry.isDirectory) {
                        val destFile = File(context.filesDir, fName)
                        writeZipEntryToFile(zipIn, destFile)
                        extractedFiles.add(destFile)
                        audiosExtracted++
                    }
                }

                zipIn.closeEntry()
                entry = zipIn.nextEntry
            }
        }

        if (recoveryDataJsonStr.isNullOrBlank()) {
            return Result.failure(IOException("ملف النسخة الاحتياطية تالف أو لا يحتوي على recovery_data.json."))
        }

        return restoreParsedRecoveryData(
            context = context,
            dataRoot = JSONObject(recoveryDataJsonStr),
            imagesCount = imagesExtracted,
            videosCount = videosExtracted,
            audiosCount = audiosExtracted
        )
    }

    private fun classifyExtractedMedia(
        fileName: String,
        onImage: () -> Unit,
        onVideo: () -> Unit,
        onAudio: () -> Unit
    ) {
        val lower = fileName.lowercase()
        when {
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") -> onImage()
            lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".mov") || lower.endsWith(".webm") -> onVideo()
            lower.endsWith(".m4a") || lower.endsWith(".mp3") || lower.endsWith(".aac") || lower.endsWith(".wav") || lower.endsWith(".ogg") -> onAudio()
            else -> onImage()
        }
    }

    private fun writeZipEntryToFile(zipIn: ZipInputStream, destFile: File) {
        val parent = destFile.parentFile
        if (parent != null && !parent.exists()) {
            parent.mkdirs()
        }
        FileOutputStream(destFile).use { output ->
            val buffer = ByteArray(BUFFER_SIZE)
            var count: Int
            while (zipIn.read(buffer).also { count = it } != -1) {
                output.write(buffer, 0, count)
            }
        }
    }

    /**
     * استعادة من ملف JSON عادي في حال تم استيراد ملف نصي مباشر
     */
    private fun restoreFromJsonStream(context: Context, inputStream: InputStream): Result<RecoveryRestoreResult> {
        val jsonStr = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { it.readText() }
        val root = JSONObject(jsonStr)

        val dataRoot = if (root.has("recoveryCenter")) {
            root.getJSONObject("recoveryCenter")
        } else if (root.has("stats") || root.has("diaries")) {
            root
        } else {
            return Result.failure(IllegalArgumentException("الملف المختار ليس ملف نسخة احتياطية صالحاً لمركز التعافي."))
        }

        return restoreParsedRecoveryData(context, dataRoot, 0, 0, 0)
    }

    /**
     * تفريغ وإعادة بناء بيانات مركز التعافي وإعادة ربط المسارات المطلقة بدقة
     */
    private fun restoreParsedRecoveryData(
        context: Context,
        dataRoot: JSONObject,
        imagesCount: Int,
        videosCount: Int,
        audiosCount: Int
    ): Result<RecoveryRestoreResult> {
        val recoveryPrefs = context.getSharedPreferences("saffah_recovery_prefs", Context.MODE_PRIVATE)
        val editor = recoveryPrefs.edit()

        // 1. استعادة الإحصائيات الأساسية
        if (dataRoot.has("stats")) {
            val statsObj = dataRoot.getJSONObject("stats")
            val startTs = statsObj.optLong("startTimestamp", System.currentTimeMillis())
            val firstEverTs = statsObj.optLong("firstEverStartTimestamp", startTs)
            val relapses = statsObj.optInt("relapseCount", 0)
            val longestSec = statsObj.optLong("longestStreakSeconds", 0L)
            val userName = statsObj.optString("userName", "")

            editor.putLong("recovery_start_timestamp", startTs)
            editor.putLong("recovery_first_ever_start_timestamp", firstEverTs)
            editor.putInt("recovery_relapse_count", relapses)
            editor.putLong("recovery_longest_streak_seconds", longestSec)
            if (userName.isNotBlank()) {
                editor.putString("recovery_user_name", userName)
            }
        }

        // 2. استعادة سجل الانتكاسات
        var relapsesRestored = 0
        if (dataRoot.has("relapseHistory")) {
            val arr = dataRoot.getJSONArray("relapseHistory")
            editor.putString("recovery_relapse_history_json", arr.toString())
            relapsesRestored = arr.length()
        }

        // 3. استعادة سجل نوبات الشوق والإلحاح (مع تصحيح مسار الصوت إن وُجد)
        var urgesRestored = 0
        if (dataRoot.has("urgeHistory")) {
            val arr = dataRoot.getJSONArray("urgeHistory")
            val updatedUrges = JSONArray()
            for (i in 0 until arr.length()) {
                val uObj = arr.getJSONObject(i)
                val relAudio = uObj.optString("audioPath", "")
                if (relAudio.isNotBlank()) {
                    val fileName = File(relAudio).name
                    val absoluteAudioFile = File(context.filesDir, fileName)
                    if (absoluteAudioFile.exists()) {
                        uObj.put("audioPath", absoluteAudioFile.absolutePath)
                    }
                }
                updatedUrges.put(uObj)
            }
            editor.putString("recovery_urge_history_json", updatedUrges.toString())
            urgesRestored = updatedUrges.length()
        }

        // 4. استعادة الأساليب والمحفزات والفحوصات
        if (dataRoot.has("customTechniques")) {
            editor.putString("recovery_custom_defense_techniques_json", dataRoot.getJSONArray("customTechniques").toString())
        }
        if (dataRoot.has("customTriggers")) {
            editor.putString("recovery_custom_triggers_json", dataRoot.getJSONArray("customTriggers").toString())
        }
        if (dataRoot.has("dopamineBio")) {
            editor.putString("recovery_dopamine_bio_json", dataRoot.getJSONArray("dopamineBio").toString())
        }
        if (dataRoot.has("dailyBaseline")) {
            editor.putString("recovery_daily_baseline_json", dataRoot.getJSONArray("dailyBaseline").toString())
        }

        // 5. استعادة ميثاق وعهد التعافي
        var pledgeRestored = false
        if (dataRoot.has("pledge")) {
            val pObj = dataRoot.getJSONObject("pledge")
            val relVideo = pObj.optString("videoPath", "")
            if (relVideo.isNotBlank()) {
                val pFileName = File(relVideo).name
                val absFile = File(context.filesDir, "recovery_pledge/$pFileName")
                if (absFile.exists()) {
                    pObj.put("videoPath", absFile.absolutePath)
                }
            }
            editor.putString("recovery_pledge_document_json", pObj.toString())
            pledgeRestored = pObj.optBoolean("isSigned", false)
        }

        // 5.1 استعادة بيانات تقويم تتبع التعافي
        var calendarDaysRestored = 0
        if (dataRoot.has("calendarHistory")) {
            val calObj = dataRoot.getJSONObject("calendarHistory")
            editor.putString("recovery_calendar_history_json", calObj.toString())
            calendarDaysRestored = calObj.length()
        }

        editor.apply()

        // 6. استعادة إعدادات دحر الرغبة
        if (dataRoot.has("urgePrefs")) {
            val up = dataRoot.getJSONObject("urgePrefs")
            val enabled = up.optBoolean("isUrgeFeatureEnabled", false)
            SaffahUrgeManager.setUrgeFeatureEnabled(context, enabled)
        }

        // 7. استعادة وإعادة بناء مذكرات التعافي وسلة المهملات
        var diariesRestored = 0
        var trashRestored = 0

        fun parseAndSaveDiaries(array: JSONArray, targetFileName: String): Int {
            val diariesDir = File(context.filesDir, "recovery_diaries").apply { if (!exists()) mkdirs() }
            val mediaDir = File(diariesDir, "media").apply { if (!exists()) mkdirs() }
            val updatedArray = JSONArray()

            for (i in 0 until array.length()) {
                val dObj = array.getJSONObject(i)
                val mediaArr = dObj.optJSONArray("mediaList") ?: JSONArray()
                val updatedMediaArr = JSONArray()

                for (j in 0 until mediaArr.length()) {
                    val mObj = mediaArr.getJSONObject(j)
                    val relPath = mObj.getString("filePath")
                    val fName = File(relPath).name
                    val absFile = File(mediaDir, fName)
                    mObj.put("filePath", absFile.absolutePath)
                    updatedMediaArr.put(mObj)
                }
                dObj.put("mediaList", updatedMediaArr)
                updatedArray.put(dObj)
            }

            val targetFile = File(diariesDir, targetFileName)
            targetFile.writeText(updatedArray.toString(2))
            return updatedArray.length()
        }

        if (dataRoot.has("diaries")) {
            diariesRestored = parseAndSaveDiaries(dataRoot.getJSONArray("diaries"), "recovery_diaries.json")
        }
        if (dataRoot.has("diariesTrash")) {
            trashRestored = parseAndSaveDiaries(dataRoot.getJSONArray("diariesTrash"), "recovery_diaries_trash.json")
        }

        // 8. استعادة وسجلات محطات خريطة رحلة التعافي
        var milestonesRestored = 0
        if (dataRoot.has("milestoneMedia")) {
            val mmObj = dataRoot.getJSONObject("milestoneMedia")
            val milestoneDir = File(context.filesDir, "milestone_media").apply { if (!exists()) mkdirs() }
            val updatedMmObj = JSONObject()
            val keys = mmObj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val arr = mmObj.getJSONArray(k)
                milestonesRestored += arr.length()
                val updatedArr = JSONArray()
                for (i in 0 until arr.length()) {
                    val mObj = arr.getJSONObject(i)
                    val relPath = mObj.getString("filePath")
                    val fName = File(relPath).name
                    val absFile = File(milestoneDir, fName)
                    mObj.put("filePath", absFile.absolutePath)
                    updatedArr.put(mObj)
                }
                updatedMmObj.put(k, updatedArr)
            }
            val mmRecordsFile = File(milestoneDir, "milestone_media_records.json")
            mmRecordsFile.writeText(updatedMmObj.toString(2))
        }

        // 9. تفعيل الحماية الأمنية والعزل لجميع المجلدات المستعادة
        SaffahMediaCompressor.initSecurity(context)

        val message = "تمت استعادة $diariesRestored مذكرة، $calendarDaysRestored يوماً في التقويم، $relapsesRestored زلة، $urgesRestored رغبة، " +
                "و$imagesCount صورة و$videosCount فيديو و$audiosCount تسجيل صوتي بنجاح تام."

        return Result.success(
            RecoveryRestoreResult(
                diariesRestored = diariesRestored,
                diariesTrashRestored = trashRestored,
                imagesRestored = imagesCount,
                videosRestored = videosCount,
                audiosRestored = audiosCount,
                relapsesRestored = relapsesRestored,
                urgesRestored = urgesRestored,
                milestonesRestored = milestonesRestored,
                calendarDaysRestored = calendarDaysRestored,
                isPledgeRestored = pledgeRestored,
                message = message
            )
        )
    }
}
