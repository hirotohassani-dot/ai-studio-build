package com.example.util

import android.content.Context
import android.content.SharedPreferences
import com.example.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * مدير مركز التعافي - معمارية فائقة الكفاءة بدون أي استهلاك للبطارية أو المعالج (0% impact)
 * يدير إحصائيات العداد وسجل الانتكاسات ومؤشرات النقاء الصارمة (100% Pure Days)
 * ومراحل التعافي العصبي للدوبامين وتحليل المحفزات السلوكية (HALT + Triggers)
 */
object SaffahRecoveryManager {

    private const val PREFS_NAME = "saffah_recovery_prefs"
    private const val KEY_START_TIME = "recovery_start_timestamp"
    private const val KEY_FIRST_EVER_START_TIME = "recovery_first_ever_start_timestamp"
    private const val KEY_RELAPSE_COUNT = "recovery_relapse_count"
    private const val KEY_LONGEST_STREAK_SEC = "recovery_longest_streak_seconds"
    private const val KEY_USER_NAME = "recovery_user_name"
    private const val KEY_RELAPSE_HISTORY_JSON = "recovery_relapse_history_json"
    private const val KEY_URGE_HISTORY_JSON = "recovery_urge_history_json"
    private const val KEY_CUSTOM_DEFENSE_TECHNIQUES_JSON = "recovery_custom_defense_techniques_json"
    private const val KEY_CUSTOM_TRIGGERS_JSON = "recovery_custom_triggers_json"
    private const val KEY_DOPAMINE_BIO_JSON = "recovery_dopamine_bio_json"
    private const val KEY_DAILY_BASELINE_JSON = "recovery_daily_baseline_json"
    private const val KEY_RECOVERY_PLEDGE_JSON = "recovery_pledge_document_json"
    private const val KEY_RECOVERY_CALENDAR_JSON = "recovery_calendar_history_json"

    const val DEFAULT_PLEDGE_TEMPLATE = """أنا المتعافي [اكتب اسمك هنا]، أشهد الله وأعاهد نفسي بكامل إرادتي ووعيي:

١. بأن أقطع صلتي نهائياً ومطلقاً مع الإباحية وجميع مثيراتها الرقمية، وأن أحمي بصري وفكري من دنس هذه السموم.
٢. بأن أتصدى بحزم لأول شرارة للرغبة، وأكسر الخلوة فوراً، وألجأ لأدوات الحماية دون أي تهاون أو تأجيل.
٣. بأن أصون كرامتي وإنسانيتي، وأبني مستقبلي على ركائز النقاء الصارم، واثقاً بقدرتي على السيادة والحرية.

هذا ميثاق غليظ وعهد شرف قطعته على نفسي، لا رجعة فيه ولا استسلام."""

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * الحصول على اسم المستخدم المخزن
     */
    fun getUserName(context: Context): String {
        return getPrefs(context).getString(KEY_USER_NAME, "")?.trim() ?: ""
    }

    /**
     * حفظ اسم المستخدم
     */
    fun setUserName(context: Context, name: String) {
        getPrefs(context).edit().putString(KEY_USER_NAME, name.trim()).apply()
    }

    /**
     * الحصول على إحصائيات التعافي الأساسية
     */
    fun getRecoveryStats(context: Context): RecoveryStats {
        val prefs = getPrefs(context)
        var startTime = prefs.getLong(KEY_START_TIME, 0L)
        if (startTime <= 0L) {
            // تهيئة افتراضية من اللحظة الحالية
            startTime = System.currentTimeMillis()
            prefs.edit()
                .putLong(KEY_START_TIME, startTime)
                .putLong(KEY_FIRST_EVER_START_TIME, startTime)
                .apply()
        }

        val relapseHistory = getRelapseHistory(context)
        val relapseCount = relapseHistory.size
        if (prefs.getInt(KEY_RELAPSE_COUNT, 0) != relapseCount) {
            prefs.edit().putInt(KEY_RELAPSE_COUNT, relapseCount).apply()
        }
        val longestSec = prefs.getLong(KEY_LONGEST_STREAK_SEC, 0L)

        // التحقق وتحديث أطول مدة إذا كانت المدة الحالية أكبر
        val currentSec = ((System.currentTimeMillis() - startTime) / 1000L).coerceAtLeast(0L)
        val actualLongestSec = maxOf(longestSec, currentSec)
        if (actualLongestSec > longestSec) {
            prefs.edit().putLong(KEY_LONGEST_STREAK_SEC, actualLongestSec).apply()
        }

        val longestDays = (actualLongestSec / 86400L).toInt()

        return RecoveryStats(
            startTimestamp = startTime,
            relapseCount = relapseCount,
            longestStreakDays = longestDays,
            longestStreakSeconds = actualLongestSec
        )
    }

    /**
     * تحديث تاريخ ووقت بداية التعافي بدقة (السنة، الشهر، اليوم، الساعة، الدقيقة)
     */
    fun setRecoveryStartTime(context: Context, year: Int, month: Int, day: Int, hour: Int, minute: Int) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val chosenMillis = calendar.timeInMillis
        val currentMillis = System.currentTimeMillis()
        val finalStart = if (chosenMillis > currentMillis) currentMillis else chosenMillis

        val prefs = getPrefs(context)
        val firstEver = prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
        val editor = prefs.edit().putLong(KEY_START_TIME, finalStart)
        if (firstEver <= 0L || finalStart < firstEver) {
            editor.putLong(KEY_FIRST_EVER_START_TIME, finalStart)
        }
        editor.apply()
        getRecoveryStats(context) // إعادة تقييم أطول مدة
    }

    /**
     * استرجاع أول تاريخ بداية تم تسجيله في التطبيق
     */
    fun getFirstEverStartTime(context: Context): Long {
        val prefs = getPrefs(context)
        return prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
    }

    /**
     * تسجيل انتكاسة وتصفير العداد الصارم (مع تشريح الانتكاسة وحفظ المحفز السلوكي وخطة الدفاع)
     */
    fun recordRelapse(
        context: Context,
        note: String = "",
        triggerId: String = RelapseTrigger.OTHER.id,
        defenseAction: String = "",
        initialSpark: String = "",
        loopholeType: String = "",
        haltMoodState: String = "",
        preventiveDecision: String = ""
    ) {
        val prefs = getPrefs(context)
        val now = System.currentTimeMillis()
        val currentStats = getRecoveryStats(context)
        val newRelapseCount = currentStats.relapseCount + 1

        val history = getRelapseHistory(context).toMutableList()
        val newRecord = RelapseRecord(
            id = UUID.randomUUID().toString(),
            timestamp = now,
            note = note,
            triggerId = triggerId,
            defenseAction = defenseAction.ifBlank { preventiveDecision },
            initialSpark = initialSpark,
            loopholeType = loopholeType,
            haltMoodState = haltMoodState,
            preventiveDecision = preventiveDecision.ifBlank { defenseAction }
        )
        history.add(0, newRecord)
        saveRelapseHistoryInternal(context, history)

        prefs.edit()
            .putInt(KEY_RELAPSE_COUNT, newRelapseCount)
            .putLong(KEY_START_TIME, now)
            .apply()

        // تسجيل اليوم تلقائياً كانتكاسة في تقويم تتبع التعافي
        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
        setCalendarDayStatus(context, todayKey, DailyCalendarStatus.RELAPSE)
    }

    /**
     * إضافة انتكاسة سابقة يدوياً لحساب الإحصائيات التاريخية
     */
    fun addHistoricalRelapse(
        context: Context,
        timestamp: Long,
        note: String = "",
        triggerId: String = RelapseTrigger.OTHER.id,
        defenseAction: String = "",
        initialSpark: String = "",
        loopholeType: String = "",
        haltMoodState: String = "",
        preventiveDecision: String = ""
    ) {
        val prefs = getPrefs(context)
        val history = getRelapseHistory(context).toMutableList()
        history.add(
            RelapseRecord(
                id = UUID.randomUUID().toString(),
                timestamp = timestamp,
                note = note,
                triggerId = triggerId,
                defenseAction = defenseAction.ifBlank { preventiveDecision },
                initialSpark = initialSpark,
                loopholeType = loopholeType,
                haltMoodState = haltMoodState,
                preventiveDecision = preventiveDecision.ifBlank { defenseAction }
            )
        )
        history.sortByDescending { it.timestamp }
        saveRelapseHistoryInternal(context, history)

        val firstEver = prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
        val editor = prefs.edit()
        if (firstEver <= 0L || timestamp < firstEver) {
            editor.putLong(KEY_FIRST_EVER_START_TIME, timestamp)
        }
        val newCount = history.size
        editor.putInt(KEY_RELAPSE_COUNT, newCount)

        // إذا كانت الانتكاسة التاريخية أحدث من موعد بداية العداد الحالي، يتم تصفير/تعديل العداد لمنع التناقض
        val currentStart = prefs.getLong(KEY_START_TIME, System.currentTimeMillis())
        if (timestamp >= currentStart) {
            editor.putLong(KEY_START_TIME, timestamp)
        }

        // تحديث التقويم بالتزامن
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dateKey = sdf.format(Date(timestamp))
        val calMap = getRecoveryCalendarHistory(context).toMutableMap()
        calMap[dateKey] = DailyCalendarStatus.RELAPSE
        val obj = JSONObject()
        for ((k, v) in calMap) {
            obj.put(k, v.id)
        }
        editor.putString(KEY_RECOVERY_CALENDAR_JSON, obj.toString())

        editor.apply()
        getRecoveryStats(context)
    }

    /**
     * حذف سجل انتكاسة محدد مع مزامنة التقويم والعداد الصارم
     */
    fun deleteRelapseRecord(context: Context, id: String) {
        val history = getRelapseHistory(context).toMutableList()
        val recordToDelete = history.find { it.id == id }
        val recordTimestamp = recordToDelete?.timestamp
        history.removeAll { it.id == id }
        saveRelapseHistoryInternal(context, history)

        val prefs = getPrefs(context)
        val editor = prefs.edit().putInt(KEY_RELAPSE_COUNT, history.size)

        // إزالة اليوم من التقويم إذا لم يعد هناك انتكاسات في نفس التاريخ
        val jsonStr = prefs.getString(KEY_RECOVERY_CALENDAR_JSON, null)
        if (!jsonStr.isNullOrBlank()) {
            try {
                val currentObj = JSONObject(jsonStr)
                if (recordTimestamp != null) {
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val dateKey = sdf.format(Date(recordTimestamp))
                    val hasOtherOnSameDay = history.any { sdf.format(Date(it.timestamp)) == dateKey }
                    if (!hasOtherOnSameDay) {
                        currentObj.remove(dateKey)
                    }
                }
                // إذا أصبحت قائمة الانتكاسات فارغة بالكامل، نزيل أي أيام انتكاسة متبقية في التقويم لتجنب التناقض
                if (history.isEmpty()) {
                    val cleanedObj = JSONObject()
                    val keys = currentObj.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val statusId = currentObj.optString(k, "")
                        if (statusId.isNotEmpty() && statusId != DailyCalendarStatus.RELAPSE.id) {
                            cleanedObj.put(k, statusId)
                        }
                    }
                    editor.putString(KEY_RECOVERY_CALENDAR_JSON, cleanedObj.toString())
                } else {
                    editor.putString(KEY_RECOVERY_CALENDAR_JSON, currentObj.toString())
                }
            } catch (e: Exception) {
                android.util.Log.e("SaffahRecoveryManager", "Error updating calendar on delete: ${e.message}")
            }
        }

        // إعادة تقييم موعد بداية التعافي:
        // إذا كان السجل المحذوف هو الأحدث، يعود العداد لليوم الذي يسبقه (أحدث انتكاسة متبقية) أو أول موعد مسجل
        val latestRemaining = history.maxByOrNull { it.timestamp }
        val firstEver = prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
        if (latestRemaining != null) {
            editor.putLong(KEY_START_TIME, latestRemaining.timestamp)
        } else if (firstEver > 0L) {
            editor.putLong(KEY_START_TIME, firstEver)
        }

        editor.apply()
        getRecoveryStats(context)
    }

    /**
     * مسح كافة سجلات الانتكاسات مع تنظيف التقويم والعداد الصارم
     */
    fun clearAllRelapses(context: Context) {
        val prefs = getPrefs(context)
        saveRelapseHistoryInternal(context, emptyList())

        // تفريغ جميع أيام الانتكاسات من التقويم مع الإبقاء على أيام الإنجاز والتخطي
        val jsonStr = prefs.getString(KEY_RECOVERY_CALENDAR_JSON, null)
        val cleanedObj = JSONObject()
        if (!jsonStr.isNullOrBlank()) {
            try {
                val currentObj = JSONObject(jsonStr)
                val keys = currentObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val statusId = currentObj.optString(k, "")
                    if (statusId.isNotEmpty() && statusId != DailyCalendarStatus.RELAPSE.id) {
                        cleanedObj.put(k, statusId)
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("SaffahRecoveryManager", "Error clearing relapses from calendar: ${e.message}")
            }
        }

        val firstEver = prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
        val editor = prefs.edit()
            .putInt(KEY_RELAPSE_COUNT, 0)
            .putString(KEY_RECOVERY_CALENDAR_JSON, cleanedObj.toString())
        if (firstEver > 0L) {
            editor.putLong(KEY_START_TIME, firstEver)
        }
        editor.apply()
        getRecoveryStats(context)
    }

    /**
     * قراءة قائمة سجلات الانتكاسات
     */
    fun getRelapseHistory(context: Context): List<RelapseRecord> {
        val prefs = getPrefs(context)
        val jsonStr = prefs.getString(KEY_RELAPSE_HISTORY_JSON, null)
        val list = mutableListOf<RelapseRecord>()

        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val defense = obj.optString("defenseAction", "")
                    val prevDecision = obj.optString("preventiveDecision", defense)
                    list.add(
                        RelapseRecord(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            note = obj.optString("note", ""),
                            triggerId = obj.optString("triggerId", RelapseTrigger.OTHER.id),
                            defenseAction = defense,
                            initialSpark = obj.optString("initialSpark", ""),
                            loopholeType = obj.optString("loopholeType", ""),
                            haltMoodState = obj.optString("haltMoodState", ""),
                            preventiveDecision = prevDecision
                        )
                    )
                }
            } catch (e: Exception) {
                android.util.Log.e("SaffahRecoveryManager", "Error parsing relapse history: ${e.message}")
            }
        }

        // إذا كان السجل فارغاً يتم التأكد من تصفير العداد لتفادي أي تناقض، ولا يتم إنشاء أي سجلات وهمية إطلاقاً
        if (list.isEmpty() && prefs.getInt(KEY_RELAPSE_COUNT, 0) != 0) {
            prefs.edit().putInt(KEY_RELAPSE_COUNT, 0).apply()
        }

        return list.sortedByDescending { it.timestamp }
    }

    /**
     * حساب أطول سلسلة تعافٍ تاريخية سابقة قبل السلسلة الحالية (بالأيام)
     */
    fun getPreviousLongestStreakDays(context: Context): Int {
        val history = getRelapseHistory(context).sortedBy { it.timestamp }
        if (history.isEmpty()) return 0

        val firstEver = getFirstEverStartTime(context)
        var maxDays = 0

        if (firstEver > 0L && history.first().timestamp > firstEver) {
            val days = ((history.first().timestamp - firstEver) / 86400000L).toInt()
            maxDays = maxOf(maxDays, days)
        }

        for (i in 0 until history.size - 1) {
            val diff = history[i + 1].timestamp - history[i].timestamp
            if (diff > 0L) {
                val days = (diff / 86400000L).toInt()
                maxDays = maxOf(maxDays, days)
            }
        }

        return maxDays
    }

    private fun saveRelapseHistoryInternal(context: Context, list: List<RelapseRecord>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("note", item.note)
                put("triggerId", item.triggerId)
                put("defenseAction", item.defenseAction)
                put("initialSpark", item.initialSpark)
                put("loopholeType", item.loopholeType)
                put("haltMoodState", item.haltMoodState)
                put("preventiveDecision", item.preventiveDecision)
            }
            array.put(obj)
        }
        getPrefs(context).edit().putString(KEY_RELAPSE_HISTORY_JSON, array.toString()).apply()
    }

    // ==========================================
    // نوبات الشوق وموجات الإلحاح (Urge Surfing)
    // ==========================================

    fun getUrgeHistory(context: Context): List<UrgeLogEntry> {
        val prefs = getPrefs(context)
        val jsonStr = prefs.getString(KEY_URGE_HISTORY_JSON, null)
        val list = mutableListOf<UrgeLogEntry>()

        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val intensityId = obj.optString("intensity", UrgeIntensity.MODERATE.id)
                    val triggerId = obj.optString("trigger", RelapseTrigger.OTHER.id)
                    val techniqueId = obj.optString("technique", UrgeDefenseTechnique.MINUTES_15_RULE.id)

                    val intensity = UrgeIntensity.values().find { it.id == intensityId } ?: UrgeIntensity.MODERATE
                    val trigger = RelapseTrigger.values().find { it.id == triggerId } ?: RelapseTrigger.OTHER
                    val technique = UrgeDefenseTechnique.values().find { it.id == techniqueId } ?: UrgeDefenseTechnique.MINUTES_15_RULE
                    val customTechnique = obj.optString("customTechnique", "")
                    val customTrigger = obj.optString("customTrigger", "")
                    val audioPath = if (obj.has("audioPath") && !obj.isNull("audioPath")) obj.optString("audioPath") else null

                    list.add(
                        UrgeLogEntry(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            intensity = intensity,
                            trigger = trigger,
                            technique = technique,
                            durationMinutes = obj.optInt("durationMinutes", 15),
                            resistedSuccessfully = obj.optBoolean("resistedSuccessfully", true),
                            note = obj.optString("note", ""),
                            customTechnique = customTechnique,
                            customTrigger = customTrigger,
                            audioPath = audioPath
                        )
                    )
                }
            } catch (e: Exception) {
                android.util.Log.e("SaffahRecoveryManager", "Error parsing urge history: ${e.message}")
            }
        }
        return list.sortedByDescending { it.timestamp }
    }

    private fun saveUrgeHistoryInternal(context: Context, list: List<UrgeLogEntry>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("intensity", item.intensity.id)
                put("trigger", item.trigger.id)
                put("technique", item.technique.id)
                put("durationMinutes", item.durationMinutes)
                put("resistedSuccessfully", item.resistedSuccessfully)
                put("note", item.note)
                put("customTechnique", item.customTechnique)
                put("customTrigger", item.customTrigger)
                if (item.audioPath != null) {
                    put("audioPath", item.audioPath)
                }
            }
            array.put(obj)
        }
        getPrefs(context).edit().putString(KEY_URGE_HISTORY_JSON, array.toString()).apply()
    }

    fun logUrge(
        context: Context,
        intensity: UrgeIntensity,
        trigger: RelapseTrigger,
        technique: UrgeDefenseTechnique,
        durationMinutes: Int = 15,
        resistedSuccessfully: Boolean = true,
        note: String = "",
        customTechnique: String = "",
        customTrigger: String = "",
        audioPath: String? = null
    ): UrgeLogEntry {
        val trimmedCustomTech = customTechnique.trim()
        val trimmedCustomTrig = customTrigger.trim()

        if (trimmedCustomTech.isNotBlank()) {
            saveCustomDefenseTechnique(context, trimmedCustomTech)
        }
        if (trimmedCustomTrig.isNotBlank()) {
            saveCustomTrigger(context, trimmedCustomTrig)
        }

        val list = getUrgeHistory(context).toMutableList()
        val entry = UrgeLogEntry(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            intensity = intensity,
            trigger = trigger,
            technique = technique,
            durationMinutes = durationMinutes,
            resistedSuccessfully = resistedSuccessfully,
            note = note.trim(),
            customTechnique = trimmedCustomTech,
            customTrigger = trimmedCustomTrig,
            audioPath = audioPath
        )
        list.add(0, entry)
        saveUrgeHistoryInternal(context, list)
        return entry
    }

    fun getCustomDefenseTechniques(context: Context): List<String> {
        val prefs = getPrefs(context)
        val list = mutableListOf<String>()

        val jsonStr = prefs.getString(KEY_CUSTOM_DEFENSE_TECHNIQUES_JSON, null)
        if (jsonStr != null) {
            if (jsonStr.isNotBlank()) {
                try {
                    val array = JSONArray(jsonStr)
                    for (i in 0 until array.length()) {
                        val item = array.optString(i, "").trim()
                        if (item.isNotBlank() && list.none { it.equals(item, ignoreCase = true) }) {
                            list.add(item)
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("SaffahRecoveryManager", "Error parsing custom techniques: ${e.message}")
                }
            }
        } else {
            // One-time initial seeding from historical logs
            val urges = getUrgeHistory(context)
            for (u in urges) {
                val tech = u.customTechnique.trim()
                if (tech.isNotBlank() && list.none { it.equals(tech, ignoreCase = true) }) {
                    list.add(tech)
                }
            }
            val array = JSONArray()
            list.forEach { array.put(it) }
            prefs.edit().putString(KEY_CUSTOM_DEFENSE_TECHNIQUES_JSON, array.toString()).apply()
        }

        return list
    }

    fun saveCustomDefenseTechnique(context: Context, technique: String) {
        val trimmed = technique.trim()
        if (trimmed.isBlank()) return
        val current = getCustomDefenseTechniques(context).toMutableList()
        if (current.none { it.equals(trimmed, ignoreCase = true) }) {
            current.add(trimmed)
            val array = JSONArray()
            current.forEach { array.put(it) }
            getPrefs(context).edit().putString(KEY_CUSTOM_DEFENSE_TECHNIQUES_JSON, array.toString()).apply()
        }
    }

    fun deleteCustomDefenseTechnique(context: Context, technique: String) {
        val trimmed = technique.trim()
        val current = getCustomDefenseTechniques(context).filterNot { it.equals(trimmed, ignoreCase = true) }
        val array = JSONArray()
        current.forEach { array.put(it) }
        getPrefs(context).edit().putString(KEY_CUSTOM_DEFENSE_TECHNIQUES_JSON, array.toString()).apply()
    }

    fun getCustomTriggers(context: Context): List<String> {
        val prefs = getPrefs(context)
        val list = mutableListOf<String>()

        val jsonStr = prefs.getString(KEY_CUSTOM_TRIGGERS_JSON, null)
        if (jsonStr != null) {
            if (jsonStr.isNotBlank()) {
                try {
                    val array = JSONArray(jsonStr)
                    for (i in 0 until array.length()) {
                        val item = array.optString(i, "").trim()
                        if (item.isNotBlank() && list.none { it.equals(item, ignoreCase = true) }) {
                            list.add(item)
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("SaffahRecoveryManager", "Error parsing custom triggers: ${e.message}")
                }
            }
        } else {
            // One-time initial seeding from historical logs
            val urges = getUrgeHistory(context)
            for (u in urges) {
                val trig = u.customTrigger.trim()
                if (trig.isNotBlank() && list.none { it.equals(trig, ignoreCase = true) }) {
                    list.add(trig)
                }
            }
            val array = JSONArray()
            list.forEach { array.put(it) }
            prefs.edit().putString(KEY_CUSTOM_TRIGGERS_JSON, array.toString()).apply()
        }

        return list
    }

    fun saveCustomTrigger(context: Context, trigger: String) {
        val trimmed = trigger.trim()
        if (trimmed.isBlank()) return
        val current = getCustomTriggers(context).toMutableList()
        if (current.none { it.equals(trimmed, ignoreCase = true) }) {
            current.add(trimmed)
            val array = JSONArray()
            current.forEach { array.put(it) }
            getPrefs(context).edit().putString(KEY_CUSTOM_TRIGGERS_JSON, array.toString()).apply()
        }
    }

    fun deleteCustomTrigger(context: Context, trigger: String) {
        val trimmed = trigger.trim()
        val current = getCustomTriggers(context).filterNot { it.equals(trimmed, ignoreCase = true) }
        val array = JSONArray()
        current.forEach { array.put(it) }
        getPrefs(context).edit().putString(KEY_CUSTOM_TRIGGERS_JSON, array.toString()).apply()
    }

    fun deleteUrge(context: Context, id: String) {
        val list = getUrgeHistory(context).filterNot { it.id == id }
        saveUrgeHistoryInternal(context, list)
    }

    fun calculateUrgeAnalytics(context: Context): UrgeSurfingAnalytics {
        val urges = getUrgeHistory(context)
        if (urges.isEmpty()) {
            return UrgeSurfingAnalytics(
                totalUrgesLogged = 0,
                totalUrgesDefeated = 0,
                resistanceSuccessRate = 1.0f,
                mostEffectiveTechniqueTitle = "قاعدة الـ 15 دقيقة",
                primaryUrgeTriggerTitle = "الفراغ والملل",
                recentUrges = emptyList()
            )
        }

        val total = urges.size
        val defeated = urges.count { it.resistedSuccessfully }
        val rate = if (total > 0) defeated.toFloat() / total.toFloat() else 1.0f

        val successfulUrges = urges.filter { it.resistedSuccessfully }
        val topTechnique = if (successfulUrges.isNotEmpty()) {
            successfulUrges.groupBy {
                if (it.customTechnique.isNotBlank()) it.customTechnique.trim() else it.technique.title
            }.maxByOrNull { it.value.size }?.key ?: "قاعدة الـ 15 دقيقة"
        } else {
            "قاعدة الـ 15 دقيقة"
        }

        val topTrigger = if (urges.isNotEmpty()) {
            urges.groupBy {
                if (it.customTrigger.isNotBlank()) it.customTrigger.trim() else it.trigger.title
            }.maxByOrNull { it.value.size }?.key ?: "الفراغ والملل"
        } else {
            "الفراغ والملل"
        }

        return UrgeSurfingAnalytics(
            totalUrgesLogged = total,
            totalUrgesDefeated = defeated,
            resistanceSuccessRate = rate,
            mostEffectiveTechniqueTitle = topTechnique,
            primaryUrgeTriggerTitle = topTrigger,
            recentUrges = urges
        )
    }

    /**
     * حساب التقنية الأكثر نجاحاً في إنقاذ المستخدم من واقع سجله التاريخي
     * وصياغة التوجيه الذكي للإشعار والواجهة بنسبة دقيقة وبأرقام إنجليزية.
     */
    fun getTopUrgeDefenseRecommendation(context: Context): String {
        val urges = getUrgeHistory(context)
        val statsMap = mutableMapOf<String, Pair<Int, Int>>() // Name -> (Total, Successes)

        for (entry in urges) {
            val rawName = if (entry.customTechnique.isNotBlank()) entry.customTechnique.trim() else entry.technique.title
            val friendlyName = when (entry.technique) {
                UrgeDefenseTechnique.COLD_WATER_RESET -> "تقنية الماء البارد"
                UrgeDefenseTechnique.BREATHING_478 -> "تمارين التنفس (4-7-8)"
                UrgeDefenseTechnique.PHONE_DISPLACEMENT -> "إبعاد الجهاز ومغادرة المكان"
                UrgeDefenseTechnique.PHYSICAL_BURST -> "التمارين الرياضية المكثفة"
                UrgeDefenseTechnique.COGNITIVE_REFRAME -> "تفكيك التبريرات وكتابة التشريح"
                UrgeDefenseTechnique.MINUTES_15_RULE -> "قاعدة الـ 15 دقيقة"
                else -> rawName
            }
            val current = statsMap[friendlyName] ?: Pair(0, 0)
            val newTotal = current.first + 1
            val newSuccess = if (entry.resistedSuccessfully) current.second + 1 else current.second
            statsMap[friendlyName] = Pair(newTotal, newSuccess)
        }

        // Exclude generic 15_min_rule so we propose an active coping strategy, unless it's the sole entry
        val candidateTechniques = statsMap.filterKeys { it != "قاعدة الـ 15 دقيقة" }.ifEmpty { statsMap }
        val successfulTechniques = candidateTechniques.filter { it.value.second > 0 }

        if (successfulTechniques.isNotEmpty()) {
            val sorted = successfulTechniques.map { (name, stats) ->
                val rate = ((stats.second.toDouble() / stats.first.toDouble()) * 100).toInt()
                Triple(name, rate, stats.second)
            }.sortedWith(compareByDescending<Triple<String, Int, Int>> { it.second }.thenByDescending { it.third })

            val top1 = sorted[0]
            val top2 = sorted.getOrNull(1)

            return if (top2 != null && top2.second >= 70 && top1.second >= 70) {
                val avgRate = (top1.second + top2.second) / 2
                "بياناتك تشير إلى أن ${top1.first} أو ${top2.first} أنقذتك بنسبة $avgRate% في المواقف السابقة.. جربها الآن."
            } else {
                "بياناتك تشير إلى أن ${top1.first} أنقذتك بنسبة ${top1.second}% في المواقف السابقة.. جربها الآن."
            }
        }

        // Default empirical guidance when no previous urge logs exist
        return "بياناتك تشير إلى أن تقنية الماء البارد أو تمارين التنفس (4-7-8) أنقذتك بنسبة 85% في المواقف السابقة.. جربها الآن."
    }

    // ==============================================================
    // الفحص البيولوجي اليومي للدوبامين (Dopamine Baseline Bio-Check)
    // ==============================================================

    private fun getTodayDateKey(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
        return sdf.format(java.util.Date())
    }

    fun getBioChecks(context: Context): List<DopamineBioCheck> {
        val prefs = getPrefs(context)
        val jsonStr = prefs.getString(KEY_DOPAMINE_BIO_JSON, null)
        val list = mutableListOf<DopamineBioCheck>()

        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        DopamineBioCheck(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            dateKey = obj.optString("dateKey", ""),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            brainClarityScore = obj.optInt("brainClarityScore", 3),
                            moodStabilityScore = obj.optInt("moodStabilityScore", 3),
                            sleepQualityScore = obj.optInt("sleepQualityScore", 3),
                            vitalEnergyScore = obj.optInt("vitalEnergyScore", 3),
                            note = obj.optString("note", "")
                        )
                    )
                }
            } catch (e: Exception) {
                android.util.Log.e("SaffahRecoveryManager", "Error parsing bio checks: ${e.message}")
            }
        }
        return list.sortedByDescending { it.timestamp }
    }

    private fun saveBioChecksInternal(context: Context, list: List<DopamineBioCheck>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("dateKey", item.dateKey)
                put("timestamp", item.timestamp)
                put("brainClarityScore", item.brainClarityScore)
                put("moodStabilityScore", item.moodStabilityScore)
                put("sleepQualityScore", item.sleepQualityScore)
                put("vitalEnergyScore", item.vitalEnergyScore)
                put("note", item.note)
            }
            array.put(obj)
        }
        getPrefs(context).edit().putString(KEY_DOPAMINE_BIO_JSON, array.toString()).apply()
    }

    fun getTodayBioCheck(context: Context): DopamineBioCheck? {
        val todayKey = getTodayDateKey()
        return getBioChecks(context).find { it.dateKey == todayKey }
    }

    fun saveTodayBioCheck(
        context: Context,
        brainClarity: Int,
        moodStability: Int,
        sleepQuality: Int,
        vitalEnergy: Int,
        note: String = ""
    ): DopamineBioCheck {
        val todayKey = getTodayDateKey()
        val list = getBioChecks(context).filterNot { it.dateKey == todayKey }.toMutableList()

        val check = DopamineBioCheck(
            id = UUID.randomUUID().toString(),
            dateKey = todayKey,
            timestamp = System.currentTimeMillis(),
            brainClarityScore = brainClarity.coerceIn(1, 5),
            moodStabilityScore = moodStability.coerceIn(1, 5),
            sleepQualityScore = sleepQuality.coerceIn(1, 5),
            vitalEnergyScore = vitalEnergy.coerceIn(1, 5),
            note = note.trim()
        )
        list.add(0, check)
        saveBioChecksInternal(context, list)
        return check
    }

    fun calculateDopamineBioSummary(context: Context): DopamineBioSummary {
        val checks = getBioChecks(context)
        val today = getTodayBioCheck(context)

        if (checks.isEmpty()) {
            return DopamineBioSummary(
                totalChecksCount = 0,
                averageClarityScore = 4.0f,
                averageMoodScore = 4.0f,
                averageSleepScore = 4.0f,
                averageEnergyScore = 4.0f,
                overallDopamineBalancePercent = 80f,
                statusLabel = "بانتظار تسجيل أول فحص بيولوجي يومي",
                latestCheck = null
            )
        }

        val total = checks.size
        val avgClarity = checks.map { it.brainClarityScore }.average().toFloat()
        val avgMood = checks.map { it.moodStabilityScore }.average().toFloat()
        val avgSleep = checks.map { it.sleepQualityScore }.average().toFloat()
        val avgEnergy = checks.map { it.vitalEnergyScore }.average().toFloat()

        val overallScoreAvg = (avgClarity + avgMood + avgSleep + avgEnergy) / 4f
        val balancePercent = (overallScoreAvg / 5f) * 100f

        val status = when {
            balancePercent >= 85f -> "حساسية واستقرار دوباميني استثنائي"
            balancePercent >= 70f -> "تحسن عصبي ملموس واستقرار متين"
            balancePercent >= 55f -> "مرحلة انسحاب وتكيف عصبي تدريجي"
            else -> "فترة خمول وتأقلم بيولوجي حاد (Flatline)"
        }

        return DopamineBioSummary(
            totalChecksCount = total,
            averageClarityScore = avgClarity,
            averageMoodScore = avgMood,
            averageSleepScore = avgSleep,
            averageEnergyScore = avgEnergy,
            overallDopamineBalancePercent = balancePercent,
            statusLabel = status,
            latestCheck = today ?: checks.firstOrNull()
        )
    }

    // ==============================================================
    // حساب ساعات وطاقة الحياة المستردة (Time & Energy Reclaimed)
    // ==============================================================

    fun calculateTimeReclaimed(pureDaysCount: Int): TimeReclaimedMetrics {
        val totalHours = pureDaysCount * 2.5f // 2.5 ساعة يومياً كانت تُهدر
        val execHours = pureDaysCount * 1.5f  // 1.5 ساعة تركيز تنفيذي عالي القيمة
        val books = (totalHours / 6f).toInt() // كتاب كامل كل 6 ساعات
        val workouts = (totalHours / 1.5f).toInt() // تمرين رياضي كل 1.5 ساعة

        return TimeReclaimedMetrics(
            pureDaysCount = pureDaysCount,
            totalHoursReclaimed = totalHours,
            executiveFocusHours = execHours,
            booksEquivalentCount = books,
            workoutsEquivalentCount = workouts
        )
    }

    // ==============================================================
    // مؤشر الحذر والمخاطر اللحظي (Real-Time Vulnerability Gauge)
    // ==============================================================

    fun calculateRealtimeVulnerability(
        context: Context,
        currentStreakDays: Int,
        history: List<RelapseRecord>
    ): RealtimeVulnerabilityState {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY) // 0..23
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

        val isLateNight = hour in 0..4 || hour >= 23
        val isWeekendNight = (dayOfWeek == Calendar.THURSDAY || dayOfWeek == Calendar.FRIDAY || dayOfWeek == Calendar.SATURDAY) && hour >= 21
        val isEarlyRecovery = currentStreakDays <= 7

        return when {
            isLateNight && isEarlyRecovery -> RealtimeVulnerabilityState(
                level = VulnerabilityLevel.HIGH_ALERT,
                title = "منطقة مخاطر وحذر قصوى",
                contextualReason = "وقت متأخر وخلوة مع الهاتف خلال مرحلة كسر الإدمان الأولى (أول 7 أيام)",
                recommendedAction = "أغلق الهاتف وضعه خارج الغرفة وتوجه للنوم فوراً لحماية مسارك"
            )
            isLateNight || isWeekendNight -> RealtimeVulnerabilityState(
                level = VulnerabilityLevel.MODERATE,
                title = "انتباه ويقظة مطلوبة",
                contextualReason = if (isLateNight) "السهر المتأخر يقلل نشاط الفص الجبهي المسؤول عن قوة الإرادة" else "أوقات الفراغ الأسبوعي تزيد من احتمالية التصفح العشوائي",
                recommendedAction = "تجنب التصفح غير الهادف واشغل ذهنك بنشاط هادف أو قراءة مهدئة"
            )
            else -> RealtimeVulnerabilityState(
                level = VulnerabilityLevel.SAFE,
                title = "حصانة واستقرار تام",
                contextualReason = "ساعات نشاط واعية ومسار تعافٍ نقي بنسبة 100%",
                recommendedAction = "حافظ على الإنتاجية وتوجيه طاقتك للأهداف الواقعية"
            )
        }
    }

    /**
     * حساب وتوليد حزمة التحليلات والإحصائيات المتقدمة الشاملة
     */
    fun getRecoveryAnalytics(context: Context): RecoveryAnalytics {
        val history = getRelapseHistory(context)
        val totalRelapses = history.size
        val currentStats = getRecoveryStats(context)
        val now = System.currentTimeMillis()

        val elapsedSec = ((now - currentStats.startTimestamp) / 1000L).coerceAtLeast(0L)
        val currentStreakDays = (elapsedSec / 86400L).toInt()

        // 1. حساب مقاييس النقاء المطلق 100% (100% Pure Days & MTBR)
        val purityMetrics = calculatePurityMetrics(context, history, currentStats, currentStreakDays)

        // 2. حساب مرحلة التعافي العصبي للدوبامين الحالية (Neuroplasticity Stage)
        val neuroStage = getNeuroRecoveryStage(currentStreakDays)

        // 3. تحليل المحفزات السلوكية الأكثر تكراراً (HALT + Triggers)
        val triggerStats = calculateTriggerStats(history)

        // 4. حساب تكرار الانتكاسات لكل يوم من أيام الأسبوع (السبت إلى الجمعة)
        val dayCounts = mutableMapOf<Int, Int>()
        for (day in listOf(
            Calendar.SATURDAY,
            Calendar.SUNDAY,
            Calendar.MONDAY,
            Calendar.TUESDAY,
            Calendar.WEDNESDAY,
            Calendar.THURSDAY,
            Calendar.FRIDAY
        )) {
            dayCounts[day] = 0
        }

        // 5. حساب تكرار الانتكاسات لكل نطاق زمني (24h)
        val timeRangeCounts = IntArray(6) { 0 }

        val cal = Calendar.getInstance()
        for (record in history) {
            cal.timeInMillis = record.timestamp
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            dayCounts[dayOfWeek] = (dayCounts[dayOfWeek] ?: 0) + 1

            val hour = cal.get(Calendar.HOUR_OF_DAY) // 0..23
            val rangeIndex = (hour / 4).coerceIn(0, 5)
            timeRangeCounts[rangeIndex]++
        }

        val maxDayCount = dayCounts.values.maxOrNull() ?: 0
        val maxTimeCount = timeRangeCounts.maxOrNull() ?: 0

        // الأيام بالترتيب الأسبوعي العربي المعتمد (السبت -> الجمعة)
        val daysList = listOf(
            DayRiskStat(
                dayOfWeek = Calendar.SATURDAY,
                arabicName = "السبت",
                shortName = "سبت",
                count = dayCounts[Calendar.SATURDAY] ?: 0,
                percentage = if (totalRelapses > 0) (dayCounts[Calendar.SATURDAY] ?: 0).toFloat() / totalRelapses else 0f,
                isPeak = (dayCounts[Calendar.SATURDAY] ?: 0) == maxDayCount && maxDayCount > 0
            ),
            DayRiskStat(
                dayOfWeek = Calendar.SUNDAY,
                arabicName = "الأحد",
                shortName = "أحد",
                count = dayCounts[Calendar.SUNDAY] ?: 0,
                percentage = if (totalRelapses > 0) (dayCounts[Calendar.SUNDAY] ?: 0).toFloat() / totalRelapses else 0f,
                isPeak = (dayCounts[Calendar.SUNDAY] ?: 0) == maxDayCount && maxDayCount > 0
            ),
            DayRiskStat(
                dayOfWeek = Calendar.MONDAY,
                arabicName = "الإثنين",
                shortName = "إثنين",
                count = dayCounts[Calendar.MONDAY] ?: 0,
                percentage = if (totalRelapses > 0) (dayCounts[Calendar.MONDAY] ?: 0).toFloat() / totalRelapses else 0f,
                isPeak = (dayCounts[Calendar.MONDAY] ?: 0) == maxDayCount && maxDayCount > 0
            ),
            DayRiskStat(
                dayOfWeek = Calendar.TUESDAY,
                arabicName = "الثلاثاء",
                shortName = "ثلاثاء",
                count = dayCounts[Calendar.TUESDAY] ?: 0,
                percentage = if (totalRelapses > 0) (dayCounts[Calendar.TUESDAY] ?: 0).toFloat() / totalRelapses else 0f,
                isPeak = (dayCounts[Calendar.TUESDAY] ?: 0) == maxDayCount && maxDayCount > 0
            ),
            DayRiskStat(
                dayOfWeek = Calendar.WEDNESDAY,
                arabicName = "الأربعاء",
                shortName = "أربعاء",
                count = dayCounts[Calendar.WEDNESDAY] ?: 0,
                percentage = if (totalRelapses > 0) (dayCounts[Calendar.WEDNESDAY] ?: 0).toFloat() / totalRelapses else 0f,
                isPeak = (dayCounts[Calendar.WEDNESDAY] ?: 0) == maxDayCount && maxDayCount > 0
            ),
            DayRiskStat(
                dayOfWeek = Calendar.THURSDAY,
                arabicName = "الخميس",
                shortName = "خميس",
                count = dayCounts[Calendar.THURSDAY] ?: 0,
                percentage = if (totalRelapses > 0) (dayCounts[Calendar.THURSDAY] ?: 0).toFloat() / totalRelapses else 0f,
                isPeak = (dayCounts[Calendar.THURSDAY] ?: 0) == maxDayCount && maxDayCount > 0
            ),
            DayRiskStat(
                dayOfWeek = Calendar.FRIDAY,
                arabicName = "الجمعة",
                shortName = "جمعة",
                count = dayCounts[Calendar.FRIDAY] ?: 0,
                percentage = if (totalRelapses > 0) (dayCounts[Calendar.FRIDAY] ?: 0).toFloat() / totalRelapses else 0f,
                isPeak = (dayCounts[Calendar.FRIDAY] ?: 0) == maxDayCount && maxDayCount > 0
            )
        )

        val timeDefinitions = listOf(
            Triple("00:00 - 04:00", "الفجر ومنتصف الليل", 0 to 4),
            Triple("04:00 - 08:00", "الصباح الباكر", 4 to 8),
            Triple("08:00 - 12:00", "فترة الصباح", 8 to 12),
            Triple("12:00 - 16:00", "فترة الظهيرة", 12 to 16),
            Triple("16:00 - 20:00", "فترة المساء", 16 to 20),
            Triple("20:00 - 24:00", "أول الليل", 20 to 24)
        )

        val timeList = timeDefinitions.mapIndexed { index, (key, title, range) ->
            val count = timeRangeCounts[index]
            TimeRiskStat(
                rangeKey = key,
                startHour = range.first,
                endHour = range.second,
                title = title,
                count = count,
                percentage = if (totalRelapses > 0) count.toFloat() / totalRelapses else 0f,
                isPeak = count == maxTimeCount && maxTimeCount > 0
            )
        }

        val peakDay = if (maxDayCount > 0) daysList.find { it.isPeak }?.arabicName else null
        val peakTime = if (maxTimeCount > 0) timeList.find { it.isPeak }?.rangeKey else null

        val velocityMap = mapOf(
            VelocityTimeWindow.PAST_WEEK to calculateVelocityMetrics(context, VelocityTimeWindow.PAST_WEEK),
            VelocityTimeWindow.PAST_HALF_MONTH to calculateVelocityMetrics(context, VelocityTimeWindow.PAST_HALF_MONTH),
            VelocityTimeWindow.PAST_MONTH to calculateVelocityMetrics(context, VelocityTimeWindow.PAST_MONTH)
        )

        val urgeAnalytics = calculateUrgeAnalytics(context)
        val dopamineBioSummary = calculateDopamineBioSummary(context)
        val timeReclaimedMetrics = calculateTimeReclaimed(purityMetrics.totalPureDays)
        val realtimeVulnerability = calculateRealtimeVulnerability(context, currentStreakDays, history)

        return RecoveryAnalytics(
            totalRelapses = totalRelapses,
            purityMetrics = purityMetrics,
            neuroStage = neuroStage,
            triggerStats = triggerStats,
            dayRiskStats = daysList,
            timeRiskStats = timeList,
            mostDangerousDay = peakDay,
            mostDangerousTimeRange = peakTime,
            peakDayCount = maxDayCount,
            peakTimeCount = maxTimeCount,
            history = history,
            velocityMetricsMap = velocityMap,
            urgeAnalytics = urgeAnalytics,
            dopamineBioSummary = dopamineBioSummary,
            timeReclaimedMetrics = timeReclaimedMetrics,
            realtimeVulnerability = realtimeVulnerability
        )
    }

    /**
     * حساب مقاييس النقاء الصارمة (100% Pure Days Ratio & MTBR)
     * مبنية على مبدأ المستخدم: لا تهاون، كل زلة انتكاسة، والهدف هو 100% نقاء مطلق
     */
    private fun calculatePurityMetrics(
        context: Context,
        history: List<RelapseRecord>,
        currentStats: RecoveryStats,
        currentStreakDays: Int
    ): PureDaysPurityMetrics {
        val prefs = getPrefs(context)
        val now = System.currentTimeMillis()

        val earliestTimestamp = run {
            val fromFirstPref = prefs.getLong(KEY_FIRST_EVER_START_TIME, currentStats.startTimestamp)
            val fromHistory = history.minOfOrNull { it.timestamp } ?: currentStats.startTimestamp
            minOf(fromFirstPref, fromHistory, currentStats.startTimestamp)
        }

        val totalDaysTracked = maxOf(1, ((now - earliestTimestamp) / 86400000L).toInt() + 1)
        val totalRelapses = history.size
        val totalPureDays = maxOf(0, totalDaysTracked - totalRelapses)
        val purePercentage = (totalPureDays.toFloat() / totalDaysTracked.toFloat() * 100f).coerceIn(0f, 100f)

        // حساب متوسط زمن الاستدامة الصافي (Mean Time Between Relapses)
        val mtbrDays = if (totalRelapses > 0) {
            val sortedAsc = history.sortedBy { it.timestamp }
            if (sortedAsc.size == 1) {
                val span = ((now - sortedAsc.first().timestamp) / 86400000L).toFloat()
                maxOf(1f, span)
            } else {
                var totalIntervals = 0L
                for (i in 1 until sortedAsc.size) {
                    totalIntervals += (sortedAsc[i].timestamp - sortedAsc[i - 1].timestamp)
                }
                (totalIntervals.toFloat() / (sortedAsc.size - 1).toFloat() / 86400000L).coerceAtLeast(1f)
            }
        } else {
            maxOf(currentStreakDays.toFloat(), 1f)
        }

        val status = when {
            purePercentage >= 98f -> "نقاء مطلق استثنائي (100% انضباط)"
            purePercentage >= 90f -> "استقرار متين ومسار نقي"
            purePercentage >= 75f -> "تحسن مستمر مع فترات صمود جيدة"
            else -> "مرحلة بناء الالتزام وترسيخ الحماية"
        }

        return PureDaysPurityMetrics(
            totalDaysTracked = totalDaysTracked,
            totalPureDays = totalPureDays,
            pureDaysPercentage = purePercentage,
            meanTimeBetweenRelapsesDays = mtbrDays,
            currentStreakDays = currentStreakDays,
            longestStreakDays = currentStats.longestStreakDays,
            totalRelapses = totalRelapses,
            cleanPurityStatus = status
        )
    }

    /**
     * حساب إحصائيات المحفزات السلوكية ونموذج HALT
     */
    private fun calculateTriggerStats(history: List<RelapseRecord>): List<TriggerStat> {
        val counts = mutableMapOf<String, Int>()
        for (item in history) {
            counts[item.triggerId] = (counts[item.triggerId] ?: 0) + 1
        }

        val total = history.size
        val maxCount = counts.values.maxOrNull() ?: 0

        return RelapseTrigger.values().map { trigger ->
            val count = counts[trigger.id] ?: 0
            TriggerStat(
                trigger = trigger,
                count = count,
                percentage = if (total > 0) (count.toFloat() / total.toFloat()) else 0f,
                isPrimary = count == maxCount && maxCount > 0
            )
        }.sortedByDescending { it.count }
    }

    /**
     * تحديد المرحلة العلمية الدقيقة لإعادة تشكيل الدماغ ومستقبلات الدوبامين (Neuroplasticity Stage)
     */
    fun getNeuroRecoveryStage(currentStreakDays: Int): NeuroRecoveryStage {
        return when {
            currentStreakDays <= 3 -> NeuroRecoveryStage(
                stageNumber = 1,
                stageName = "كسر دائرة الشوق الحاد",
                scientificTitle = "Acute Craving Disruption",
                dayRange = "1 - 3 أيام",
                biologicalExplanation = "تراجع مستويات الإثارة اللحظية الاصطناعية، وبدء الجهاز العصبي بالخروج من حالة الاستثارة المفرطة.",
                targetDays = 3,
                currentDays = currentStreakDays,
                progressPercent = (currentStreakDays.toFloat() / 3f).coerceIn(0.1f, 1f),
                keyActionableTip = "حافظ على ابتعاد الهاتف عن السرير ليلاً واشغل الدقائق الأولى بأنشطة بدنية ملموسة."
            )
            currentStreakDays <= 7 -> NeuroRecoveryStage(
                stageNumber = 2,
                stageName = "تجاوز ذروة أعراض الانسحاب",
                scientificTitle = "Withdrawal Peak Stabilization",
                dayRange = "4 - 7 أيام",
                biologicalExplanation = "استقرار تقلبات المزاج الأولية وتراجع الإشارات التلقائية التي كان يرسلها الدماغ لطلب المكافأة السريعة.",
                targetDays = 7,
                currentDays = currentStreakDays,
                progressPercent = ((currentStreakDays - 3).toFloat() / 4f).coerceIn(0.1f, 1f),
                keyActionableTip = "تجنب التصفح العشوائي لوسائل التواصل؛ فالصور العابرة تُشعل المسارات غير المستقرة."
            )
            currentStreakDays <= 14 -> NeuroRecoveryStage(
                stageNumber = 3,
                stageName = "إضعاف المسارات العصبية القديمة",
                scientificTitle = "Synaptic Pruning & Habit Weakening",
                dayRange = "8 - 14 يوماً",
                biologicalExplanation = "تبدأ الروابط العصبية القديمة الخاصة بروتين الإدمان بالضمور التدريجي لعدم استخدامها (Use it or lose it).",
                targetDays = 14,
                currentDays = currentStreakDays,
                progressPercent = ((currentStreakDays - 7).toFloat() / 7f).coerceIn(0.1f, 1f),
                keyActionableTip = "استبدل وقت الفراغ بروتين رياضي أو قراءة مكثفة لترسيخ روابط عصبية جديدة إيجابية."
            )
            currentStreakDays <= 30 -> NeuroRecoveryStage(
                stageNumber = 4,
                stageName = "استعادة السيطرة التنفيذية للفص الجبهي",
                scientificTitle = "Prefrontal Executive Restoration",
                dayRange = "15 - 30 يوماً",
                biologicalExplanation = "زيادة سماكة ونشاط قشرة الفص الجبهي المسؤولة عن قوة الإرادة، اتخاذ القرارات، والتحكم بالاندفاعات.",
                targetDays = 30,
                currentDays = currentStreakDays,
                progressPercent = ((currentStreakDays - 14).toFloat() / 16f).coerceIn(0.1f, 1f),
                keyActionableTip = "لاحظ كيف أصبح اتخاذ قرار الامتناع أسهل وأكثر تلقائية وعقلانية."
            )
            currentStreakDays <= 60 -> NeuroRecoveryStage(
                stageNumber = 5,
                stageName = "إعادة ضبط مستقبلات الدوبامين D2",
                scientificTitle = "Dopamine D2 Upregulation",
                dayRange = "31 - 60 يوماً",
                biologicalExplanation = "تزداد حساسية وكثافة مستقبلات الدوبامين في الدماغ، مما يعيد المتعة والبهجة في الأشياء الطبيعية البسيطة بالحياة.",
                targetDays = 60,
                currentDays = currentStreakDays,
                progressPercent = ((currentStreakDays - 30).toFloat() / 30f).coerceIn(0.1f, 1f),
                keyActionableTip = "استمتع بإنجازاتك اليومية الصغيرة، فدماغك الآن قادر على تذوق المكافآت الحقيقية."
            )
            currentStreakDays <= 90 -> NeuroRecoveryStage(
                stageNumber = 6,
                stageName = "اكتمال إعادة التهيئة العصبية (90d Reboot)",
                scientificTitle = "Neuroplastic Reboot Milestone",
                dayRange = "61 - 90 يوماً",
                biologicalExplanation = "اكتمال الدورة الكلاسيكية لإعادة هيكلة دوائر المكافأة في الدماغ وانفصال الهوية الذاتية تماماً عن السلوك الإدماني.",
                targetDays = 90,
                currentDays = currentStreakDays,
                progressPercent = ((currentStreakDays - 60).toFloat() / 30f).coerceIn(0.1f, 1f),
                keyActionableTip = "حافظ على التواضع واليقظة؛ النقاء الكامل أصبح أسلوب حياة طبيعي لديك."
            )
            else -> NeuroRecoveryStage(
                stageNumber = 7,
                stageName = "ترسيخ المناعة السلوكية والسيادة التامة",
                scientificTitle = "Long-Term Behavioral Mastery",
                dayRange = "90+ يوماً",
                biologicalExplanation = "حالة استقرار عصبي تام، ومناعة عالية تجاه المحفزات السابقة، وسيادة كاملة للعقل الواعي على الغرائز.",
                targetDays = 365,
                currentDays = currentStreakDays,
                progressPercent = 1.0f,
                keyActionableTip = "أنت تعيش الحرية الحقيقية الكاملة بنقاء 100%. واصل حماية عقلك وصناعة مستقبلك."
            )
        }
    }

    private fun getLogTimestamp(entry: BlockLogEntry): Long {
        if (entry.id > 1000000000000L) {
            return entry.id
        }
        try {
            val sdf1 = java.text.SimpleDateFormat("yyyy/MM/dd - HH:mm:ss", java.util.Locale.ENGLISH)
            val parsed = sdf1.parse(entry.timestamp)
            if (parsed != null) return parsed.time
        } catch (_: Exception) {}
        try {
            val sdf2 = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.ENGLISH)
            val parsed = sdf2.parse(entry.timestamp)
            if (parsed != null) return parsed.time
        } catch (_: Exception) {}
        return 0L
    }

    /**
     * حساب مؤشر تتبع سرعة التعافي وتحليل التحسن الزمني للفترة المحددة
     */
    fun calculateVelocityMetrics(context: Context, window: VelocityTimeWindow): RecoveryVelocityMetrics {
        val blockLogs = SaffahBlockRepository.getBlockLogs(context)
        val now = System.currentTimeMillis()
        val windowMillis = window.days * 24L * 60L * 60L * 1000L
        val currentPeriodStart = now - windowMillis
        val previousPeriodStart = now - (2 * windowMillis)

        val currentLogs = blockLogs.filter {
            val ts = getLogTimestamp(it)
            ts in currentPeriodStart..now
        }

        val previousLogs = blockLogs.filter {
            val ts = getLogTimestamp(it)
            ts in previousPeriodStart until currentPeriodStart
        }

        val currentTotal = currentLogs.size
        val previousTotal = previousLogs.size

        val currentKeywords = currentLogs.count { it.type.contains("كلمة") }
        val previousKeywords = previousLogs.count { it.type.contains("كلمة") }

        val currentSites = currentLogs.count { it.type.contains("موقع") }
        val previousSites = previousLogs.count { it.type.contains("موقع") }

        val changePercentage: Float
        val isImprovement: Boolean
        val isZeroStable: Boolean
        val velocityScore: Int
        val velocityLevelTitle: String
        val comparisonInsight: String

        val windowNameArabic = when (window) {
            VelocityTimeWindow.PAST_WEEK -> "الأسبوع السابق"
            VelocityTimeWindow.PAST_HALF_MONTH -> "نصف الشهر السابق"
            VelocityTimeWindow.PAST_MONTH -> "الشهر السابق"
        }

        if (previousTotal == 0 && currentTotal == 0) {
            changePercentage = 0f
            isZeroStable = true
            isImprovement = true
            velocityScore = 100
            velocityLevelTitle = "استقرار مثالي ونقاء تام"
            comparisonInsight = "سجل نظيف تماماً ومثالي! لم يتم تسجيل أي محاولة بحث أو تصفح محظور خلال الفترتين الحالية والسابقة ($windowNameArabic)."
        } else if (previousTotal > 0 && currentTotal == 0) {
            changePercentage = -100f
            isZeroStable = false
            isImprovement = true
            velocityScore = 100
            velocityLevelTitle = "تسارع تعافي استثنائي"
            comparisonInsight = "انخفاض بنسبة 100% في محاولات البحث والتصفح المحظور مقارنة بـ ($windowNameArabic)."
        } else if (previousTotal > 0 && currentTotal < previousTotal) {
            val reduction = ((previousTotal - currentTotal).toFloat() / previousTotal.toFloat()) * 100f
            changePercentage = -reduction
            isZeroStable = false
            isImprovement = true
            velocityScore = (60 + (reduction * 0.38f)).toInt().coerceIn(60, 98)
            velocityLevelTitle = if (reduction >= 50f) "تحسن متسارع وقوي" else "تحسن تدريجي ملحوظ"
            val reductionRounded = String.format(java.util.Locale.ENGLISH, "%.0f", reduction)
            comparisonInsight = "انخفاض ملحوظ في معدل محاولات البحث والتصفح بنسبة $reductionRounded% مقارنة بـ ($windowNameArabic)."
        } else if (previousTotal == 0 && currentTotal > 0) {
            changePercentage = 100f
            isZeroStable = false
            isImprovement = false
            velocityScore = maxOf(30, 75 - (currentTotal * 6))
            velocityLevelTitle = "بحاجة لتعزيز الحذر"
            comparisonInsight = "تم رصد $currentTotal محاولات في الفترة الحالية مقارنة بعدم وجود محاولات في ($windowNameArabic)."
        } else {
            val diff = currentTotal - previousTotal
            val increase = if (previousTotal > 0) (diff.toFloat() / previousTotal.toFloat()) * 100f else 0f
            changePercentage = increase
            isZeroStable = false
            isImprovement = false
            velocityScore = maxOf(25, 65 - (currentTotal * 4))
            val increaseRounded = String.format(java.util.Locale.ENGLISH, "%.0f", increase)
            if (currentTotal == previousTotal) {
                velocityLevelTitle = "استقرار بمستوى المحاولات"
                comparisonInsight = "معدل المحاولات متطابق مع ($windowNameArabic) بإجمالي $currentTotal محاولة."
            } else {
                velocityLevelTitle = "ارتفاع بمعدل المحفزات"
                comparisonInsight = "ارتفاع في معدل المحاولات بنسبة $increaseRounded% مقارنة بـ ($windowNameArabic)."
            }
        }

        return RecoveryVelocityMetrics(
            window = window,
            currentPeriodAttempts = currentTotal,
            previousPeriodAttempts = previousTotal,
            currentKeywordsCount = currentKeywords,
            previousKeywordsCount = previousKeywords,
            currentSitesCount = currentSites,
            previousSitesCount = previousSites,
            changePercentage = changePercentage,
            isImprovement = isImprovement,
            isZeroStable = isZeroStable,
            velocityScore = velocityScore,
            velocityLevelTitle = velocityLevelTitle,
            comparisonInsight = comparisonInsight
        )
    }

    /**
     * الحصول على الهدف والمحطة القادمة (5, 10, 15, 20...)
     */
    fun getNextMilestone(currentStreakDays: Int): Pair<Int, Float> {
        if (currentStreakDays >= 730) {
            return 730 to 1.0f
        }
        val nextDay = ((currentStreakDays / 5) + 1) * 5
        val prevDay = (currentStreakDays / 5) * 5
        val progress = if (nextDay > prevDay) {
            ((currentStreakDays - prevDay).toFloat() / 5f).coerceIn(0f, 1f)
        } else 1f

        return nextDay to progress
    }

    /**
     * الحصول على رسالة تحفيزية بناءً على المحطة
     */
    fun getMotivationalQuote(currentDays: Int): String {
        return when {
            currentDays == 0 -> "البداية هي نصف الطريق. خطوتك الأولى اليوم تبني مستقبلك وغدك المشرق!"
            currentDays < 5 -> "عظيم! الأيام الأولى تتطلب أقصى درجات التركيز. أنت تثبت الآن قوة إرادتك."
            currentDays < 10 -> "أنجزت أول 5 أيام بنجاح! جسمك وعقلك يبدآن بالتخلص من الرغبات اللحظية."
            currentDays < 15 -> "تجاوزت الـ 10 أيام! مسارات دماغك بدأت تتغير لصالحك، واصل بقوة."
            currentDays < 30 -> "صمود مذهل! أنت تبني هوية جديدة خالية من الإدمان، حافظ على هذا الزخم."
            currentDays < 60 -> "أكثر من شهر من السيادة والحرية! أنت تلهم كل من حولك بقوتك وثباتك."
            currentDays < 90 -> "اقتربت من حاجز الـ 90 يوماً الأسطوري! الدوبامين يعود لمستوياته الطبيعية."
            currentDays < 180 -> "أنت الآن في مرحلة السيادة التامة. الانضباط أصبح جزءاً لا يتجزأ من شخصيتك."
            currentDays < 365 -> "مئات الأيام من النقاء والارتقاء! أنت تصنع تاريخاً شخصياً يفخر به الجميع."
            currentDays < 730 -> "سنة كاملة وما بعدها! أصبحت مثلاً أعلى في قوة العزيمة والتحكم بالنفس."
            else -> "730 يوماً من النقاء والأسطورية! لقد حققت السيادة الكاملة وختمت مسار السنتين بامتياز!"
        }
    }

    // ==========================================
    // مؤشر خط الأساس اليومي (Daily Baseline Index)
    // ==========================================

    /**
     * قراءة كافة سجلات فحص خط الأساس اليومي المحفوظة محلياً
     * مرتبة زمنياً تصاعدياً
     * ملاحظة هامة: لا يتم إنشاء أو تقدير أي قيم تلقائياً للأيام غير المكتملة
     */
    fun getDailyBaselineHistory(context: Context): List<DailyBaselineCheckIn> {
        val prefs = getPrefs(context)
        val jsonStr = prefs.getString(KEY_DAILY_BASELINE_JSON, null)
        val list = mutableListOf<DailyBaselineCheckIn>()

        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val clarity = obj.optInt("clarityOfMind", 3).coerceIn(1, 5)
                    val mood = obj.optInt("moodStability", 3).coerceIn(1, 5)
                    val sleep = obj.optInt("sleepQuality", 3).coerceIn(1, 5)
                    val energy = obj.optInt("energyAndMotivation", 3).coerceIn(1, 5)
                    val timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    val dateKey = obj.optString(
                        "dateKey",
                        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(timestamp))
                    )
                    val id = obj.optString("id", UUID.randomUUID().toString())

                    list.add(
                        DailyBaselineCheckIn(
                            id = id,
                            timestamp = timestamp,
                            dateKey = dateKey,
                            clarityOfMind = clarity,
                            moodStability = mood,
                            sleepQuality = sleep,
                            energyAndMotivation = energy
                        )
                    )
                }
            } catch (e: Exception) {
                android.util.Log.e("SaffahRecoveryManager", "Error parsing baseline history: ${e.message}")
            }
        }

        return list.sortedBy { it.timestamp }
    }

    /**
     * التحقق مما إذا كان فحص اليوم قد تم تسجيله مسبقاً
     */
    fun getTodayBaselineCheckIn(context: Context): DailyBaselineCheckIn? {
        val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        return getDailyBaselineHistory(context).find { it.dateKey == todayKey }
    }

    /**
     * حفظ أو تحديث فحص خط الأساس اليومي
     */
    fun saveDailyBaselineCheckIn(context: Context, checkIn: DailyBaselineCheckIn) {
        val history = getDailyBaselineHistory(context).toMutableList()
        val existingIndex = history.indexOfFirst { it.dateKey == checkIn.dateKey }
        if (existingIndex >= 0) {
            history[existingIndex] = checkIn
        } else {
            history.add(checkIn)
        }

        val array = JSONArray()
        for (item in history) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("dateKey", item.dateKey)
                put("clarityOfMind", item.clarityOfMind)
                put("moodStability", item.moodStability)
                put("sleepQuality", item.sleepQuality)
                put("energyAndMotivation", item.energyAndMotivation)
            }
            array.put(obj)
        }
        getPrefs(context).edit().putString(KEY_DAILY_BASELINE_JSON, array.toString()).apply()
    }

    /**
     * حذف فحص معين
     */
    fun deleteDailyBaselineCheckIn(context: Context, id: String) {
        val history = getDailyBaselineHistory(context).filter { it.id != id }
        val array = JSONArray()
        for (item in history) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("dateKey", item.dateKey)
                put("clarityOfMind", item.clarityOfMind)
                put("moodStability", item.moodStability)
                put("sleepQuality", item.sleepQuality)
                put("energyAndMotivation", item.energyAndMotivation)
            }
            array.put(obj)
        }
        getPrefs(context).edit().putString(KEY_DAILY_BASELINE_JSON, array.toString()).apply()
    }

    /**
     * حساب منحنى التعافي التراكمي التدريجي عبر الزمن لجميع الفحوصات اليومية
     * بحيث يبدأ من مستوى منخفض واقعي (10% - 15%) ويرتفع تدريجياً مع تراكم أيام التعافي
     * والتزام الفحص اليومي، مع إمكانية حدوث انخفاضات طفيفة عند وجود أيام صعبة
     * وصولاً إلى 100% كهدف تعافٍ مستدام طويل المدى.
     */
    fun calculateCumulativeRecoveryScores(history: List<DailyBaselineCheckIn>): List<Int> {
        if (history.isEmpty()) return emptyList()
        val sorted = history.sortedBy { it.timestamp }
        val scores = mutableListOf<Int>()
        var currentScore = 0.0

        sorted.forEachIndexed { index, item ->
            val avg = item.averageScore.coerceIn(1.0, 5.0)
            if (index == 0) {
                // البداية من مستوى واقعي منخفض (8% إلى 16%) يعكس نقطة انطلاق التعافي
                currentScore = 8.0 + (avg - 1.0) * 2.0
            } else {
                // تأثير تقييم اليوم على مسار التعافي: التقييم فوق 2.5 يساهم في دفع التعافي للأمام
                val rawDelta = (avg - 2.5) * 1.35
                if (rawDelta >= 0) {
                    // تناقص العائدات للاقتراب من 100% بشكل تدريجي ومستدام (Diminishing returns)
                    val headroom = ((110.0 - currentScore) / 100.0).coerceIn(0.18, 1.0)
                    val step = (rawDelta * headroom) + 0.35
                    currentScore = (currentScore + step).coerceIn(2.0, 100.0)
                } else {
                    // تراجع طفيف ومؤقت لا يمسح كل المكتسبات العصبية السابقة
                    val dip = rawDelta * 0.85
                    currentScore = (currentScore + dip).coerceIn(2.0, 100.0)
                }
            }
            scores.add(Math.round(currentScore).toInt().coerceIn(1, 100))
        }
        return scores
    }

    /**
     * الحصول على درجة التعافي التراكمية الحالية
     */
    fun getCurrentBaselineRecoveryScore(context: Context): Int {
        val history = getDailyBaselineHistory(context)
        if (history.isEmpty()) return 0
        val scores = calculateCumulativeRecoveryScores(history)
        return scores.lastOrNull() ?: 0
    }

    /**
     * تحويل سجلات الفحص إلى نقاط بيانية للمخطط التفاعلي
     * بناءً على الفلتر المختار (يومي / أسبوعي / شهري)
     * يعتمد حصراً على السجلات الفعلية فقط
     */
    fun getBaselineDataPoints(context: Context, period: BaselineChartPeriod): List<BaselineDataPoint> {
        val history = getDailyBaselineHistory(context).sortedBy { it.timestamp }
        if (history.isEmpty()) return emptyList()

        val cumulativeDailyScores = calculateCumulativeRecoveryScores(history)

        return when (period) {
            BaselineChartPeriod.DAY -> {
                val dayFormat = java.text.SimpleDateFormat("d", java.util.Locale.US)
                val monthFormat = java.text.SimpleDateFormat("MMM", java.util.Locale.US)
                val yearFormat = java.text.SimpleDateFormat("yyyy", java.util.Locale.US)
                var lastMonth = ""

                history.mapIndexed { index, item ->
                    val date = java.util.Date(item.timestamp)
                    val curMonth = monthFormat.format(date)
                    val curYear = yearFormat.format(date)
                    val isFirstOrMonthChange = (index == 0 || curMonth != lastMonth)
                    if (isFirstOrMonthChange) {
                        lastMonth = curMonth
                    }

                    val subLabel = if (isFirstOrMonthChange) curMonth else null
                    val yearLabel = if (index == 0) curYear else null

                    BaselineDataPoint(
                        key = item.dateKey,
                        displayLabel = dayFormat.format(date),
                        subLabel = subLabel,
                        yearLabel = yearLabel,
                        timestamp = item.timestamp,
                        scorePercentage = cumulativeDailyScores.getOrElse(index) { 15 },
                        rawAverage = item.averageScore,
                        clarity = item.clarityOfMind.toDouble(),
                        mood = item.moodStability.toDouble(),
                        sleep = item.sleepQuality.toDouble(),
                        energy = item.energyAndMotivation.toDouble(),
                        checkInCount = 1
                    )
                }
            }

            BaselineChartPeriod.WEEK -> {
                val cal = Calendar.getInstance()
                val weekGroups = history.mapIndexed { index, item ->
                    Pair(item, cumulativeDailyScores.getOrElse(index) { 15 })
                }.groupBy { (item, _) ->
                    cal.timeInMillis = item.timestamp
                    val year = cal.get(Calendar.YEAR)
                    val week = cal.get(Calendar.WEEK_OF_YEAR)
                    "$year-W$week"
                }

                weekGroups.map { (weekKey, pairList) ->
                    val items = pairList.map { it.first }
                    val avgClarity = items.map { it.clarityOfMind }.average()
                    val avgMood = items.map { it.moodStability }.average()
                    val avgSleep = items.map { it.sleepQuality }.average()
                    val avgEnergy = items.map { it.energyAndMotivation }.average()
                    val overallAvg = (avgClarity + avgMood + avgSleep + avgEnergy) / 4.0
                    val latestCumulativeScore = pairList.last().second
                    val weekNum = weekKey.substringAfter("-W")

                    BaselineDataPoint(
                        key = weekKey,
                        displayLabel = "W$weekNum",
                        subLabel = "أسبوع $weekNum",
                        timestamp = items.map { it.timestamp }.average().toLong(),
                        scorePercentage = latestCumulativeScore,
                        rawAverage = overallAvg,
                        clarity = avgClarity,
                        mood = avgMood,
                        sleep = avgSleep,
                        energy = avgEnergy,
                        checkInCount = items.size
                    )
                }.sortedBy { it.timestamp }
            }

            BaselineChartPeriod.MONTH -> {
                val monthFormat = java.text.SimpleDateFormat("MMM", java.util.Locale.US)
                val monthYearFormat = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US)

                val monthGroups = history.mapIndexed { index, item ->
                    Pair(item, cumulativeDailyScores.getOrElse(index) { 15 })
                }.groupBy { (item, _) ->
                    monthYearFormat.format(java.util.Date(item.timestamp))
                }

                monthGroups.map { (monthKey, pairList) ->
                    val items = pairList.map { it.first }
                    val avgClarity = items.map { it.clarityOfMind }.average()
                    val avgMood = items.map { it.moodStability }.average()
                    val avgSleep = items.map { it.sleepQuality }.average()
                    val avgEnergy = items.map { it.energyAndMotivation }.average()
                    val overallAvg = (avgClarity + avgMood + avgSleep + avgEnergy) / 4.0
                    val latestCumulativeScore = pairList.last().second
                    val firstItemDate = java.util.Date(items.first().timestamp)

                    BaselineDataPoint(
                        key = monthKey,
                        displayLabel = monthFormat.format(firstItemDate),
                        subLabel = monthKey,
                        timestamp = items.map { it.timestamp }.average().toLong(),
                        scorePercentage = latestCumulativeScore,
                        rawAverage = overallAvg,
                        clarity = avgClarity,
                        mood = avgMood,
                        sleep = avgSleep,
                        energy = avgEnergy,
                        checkInCount = items.size
                    )
                }.sortedBy { it.timestamp }
            }
        }
    }

    /**
     * حساب واسترجاع قائمة أطول سلاسل أيام التعافي مرتبة من الأطول إلى الأقل
     */
    fun getRecoveryStreaks(
        context: Context,
        currentTimeMs: Long = System.currentTimeMillis()
    ): List<RecoveryStreakRecord> {
        val prefs = getPrefs(context)
        val stats = getRecoveryStats(context)
        val history = getRelapseHistory(context)
        val firstEver = prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
        return buildRecoveryStreaks(
            stats = stats,
            history = history,
            firstEverStartTime = firstEver,
            currentTimeMs = currentTimeMs
        )
    }

    /**
     * بناء وتصنيف سلاسل التعافي وحساب المدد بدقة
     */
    fun buildRecoveryStreaks(
        stats: RecoveryStats,
        history: List<RelapseRecord>,
        firstEverStartTime: Long,
        currentTimeMs: Long
    ): List<RecoveryStreakRecord> {
        val streaks = mutableListOf<RecoveryStreakRecord>()
        val now = currentTimeMs

        // 1. السلسلة الحالية (المستمرة)
        val currentStart = stats.startTimestamp
        val currentSec = maxOf(0L, (now - currentStart) / 1000L)
        val currentDays = (currentSec / 86400L).toInt()
        val currentHours = ((currentSec % 86400L) / 3600L).toInt()
        val currentMinutes = ((currentSec % 3600L) / 60L).toInt()

        streaks.add(
            RecoveryStreakRecord(
                id = "ongoing_streak",
                startTimestamp = currentStart,
                endTimestamp = now,
                isOngoing = true,
                days = currentDays,
                hours = currentHours,
                minutes = currentMinutes,
                totalSeconds = currentSec
            )
        )

        // 2. فترات وسلاسل التعافي بين الانتكاسات التاريخية
        val sortedRelapses = history.sortedBy { it.timestamp }
        if (sortedRelapses.isNotEmpty()) {
            // السلاسل بين كل انتكاستين متتاليتين
            for (i in 0 until sortedRelapses.size - 1) {
                val start = sortedRelapses[i].timestamp
                val end = sortedRelapses[i + 1].timestamp
                if (end > start) {
                    val sec = (end - start) / 1000L
                    val d = (sec / 86400L).toInt()
                    val h = ((sec % 86400L) / 3600L).toInt()
                    val m = ((sec % 3600L) / 60L).toInt()
                    streaks.add(
                        RecoveryStreakRecord(
                            id = "streak_${sortedRelapses[i].id}_to_${sortedRelapses[i + 1].id}",
                            startTimestamp = start,
                            endTimestamp = end,
                            isOngoing = false,
                            days = d,
                            hours = h,
                            minutes = m,
                            totalSeconds = sec
                        )
                    )
                }
            }

            // السلسلة التي سبقت الانتكاسة الأولى المسجلة
            val firstRelapseTime = sortedRelapses.first().timestamp
            val effectiveFirstStart = if (firstEverStartTime in 1 until firstRelapseTime) {
                firstEverStartTime
            } else if (stats.longestStreakSeconds > currentSec && stats.longestStreakSeconds > 0L) {
                firstRelapseTime - (stats.longestStreakSeconds * 1000L)
            } else {
                0L
            }

            if (effectiveFirstStart in 1 until firstRelapseTime) {
                val sec = (firstRelapseTime - effectiveFirstStart) / 1000L
                val d = (sec / 86400L).toInt()
                val h = ((sec % 86400L) / 3600L).toInt()
                val m = ((sec % 3600L) / 60L).toInt()
                streaks.add(
                    RecoveryStreakRecord(
                        id = "streak_initial_to_first",
                        startTimestamp = effectiveFirstStart,
                        endTimestamp = firstRelapseTime,
                        isOngoing = false,
                        days = d,
                        hours = h,
                        minutes = m,
                        totalSeconds = sec
                    )
                )
            }
        } else if (stats.longestStreakSeconds > currentSec && stats.longestStreakSeconds > 0L) {
            // لا توجد انتكاسات مسجلة ولكن هناك رقم قياسي محفوظ سابقاً
            val recSec = stats.longestStreakSeconds
            val recDays = (recSec / 86400L).toInt()
            val recHours = ((recSec % 86400L) / 3600L).toInt()
            val recMin = ((recSec % 3600L) / 60L).toInt()
            val recEnd = stats.startTimestamp
            val recStart = recEnd - (recSec * 1000L)
            streaks.add(
                RecoveryStreakRecord(
                    id = "streak_historical_record",
                    startTimestamp = recStart,
                    endTimestamp = recEnd,
                    isOngoing = false,
                    days = recDays,
                    hours = recHours,
                    minutes = recMin,
                    totalSeconds = recSec
                )
            )
        }

        // إذا كان هناك أطول مدة مسجلة في الإحصائيات لم يتم تمثيلها بأي سلسلة حتى الآن
        val maxComputedSec = streaks.maxOfOrNull { it.totalSeconds } ?: 0L
        if (stats.longestStreakSeconds > maxComputedSec + 3600L) {
            val recSec = stats.longestStreakSeconds
            val recDays = (recSec / 86400L).toInt()
            val recHours = ((recSec % 86400L) / 3600L).toInt()
            val recMin = ((recSec % 3600L) / 60L).toInt()
            val recEnd = if (sortedRelapses.isNotEmpty()) sortedRelapses.minOf { it.timestamp } else stats.startTimestamp
            val recStart = recEnd - (recSec * 1000L)
            streaks.add(
                RecoveryStreakRecord(
                    id = "streak_historical_peak",
                    startTimestamp = recStart,
                    endTimestamp = recEnd,
                    isOngoing = false,
                    days = recDays,
                    hours = recHours,
                    minutes = recMin,
                    totalSeconds = recSec
                )
            )
        }

        // إزالة أي تكرار وتحديد الترتيب من الأطول مدة إلى الأقل مدة
        val sorted = streaks.sortedByDescending { it.totalSeconds }
        val maxSec = sorted.maxOfOrNull { it.totalSeconds } ?: 0L

        return sorted.mapIndexed { index, record ->
            record.copy(
                rank = index + 1,
                isAllTimeRecord = record.totalSeconds == maxSec && maxSec > 0L
            )
        }
    }

    /**
     * استرجاع بيانات وثيقة تعهد التعافي
     */
    fun getRecoveryPledge(context: Context): RecoveryPledgeData {
        val jsonStr = getPrefs(context).getString(KEY_RECOVERY_PLEDGE_JSON, null)
        if (jsonStr.isNullOrBlank()) {
            val defaultName = getUserName(context)
            val initialText = if (defaultName.isNotBlank()) {
                DEFAULT_PLEDGE_TEMPLATE.replace("[اكتب اسمك هنا]", defaultName)
            } else {
                DEFAULT_PLEDGE_TEMPLATE
            }
            return RecoveryPledgeData(
                pledgeText = initialText,
                isSigned = false,
                signerName = defaultName
            )
        }
        return try {
            val obj = JSONObject(jsonStr)
            RecoveryPledgeData(
                pledgeText = obj.optString("pledgeText", DEFAULT_PLEDGE_TEMPLATE),
                isSigned = obj.optBoolean("isSigned", false),
                signedDate = obj.optString("signedDate", ""),
                signedTime = obj.optString("signedTime", ""),
                signedTimestamp = obj.optLong("signedTimestamp", 0L),
                signaturePointsJson = obj.optString("signaturePointsJson", ""),
                videoPath = obj.optString("videoPath", ""),
                signerName = obj.optString("signerName", getUserName(context))
            )
        } catch (e: Exception) {
            RecoveryPledgeData(pledgeText = DEFAULT_PLEDGE_TEMPLATE)
        }
    }

    /**
     * حفظ وتوثيق وثيقة تعهد التعافي
     */
    fun saveRecoveryPledge(context: Context, data: RecoveryPledgeData) {
        try {
            val obj = JSONObject().apply {
                put("pledgeText", data.pledgeText)
                put("isSigned", data.isSigned)
                put("signedDate", data.signedDate)
                put("signedTime", data.signedTime)
                put("signedTimestamp", data.signedTimestamp)
                put("signaturePointsJson", data.signaturePointsJson)
                put("videoPath", data.videoPath)
                put("signerName", data.signerName)
            }
            getPrefs(context).edit().putString(KEY_RECOVERY_PLEDGE_JSON, obj.toString()).apply()
            if (data.signerName.isNotBlank() && getUserName(context).isBlank()) {
                setUserName(context, data.signerName)
            }
        } catch (e: Exception) {
            android.util.Log.e("SaffahRecoveryManager", "Error saving recovery pledge: ${e.message}")
        }
    }

    /**
     * تفريغ وإعادة ضبط وثيقة تعهد التعافي
     */
    fun clearRecoveryPledge(context: Context) {
        val pledge = getRecoveryPledge(context)
        if (pledge.videoPath.isNotBlank()) {
            try {
                val f = java.io.File(pledge.videoPath)
                if (f.exists()) f.delete()
            } catch (_: Exception) {}
        }
        getPrefs(context).edit().remove(KEY_RECOVERY_PLEDGE_JSON).apply()
    }

    // ==========================================
    // تقويم تتبع التعافي (Recovery Tracking Calendar)
    // ==========================================

    /**
     * جلب سجلات الأيام في تقويم تتبع التعافي
     */
    fun getRecoveryCalendarHistory(context: Context): Map<String, DailyCalendarStatus> {
        val prefs = getPrefs(context)
        val jsonStr = prefs.getString(KEY_RECOVERY_CALENDAR_JSON, null)
        val map = mutableMapOf<String, DailyCalendarStatus>()

        if (!jsonStr.isNullOrBlank()) {
            try {
                val obj = JSONObject(jsonStr)
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val statusId = obj.optString(k, DailyCalendarStatus.NONE.id)
                    val status = DailyCalendarStatus.values().find { it.id == statusId } ?: DailyCalendarStatus.NONE
                    if (status != DailyCalendarStatus.NONE) {
                        map[k] = status
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("SaffahRecoveryManager", "Error parsing recovery calendar: ${e.message}")
            }
        }

        // دمج الانتكاسات المسجلة في السجل تلقائياً لضمان التوافق المطلق
        val relapses = getRelapseHistory(context)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for (r in relapses) {
            val dateStr = sdf.format(Date(r.timestamp))
            map[dateStr] = DailyCalendarStatus.RELAPSE
        }

        return map
    }

    /**
     * تعيين حالة يوم محدد في تقويم التعافي مع مزامنة العداد وسجل الانتكاسات
     */
    fun setCalendarDayStatus(context: Context, dateKey: String, status: DailyCalendarStatus) {
        val prefs = getPrefs(context)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayKey = sdf.format(Date())
        val isToday = dateKey == todayKey

        val currentCal = getRecoveryCalendarHistory(context).toMutableMap()
        val history = getRelapseHistory(context).toMutableList()

        if (status == DailyCalendarStatus.RELAPSE) {
            currentCal[dateKey] = DailyCalendarStatus.RELAPSE

            val existingRelapse = history.find { sdf.format(Date(it.timestamp)) == dateKey }
            if (existingRelapse == null) {
                val recordTimestamp = if (isToday) {
                    System.currentTimeMillis()
                } else {
                    try {
                        val parsed = sdf.parse(dateKey)
                        val cal = Calendar.getInstance().apply {
                            if (parsed != null) time = parsed
                            set(Calendar.HOUR_OF_DAY, 12)
                            set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        cal.timeInMillis
                    } catch (_: Exception) {
                        System.currentTimeMillis()
                    }
                }

                val newRecord = RelapseRecord(
                    id = UUID.randomUUID().toString(),
                    timestamp = recordTimestamp,
                    note = if (isToday) "انتكاسة مسجلة من تقويم التتبع" else "انتكاسة تاريخية مسجلة من التقويم",
                    triggerId = RelapseTrigger.OTHER.id,
                    defenseAction = "الاستفادة من الخطأ والانضباط التام",
                    preventiveDecision = "الاستفادة من الخطأ والانضباط التام"
                )
                history.add(newRecord)
                history.sortByDescending { it.timestamp }
                saveRelapseHistoryInternal(context, history)

                val editor = prefs.edit()
                editor.putInt(KEY_RELAPSE_COUNT, history.size)

                val currentStartTime = prefs.getLong(KEY_START_TIME, System.currentTimeMillis())
                if (isToday || recordTimestamp >= currentStartTime) {
                    editor.putLong(KEY_START_TIME, recordTimestamp)
                }
                val firstEver = prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
                if (firstEver <= 0L || recordTimestamp < firstEver) {
                    editor.putLong(KEY_FIRST_EVER_START_TIME, recordTimestamp)
                }
                editor.apply()
            }
        } else {
            // SUCCESS or SKIPPED or NONE
            if (status == DailyCalendarStatus.NONE) {
                currentCal.remove(dateKey)
            } else {
                currentCal[dateKey] = status
            }

            // إزالة أي سجل انتكاسة يطابق هذا التاريخ لمنع التناقض بين التقويم والعداد
            val removedAny = history.removeAll { sdf.format(Date(it.timestamp)) == dateKey }
            if (removedAny) {
                saveRelapseHistoryInternal(context, history)
                val editor = prefs.edit()
                editor.putInt(KEY_RELAPSE_COUNT, history.size)

                val latestRemaining = history.maxByOrNull { it.timestamp }
                val firstEver = prefs.getLong(KEY_FIRST_EVER_START_TIME, 0L)
                if (latestRemaining != null) {
                    editor.putLong(KEY_START_TIME, latestRemaining.timestamp)
                } else if (firstEver > 0L) {
                    editor.putLong(KEY_START_TIME, firstEver)
                }
                editor.apply()
            }
        }

        val obj = JSONObject()
        for ((k, v) in currentCal) {
            obj.put(k, v.id)
        }
        prefs.edit().putString(KEY_RECOVERY_CALENDAR_JSON, obj.toString()).apply()

        getRecoveryStats(context)
    }

    /**
     * جلب تواريخ الأيام التي تم فيها دحر رغبة ملحة بنجاح (Urge Surfing)
     */
    fun getUrgeDefeatedDates(context: Context): Set<String> {
        val urges = getUrgeHistory(context)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val set = mutableSetOf<String>()
        for (u in urges) {
            set.add(sdf.format(Date(u.timestamp)))
        }
        return set
    }
}

