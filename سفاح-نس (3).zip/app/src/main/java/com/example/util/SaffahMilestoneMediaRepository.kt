package com.example.util

import android.content.Context
import android.util.Log
import com.example.model.DiaryMediaItem
import com.example.model.DiaryMediaSource
import com.example.model.DiaryMediaType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * مستودع إدارة وحفظ تسجيلات الصوت والفيديو الخاصة بمحطات خريطة رحلة التعافي
 */
object SaffahMilestoneMediaRepository {

    private const val TAG = "MilestoneMediaRepo"
    private const val DATA_FILE = "milestone_media_records.json"

    private fun getMediaDirectory(context: Context): File {
        val dir = File(context.filesDir, "milestone_media")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        SaffahMediaCompressor.initSecurity(context)
        return dir
    }

    private fun getDataFile(context: Context): File {
        val dir = getMediaDirectory(context)
        return File(dir, DATA_FILE)
    }

    @Synchronized
    fun getMediaForMilestone(context: Context, milestoneDay: Int): List<DiaryMediaItem> {
        val file = getDataFile(context)
        if (!file.exists()) return emptyList()

        return try {
            val jsonStr = file.readText()
            if (jsonStr.isBlank()) return emptyList()
            val rootObj = JSONObject(jsonStr)
            val key = milestoneDay.toString()
            if (!rootObj.has(key)) return emptyList()

            val array = rootObj.getJSONArray(key)
            val list = mutableListOf<DiaryMediaItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.getString("id")
                val typeStr = obj.getString("type")
                val sourceStr = obj.optString("source", DiaryMediaSource.RECORDED_IN_APP.name)
                val filePath = obj.getString("filePath")
                val fileName = obj.optString("fileName", "")
                val durationSeconds = obj.optInt("durationSeconds", 0)
                val fileSizeBytes = obj.optLong("fileSizeBytes", 0L)
                val createdAt = obj.optLong("createdAt", System.currentTimeMillis())

                val type = try {
                    DiaryMediaType.valueOf(typeStr)
                } catch (e: Exception) {
                    DiaryMediaType.AUDIO
                }

                val source = try {
                    DiaryMediaSource.valueOf(sourceStr)
                } catch (e: Exception) {
                    DiaryMediaSource.RECORDED_IN_APP
                }

                list.add(
                    DiaryMediaItem(
                        id = id,
                        type = type,
                        source = source,
                        filePath = filePath,
                        fileName = fileName,
                        durationSeconds = durationSeconds,
                        fileSizeBytes = fileSizeBytes,
                        createdAt = createdAt
                    )
                )
            }
            list.sortedByDescending { it.createdAt }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading milestone media: ${e.message}", e)
            emptyList()
        }
    }

    @Synchronized
    fun saveMediaForMilestone(context: Context, milestoneDay: Int, mediaList: List<DiaryMediaItem>) {
        try {
            val file = getDataFile(context)
            val rootObj = if (file.exists() && file.readText().isNotBlank()) {
                JSONObject(file.readText())
            } else {
                JSONObject()
            }

            val array = JSONArray()
            for (m in mediaList) {
                val obj = JSONObject().apply {
                    put("id", m.id)
                    put("type", m.type.name)
                    put("source", m.source.name)
                    put("filePath", m.filePath)
                    put("fileName", m.fileName)
                    put("durationSeconds", m.durationSeconds)
                    put("fileSizeBytes", m.fileSizeBytes)
                    put("createdAt", m.createdAt)
                }
                array.put(obj)
            }

            rootObj.put(milestoneDay.toString(), array)
            val tempFile = File(file.parentFile, "${file.name}.tmp")
            tempFile.writeText(rootObj.toString(2))
            if (tempFile.exists()) {
                if (file.exists()) file.delete()
                tempFile.renameTo(file)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving milestone media: ${e.message}", e)
        }
    }

    @Synchronized
    fun addMediaToMilestone(context: Context, milestoneDay: Int, media: DiaryMediaItem) {
        val current = getMediaForMilestone(context, milestoneDay).toMutableList()
        current.add(0, media)
        saveMediaForMilestone(context, milestoneDay, current)
    }

    @Synchronized
    fun deleteMediaFromMilestone(context: Context, milestoneDay: Int, mediaId: String) {
        val current = getMediaForMilestone(context, milestoneDay).toMutableList()
        val target = current.find { it.id == mediaId }
        target?.let {
            try {
                SaffahMediaCompressor.deleteMediaAndThumbnail(it.filePath)
            } catch (e: Exception) {
                Log.w(TAG, "Error deleting file: ${e.message}")
            }
        }
        current.removeAll { it.id == mediaId }
        saveMediaForMilestone(context, milestoneDay, current)
    }

    @Synchronized
    fun renameMediaInMilestone(context: Context, milestoneDay: Int, mediaId: String, newName: String) {
        val current = getMediaForMilestone(context, milestoneDay).map {
            if (it.id == mediaId) it.copy(fileName = newName) else it
        }
        saveMediaForMilestone(context, milestoneDay, current)
    }

    fun createMilestoneAudioFile(context: Context, milestoneDay: Int): File {
        val dir = getMediaDirectory(context)
        return File(dir, "milestone_${milestoneDay}_audio_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.m4a")
    }

    fun createMilestoneVideoFile(context: Context, milestoneDay: Int): File {
        val dir = getMediaDirectory(context)
        return File(dir, "milestone_${milestoneDay}_video_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.mp4")
    }
}
