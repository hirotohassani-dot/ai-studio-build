package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.model.DnsFilterServer
import com.example.util.SaffahBlockRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class SaffahVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    @Volatile private var mainExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var dnsWorkerPool: ExecutorService = Executors.newFixedThreadPool(4)
    @Volatile private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        // Always promote to foreground immediately for Android 8+ / 14 compatibility
        val notification = createVpnNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e("SaffahVpn", "startForeground failed safely: ${e.message}")
        }

        if (com.example.util.SaffahProtectionManager.isKeeperServiceEnabled(this)) {
            SaffahKeeperService.ensureKeeperNotification(this)
        }

        if (action == ACTION_STOP_VPN) {
            stopVpn()
            return START_NOT_STICKY
        }

        val dnsServerOrdinal = intent?.getIntExtra(EXTRA_DNS_SERVER, 0) ?: 0
        val selectedDns = DnsFilterServer.values().getOrElse(dnsServerOrdinal) { DnsFilterServer.CLEAN_BROWSING }
        
        val providedExcludedArray = intent?.getStringArrayExtra(EXTRA_EXCLUDED_PACKAGES)
        val excludedSet: Set<String> = if (providedExcludedArray != null && providedExcludedArray.isNotEmpty()) {
            val set = providedExcludedArray.toSet()
            com.example.util.SaffahBlockRepository.saveExcludedVpnApps(this, set)
            set
        } else {
            com.example.util.SaffahBlockRepository.getExcludedVpnApps(this)
        }

        startVpn(selectedDns, excludedSet, isExplicitAction = (action == ACTION_START_VPN))
        return START_STICKY
    }

    private var activeExcludedPackagesSet: Set<String>? = null
    private var activeDnsServer: DnsFilterServer? = null
    @Volatile private var cachedPrimaryIpBytes: ByteArray? = null
    @Volatile private var cachedSecondaryIpBytes: ByteArray? = null

    private fun startVpn(dnsServer: DnsFilterServer, excludedSet: Set<String>, isExplicitAction: Boolean = false) {
        if (!isExplicitAction && isRunning && vpnInterface != null && _isVpnActive.value 
            && activeDnsServer == dnsServer && activeExcludedPackagesSet == excludedSet) {
            Log.i("SaffahVpn", "VPN is already active with identical configuration (${excludedSet.size} excluded apps). Skipping restart.")
            return
        }

        activeDnsServer = dnsServer
        activeExcludedPackagesSet = excludedSet
        try {
            cachedPrimaryIpBytes = InetAddress.getByName(dnsServer.primaryIp).address
            cachedSecondaryIpBytes = InetAddress.getByName(dnsServer.secondaryIp).address
        } catch (_: Exception) {}
        val excludedPackagesArray = excludedSet.toTypedArray()

        try {
            stopVpnInterfaceOnly()

            val builder = Builder()
                .setSession("السَّفاح - حماية VPN")
                .setMtu(1500)
                .addAddress("10.1.10.1", 24)
                .addDnsServer(dnsServer.primaryIp)
                .addDnsServer(dnsServer.secondaryIp)

            try {
                builder.addRoute(dnsServer.primaryIp, 32)
                builder.addRoute(dnsServer.secondaryIp, 32)
            } catch (e: Exception) {
                Log.w("SaffahVpn", "IPv4 Route setup note: ${e.message}")
            }

            // Problem 1: IPv6 DNS Leak Elimination
            // Add private local IPv6 address (Unique Local Address) to the tunnel interface
            try {
                builder.addAddress("fd00:1::1", 64)
            } catch (e: Exception) {
                Log.w("SaffahVpn", "IPv6 address setup note: ${e.message}")
            }

            // Register IPv6 DNS servers and route strictly /128 into the tunnel
            // NEVER route ::/0 as this is a split-tunnel DNS filter, not a full network proxy
            if (dnsServer.ipv6Primary.isNotBlank()) {
                try {
                    val v6Primary = InetAddress.getByName(dnsServer.ipv6Primary)
                    builder.addDnsServer(v6Primary)
                    builder.addRoute(v6Primary, 128)
                } catch (e: Exception) {
                    Log.w("SaffahVpn", "IPv6 primary DNS route setup note: ${e.message}")
                }
            }
            if (dnsServer.ipv6Secondary.isNotBlank()) {
                try {
                    val v6Secondary = InetAddress.getByName(dnsServer.ipv6Secondary)
                    builder.addDnsServer(v6Secondary)
                    builder.addRoute(v6Secondary, 128)
                } catch (e: Exception) {
                    Log.w("SaffahVpn", "IPv6 secondary DNS route setup note: ${e.message}")
                }
            }

            // Crucial: Exclude our own app from the VPN interface to prevent local network routing loops and Wi-Fi disconnect cycles
            try {
                builder.addDisallowedApplication(packageName)
            } catch (e: Exception) {
                Log.e("SaffahVpn", "Error excluding own app $packageName: ${e.message}")
            }

            // Exclude user-selected apps if specified
            for (pkg in excludedSet) {
                if (pkg != packageName && pkg.isNotBlank()) {
                    try {
                        builder.addDisallowedApplication(pkg)
                        Log.d("SaffahVpn", "Successfully excluded app from VPN tunnel: $pkg")
                    } catch (e: Exception) {
                        Log.e("SaffahVpn", "Error excluding app $pkg: ${e.message}")
                    }
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }
            builder.allowBypass()
            builder.setBlocking(true)

            val pfd = builder.establish()
            vpnInterface = pfd

            if (pfd != null) {
                isRunning = true
                _isVpnActive.value = true
                com.example.util.SaffahLockTaskManager.updateStateAndCheck(this)
                synchronized(this) {
                    if (mainExecutor.isShutdown || mainExecutor.isTerminated) {
                        mainExecutor = Executors.newSingleThreadExecutor()
                    }
                    if (dnsWorkerPool.isShutdown || dnsWorkerPool.isTerminated) {
                        dnsWorkerPool = Executors.newFixedThreadPool(4)
                    }
                }
                try {
                    mainExecutor.execute {
                        runDnsProxyLoop(pfd, dnsServer, excludedPackagesArray)
                    }
                    Log.i("SaffahVpn", "Saffah VPN started successfully with active DNS proxy!")
                } catch (e: Exception) {
                    Log.e("SaffahVpn", "Failed to start DNS proxy loop on executor: ${e.message}", e)
                }
            } else {
                _isVpnActive.value = false
                com.example.util.SaffahLockTaskManager.updateStateAndCheck(this)
                Log.e("SaffahVpn", "Builder.establish() returned null.")
            }

        } catch (e: Exception) {
            _isVpnActive.value = false
            Log.e("SaffahVpn", "Failed to establish VPN: ${e.message}", e)
            com.example.util.SaffahLockTaskManager.updateStateAndCheck(this)
        }
    }

    private fun runDnsProxyLoop(pfd: ParcelFileDescriptor, dnsServer: DnsFilterServer, excludedPackages: Array<String>) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buffer = ByteArray(4096)
        var eofCount = 0

        try {
            while (isRunning) {
                val length = try {
                    input.read(buffer)
                } catch (e: Exception) {
                    if (isRunning) {
                        Log.w("SaffahVpn", "Exception reading from VPN input stream: ${e.message}")
                    }
                    -1
                }

                if (length == 0) {
                    // 0 bytes read - just no packet available, sleep briefly and continue loop
                    try { Thread.sleep(150) } catch (ignored: Exception) {}
                    continue
                }

                if (length < 0) {
                    // EOF (-1) returned
                    if (!isRunning) break
                    eofCount++
                    if (eofCount >= 20) { // 2 seconds of sustained EOF
                        Log.w("SaffahVpn", "Sustained EOF reached ($eofCount times). VPN descriptor closed by OS.")
                        break
                    }
                    try { Thread.sleep(100) } catch (ignored: Exception) {}
                    continue
                }

                // Reset EOF counter on valid packet read
                eofCount = 0

                if (length >= 20) {
                    val firstByte = buffer[0].toInt() and 0xFF
                    val version = (firstByte shr 4) and 0x0F

                    if (version == 4) {
                        val ihl = (firstByte and 0x0F) * 4
                        val protocol = buffer[9].toInt() and 0xFF

                        if (protocol == 17 && length >= ihl + 8) { // IPv4 UDP
                            val dstPort = ((buffer[ihl + 2].toInt() and 0xFF) shl 8) or (buffer[ihl + 3].toInt() and 0xFF)
                            if (dstPort == 53) { // IPv4 DNS Query
                                val srcPort = ((buffer[ihl].toInt() and 0xFF) shl 8) or (buffer[ihl + 1].toInt() and 0xFF)
                                val udpLen = ((buffer[ihl + 4].toInt() and 0xFF) shl 8) or (buffer[ihl + 5].toInt() and 0xFF)
                                val dnsDataLen = udpLen - 8

                                if (dnsDataLen > 0 && ihl + 8 + dnsDataLen <= length) {
                                    val dnsQueryBytes = buffer.copyOfRange(ihl + 8, ihl + 8 + dnsDataLen)
                                    val clientIp = buffer.copyOfRange(12, 16)
                                    val serverIp = buffer.copyOfRange(16, 20)

                                    val pBytes = cachedPrimaryIpBytes
                                    val isPrimary = pBytes == null || (
                                        serverIp[0] == pBytes[0] && serverIp[1] == pBytes[1] &&
                                        serverIp[2] == pBytes[2] && serverIp[3] == pBytes[3]
                                    )

                                    val targetDnsServerIp = if (isPrimary) dnsServer.primaryIp else dnsServer.secondaryIp
                                    val fallbackDnsServerIp = if (isPrimary) dnsServer.secondaryIp else dnsServer.primaryIp

                                    try {
                                        dnsWorkerPool.execute {
                                            handleDnsQuery(
                                                isIpv6 = false,
                                                dnsQueryBytes = dnsQueryBytes,
                                                clientIp = clientIp,
                                                clientPort = srcPort,
                                                serverIpBytes = serverIp,
                                                targetDnsServerIp = targetDnsServerIp,
                                                fallbackDnsServerIp = fallbackDnsServerIp,
                                                outputStream = output
                                            )
                                        }
                                    } catch (e: Exception) {
                                        Log.w("SaffahVpn", "Worker pool full or shutting down: ${e.message}")
                                    }
                                }
                            }
                        } else if (protocol == 6 && length >= ihl + 20) { // IPv4 TCP Port 53 -> Fast-RST!
                            val dstPort = ((buffer[ihl + 2].toInt() and 0xFF) shl 8) or (buffer[ihl + 3].toInt() and 0xFF)
                            if (dstPort == 53) {
                                val srcPort = ((buffer[ihl].toInt() and 0xFF) shl 8) or (buffer[ihl + 1].toInt() and 0xFF)
                                val clientIp = buffer.copyOfRange(12, 16)
                                val serverIp = buffer.copyOfRange(16, 20)
                                val seqNum = ((buffer[ihl + 4].toLong() and 0xFF) shl 24) or
                                             ((buffer[ihl + 5].toLong() and 0xFF) shl 16) or
                                             ((buffer[ihl + 6].toLong() and 0xFF) shl 8) or
                                             (buffer[ihl + 7].toLong() and 0xFF)
                                val ackNum = ((buffer[ihl + 8].toLong() and 0xFF) shl 24) or
                                             ((buffer[ihl + 9].toLong() and 0xFF) shl 16) or
                                             ((buffer[ihl + 10].toLong() and 0xFF) shl 8) or
                                             (buffer[ihl + 11].toLong() and 0xFF)
                                val tcpFlags = buffer[ihl + 13].toInt() and 0xFF
                                val isRst = (tcpFlags and 0x04) != 0

                                if (!isRst) {
                                    val tcpHeaderLen = ((buffer[ihl + 12].toInt() and 0xF0) shr 4) * 4
                                    val payloadLen = length - ihl - tcpHeaderLen
                                    val rstPacket = buildIpv4TcpRstPacket(
                                        srcIp = serverIp,
                                        dstIp = clientIp,
                                        srcPort = 53,
                                        dstPort = srcPort,
                                        incomingSeq = seqNum,
                                        incomingAck = ackNum,
                                        incomingFlags = tcpFlags,
                                        payloadLen = if (payloadLen > 0) payloadLen else 0
                                    )
                                    sendPacketSafely(output, rstPacket)
                                }
                            }
                        }
                    } else if (version == 6 && length >= 40) { // IPv6 (40 bytes fixed header)
                        val nextHeader = buffer[6].toInt() and 0xFF
                        val clientIp = buffer.copyOfRange(8, 24)
                        val serverIp = buffer.copyOfRange(24, 40)

                        if (nextHeader == 17 && length >= 48) { // IPv6 UDP
                            val dstPort = ((buffer[42].toInt() and 0xFF) shl 8) or (buffer[43].toInt() and 0xFF)
                            if (dstPort == 53) { // IPv6 DNS Query
                                val srcPort = ((buffer[40].toInt() and 0xFF) shl 8) or (buffer[41].toInt() and 0xFF)
                                val udpLen = ((buffer[44].toInt() and 0xFF) shl 8) or (buffer[45].toInt() and 0xFF)
                                val dnsDataLen = udpLen - 8

                                if (dnsDataLen > 0 && 40 + 8 + dnsDataLen <= length) {
                                    val dnsQueryBytes = buffer.copyOfRange(48, 48 + dnsDataLen)
                                    val targetDnsServerIp = try {
                                        InetAddress.getByAddress(serverIp).hostAddress ?: dnsServer.ipv6Primary
                                    } catch (_: Exception) {
                                        dnsServer.ipv6Primary
                                    }

                                    try {
                                        dnsWorkerPool.execute {
                                            handleDnsQuery(
                                                isIpv6 = true,
                                                dnsQueryBytes = dnsQueryBytes,
                                                clientIp = clientIp,
                                                clientPort = srcPort,
                                                serverIpBytes = serverIp,
                                                targetDnsServerIp = targetDnsServerIp,
                                                fallbackDnsServerIp = if (dnsServer.ipv6Secondary.isNotBlank()) dnsServer.ipv6Secondary else dnsServer.primaryIp,
                                                outputStream = output
                                            )
                                        }
                                    } catch (e: Exception) {
                                        Log.w("SaffahVpn", "Worker pool full or shutting down (IPv6): ${e.message}")
                                    }
                                }
                            }
                        } else if (nextHeader == 6 && length >= 60) { // IPv6 TCP Port 53 -> Fast-RST!
                            val dstPort = ((buffer[42].toInt() and 0xFF) shl 8) or (buffer[43].toInt() and 0xFF)
                            if (dstPort == 53) {
                                val srcPort = ((buffer[40].toInt() and 0xFF) shl 8) or (buffer[41].toInt() and 0xFF)
                                val seqNum = ((buffer[44].toLong() and 0xFF) shl 24) or
                                             ((buffer[45].toLong() and 0xFF) shl 16) or
                                             ((buffer[46].toLong() and 0xFF) shl 8) or
                                             (buffer[47].toLong() and 0xFF)
                                val ackNum = ((buffer[48].toLong() and 0xFF) shl 24) or
                                             ((buffer[49].toLong() and 0xFF) shl 16) or
                                             ((buffer[50].toLong() and 0xFF) shl 8) or
                                             (buffer[51].toLong() and 0xFF)
                                val tcpFlags = buffer[53].toInt() and 0xFF
                                val isRst = (tcpFlags and 0x04) != 0

                                if (!isRst) {
                                    val tcpHeaderLen = ((buffer[52].toInt() and 0xF0) shr 4) * 4
                                    val payloadLen = length - 40 - tcpHeaderLen
                                    val rstPacket = buildIpv6TcpRstPacket(
                                        srcIp = serverIp,
                                        dstIp = clientIp,
                                        srcPort = 53,
                                        dstPort = srcPort,
                                        incomingSeq = seqNum,
                                        incomingAck = ackNum,
                                        incomingFlags = tcpFlags,
                                        payloadLen = if (payloadLen > 0) payloadLen else 0
                                    )
                                    sendPacketSafely(output, rstPacket)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.i("SaffahVpn", "DNS Proxy loop ended: ${e.message}")
        } finally {
            try { input.close() } catch (ignored: Throwable) {}
            try { output.close() } catch (ignored: Throwable) {}
            if (isRunning) {
                Log.w("SaffahVpn", "DNS Proxy loop exited while isRunning was true.")
                isRunning = false
                _isVpnActive.value = false
                com.example.util.SaffahLockTaskManager.updateStateAndCheck(this)
            } else {
                _isVpnActive.value = false
            }
        }
    }

    private data class CachedDnsResponse(
        val responsePayload: ByteArray,
        val expiryTimeMillis: Long
    )

    private val dnsResponseCache = java.util.concurrent.ConcurrentHashMap<String, CachedDnsResponse>()
    private val inetAddressCache = java.util.concurrent.ConcurrentHashMap<String, InetAddress>()
    private val blockedDomainDnsCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    private val workerSocket = object : ThreadLocal<DatagramSocket>() {
        override fun initialValue(): DatagramSocket? {
            return try {
                val socket = DatagramSocket()
                protect(socket)
                socket.soTimeout = 2000
                socket
            } catch (e: Exception) {
                null
            }
        }
    }

    private val workerBuffer = object : ThreadLocal<ByteArray>() {
        override fun initialValue(): ByteArray = ByteArray(4096)
    }

    private fun getOrCreateWorkerSocket(): DatagramSocket? {
        var socket = workerSocket.get()
        if (socket == null || socket.isClosed) {
            try {
                socket = DatagramSocket()
                protect(socket)
                socket.soTimeout = 2000
                workerSocket.set(socket)
            } catch (e: Exception) {
                return null
            }
        }
        return socket
    }

    private fun extractDnsQuestionKey(dnsQueryBytes: ByteArray): String? {
        if (dnsQueryBytes.size < 12) return null
        val qdCount = ((dnsQueryBytes[4].toInt() and 0xFF) shl 8) or (dnsQueryBytes[5].toInt() and 0xFF)
        if (qdCount < 1) return null

        var offset = 12
        val sb = StringBuilder()
        while (offset < dnsQueryBytes.size) {
            val len = dnsQueryBytes[offset].toInt() and 0xFF
            if (len == 0) {
                offset++
                break
            }
            if ((len and 0xC0) != 0) {
                offset += 2
                break
            }
            offset++
            if (offset + len > dnsQueryBytes.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            for (i in 0 until len) {
                val c = dnsQueryBytes[offset + i].toInt().toChar()
                sb.append(if (c in 'A'..'Z') (c + 32) else c)
            }
            offset += len
        }

        if (offset + 4 <= dnsQueryBytes.size) {
            val qType = ((dnsQueryBytes[offset].toInt() and 0xFF) shl 8) or (dnsQueryBytes[offset + 1].toInt() and 0xFF)
            val qClass = ((dnsQueryBytes[offset + 2].toInt() and 0xFF) shl 8) or (dnsQueryBytes[offset + 3].toInt() and 0xFF)
            return "$sb:$qType:$qClass"
        }
        return sb.toString()
    }

    private fun extractDomainFromDnsQuery(dnsQueryBytes: ByteArray): String? {
        if (dnsQueryBytes.size < 12) return null
        val qdCount = ((dnsQueryBytes[4].toInt() and 0xFF) shl 8) or (dnsQueryBytes[5].toInt() and 0xFF)
        if (qdCount < 1) return null

        var offset = 12
        val sb = StringBuilder()
        while (offset < dnsQueryBytes.size) {
            val len = dnsQueryBytes[offset].toInt() and 0xFF
            if (len == 0) break
            if ((len and 0xC0) != 0) break
            offset++
            if (offset + len > dnsQueryBytes.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            for (i in 0 until len) {
                val c = dnsQueryBytes[offset + i].toInt().toChar()
                sb.append(if (c in 'A'..'Z') (c + 32) else c)
            }
            offset += len
        }
        return sb.toString()
    }

    private fun findDnsQuestionEnd(dnsQueryBytes: ByteArray): Int {
        if (dnsQueryBytes.size < 12) return -1
        var offset = 12
        while (offset < dnsQueryBytes.size) {
            val len = dnsQueryBytes[offset].toInt() and 0xFF
            if (len == 0) {
                offset++
                break
            }
            if ((len and 0xC0) != 0) {
                offset += 2
                break
            }
            offset += (len + 1)
        }
        return if (offset + 4 <= dnsQueryBytes.size) offset + 4 else -1
    }

    private fun buildDnsBlockedResponse(queryBytes: ByteArray): ByteArray {
        val qEnd = findDnsQuestionEnd(queryBytes)
        if (qEnd <= 12) return buildDnsNxDomainResponse(queryBytes)

        val questionLen = qEnd - 12
        val response = ByteArray(12 + questionLen + 16)
        // Copy Transaction ID
        response[0] = queryBytes[0]
        response[1] = queryBytes[1]
        // Flags: Standard query response, No error, Authoritative (0x8180)
        response[2] = 0x81.toByte()
        response[3] = 0x80.toByte()
        // QDCOUNT = 1
        response[4] = 0x00; response[5] = 0x01
        // ANCOUNT = 1
        response[6] = 0x00; response[7] = 0x01
        // NSCOUNT = 0, ARCOUNT = 0
        response[8] = 0x00; response[9] = 0x00
        response[10] = 0x00; response[11] = 0x00

        // Copy Question section
        System.arraycopy(queryBytes, 12, response, 12, questionLen)

        // Answer section: Name pointer to question at offset 12 (0xC00C)
        val ansOffset = 12 + questionLen
        response[ansOffset] = 0xC0.toByte()
        response[ansOffset + 1] = 0x0C.toByte()
        // Type: A (0x0001)
        response[ansOffset + 2] = 0x00.toByte()
        response[ansOffset + 3] = 0x01.toByte()
        // Class: IN (0x0001)
        response[ansOffset + 4] = 0x00.toByte()
        response[ansOffset + 5] = 0x01.toByte()
        // TTL: 86400 seconds (1 day) -> 0x00015180
        response[ansOffset + 6] = 0x00.toByte()
        response[ansOffset + 7] = 0x01.toByte()
        response[ansOffset + 8] = 0x51.toByte()
        response[ansOffset + 9] = 0x80.toByte()
        // RDLENGTH: 4
        response[ansOffset + 10] = 0x00.toByte()
        response[ansOffset + 11] = 0x04.toByte()
        // RDATA: 0.0.0.0 (Sinkhole)
        response[ansOffset + 12] = 0x00.toByte()
        response[ansOffset + 13] = 0x00.toByte()
        response[ansOffset + 14] = 0x00.toByte()
        response[ansOffset + 15] = 0x00.toByte()

        return response
    }

    private fun buildDnsNxDomainResponse(queryBytes: ByteArray): ByteArray {
        val response = ByteArray(12)
        response[0] = queryBytes[0]
        response[1] = queryBytes[1]
        // Flags: Response, Name Error / NXDOMAIN (0x8183)
        response[2] = 0x81.toByte()
        response[3] = 0x83.toByte()
        return response
    }

    private fun pruneDnsCacheIfNeeded(now: Long) {
        if (dnsResponseCache.size <= 600) return
        try {
            // 1. Remove expired entries first in a single pass
            val iterator = dnsResponseCache.entries.iterator()
            var evictedCount = 0
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (entry.value.expiryTimeMillis <= now) {
                    iterator.remove()
                    evictedCount++
                }
            }

            // 2. If still high (> 500), evict up to 150 entries in a single pass without sorting overhead
            if (dnsResponseCache.size > 500) {
                val pruneIterator = dnsResponseCache.entries.iterator()
                var overflowEvicted = 0
                while (pruneIterator.hasNext() && overflowEvicted < 150) {
                    pruneIterator.next()
                    pruneIterator.remove()
                    overflowEvicted++
                }
            }
        } catch (_: Exception) {}
    }

    private fun handleDnsQuery(
        isIpv6: Boolean,
        dnsQueryBytes: ByteArray,
        clientIp: ByteArray,
        clientPort: Int,
        serverIpBytes: ByteArray,
        targetDnsServerIp: String,
        fallbackDnsServerIp: String,
        outputStream: FileOutputStream
    ) {
        // Zero-delay instant DNS sinkhole for blocked domains: wire-speed O(1) matching without upstream query
        val queryDomain = extractDomainFromDnsQuery(dnsQueryBytes)
        if (queryDomain != null) {
            val isBlocked = blockedDomainDnsCache[queryDomain] ?: run {
                val matched = SaffahBlockRepository.findMatchedBlockedSiteFast(queryDomain, applicationContext) != null
                if (blockedDomainDnsCache.size > 800) {
                    blockedDomainDnsCache.clear()
                }
                blockedDomainDnsCache[queryDomain] = matched
                matched
            }
            if (isBlocked) {
                val sinkholeResponse = buildDnsBlockedResponse(dnsQueryBytes)
                val packet = if (isIpv6) {
                    buildIpv6UdpPacket(
                        srcIp = serverIpBytes,
                        dstIp = clientIp,
                        srcPort = 53,
                        dstPort = clientPort,
                        payload = sinkholeResponse
                    )
                } else {
                    buildIpv4UdpPacket(
                        srcIp = serverIpBytes,
                        dstIp = clientIp,
                        srcPort = 53,
                        dstPort = clientPort,
                        payload = sinkholeResponse
                    )
                }
                sendPacketSafely(outputStream, packet)
                return
            }
        }

        val cacheKey = extractDnsQuestionKey(dnsQueryBytes)
        val now = System.currentTimeMillis()

        var dnsResponse: ByteArray? = null

        if (cacheKey != null) {
            val cached = dnsResponseCache[cacheKey]
            if (cached != null && now < cached.expiryTimeMillis) {
                // Instant cache hit: zero network overhead, zero battery drain!
                val hit = cached.responsePayload.copyOf()
                if (hit.size >= 2 && dnsQueryBytes.size >= 2) {
                    hit[0] = dnsQueryBytes[0]
                    hit[1] = dnsQueryBytes[1]
                }
                dnsResponse = hit
            }
        }

        if (dnsResponse == null) {
            // 1. Try target DNS server (IPv6 or IPv4)
            dnsResponse = queryUpstreamDns(dnsQueryBytes, targetDnsServerIp)

            // 2. Try secondary fallback if different
            if (dnsResponse == null && fallbackDnsServerIp.isNotBlank() && fallbackDnsServerIp != targetDnsServerIp) {
                dnsResponse = queryUpstreamDns(dnsQueryBytes, fallbackDnsServerIp)
            }

            // 3. Crucial Fallback Resilience: If IPv6 was requested and upstream IPv6 fails/unreachable,
            // automatically forward query to IPv4 primary!
            if (dnsResponse == null && isIpv6) {
                val ipv4Primary = activeDnsServer?.primaryIp
                if (!ipv4Primary.isNullOrBlank() && ipv4Primary != targetDnsServerIp && ipv4Primary != fallbackDnsServerIp) {
                    dnsResponse = queryUpstreamDns(dnsQueryBytes, ipv4Primary)
                }
            }

            if (dnsResponse != null && cacheKey != null) {
                pruneDnsCacheIfNeeded(now)
                dnsResponseCache[cacheKey] = CachedDnsResponse(
                    responsePayload = dnsResponse.copyOf(),
                    expiryTimeMillis = now + 600_000L // 10 minutes cache to minimize radio chip wakeups and cellular battery consumption
                )
            }
        }

        if (dnsResponse == null) return

        // Encapsulate response back into appropriate IP/UDP packet:
        // Client asked via IPv6 -> reply with IPv6 UDP packet
        // Client asked via IPv4 -> reply with IPv4 UDP packet
        val packet = if (isIpv6) {
            buildIpv6UdpPacket(
                srcIp = serverIpBytes,
                dstIp = clientIp,
                srcPort = 53,
                dstPort = clientPort,
                payload = dnsResponse
            )
        } else {
            buildIpv4UdpPacket(
                srcIp = serverIpBytes,
                dstIp = clientIp,
                srcPort = 53,
                dstPort = clientPort,
                payload = dnsResponse
            )
        }

        sendPacketSafely(outputStream, packet)
    }

    private fun sendPacketSafely(outputStream: FileOutputStream, packet: ByteArray) {
        synchronized(outputStream) {
            try {
                outputStream.write(packet)
                outputStream.flush()
            } catch (e: Exception) {
                Log.e("SaffahVpn", "Error writing packet to VPN interface: ${e.message}")
            }
        }
    }

    private fun queryUpstreamDns(queryBytes: ByteArray, dnsServerIp: String): ByteArray? {
        val socket = getOrCreateWorkerSocket() ?: return null
        return try {
            val serverAddr = inetAddressCache.computeIfAbsent(dnsServerIp) {
                InetAddress.getByName(it)
            }
            val outPacket = DatagramPacket(queryBytes, queryBytes.size, serverAddr, 53)
            socket.send(outPacket)

            val respBuffer = workerBuffer.get() ?: ByteArray(4096)
            val inPacket = DatagramPacket(respBuffer, respBuffer.size)
            socket.receive(inPacket)

            respBuffer.copyOfRange(0, inPacket.length)
        } catch (e: Exception) {
            try { socket.close() } catch (_: Exception) {}
            workerSocket.set(null)
            null
        }
    }

    private fun buildIpv4UdpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val ipHeaderLen = 20
        val udpHeaderLen = 8
        val totalLen = ipHeaderLen + udpHeaderLen + payload.size

        val buf = ByteArray(totalLen)

        // --- IPv4 Header ---
        buf[0] = 0x45.toByte() // Version 4, IHL 5 (20 bytes)
        buf[1] = 0x00.toByte() // TOS
        buf[2] = (totalLen shr 8).toByte()
        buf[3] = (totalLen and 0xFF).toByte()
        buf[4] = 0x12.toByte() // ID
        buf[5] = 0x34.toByte()
        buf[6] = 0x40.toByte() // Don't fragment flag
        buf[7] = 0x00.toByte()
        buf[8] = 64.toByte()   // TTL
        buf[9] = 17.toByte()   // Protocol: UDP

        buf[10] = 0.toByte()
        buf[11] = 0.toByte()

        System.arraycopy(srcIp, 0, buf, 12, 4)
        System.arraycopy(dstIp, 0, buf, 16, 4)

        val ipChecksum = calculateChecksum(buf, 0, ipHeaderLen)
        buf[10] = (ipChecksum shr 8).toByte()
        buf[11] = (ipChecksum and 0xFF).toByte()

        // --- UDP Header ---
        val udpLen = udpHeaderLen + payload.size
        buf[20] = (srcPort shr 8).toByte()
        buf[21] = (srcPort and 0xFF).toByte()
        buf[22] = (dstPort shr 8).toByte()
        buf[23] = (dstPort and 0xFF).toByte()
        buf[24] = (udpLen shr 8).toByte()
        buf[25] = (udpLen and 0xFF).toByte()
        buf[26] = 0.toByte() // UDP checksum is optional in IPv4
        buf[27] = 0.toByte()

        // --- Payload ---
        System.arraycopy(payload, 0, buf, 28, payload.size)

        return buf
    }

    private fun buildIpv6UdpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val ipHeaderLen = 40
        val udpHeaderLen = 8
        val udpLen = udpHeaderLen + payload.size
        val totalLen = ipHeaderLen + udpLen

        val buf = ByteArray(totalLen)

        // --- IPv6 Fixed Header (40 bytes) ---
        buf[0] = 0x60.toByte() // Version 6
        buf[1] = 0x00.toByte()
        buf[2] = 0x00.toByte()
        buf[3] = 0x00.toByte()
        buf[4] = (udpLen shr 8).toByte() // Payload Length
        buf[5] = (udpLen and 0xFF).toByte()
        buf[6] = 17.toByte()   // Next Header: 17 (UDP)
        buf[7] = 64.toByte()   // Hop Limit: 64
        System.arraycopy(srcIp, 0, buf, 8, 16)   // Source IPv6 (16 bytes)
        System.arraycopy(dstIp, 0, buf, 24, 16)  // Destination IPv6 (16 bytes)

        // --- UDP Header (8 bytes) ---
        buf[40] = (srcPort shr 8).toByte()
        buf[41] = (srcPort and 0xFF).toByte()
        buf[42] = (dstPort shr 8).toByte()
        buf[43] = (dstPort and 0xFF).toByte()
        buf[44] = (udpLen shr 8).toByte()
        buf[45] = (udpLen and 0xFF).toByte()
        buf[46] = 0.toByte() // Checksum placeholder
        buf[47] = 0.toByte()

        // --- Payload ---
        System.arraycopy(payload, 0, buf, 48, payload.size)

        // --- IPv6 UDP Checksum calculation over Pseudo-Header + UDP Header + Payload ---
        var sum = 0L

        // 1. Source IP (8 words of 16-bit)
        var i = 0
        while (i < 16) {
            sum += ((srcIp[i].toInt() and 0xFF) shl 8) or (srcIp[i + 1].toInt() and 0xFF)
            i += 2
        }

        // 2. Destination IP (8 words of 16-bit)
        i = 0
        while (i < 16) {
            sum += ((dstIp[i].toInt() and 0xFF) shl 8) or (dstIp[i + 1].toInt() and 0xFF)
            i += 2
        }

        // 3. UDP Length (32-bit: high word, low word)
        sum += (udpLen shr 16) and 0xFFFF
        sum += udpLen and 0xFFFF

        // 4. Next Header (32-bit: 0x0000, 0x0011)
        sum += 17

        // 5. UDP Header & Payload (from offset 40 to totalLen)
        i = 40
        while (i < totalLen - 1) {
            sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < totalLen) {
            sum += ((buf[i].toInt() and 0xFF) shl 8)
        }

        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        var checksum = (sum.inv() and 0xFFFF).toInt()
        if (checksum == 0) checksum = 0xFFFF

        buf[46] = (checksum shr 8).toByte()
        buf[47] = (checksum and 0xFF).toByte()

        return buf
    }

    private fun buildIpv4TcpRstPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        incomingSeq: Long,
        incomingAck: Long,
        incomingFlags: Int,
        payloadLen: Int
    ): ByteArray {
        val ipHeaderLen = 20
        val tcpHeaderLen = 20
        val totalLen = ipHeaderLen + tcpHeaderLen
        val buf = ByteArray(totalLen)

        // --- IPv4 Header ---
        buf[0] = 0x45.toByte() // Version 4, IHL 5
        buf[1] = 0x00.toByte() // TOS
        buf[2] = (totalLen shr 8).toByte()
        buf[3] = (totalLen and 0xFF).toByte()
        buf[4] = 0x00.toByte() // Identification
        buf[5] = 0x00.toByte()
        buf[6] = 0x40.toByte() // Don't fragment flag
        buf[7] = 0x00.toByte()
        buf[8] = 64.toByte()   // TTL
        buf[9] = 6.toByte()    // Protocol: TCP
        buf[10] = 0.toByte()   // Checksum placeholder
        buf[11] = 0.toByte()

        System.arraycopy(srcIp, 0, buf, 12, 4)
        System.arraycopy(dstIp, 0, buf, 16, 4)

        val ipChecksum = calculateChecksum(buf, 0, ipHeaderLen)
        buf[10] = (ipChecksum shr 8).toByte()
        buf[11] = (ipChecksum and 0xFF).toByte()

        // --- TCP Header ---
        // RFC 793 Reset Generation:
        val hasAck = (incomingFlags and 0x10) != 0
        val isSyn = (incomingFlags and 0x02) != 0

        val (seqToSend, ackToSend, flagsToSend) = if (hasAck) {
            Triple(incomingAck, 0L, 0x04) // RST
        } else {
            val advance = if (isSyn) 1L else (if (payloadLen > 0) payloadLen.toLong() else 0L)
            Triple(0L, (incomingSeq + advance) and 0xFFFFFFFFL, 0x14) // RST, ACK
        }

        buf[20] = (srcPort shr 8).toByte()
        buf[21] = (srcPort and 0xFF).toByte()
        buf[22] = (dstPort shr 8).toByte()
        buf[23] = (dstPort and 0xFF).toByte()

        // Sequence Number (4 bytes)
        buf[24] = ((seqToSend shr 24) and 0xFF).toByte()
        buf[25] = ((seqToSend shr 16) and 0xFF).toByte()
        buf[26] = ((seqToSend shr 8) and 0xFF).toByte()
        buf[27] = (seqToSend and 0xFF).toByte()

        // Acknowledgment Number (4 bytes)
        buf[28] = ((ackToSend shr 24) and 0xFF).toByte()
        buf[29] = ((ackToSend shr 16) and 0xFF).toByte()
        buf[30] = ((ackToSend shr 8) and 0xFF).toByte()
        buf[31] = (ackToSend and 0xFF).toByte()

        buf[32] = 0x50.toByte()        // Data offset: 5 (20 bytes header)
        buf[33] = flagsToSend.toByte() // Flags: RST or RST+ACK
        buf[34] = 0x00.toByte()        // Window: 0
        buf[35] = 0x00.toByte()
        buf[36] = 0x00.toByte()        // Checksum placeholder
        buf[37] = 0x00.toByte()
        buf[38] = 0x00.toByte()        // Urgent pointer: 0
        buf[39] = 0x00.toByte()

        // IPv4 TCP Checksum calculation with Pseudo-Header
        var sum = 0L
        sum += ((srcIp[0].toInt() and 0xFF) shl 8) or (srcIp[1].toInt() and 0xFF)
        sum += ((srcIp[2].toInt() and 0xFF) shl 8) or (srcIp[3].toInt() and 0xFF)
        sum += ((dstIp[0].toInt() and 0xFF) shl 8) or (dstIp[1].toInt() and 0xFF)
        sum += ((dstIp[2].toInt() and 0xFF) shl 8) or (dstIp[3].toInt() and 0xFF)
        sum += 6 // Protocol TCP
        sum += tcpHeaderLen

        var j = 20
        while (j < totalLen) {
            sum += ((buf[j].toInt() and 0xFF) shl 8) or (buf[j + 1].toInt() and 0xFF)
            j += 2
        }

        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        var tcpChecksum = (sum.inv() and 0xFFFF).toInt()
        if (tcpChecksum == 0) tcpChecksum = 0xFFFF

        buf[36] = (tcpChecksum shr 8).toByte()
        buf[37] = (tcpChecksum and 0xFF).toByte()

        return buf
    }

    private fun buildIpv6TcpRstPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        incomingSeq: Long,
        incomingAck: Long,
        incomingFlags: Int,
        payloadLen: Int
    ): ByteArray {
        val ipHeaderLen = 40
        val tcpHeaderLen = 20
        val totalLen = ipHeaderLen + tcpHeaderLen
        val buf = ByteArray(totalLen)

        // --- IPv6 Header ---
        buf[0] = 0x60.toByte() // Version 6
        buf[1] = 0x00.toByte()
        buf[2] = 0x00.toByte()
        buf[3] = 0x00.toByte()
        buf[4] = (tcpHeaderLen shr 8).toByte() // Payload length
        buf[5] = (tcpHeaderLen and 0xFF).toByte()
        buf[6] = 6.toByte()    // Next Header: TCP
        buf[7] = 64.toByte()   // Hop limit: 64
        System.arraycopy(srcIp, 0, buf, 8, 16)
        System.arraycopy(dstIp, 0, buf, 24, 16)

        // --- TCP Header ---
        val hasAck = (incomingFlags and 0x10) != 0
        val isSyn = (incomingFlags and 0x02) != 0

        val (seqToSend, ackToSend, flagsToSend) = if (hasAck) {
            Triple(incomingAck, 0L, 0x04) // RST
        } else {
            val advance = if (isSyn) 1L else (if (payloadLen > 0) payloadLen.toLong() else 0L)
            Triple(0L, (incomingSeq + advance) and 0xFFFFFFFFL, 0x14) // RST, ACK
        }

        buf[40] = (srcPort shr 8).toByte()
        buf[41] = (srcPort and 0xFF).toByte()
        buf[42] = (dstPort shr 8).toByte()
        buf[43] = (dstPort and 0xFF).toByte()

        // Sequence number
        buf[44] = ((seqToSend shr 24) and 0xFF).toByte()
        buf[45] = ((seqToSend shr 16) and 0xFF).toByte()
        buf[46] = ((seqToSend shr 8) and 0xFF).toByte()
        buf[47] = (seqToSend and 0xFF).toByte()

        // Acknowledgment number
        buf[48] = ((ackToSend shr 24) and 0xFF).toByte()
        buf[49] = ((ackToSend shr 16) and 0xFF).toByte()
        buf[50] = ((ackToSend shr 8) and 0xFF).toByte()
        buf[51] = (ackToSend and 0xFF).toByte()

        buf[52] = 0x50.toByte()        // Data offset: 5 (20 bytes)
        buf[53] = flagsToSend.toByte() // Flags: RST or RST+ACK
        buf[54] = 0x00.toByte()        // Window: 0
        buf[55] = 0x00.toByte()
        buf[56] = 0x00.toByte()        // Checksum placeholder
        buf[57] = 0x00.toByte()
        buf[58] = 0x00.toByte()        // Urgent pointer: 0
        buf[59] = 0x00.toByte()

        // IPv6 TCP Checksum calculation with Pseudo-Header
        var sum = 0L
        var i = 0
        while (i < 16) {
            sum += ((srcIp[i].toInt() and 0xFF) shl 8) or (srcIp[i + 1].toInt() and 0xFF)
            i += 2
        }
        i = 0
        while (i < 16) {
            sum += ((dstIp[i].toInt() and 0xFF) shl 8) or (dstIp[i + 1].toInt() and 0xFF)
            i += 2
        }
        sum += tcpHeaderLen
        sum += 6 // Next Header: TCP

        var j = 40
        while (j < totalLen) {
            sum += ((buf[j].toInt() and 0xFF) shl 8) or (buf[j + 1].toInt() and 0xFF)
            j += 2
        }

        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        var tcpChecksum = (sum.inv() and 0xFFFF).toInt()
        if (tcpChecksum == 0) tcpChecksum = 0xFFFF

        buf[56] = (tcpChecksum shr 8).toByte()
        buf[57] = (tcpChecksum and 0xFF).toByte()

        return buf
    }

    private fun calculateChecksum(buf: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length - 1) {
            val word = ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (i < offset + length) {
            sum += ((buf[i].toInt() and 0xFF) shl 8)
        }
        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "درع السفاح - شبكة VPN",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "إبقاء اتصال VPN نشطاً لمراقبة وحجب حركة البيانات الضارة"
                    setShowBadge(false)
                    enableLights(false)
                    enableVibration(false)
                }
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                manager?.createNotificationChannel(channel)
            } catch (e: Exception) {
                Log.e("SaffahVpn", "Error creating notification channel: ${e.message}")
            }
        }
    }

    private fun createVpnNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            NOTIFICATION_ID,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("درع حماية VPN نشط")
            .setContentText("جدار الحماية وتصفية المحتوى قيد التشغيل")
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun stopVpnInterfaceOnly() {
        isRunning = false
        _isVpnActive.value = false
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            Log.e("SaffahVpn", "Error closing vpnInterface", e)
        }
    }

    private fun stopVpn() {
        activeExcludedPackagesSet = null
        activeDnsServer = null
        stopVpnInterfaceOnly()
        _isVpnActive.value = false
        com.example.util.SaffahLockTaskManager.updateStateAndCheck(this)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
            Log.i("SaffahVpn", "Saffah VPN stopped cleanly")
        } catch (e: Exception) {
            Log.e("SaffahVpn", "Error stopping VPN service", e)
        } finally {
            if (com.example.util.SaffahProtectionManager.isKeeperServiceEnabled(this)) {
                SaffahKeeperService.ensureKeeperNotification(this)
            }
        }
    }

    override fun onRevoke() {
        val wasIntended = com.example.util.SaffahLockTaskManager.isVpnIntendedActive(this)
        stopVpnInterfaceOnly()
        _isVpnActive.value = false
        if (wasIntended) {
            Log.w("SaffahVpn", "VPN onRevoke called while VPN was intended active!")
            val reason = com.example.util.SaffahLockTaskManager.updateStateAndCheck(this)
            if (reason != com.example.util.SaffahLockTaskManager.LockReason.NONE) {
                com.example.util.SaffahLockTaskManager.launchLockTaskApp(this, reason)
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        } catch (e: Exception) {
            Log.e("SaffahVpn", "Error in onRevoke cleanup: ${e.message}")
        } finally {
            if (com.example.util.SaffahProtectionManager.isKeeperServiceEnabled(this)) {
                SaffahKeeperService.ensureKeeperNotification(this)
            }
        }
        super.onRevoke()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.i("SaffahVpn", "VPN task removed from recents: executing instant emergency revival...")
        com.example.util.SaffahProtectionManager.scheduleEmergencyRevival(applicationContext, delayMillis = 150L)
        if (com.example.util.SaffahLockTaskManager.isVpnIntendedActive(applicationContext)) {
            com.example.util.SaffahProtectionManager.scheduleVpnEmergencyRevival(applicationContext, delayMillis = 250L)
        }
        if (com.example.util.SaffahProtectionManager.isKeeperServiceEnabled(applicationContext)) {
            SaffahKeeperService.ensureKeeperNotification(applicationContext)
        }
    }

    override fun onDestroy() {
        val wasIntended = com.example.util.SaffahLockTaskManager.isVpnIntendedActive(this)
        stopVpn()
        _isVpnActive.value = false
        try {
            dnsResponseCache.clear()
            inetAddressCache.clear()
            mainExecutor.shutdownNow()
            dnsWorkerPool.shutdownNow()
        } catch (e: Exception) {
            Log.e("SaffahVpn", "Error shutting down executors", e)
        }
        super.onDestroy()

        if (com.example.util.SaffahProtectionManager.isKeeperServiceEnabled(this)) {
            SaffahKeeperService.ensureKeeperNotification(this)
        }

        if (wasIntended) {
            Log.w("SaffahVpn", "VPN destroyed while intended active! Scheduling instant revival...")
            com.example.util.SaffahProtectionManager.scheduleEmergencyRevival(applicationContext, delayMillis = 150L)
            com.example.util.SaffahProtectionManager.scheduleVpnEmergencyRevival(applicationContext, delayMillis = 250L)
        }
    }

    companion object {
        const val ACTION_START_VPN = "com.example.saffah.START_VPN"
        const val ACTION_STOP_VPN = "com.example.saffah.STOP_VPN"
        const val EXTRA_DNS_SERVER = "extra_dns_server"
        const val EXTRA_EXCLUDED_PACKAGES = "extra_excluded_packages"
        const val CHANNEL_ID = "saffah_vpn_channel"
        const val NOTIFICATION_ID = 9002

        private val _isVpnActive = MutableStateFlow(false)
        val isVpnActive: StateFlow<Boolean> = _isVpnActive.asStateFlow()

        fun isVpnActiveOrConnected(context: Context): Boolean {
            return _isVpnActive.value
        }
    }
}

