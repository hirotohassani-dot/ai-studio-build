package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Toast
import com.example.util.SaffahAnimeClassifier
import com.example.util.SaffahBlockRepository
import com.example.util.SaffahLockTaskManager
import com.example.util.SaffahNudeNetClassifier
import com.example.util.NudeNetDetector
import com.example.util.FrameScheduler
import com.example.util.LiveDetectorPrefs
import com.example.util.SaffahProtectionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

class SaffahAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var isServiceBound: Boolean = false

        @Volatile
        var activeUserSessionPackage: String? = null

        @Volatile
        var instance: SaffahAccessibilityService? = null

        fun notifyScheduleOrBedtimeChanged(context: android.content.Context) {
            instance?.let { service ->
                service.minuteTickHandler.post {
                    SaffahBlockRepository.invalidateTimeCache()
                    service.checkAndEnforceImmediateForegroundBlock()
                    service.scheduleNextMinuteTick()
                }
            }
        }

        fun notifyAiProtectionChanged(context: android.content.Context) {
            instance?.let { service ->
                service.updateAiProtectionState()
            }
        }

        private const val DEBOUNCE_MS = 3500L

        // Supported browsers for URL blocking (Chrome, Brave, Opera, Opera Mini, DuckDuckGo, Vivaldi, Tor Browser, Spin, Quetta, Samsung, Edge, etc.)
        private val SUPPORTED_BROWSER_PACKAGES = setOf(
            // Chrome & Chromium
            "com.android.chrome",
            "com.chrome.beta",
            "com.chrome.dev",
            "com.chrome.canary",
            "org.chromium.chrome",

            // Samsung Internet
            "com.sec.android.app.sbrowser",
            "com.sec.android.app.sbrowser.beta",
            "com.sec.android.app.sbrowser.lite",

            // Microsoft Edge
            "com.microsoft.emmx",
            "com.microsoft.emmx.beta",
            "com.microsoft.emmx.canary",
            "com.microsoft.emmx.dev",

            // Brave
            "com.brave.browser",
            "com.brave.browser_beta",
            "com.brave.browser_nightly",

            // Opera & Opera Mini & GX
            "com.opera.browser",
            "com.opera.browser.beta",
            "com.opera.touch",
            "com.opera.gx",
            "com.opera.mini.native",
            "com.opera.mini.native.beta",

            // DuckDuckGo
            "com.duckduckgo.mobile.android",

            // Vivaldi
            "com.vivaldi.browser",
            "com.vivaldi.browser.snapshot",

            // Tor Browser
            "org.torproject.torbrowser",
            "org.torproject.torbrowser_alpha",

            // Spin
            "com.nationaleducation.spinbrowser",
            "com.spin.browser",

            // 1DM / 1DM+
            "idm.internet.download.manager",
            "idm.internet.download.manager.plus",
            "idm.internet.download.manager.lite",
            "idm.internet.download.manager.adm",

            // Quetta Browser
            "net.quetta.browser",
            "net.quetta.browser.beta",

            // Google App / Search
            "com.google.android.googlequicksearchbox",
            "com.google.android.apps.searchlite"
        )

        private val TELEGRAM_PACKAGES = setOf(
            "org.telegram.messenger",
            "org.telegram.messenger.web",
            "org.telegram.messenger.beta",
            "org.telegram.plus",
            "ph.telegra.telegraph",
            "com.iMe.android"
        )

        private val GLOBAL_SEARCH_TABS = setOf(
            "Chats", "Channels", "Apps", "Posts", "Media", "Downloads", "Links", "Files", "Music", "Voice",
            "محادثات", "قنوات", "تطبيقات", "منشورات", "وسائط", "تنزيلات", "روابط", "ملفات", "موسيقى", "صوتيات",
            "الدردشات", "القنوات", "التطبيقات", "المنشورات", "الوسائط", "الروابط", "الملفات"
        )

        private val SHORTS_VIEW_IDS = listOf(
            "reel_watch_fragment_root",
            "reel_recycler",
            "reel_watch_player",
            "reel_player_page_container",
            "reel_player_footer_container",
            "reel_player_overlay_root",
            "reel_scrim_shorts_while_bottom_gradient",
            "reel_time_bar"
        )

        private val INSTAGRAM_PACKAGES = setOf(
            "com.instagram.android",
            "com.instagram.lite",
            "com.instapro.android",
            "com.instapro2.android",
            "cc.honista.app"
        )

        private val INSTAGRAM_CLIPS_VIEW_IDS = listOf(
            "root_clips_layout",
            "clips_viewer_container",
            "clips_viewer_view_pager",
            "clips_viewer_media_view_pager",
            "clips_view_pager",
            "clips_viewer_action_bar",
            "clips_ufi_component",
            "clips_viewer_video_layout",
            "clips_pause_and_mute_component",
            "clips_bottom_legibility_gradient_component"
        )
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val ownPackageName: String by lazy { applicationContext.packageName }
    private val ownPrefix: String by lazy { "${applicationContext.packageName}." }
    private val lastContentChangeScanTimestampMap = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val lastScrollScanTimestampMap = java.util.concurrent.ConcurrentHashMap<String, Long>()

    @Volatile private var lastEvaluatedPackage: String = ""
    @Volatile private var lastEvaluatedPackageTimestamp: Long = 0L
    @Volatile private var lastEvaluatedDecision: SaffahBlockRepository.AppBlockDecision? = null
    @Volatile private var lastTransientRootCheckTimestamp: Long = 0L

    private var lastToastTime = 0L
    private var lastBlockedItem = ""
    private var lastBlockTimestamp = 0L
    private var lastInAppBrowserBlockTimestamp = 0L
    private var currentTopActivityName = ""
    private val supportedBrowserCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val anyBrowserCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val knownNonBrowserCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val recentlyBlockedPackages = java.util.concurrent.ConcurrentHashMap<String, Long>()

    // Reusable queues for accessibility tree traversals on the Main Looper thread to eliminate GC allocations and device heating
    private val reusableHierarchyNodesQueue = ArrayDeque<AccessibilityNodeInfo>(64)
    private val reusableMediaCheckNodesQueue = ArrayDeque<AccessibilityNodeInfo>(32)

    // AI Screen Protection (NudeNet ONNX + MobileNetV3 Anime) properties & state
    private var frameScheduler: FrameScheduler? = null
    private var lastAiViolationTimestamp = 0L
    private var previousAiViolationTimestamp = 0L
    private val screenshotExecutor by lazy {
        java.util.concurrent.Executors.newSingleThreadExecutor()
    }

    fun updateAiProtectionState() {
        val enabled = SaffahBlockRepository.isAiProtectionEnabled(this)
        if (enabled) {
            startAiProtectionLoop()
        } else {
            stopAiProtectionLoop()
        }
    }

    @Volatile private var isCurrentlyInRecents: Boolean = false
    @Volatile private var isCurrentlyInLauncher: Boolean = false
    @Volatile private var lastActiveIncludedPackage: String? = null

    /**
     * Checks if Recents / Overview task switcher is currently active on screen.
     */
    private fun isRecentsActive(): Boolean {
        if (isCurrentlyInRecents) return true
        val currentPkg = activeUserSessionPackage ?: ""
        if (isRecentsOrOverview(currentPkg, currentTopActivityName)) return true

        val activeRoot = try { rootInActiveWindow } catch (_: Exception) { null }
        val activePkg = try { activeRoot?.packageName?.toString() } catch (_: Exception) { null } ?: ""
        val activeCls = try { activeRoot?.className?.toString() } catch (_: Exception) { null } ?: ""

        if (isRecentsOrOverview(activePkg, activeCls)) return true

        // If active package is launcher or SystemUI, check if any nodes indicate recents screen
        if (isTargetLauncher(activePkg) || activePkg == "com.android.systemui" || activePkg.contains("systemui")) {
            if (activeCls.contains("Quickstep") || activeCls.contains("Recents") || activeCls.contains("Overview") || activeCls.contains("TaskView")) return true
            if (hasRecentsNodeSignature(activeRoot)) return true
        }

        return false
    }

    private fun hasRecentsNodeSignature(rootNode: AccessibilityNodeInfo?): Boolean {
        if (rootNode == null) return false
        val queue = reusableMediaCheckNodesQueue
        queue.clear()
        queue.add(rootNode)
        var count = 0
        try {
            while (queue.isNotEmpty() && count < 25) {
                val node = queue.removeFirst()
                count++
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                val text = node.text?.toString()?.lowercase() ?: ""

                if (id.contains("recents") || id.contains("overview") || id.contains("task_view") ||
                    id.contains("clear_all") || id.contains("recent_apps") || id.contains("snapshot") ||
                    id.contains("dismiss_task") || id.contains("task_thumbnail") || id.contains("task_panel") ||
                    desc.contains("clear all") || desc.contains("مسح الكل") || desc.contains("إغلاق الكل") ||
                    desc.contains("recents") || desc.contains("التطبيقات الحديثة") ||
                    text.contains("مسح الكل") || text.contains("إغلاق الكل") || text.contains("clear all")) {
                    return true
                }

                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) queue.add(child)
                }
            }
            return false
        } finally {
            queue.clear()
        }
    }

    /**
     * Checks if any included app for AI protection is actively in use on screen.
     * Accurately supports:
     * - Full-screen active apps
     * - Floating windows (Freeform / Mini floating window)
     * - Split-screen windows
     * And automatically pauses/stops when:
     * - User exits to Home/Launcher screen (without floating included app)
     * - User enters Recents / Overview screen (apps open in overview preview)
     * - User dismisses/removes the app from recents
     */
    private fun getActiveIncludedApp(): String? {
        val pm = getSystemService(POWER_SERVICE) as? android.os.PowerManager
        if (pm?.isInteractive != true) return null

        val km = getSystemService(KEYGUARD_SERVICE) as? android.app.KeyguardManager
        if (km?.isKeyguardLocked == true) return null

        val includedApps = SaffahBlockRepository.getAiProtectionIncludedApps(applicationContext)
        if (includedApps.isEmpty()) return null

        // 1. If currently in Recents / Overview, takeScreenshot MUST NOT run:
        if (isRecentsActive()) {
            isCurrentlyInRecents = true
            return null
        }

        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        val activeWindowRoot = try { rootInActiveWindow } catch (_: Exception) { null }
        val activePkg = try { activeWindowRoot?.packageName?.toString() } catch (_: Exception) { null }
        val activeCls = try { activeWindowRoot?.className?.toString() } catch (_: Exception) { null } ?: ""

        val isLauncherActive = isCurrentlyInLauncher || (activePkg != null && isTargetLauncher(activePkg))
        val isRecentsScreen = isCurrentlyInRecents || isRecentsOrOverview(activePkg ?: "", activeCls)

        // 2. If user is in Recents screen, takeScreenshot MUST NOT run:
        if (isRecentsScreen) {
            isCurrentlyInRecents = true
            return null
        }

        // 3. Check for Floating Window (Freeform window) or Split-screen among visible windows:
        // When user is on Launcher (Home screen), ONLY genuine floating windows (bounds smaller than fullscreen) can qualify.
        val windowList = try { windows } catch (_: Exception) { null }
        var detectedFloatingOrSplitApp: String? = null

        if (!windowList.isNullOrEmpty()) {
            for (w in windowList) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue

                val rootNode = try { w.root } catch (_: Exception) { null }
                val pkg = try { rootNode?.packageName?.toString() } catch (_: Exception) { null } ?: continue

                if (isTargetLauncher(pkg) || isRecentsOrOverview(pkg, "") || pkg == "com.android.systemui") continue

                if (includedApps.contains(pkg)) {
                    val rect = android.graphics.Rect()
                    w.getBoundsInScreen(rect)

                    // Ensure window is on-screen and non-trivial size
                    val isIntersects = rect.intersect(0, 0, screenWidth, screenHeight)
                    if (!isIntersects || rect.width() < 120 || rect.height() < 120) continue

                    val isFullscreenBounds = rect.width() >= (screenWidth * 0.96f).toInt() && 
                                            rect.height() >= (screenHeight * 0.96f).toInt()

                    if (isLauncherActive) {
                        // User is on Home screen!
                        // A window with full-screen bounds is merely a background/stale window.
                        // ONLY a genuine floating window (smaller bounds) is actively on top of the launcher.
                        if (!isFullscreenBounds) {
                            lastActiveIncludedPackage = pkg
                            return pkg
                        }
                    } else {
                        // Not on launcher: either split-screen, floating window over another app, or active app
                        if (!isFullscreenBounds || w.isActive || w.isFocused || activePkg == pkg) {
                            detectedFloatingOrSplitApp = pkg
                            break
                        }
                    }
                }
            }
        }

        if (detectedFloatingOrSplitApp != null) {
            lastActiveIncludedPackage = detectedFloatingOrSplitApp
            return detectedFloatingOrSplitApp
        }

        // 4. If user is on Launcher with no floating window, takeScreenshot MUST NOT run:
        if (isLauncherActive) {
            return null
        }

        // 5. Active foreground app check (Full-screen app):
        if (activePkg != null && includedApps.contains(activePkg)) {
            lastActiveIncludedPackage = activePkg
            return activePkg
        }

        val currentSessionPkg = activeUserSessionPackage
        if (currentSessionPkg != null && !isCurrentlyInLauncher && !isTargetLauncher(currentSessionPkg) && includedApps.contains(currentSessionPkg)) {
            lastActiveIncludedPackage = currentSessionPkg
            return currentSessionPkg
        }

        return null
    }

    private fun isTargetIncludedAppInActiveUse(): Boolean {
        return getActiveIncludedApp() != null
    }

    private fun triggerImmediateAiCheckIfApplicable() {
        if (!SaffahBlockRepository.isAiProtectionEnabled(applicationContext)) return
        startAiProtectionLoop()
    }

    private fun stopAiProtectionLoop() {
        frameScheduler?.stop()
    }

    private fun startAiProtectionLoop() {
        serviceScope.launch(Dispatchers.Default) {
            if (SaffahBlockRepository.isAiNudeNetEnabled(applicationContext)) {
                SaffahNudeNetClassifier.initialize(applicationContext)
            }
            if (SaffahBlockRepository.isAiAnimeEnabled(applicationContext)) {
                SaffahAnimeClassifier.initialize(applicationContext)
            }
        }
        if (frameScheduler == null) {
            frameScheduler = FrameScheduler(
                ctx = applicationContext,
                prefs = LiveDetectorPrefs(applicationContext),
                nudeProvider = {
                    if (SaffahBlockRepository.isAiNudeNetEnabled(applicationContext)) {
                        if (!SaffahNudeNetClassifier.isReady()) {
                            SaffahNudeNetClassifier.initialize(applicationContext)
                        }
                        SaffahNudeNetClassifier.getDetector()
                    } else null
                },
                animeProvider = {
                    if (SaffahBlockRepository.isAiAnimeEnabled(applicationContext)) {
                        if (!SaffahAnimeClassifier.isReady()) {
                            SaffahAnimeClassifier.initialize(applicationContext)
                        }
                        SaffahAnimeClassifier.getDetector()
                    } else null
                },
                capture = { callback ->
                    takeScreenshotForScheduler(callback)
                },
                isIgnoredForeground = {
                    isIgnoredForegroundForAi()
                },
                onViolation = { reason, dryRun ->
                    handleUnifiedAiViolation(reason, dryRun)
                }
            )
        }
        frameScheduler?.start()
    }

    private fun isIgnoredForegroundForAi(): Boolean {
        val pkg = activeUserSessionPackage ?: ""
        if (pkg.isBlank()) return true
        if (pkg == packageName || pkg == "com.example" || pkg == "com.android.systemui") return true
        if (isLauncherOrSystemApp(pkg) || isRecentsActive()) return true
        if (pkg.contains("inputmethod") || pkg.contains("keyboard") || pkg.contains(".ime")) return true
        return false
    }

    private fun takeScreenshotForScheduler(callback: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            callback(null)
            return
        }
        periodicCheckHandler.post {
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    screenshotExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshotResult: ScreenshotResult) {
                            val hardwareBuffer = screenshotResult.hardwareBuffer
                            val colorSpace = screenshotResult.colorSpace
                            try {
                                val hwBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
                                if (hwBitmap != null) {
                                    val softwareBitmap = try {
                                        hwBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                    } catch (e: Exception) {
                                        Log.e("SaffahAccessibility", "Failed to copy hwBitmap: ${e.message}")
                                        null
                                    }
                                    hwBitmap.recycle()
                                    if (softwareBitmap != null) {
                                        val croppedBmp = cropSystemBars(softwareBitmap)
                                        if (croppedBmp !== softwareBitmap) {
                                            softwareBitmap.recycle()
                                        }
                                        callback(croppedBmp)
                                    } else {
                                        callback(null)
                                    }
                                } else {
                                    callback(null)
                                }
                            } catch (e: Exception) {
                                Log.w("SaffahAccessibility", "Error converting screenshot: ${e.message}")
                                callback(null)
                            } finally {
                                hardwareBuffer.close()
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            Log.w("SaffahAccessibility", "takeScreenshot onFailure code: $errorCode")
                            callback(null)
                        }
                    }
                )
            } catch (e: Throwable) {
                Log.e("SaffahAccessibility", "Error executing takeScreenshot: ${e.message}", e)
                callback(null)
            }
        }
    }

    private fun cropSystemBars(src: Bitmap): Bitmap {
        try {
            val w = src.width
            val h = src.height
            // Fallback: 4% top (status bar), 6% bottom (navigation bar)
            val topCrop = (h * 0.04f).toInt().coerceAtLeast(0)
            val botCrop = (h * 0.06f).toInt().coerceAtLeast(0)
            val newH = h - topCrop - botCrop
            if (newH > 100 && w > 100) {
                return Bitmap.createBitmap(src, 0, topCrop, w, newH)
            }
        } catch (e: Throwable) {
            Log.w("SaffahAccessibility", "Failed to crop system bars: ${e.message}")
        }
        return src
    }

    private fun handleUnifiedAiViolation(reason: String, dryRun: Boolean) {
        serviceScope.launch(Dispatchers.Main) {
            if (dryRun) {
                Log.i("SaffahAccessibility", "[DRY RUN] $reason")
                showBlockedToast("[DRY RUN] $reason")
            } else {
                executeAiViolationAction(reason)
            }
        }
    }

    private fun executeAiViolationAction(reason: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastAiViolationTimestamp < 1200L) return
        lastAiViolationTimestamp = now

        val activeApp = getActiveIncludedApp() ?: lastActiveIncludedPackage ?: activeUserSessionPackage ?: (SaffahBlockRepository.getAiProtectionIncludedApps(applicationContext).firstOrNull() ?: "com.android.chrome")
        Log.i("SaffahAccessibility", "AI VIOLATION TRIGGERED in $activeApp: $reason")

        val isAnime = reason.startsWith("ANIME")
        val type = if (isAnime) {
            if (reason.contains("r18")) "صورة محظورة: هينتاي وعري أنمي" else "صورة محظورة: أنمي مثير وفاضح"
        } else {
            "صورة محظورة: عري ومحتوى واقعي فاضح"
        }

        SaffahBlockRepository.addBlockLog(
            context = this,
            item = "رصد ذكاء اصطناعي: $reason",
            type = type,
            sourceApp = activeApp
        )

        showBlockedToast("تم إغلاق المحتوى لاحتوائه على محتوى غير لائق ($reason)")

        val targetRoot = try { rootInActiveWindow } catch (e: Exception) { null }
        if (targetRoot != null) {
            try { findAndClickCloseButton(targetRoot) } catch (_: Exception) {}
        }
        val windowList = try { windows } catch (_: Exception) { null }
        if (!windowList.isNullOrEmpty()) {
            for (w in windowList) {
                val r = try { w.root } catch (_: Exception) { null } ?: continue
                if (r.packageName?.toString() == activeApp) {
                    try { findAndClickCloseButton(r) } catch (_: Exception) {}
                }
            }
        }

        performGlobalAction(GLOBAL_ACTION_BACK)
        periodicCheckHandler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_BACK)
        }, 150L)
        periodicCheckHandler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_BACK)
        }, 350L)

        val timeSinceLastViolation = now - previousAiViolationTimestamp
        previousAiViolationTimestamp = now
        if (timeSinceLastViolation in 1..2500L) {
            periodicCheckHandler.postDelayed({
                performGlobalAction(GLOBAL_ACTION_HOME)
            }, 400L)
        }
    }

    private var lastGlobalBlockActionRealtime: Long = 0L
    private var lastHomeIntentRealtime: Long = 0L
    private var lastPackageSuspensionSyncRealtime: Long = 0L
    private val launcherCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val launcherOrSystemAppCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private fun isLauncherOrSystemApp(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        launcherOrSystemAppCache[packageName]?.let { return it }
        val res = isTargetLauncher(packageName) || SaffahBlockRepository.isStrictUnblockableSystemPackage(this, packageName)
        launcherOrSystemAppCache[packageName] = res
        return res
    }

    private fun isTargetLauncher(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        launcherCache[packageName]?.let { return it }
        val ownPkg = applicationContext.packageName.lowercase()
        val lower = packageName.lowercase().trim()
        if (lower == ownPkg) {
            launcherCache[packageName] = false
            return false
        }
        val isLauncher = lower == "com.android.launcher" ||
                lower == "com.android.launcher3" ||
                lower == "com.coloros.launcher" ||
                lower == "com.oppo.launcher" ||
                lower == "com.realme.launcher" ||
                lower == "com.oplus.launcher" ||
                lower == "com.heytap.launcher" ||
                lower == "com.coloros.home" ||
                lower == "com.oppo.home" ||
                lower == "com.oplus.home" ||
                lower == "com.realme.home" ||
                lower == "com.google.android.apps.nexuslauncher" ||
                lower.contains("launcher") ||
                lower.contains("trebuchet") ||
                SaffahBlockRepository.isHomeLauncherPackage(this, packageName)
        launcherCache[packageName] = isLauncher
        return isLauncher
    }

    private fun isRecentsOrOverview(packageName: String, className: String = ""): Boolean {
        if (packageName.isBlank()) return false
        val pkgLower = packageName.lowercase().trim()
        val clsLower = className.lowercase().trim()

        if (pkgLower.contains("recents") || pkgLower.contains("overview") || pkgLower.contains("recenttask")) return true
        if (clsLower.contains("recents") || clsLower.contains("overview") ||
            clsLower.contains("taskview") || clsLower.contains("taskstack") ||
            clsLower.contains("quickstep") || clsLower.contains("overviewstate") ||
            clsLower.contains("recentapps") || clsLower.contains("taskswitcher") ||
            clsLower.contains("recentsactivity") || clsLower.contains("recenttask") ||
            clsLower.contains("overviewproxy")) return true
        if ((pkgLower == "com.android.systemui" || pkgLower.contains("systemui")) &&
            (clsLower.contains("recent") || clsLower.contains("task") || clsLower.contains("overview") || clsLower.contains("switcher"))) return true
        return false
    }

    private val gameAppCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val utilityAppCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    private fun isGameApp(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        gameAppCache[packageName]?.let { return it }
        val ownPkg = applicationContext.packageName.lowercase()
        val lower = packageName.lowercase().trim()
        if (lower == ownPkg || lower.startsWith("com.example")) {
            gameAppCache[packageName] = false
            return false
        }
        val isGame = try {
            val pm = applicationContext.packageManager
            val appInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, android.content.pm.PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            val isCatGame = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                appInfo.category == android.content.pm.ApplicationInfo.CATEGORY_GAME
            } else {
                false
            }
            @Suppress("DEPRECATION")
            val isFlagGame = (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_IS_GAME) != 0
            val isKnownGameName = lower.contains(".game") || lower.contains(".games") || lower.contains(".gaming") ||
                    lower.contains("pubg") || lower.contains("freefire") || lower.contains("roblox") ||
                    lower.contains("minecraft") || lower.contains("genshin") || lower.contains("fortnite") ||
                    lower.contains("brawlstars") || lower.contains("clashofclans") || lower.contains("subwaysurf") ||
                    lower.contains("ea.gp.") || lower.contains("gameloft") || lower.contains("unity3d") ||
                    lower.contains("epicgames") || lower.contains("riotgames") || lower.contains("mojang") ||
                    lower.contains("tencent.ig") || lower.contains("dts.freefire") || lower.contains("activision.callofduty") ||
                    lower.contains("king.candycrush") || lower.contains("supercell.")
            isCatGame || isFlagGame || isKnownGameName
        } catch (_: Exception) {
            val isKnownGameName = lower.contains(".game") || lower.contains(".games") || lower.contains(".gaming") ||
                    lower.contains("pubg") || lower.contains("freefire") || lower.contains("roblox") ||
                    lower.contains("minecraft") || lower.contains("genshin") || lower.contains("fortnite") ||
                    lower.contains("brawlstars") || lower.contains("clashofclans") || lower.contains("subwaysurf") ||
                    lower.contains("ea.gp.") || lower.contains("gameloft") || lower.contains("unity3d") ||
                    lower.contains("epicgames") || lower.contains("riotgames") || lower.contains("mojang") ||
                    lower.contains("tencent.ig") || lower.contains("dts.freefire") || lower.contains("activision.callofduty") ||
                    lower.contains("king.candycrush") || lower.contains("supercell.")
            isKnownGameName
        }
        gameAppCache[packageName] = isGame
        return isGame
    }

    private fun isUtilityOrMediaCaptureApp(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        utilityAppCache[packageName]?.let { return it }
        val lower = packageName.lowercase().trim()
        val isUtil = lower.contains("camera") ||
                lower.contains("gallery") ||
                lower.contains("photos") ||
                lower.contains("calculator") ||
                lower.contains("clock") ||
                lower.contains("dialer") ||
                lower.contains("contacts") ||
                lower.contains("compass") ||
                lower.contains("soundrecorder") ||
                lower.contains("voicerecorder") ||
                lower.contains("flashlight") ||
                lower.contains("wallpaper")
        utilityAppCache[packageName] = isUtil
        return isUtil
    }

    private fun isExcludedBrowser(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val lower = packageName.lowercase().trim()
        // Do NOT exclude 1DM / 1DM+
        if (lower.contains("idm.internet") || lower.contains("internet.download.manager")) {
            return false
        }
        return lower.contains("heytap") ||
                lower.contains("coloros.browser") ||
                lower.contains("nearme.browser") ||
                lower.contains("oppo.browser") ||
                lower.contains("realme.browser") ||
                lower.contains("mi.globalbrowser") ||
                lower.contains("vivo.browser") ||
                lower.contains("org.ecosia.android") ||
                lower.contains("ecosia") ||
                lower.contains("org.mozilla") ||
                lower.contains("firefox") ||
                lower.contains("fenix") ||
                lower.contains("klar") ||
                lower.contains("focus") ||
                lower.contains("com.dv.adm") ||
                lower.contains("cast.webvideo")
    }

    private fun isSupportedBrowser(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        if (isExcludedBrowser(packageName)) return false
        supportedBrowserCache[packageName]?.let { return it }
        if (SUPPORTED_BROWSER_PACKAGES.contains(packageName)) {
            supportedBrowserCache[packageName] = true
            return true
        }
        val lower = packageName.lowercase()
        val isMatch = lower.contains("com.android.chrome") ||
                lower.contains("net.quetta.browser") ||
                lower.contains("quetta") ||
                lower.contains("idm.internet.download.manager") ||
                lower.contains("internet.download.manager") ||
                lower.contains("idm.internet") ||
                lower.contains("com.brave.browser") ||
                lower.contains("com.opera.browser") ||
                lower.contains("com.opera.mini") ||
                lower.contains("com.duckduckgo.mobile") ||
                lower.contains("com.vivaldi.browser") ||
                lower.contains("org.torproject.torbrowser") ||
                lower.contains("spinbrowser") ||
                lower.contains("googlequicksearchbox") ||
                lower.contains("searchlite") ||
                lower.contains("sbrowser") ||
                lower.contains("microsoft.emmx") ||
                lower.contains("chromium")
        supportedBrowserCache[packageName] = isMatch
        return isMatch
    }

    private inline val AccessibilityNodeInfo.safeChildCount: Int
        get() = try { childCount } catch (_: Throwable) { 0 }

    private inline fun AccessibilityNodeInfo.safeGetChild(index: Int): AccessibilityNodeInfo? {
        return try {
            getChild(index)
        } catch (_: Throwable) {
            null
        }
    }

    private fun isKnownNonBrowser(packageName: String): Boolean {
        if (packageName.isBlank()) return true
        knownNonBrowserCache[packageName]?.let { return it }
        val lower = packageName.lowercase()
        if (isTelegramPackage(packageName)) {
            knownNonBrowserCache[packageName] = true
            return true
        }
        val isNon = lower.contains("whatsapp") ||
                lower.contains("instagram") ||
                lower.contains("facebook") ||
                lower.contains("messenger") ||
                lower.contains("youtube") ||
                lower.contains("tiktok") ||
                lower.contains("twitter") ||
                lower.contains("snapchat") ||
                lower.contains("discord") ||
                lower.contains("reddit") ||
                lower.contains("gmail") ||
                lower.contains("outlook") ||
                lower.contains("spotify") ||
                lower.contains("netflix") ||
                lower.contains("calculator") ||
                lower.contains("camera") ||
                lower.contains("gallery") ||
                lower.contains("photos") ||
                lower.contains("contacts") ||
                lower.contains("dialer") ||
                lower.contains("clock") ||
                lower.contains("systemui") ||
                lower.contains("launcher") ||
                lower.contains("settings") ||
                lower.contains("vending")
        knownNonBrowserCache[packageName] = isNon
        return isNon
    }

    private fun isBrowserAppPackage(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        if (isExcludedBrowser(packageName)) {
            anyBrowserCache[packageName] = false
            return false
        }
        anyBrowserCache[packageName]?.let { return it }

        if (isKnownNonBrowser(packageName)) {
            anyBrowserCache[packageName] = false
            return false
        }

        val lowerPkg = packageName.lowercase()
        val ownPkg = applicationContext.packageName.lowercase()
        if (lowerPkg == ownPkg || lowerPkg.startsWith("com.example")) {
            anyBrowserCache[packageName] = false
            return false
        }

        if (isSupportedBrowser(packageName)) {
            anyBrowserCache[packageName] = true
            return true
        }

        // 1. Comprehensive package name keyword matching for known browsers (excluding removed ones)
        if ((lowerPkg.contains("browser") && !lowerPkg.contains("broker")) ||
            lowerPkg.contains("idm.internet") ||
            lowerPkg.contains("internet.download.manager") ||
            lowerPkg.contains("sbrowser") ||
            lowerPkg.contains("webbrowser") ||
            lowerPkg.contains("huawei.browser") ||
            lowerPkg.contains("emmx") ||
            lowerPkg.contains("kiwi") ||
            lowerPkg.contains("ucmobile") ||
            lowerPkg.contains("uc.browser") ||
            lowerPkg.contains("yandex") ||
            lowerPkg.contains("puffin") ||
            lowerPkg.contains("dolphin") ||
            lowerPkg.contains("aloha") ||
            lowerPkg.contains("via") ||
            lowerPkg.contains("mint") ||
            lowerPkg.contains("phoenix") ||
            lowerPkg.contains("soul") ||
            lowerPkg.contains("pure") ||
            lowerPkg.contains("ghostery") ||
            lowerPkg.contains("privacybrowser") ||
            lowerPkg.contains("chromium") ||
            lowerPkg.contains("chrome") ||
            lowerPkg.contains("opera") ||
            lowerPkg.contains("brave") ||
            lowerPkg.contains("vivaldi") ||
            lowerPkg.contains("torproject") ||
            lowerPkg.contains("torbrowser") ||
            lowerPkg.contains("duckduckgo") ||
            lowerPkg.contains("whale") ||
            lowerPkg.contains("quark") ||
            lowerPkg.contains("baidu") ||
            lowerPkg.contains("qihoo") ||
            lowerPkg.contains("sleipnir")
        ) {
            anyBrowserCache[packageName] = true
            return true
        }

        // 2. Query PackageManager for HTTP/HTTPS VIEW intent resolution (Catches ANY custom or unknown browser)
        try {
            val pm = applicationContext.packageManager

            // Query browsable HTTP/HTTPS intent
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")).apply {
                setPackage(packageName)
                addCategory(Intent.CATEGORY_BROWSABLE)
            }
            val resolveInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(intent, 0)
            }
            if (resolveInfo.isNotEmpty()) {
                anyBrowserCache[packageName] = true
                return true
            }

            // Secondary check: HTTP scheme without BROWSABLE category requirement
            val httpIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("http://www.google.com")).apply {
                setPackage(packageName)
            }
            val httpResolveInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(httpIntent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(httpIntent, 0)
            }
            if (httpResolveInfo.isNotEmpty()) {
                anyBrowserCache[packageName] = true
                return true
            }
        } catch (e: Exception) {
            Log.e("SaffahAccessibility", "Error checking intent activities for browser $packageName: ${e.message}")
        }

        anyBrowserCache[packageName] = false
        return false
    }

    private fun isUnsupportedBrowser(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        if (isKnownNonBrowser(packageName)) return false
        if (isSupportedBrowser(packageName)) return false
        return isBrowserAppPackage(packageName)
    }

    private fun isCustomTabActivity(className: String): Boolean {
        if (className.isBlank()) return false
        val lower = className.lowercase()
        return lower.contains("customtab") ||
                lower.contains("custom_tab") ||
                lower.contains("customtabs") ||
                lower.contains("cct") ||
                lower.contains("chromecustomtab")
    }

    private fun isKnownInAppBrowserActivity(className: String, packageName: String): Boolean {
        if (className.isBlank()) return false
        if (isSupportedBrowser(packageName)) return false
        val lower = className.lowercase()
        val isStandaloneBrowser = isBrowserAppPackage(packageName)

        // Known proprietary in-app browsers across social & third-party apps
        if (lower.contains("browserliteactivity") ||
            lower.contains("fbchromeactivity") ||
            lower.contains("inappbrowser") ||
            lower.contains("in_app_browser") ||
            lower.contains("webviewactivity") ||
            lower.contains("web_view_activity") ||
            lower.contains("botwebviewsheet") ||
            lower.contains("crossplatformactivity") ||
            lower.contains("bulletactivity") ||
            lower.contains("simplewebview") ||
            lower.contains("embeddedbrowser") ||
            lower.contains("internalbrowser") ||
            lower.contains("htmlvieweractivity") ||
            lower.contains("urlvieweractivity") ||
            lower.contains("articleactivity") ||
            lower.contains("webactivity") ||
            lower.contains("webpageactivity")
        ) {
            return true
        }

        // Generic "browseractivity" only if the package is NOT a standalone browser app
        if (!isStandaloneBrowser && lower.contains("browseractivity") && !lower.contains("chrometabbedactivity")) {
            return true
        }

        return false
    }

    private fun hasCustomTabUi(rootNode: AccessibilityNodeInfo?): Boolean {
        if (rootNode == null) return false
        val queue = reusableMediaCheckNodesQueue
        queue.clear()
        queue.add(rootNode)
        var count = 0
        try {
            while (queue.isNotEmpty() && count < 100) {
                val node = queue.removeFirst()
                count++
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                if (id.contains("custom_tab_toolbar") ||
                    id.contains("custom_tab_close_button") ||
                    id.contains("custom_tab_domain") ||
                    id.contains("custom_tab_title") ||
                    id.contains("title_url_container") ||
                    (id.contains("custom_tab") && id.contains("toolbar")) ||
                    (id.contains("cct") && (id.contains("toolbar") || id.contains("close") || id.contains("url"))) ||
                    id.contains("open_in_browser") ||
                    desc.contains("open in browser") ||
                    desc.contains("فتح في المتصفح") ||
                    desc.contains("custom tab")
                ) {
                    return true
                }
                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) queue.add(child)
                }
            }
            return false
        } finally {
            queue.clear()
        }
    }

    private fun findAndClickCloseButton(rootNode: AccessibilityNodeInfo?): Boolean {
        if (rootNode == null) return false
        val queue = reusableMediaCheckNodesQueue
        queue.clear()
        queue.add(rootNode)
        var count = 0
        try {
            while (queue.isNotEmpty() && count < 80) {
                val node = queue.removeFirst()
                count++
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                val text = node.text?.toString()?.lowercase() ?: ""
                val isCloseCandidate = id.contains("custom_tab_close_button") ||
                        id.contains("close_button") ||
                        id.contains("btn_close") ||
                        id.contains("action_mode_close_button") ||
                        desc == "close" ||
                        desc == "إغلاق" ||
                        desc == "close tab" ||
                        desc == "إغلاق علامة التبويب" ||
                        desc == "navigate up" ||
                        desc == "التنقل إلى أعلى" ||
                        text == "close" ||
                        text == "إغلاق"

                if (isCloseCandidate) {
                    if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                    val parent = node.parent
                    if (parent != null && parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                }
                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) queue.add(child)
                }
            }
            return false
        } finally {
            queue.clear()
        }
    }

    private fun hasInAppWebView(
        rootNode: AccessibilityNodeInfo?,
        eventSource: AccessibilityNodeInfo? = null
    ): Boolean {
        val rect = Rect()

        // 1. Direct inspection of eventSource (0ms fast check)
        if (eventSource != null) {
            val srcCls = eventSource.className?.toString() ?: ""
            val srcId = eventSource.viewIdResourceName?.lowercase() ?: ""
            val isSrcWebView = srcCls.contains("WebView", ignoreCase = true) ||
                    srcCls.contains("AwContents", ignoreCase = true) ||
                    srcCls.contains("ChromiumWebView", ignoreCase = true) ||
                    srcCls.contains("WebContentsView", ignoreCase = true) ||
                    srcCls.contains("FlutterWebView", ignoreCase = true) ||
                    srcCls.contains("RNCWebView", ignoreCase = true) ||
                    srcId.contains("webview") ||
                    srcId.contains("web_view") ||
                    srcId.contains("browser_container") ||
                    srcId.contains("browser_view") ||
                    srcId.contains("web_container")

            if (isSrcWebView) {
                eventSource.getBoundsInScreen(rect)
                if (rect.width() >= 250 && rect.height() >= 350) {
                    return true
                }
            }

            val parent = eventSource.parent
            if (parent != null) {
                val pCls = parent.className?.toString() ?: ""
                val pId = parent.viewIdResourceName?.lowercase() ?: ""
                if (pCls.contains("WebView", ignoreCase = true) ||
                    pCls.contains("AwContents", ignoreCase = true) ||
                    pCls.contains("ChromiumWebView", ignoreCase = true) ||
                    pId.contains("webview") || pId.contains("web_view")
                ) {
                    parent.getBoundsInScreen(rect)
                    if (rect.width() >= 250 && rect.height() >= 350) {
                        return true
                    }
                }
            }
        }

        // 2. Tree BFS inspection (up to 250 nodes to traverse deep layouts)
        if (rootNode == null) return false
        val queue = reusableHierarchyNodesQueue
        queue.clear()
        queue.add(rootNode)
        var count = 0
        try {
            while (queue.isNotEmpty() && count < 250) {
                val node = queue.removeFirst()
                count++
                val cls = node.className?.toString() ?: ""
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val isWebViewClass = cls.contains("WebView", ignoreCase = true) ||
                        cls.contains("AwContents", ignoreCase = true) ||
                        cls.contains("ChromiumWebView", ignoreCase = true) ||
                        cls.contains("WebContentsView", ignoreCase = true) ||
                        cls.contains("FlutterWebView", ignoreCase = true) ||
                        cls.contains("RNCWebView", ignoreCase = true)
                val isWebViewId = id.contains("webview") ||
                        id.contains("web_view") ||
                        id.contains("browser_container") ||
                        id.contains("browser_view") ||
                        id.contains("web_container")

                if (isWebViewClass || isWebViewId) {
                    node.getBoundsInScreen(rect)
                    // Discard small ad banners (e.g. 320x50) and tiny tracking pixels/badges.
                    // Genuine in-app browsing webviews occupy substantial screen real estate.
                    if (rect.width() >= 250 && rect.height() >= 350) {
                        return true
                    }
                }
                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) queue.add(child)
                }
            }
            return false
        } finally {
            queue.clear()
        }
    }

    private fun isInAppBrowserOrCustomTab(
        packageName: String,
        activityOrClassName: String,
        rootNode: AccessibilityNodeInfo?,
        eventSource: AccessibilityNodeInfo? = null,
        rootPkg: String = ""
    ): Boolean {
        if (packageName.isBlank()) return false
        val ownPkg = applicationContext.packageName.lowercase()
        val lowerPkg = packageName.lowercase().trim()
        if (lowerPkg == ownPkg) {
            return false
        }
        if (isLauncherOrSystemApp(packageName)) {
            return false
        }

        val isSupported = isSupportedBrowser(packageName) || (rootPkg.isNotBlank() && isSupportedBrowser(rootPkg))

        // 1. Custom Tab check:
        // Do NOT block if the Custom Tab belongs to a supported browser (Chrome, Brave, Firefox, Edge, etc.)
        val isCustomTab = isCustomTabActivity(activityOrClassName) || hasCustomTabUi(rootNode)
        if (isCustomTab) {
            if (isSupported) {
                return false
            }
            // Block Custom Tab only if it is an UNSUPPORTED browser
            return true
        }

        // 2. Standalone supported browsers running normal browsing tabs are ALLOWED
        if (isSupported) {
            return false
        }

        // 3. Standalone unsupported browsers are handled by "isBlockUnsupportedBrowsers" toggle
        if (isBrowserAppPackage(packageName)) {
            return false
        }

        // 4. Dedicated In-App Browser Activities in host apps (e.g. Facebook BrowserLiteActivity, Telegram BotWebViewSheet)
        if (isKnownInAppBrowserActivity(activityOrClassName, packageName)) {
            return true
        }

        // 5. Embedded WebViews in host apps
        if (hasInAppWebView(rootNode, eventSource)) {
            return true
        }

        return false
    }

    private fun dismissInAppBrowser(
        sourcePackage: String,
        sourceAppName: String,
        blockedItem: String,
        rootNode: AccessibilityNodeInfo? = null
    ) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInAppBrowserBlockTimestamp < 800L) {
            return
        }
        lastInAppBrowserBlockTimestamp = now

        // 1. Log block event in repository
        val appSource = sourcePackage.takeIf { it.isNotBlank() } ?: sourceAppName
        SaffahBlockRepository.addBlockLog(
            this,
            blockedItem,
            "حظر المتصفح المدمج",
            appSource
        )

        // 2. Show clear user toast feedback (No emojis per project rules)
        showBlockedToast("تم إغلاق المتصفح المدمج ($sourceAppName) لحمايتك")

        // 3. Attempt to click dedicated close button first (cleans up custom tabs immediately)
        val targetRoot = rootNode ?: try { rootInActiveWindow } catch (e: Exception) { null }
        if (targetRoot != null) {
            try {
                findAndClickCloseButton(targetRoot)
            } catch (e: Exception) {
                Log.w("SaffahAccessibility", "Error clicking close button: ${e.message}")
            }
        }

        // 4. Always perform GLOBAL_ACTION_BACK to return user to the host app!
        // CRITICAL: NEVER call performGlobalAction(GLOBAL_ACTION_HOME) or launch homeIntent here!
        // This ensures the host application stays open in the foreground and ONLY the in-app browser is dismissed.
        performGlobalAction(GLOBAL_ACTION_BACK)

        // 5. Follow-up safety check: In case the webview had internal history or multi-step navigation
        periodicCheckHandler.postDelayed({
            try {
                val currentClass = currentTopActivityName
                val currentPkg = try { rootInActiveWindow?.packageName?.toString() ?: "" } catch (e: Exception) { "" }
                val isSupported = isSupportedBrowser(currentPkg) || isSupportedBrowser(sourcePackage)
                val isStillInApp = isKnownInAppBrowserActivity(currentClass, sourcePackage) ||
                        (isCustomTabActivity(currentClass) && !isSupported)
                if (isStillInApp) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                }
            } catch (e: Exception) {
                // ignore
            }
        }, 350L)
    }

    private val telegramPackageCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private fun isTelegramPackage(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        telegramPackageCache[packageName]?.let { return it }
        if (TELEGRAM_PACKAGES.contains(packageName)) {
            telegramPackageCache[packageName] = true
            return true
        }
        val lower = packageName.lowercase()
        val res = lower.contains("telegram") || lower.contains("telegra") || lower.contains("ime.android")
        telegramPackageCache[packageName] = res
        return res
    }

    private fun isTelegramGlobalSearch(rootNode: AccessibilityNodeInfo): Boolean {
        var hasSearchField = false
        var filterTabsCount = 0
        var hasTabContentDesc = false
        val rect = Rect()

        val nodesToProcess = reusableMediaCheckNodesQueue
        nodesToProcess.clear()
        nodesToProcess.add(rootNode)
        var nodesExamined = 0

        try {
            while (nodesToProcess.isNotEmpty() && nodesExamined < 30) {
                val node = nodesToProcess.removeFirst()
                nodesExamined++

                val className = node.className?.toString() ?: ""
                val desc = node.contentDescription?.toString() ?: ""
                val text = node.text?.toString() ?: ""

                // 1. Check for search EditText field
                if (className == "android.widget.EditText") {
                    node.getBoundsInScreen(rect)
                    if ((node.isFocusable || node.isClickable) && (rect.top <= 1200 || rect.isEmpty)) {
                        hasSearchField = true
                    }
                }

                // 2. Check for RecyclerView representing Filter Tabs (Chats, Channels, Apps, Posts, Media)
                if (className == "androidx.recyclerview.widget.RecyclerView" && node.isScrollable) {
                    var viewChildren = 0
                    for (i in 0 until node.safeChildCount) {
                        val child = node.safeGetChild(i) ?: continue
                        val childClass = child.className?.toString() ?: ""
                        val childDesc = child.contentDescription?.toString() ?: ""
                        val childText = child.text?.toString() ?: ""

                        if (childClass == "android.view.View" || childClass.contains("TextView") || childClass.contains("Tab")) {
                            viewChildren++
                        }
                        if (childDesc in GLOBAL_SEARCH_TABS || childText in GLOBAL_SEARCH_TABS) {
                            hasTabContentDesc = true
                        }
                    }
                    if (viewChildren >= 3 || hasTabContentDesc) {
                        filterTabsCount = viewChildren.coerceAtLeast(filterTabsCount)
                    }
                }

                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) {
                        nodesToProcess.add(child)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error checking Telegram search: ${e.message}")
        } finally {
            nodesToProcess.clear()
        }

        // Global search requires both the search EditText field AND the presence of filter tabs (>= 3 children or recognized tab desc)
        return hasSearchField && (filterTabsCount >= 3 || hasTabContentDesc)
    }

    private val whatsAppPackageCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private fun isWhatsAppPackage(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        whatsAppPackageCache[packageName]?.let { return it }
        val lower = packageName.lowercase()
        val res = lower == "com.whatsapp" || lower == "com.whatsapp.w4b" || lower.contains("whatsapp")
        whatsAppPackageCache[packageName] = res
        return res
    }

    private val youTubePackageCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private fun isYouTubePackage(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        youTubePackageCache[packageName]?.let { return it }
        val lower = packageName.lowercase()
        val res = lower == "com.google.android.youtube" ||
                lower == "app.rvx.android.youtube" ||
                lower == "com.vanced.android.youtube" ||
                (lower.contains("youtube") && !lower.contains("browser"))
        youTubePackageCache[packageName] = res
        return res
    }

    private fun isYouTubeShortsActive(rootNode: AccessibilityNodeInfo): Boolean {
        val nodesToProcess = reusableMediaCheckNodesQueue
        nodesToProcess.clear()
        nodesToProcess.add(rootNode)
        var nodesExamined = 0
        var isShorts = false

        try {
            while (nodesToProcess.isNotEmpty() && nodesExamined < 30) {
                val node = nodesToProcess.removeFirst()
                nodesExamined++

                val viewId = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""

                if (viewId.contains(":id/reel_") ||
                    viewId.contains("shorts_") ||
                    viewId.contains("reel_watch_") ||
                    viewId.contains("reel_player_") ||
                    (desc.contains("shorts") && node.isSelected)
                ) {
                    isShorts = true
                    break
                }

                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) {
                        nodesToProcess.add(child)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error checking YouTube shorts: ${e.message}")
        } finally {
            nodesToProcess.clear()
        }

        return isShorts
    }

    private val fbLitePackageCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private fun isFacebookLitePackage(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        fbLitePackageCache[packageName]?.let { return it }
        val lower = packageName.lowercase()
        val res = lower == "com.facebook.lite" || lower.contains("facebook.lite")
        fbLitePackageCache[packageName] = res
        return res
    }

    private fun isFacebookLiteReelsActive(rootNode: AccessibilityNodeInfo): Boolean {
        // Facebook Lite Reels Fullscreen Viewer has:
        // 1. A full-height video_view taking almost the entire vertical screen (height >= 1500px, top <= 450, bottom >= 2100)
        // 2. A distinctive vertical action dock on the right edge (at least 2 stacked clickable buttons with left >= 850px in the lower screen area)
        // 3. Or audio title bar at bottom left overlaying the video
        
        var hasFullscreenVideo = false
        var rightSideActionButtonsCount = 0
        var hasAudioBar = false
        val rect = android.graphics.Rect()

        // 1. Direct check for video_view dimensions
        val videoNodes = rootNode.findAccessibilityNodeInfosByViewId("com.facebook.lite:id/video_view")
        if (!videoNodes.isNullOrEmpty()) {
            for (node in videoNodes) {
                node.getBoundsInScreen(rect)
                // Reels video in FB Lite occupies vertical full screen (height >= 1500px, top <= 450, bottom >= 2100)
                if (rect.height() >= 1500 && rect.top <= 450 && rect.bottom >= 2100) {
                    hasFullscreenVideo = true
                }
            }
        }

        // 2. BFS Traversal to verify full screen video and vertical right-side action buttons
        val nodesToProcess = reusableMediaCheckNodesQueue
        nodesToProcess.clear()
        nodesToProcess.add(rootNode)
        var nodesExamined = 0

        try {
            while (nodesToProcess.isNotEmpty() && nodesExamined < 30) {
                val node = nodesToProcess.removeFirst()
                nodesExamined++

                node.getBoundsInScreen(rect)

                // Check if this node is full-screen video if not detected yet
                val viewId = node.viewIdResourceName?.lowercase() ?: ""
                if (viewId.contains("com.facebook.lite:id/video_view") && rect.height() >= 1500 && rect.top <= 450 && rect.bottom >= 2100) {
                    hasFullscreenVideo = true
                }

                // Check right margin stacked action buttons (Like, Comment, Share, More)
                // Bounds in XML: x in [850, 1080], y in [1400, 2380], clickable = true, compact button width <= 200
                if (node.isClickable && rect.left >= 850 && rect.top >= 1400 && rect.bottom <= 2380 && rect.width() <= 200 && rect.height() in 100..280) {
                    rightSideActionButtonsCount++
                }

                // Check bottom audio/music bar overlay: width >= 600, height in 30..120, top >= 2150
                if (rect.left <= 100 && rect.width() >= 600 && rect.height() in 30..120 && rect.top >= 2150) {
                    hasAudioBar = true
                }

                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) {
                        nodesToProcess.add(child)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error checking FB Lite reels: ${e.message}")
        } finally {
            nodesToProcess.clear()
        }

        // Strict condition: Must have full-screen vertical video AND (vertical right action buttons >= 2 OR audio bar)
        return hasFullscreenVideo && (rightSideActionButtonsCount >= 2 || hasAudioBar)
    }

    private val instagramPackageCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private fun isInstagramPackage(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        instagramPackageCache[packageName]?.let { return it }
        if (INSTAGRAM_PACKAGES.contains(packageName)) {
            instagramPackageCache[packageName] = true
            return true
        }
        val lower = packageName.lowercase()
        val res = lower == "com.instagram.android" || lower == "com.instagram.lite" || lower.contains("instagram")
        instagramPackageCache[packageName] = res
        return res
    }

    private val triggerAppCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private fun isTriggerApp(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        triggerAppCache[packageName]?.let { return it }
        val res = isInstagramPackage(packageName) ||
                isYouTubePackage(packageName) ||
                isFacebookLitePackage(packageName) ||
                isTelegramPackage(packageName) ||
                isWhatsAppPackage(packageName)
        triggerAppCache[packageName] = res
        return res
    }

    private fun isInstagramReelsActive(rootNode: AccessibilityNodeInfo): Boolean {
        // Fast single-pass traversal examining up to 30 nodes (instead of dozens of separate IPC queries)
        val nodesToProcess = reusableMediaCheckNodesQueue
        nodesToProcess.clear()
        nodesToProcess.add(rootNode)
        var nodesExamined = 0
        var isReelsViewer = false

        try {
            while (nodesToProcess.isNotEmpty() && nodesExamined < 30) {
                val node = nodesToProcess.removeFirst()
                nodesExamined++

                val viewId = node.viewIdResourceName?.lowercase() ?: ""

                // 1. Check if Reels tab is selected
                if (viewId.endsWith("clips_tab") && node.isSelected) {
                    isReelsViewer = true
                    break
                }

                // 2. Check fullscreen viewer identifiers
                if (viewId.contains("root_clips_layout") ||
                    viewId.contains("clips_viewer_container") ||
                    viewId.contains("clips_viewer_view_pager") ||
                    viewId.contains("clips_viewer_media_view_pager") ||
                    viewId.contains("clips_viewer_action_bar") ||
                    viewId.contains("clips_ufi_component") ||
                    viewId.contains("clips_viewer_video_layout") ||
                    viewId.contains("clips_pause_and_mute_component") ||
                    viewId.contains("clips_bottom_legibility_gradient_component")
                ) {
                    isReelsViewer = true
                    break
                }

                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) {
                        nodesToProcess.add(child)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error checking Instagram reels: ${e.message}")
        } finally {
            nodesToProcess.clear()
        }

        return isReelsViewer
    }

    private fun isWhatsAppChannelSearchOrDirectory(rootNode: AccessibilityNodeInfo): Boolean {
        val nodesToProcess = reusableMediaCheckNodesQueue
        nodesToProcess.clear()
        nodesToProcess.add(rootNode)
        var nodesExamined = 0
        var isChannelSearch = false

        try {
            while (nodesToProcess.isNotEmpty() && nodesExamined < 30) {
                val node = nodesToProcess.removeFirst()
                nodesExamined++

                val viewId = node.viewIdResourceName?.lowercase() ?: ""
                if (viewId.contains("directory_category_list") ||
                    viewId.contains("newsletter_directory_row") ||
                    viewId.contains("chips_container") ||
                    viewId.contains("search_category_image")
                ) {
                    isChannelSearch = true
                    break
                }

                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) {
                        nodesToProcess.add(child)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error checking WhatsApp channel: ${e.message}")
        } finally {
            nodesToProcess.clear()
        }

        return isChannelSearch
    }

    @Volatile
    private var isScreenInteractive = true

    private val screenStateReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
            when (intent?.action) {
                android.content.Intent.ACTION_SCREEN_OFF -> {
                    isScreenInteractive = false
                    stopAiProtectionLoop()
                    val prev = activeUserSessionPackage
                    if (prev != null) {
                        completeAppSession(prev)
                        activeUserSessionPackage = null
                    }
                    periodicCheckHandler.removeCallbacks(periodicCheckRunnable)
                    minuteTickHandler.removeCallbacks(minuteTickRunnable)
                    context?.let { SaffahBlockRepository.notifyScreenOff(it) }
                }
                android.content.Intent.ACTION_SCREEN_ON -> {
                    isScreenInteractive = true
                    updateAiProtectionState()
                    if (SaffahProtectionManager.isKeeperServiceEnabled(this@SaffahAccessibilityService)) {
                        val isForeground = SaffahProtectionManager.isKeeperServiceForeground(this@SaffahAccessibilityService)
                        if (!isForeground || !com.example.service.SaffahKeeperService.isKeeperRunning.value) {
                            SaffahProtectionManager.startKeeperService(this@SaffahAccessibilityService)
                        }
                        com.example.service.SaffahKeeperService.ensureKeeperNotification(this@SaffahAccessibilityService)
                    }
                    SaffahBlockRepository.invalidateTimeCache()
                    com.example.util.SaffahBedtimeManager.evaluateBedtimeState(this@SaffahAccessibilityService)
                    periodicCheckHandler.removeCallbacks(periodicCheckRunnable)
                    periodicCheckHandler.post(periodicCheckRunnable)
                    scheduleNextMinuteTick()
                    minuteTickHandler.post(minuteTickRunnable)
                }
                android.content.Intent.ACTION_POWER_CONNECTED -> {
                    context?.let { ctx ->
                        com.example.util.SaffahChargingManager.onPowerConnected(ctx)
                    }
                }
                android.content.Intent.ACTION_POWER_DISCONNECTED -> {
                    context?.let { ctx ->
                        com.example.util.SaffahChargingManager.onPowerDisconnected(ctx)
                    }
                }
            }
        }
    }

    private fun getAllVisiblePackages(): Set<String> {
        val visible = mutableSetOf<String>()
        val nowRealtime = SystemClock.elapsedRealtime()

        // 1. Check all on-screen interactive windows (includes Floating windows, FlexDrop, Freeform, Split-screen)
        try {
            val windowList = windows
            if (!windowList.isNullOrEmpty()) {
                for (window in windowList) {
                    val root = try { window.root } catch (e: Exception) { null }
                    val pkg = root?.packageName?.toString()
                    if (!pkg.isNullOrBlank() && !SaffahBlockRepository.isStrictUnblockableSystemPackage(this, pkg)) {
                        val isSettings = SaffahBlockRepository.isSystemSettingsPackage(this, pkg) || SaffahBlockRepository.isSystemSettingsPackageName(pkg)
                        if (isSettings) {
                            if (SaffahBlockRepository.isCurrentlyBedtime(this) && !SaffahBlockRepository.getBedtimeAllowedApps(this).contains(pkg)) {
                                visible.add(pkg)
                            }
                        } else if (!isTargetLauncher(pkg)) {
                            visible.add(pkg)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error querying interactive windows: ${e.message}")
        }

        // 2. Check root in active window as fallback if windows list yielded nothing
        if (visible.isEmpty()) {
            try {
                val activeRoot = rootInActiveWindow
                val activePkg = activeRoot?.packageName?.toString()
                if (!activePkg.isNullOrBlank() && !SaffahBlockRepository.isStrictUnblockableSystemPackage(this, activePkg)) {
                    val isSettings = SaffahBlockRepository.isSystemSettingsPackage(this, activePkg) || SaffahBlockRepository.isSystemSettingsPackageName(activePkg)
                    if (isSettings) {
                        if (SaffahBlockRepository.isCurrentlyBedtime(this) && !SaffahBlockRepository.getBedtimeAllowedApps(this).contains(activePkg)) {
                            visible.add(activePkg)
                        }
                    } else if (!isTargetLauncher(activePkg)) {
                        visible.add(activePkg)
                    }
                }
            } catch (e: Exception) {
                Log.w("SaffahAccessibility", "Error querying rootInActiveWindow: ${e.message}")
            }
        }

        val activeSession = activeUserSessionPackage
        if (!activeSession.isNullOrBlank() &&
            !SaffahBlockRepository.isStrictUnblockableSystemPackage(this, activeSession) &&
            !isTargetLauncher(activeSession)
        ) {
            visible.add(activeSession)
        }

        return visible
    }

    private var lastNotificationEvalRealtime: Long = 0L
    private var lastBedtimeEvalRealtime: Long = 0L
    private val periodicCheckHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val periodicCheckRunnable: Runnable = object : Runnable {
        override fun run() {
            if (!isServiceBound || !isScreenInteractive) return
            serviceScope.launch(Dispatchers.IO) {
                try {
                    val nowRealtime = SystemClock.elapsedRealtime()

                    // Periodically evaluate bedtime state so grayscale is active immediately at bedtime hour (every 30s)
                    if (nowRealtime - lastBedtimeEvalRealtime >= 30_000L) {
                        lastBedtimeEvalRealtime = nowRealtime
                        com.example.util.SaffahBedtimeManager.evaluateBedtimeState(this@SaffahAccessibilityService)
                    }
                    if (nowRealtime - lastNotificationEvalRealtime >= 60_000L) {
                        lastNotificationEvalRealtime = nowRealtime
                        com.example.util.SaffahNotificationManager.evaluateAllNotifications(this@SaffahAccessibilityService)
                    }

                    // Fast resolution: If active user session package is already tracked, use it!
                    val sessionPkg = activeUserSessionPackage
                    val effectivePkg = when {
                        !sessionPkg.isNullOrBlank() &&
                            !SaffahBlockRepository.isStrictUnblockableSystemPackage(this@SaffahAccessibilityService, sessionPkg) &&
                            !isTargetLauncher(sessionPkg) -> sessionPkg
                        else -> null
                    }

                    val targetPkgs = mutableSetOf<String>()
                    if (!effectivePkg.isNullOrBlank()) {
                        targetPkgs.add(effectivePkg)
                    } else {
                        val visible = withContext(Dispatchers.Main) {
                            getAllVisiblePackages()
                        }
                        targetPkgs.addAll(visible)
                    }

                    for (pkg in targetPkgs) {
                        val decision = SaffahBlockRepository.evaluateAppBlockDecision(this@SaffahAccessibilityService, pkg)
                        if (decision != null && decision.isBlocked) {
                            val appLabel = getAppNameFromPackage(pkg)
                            val lastBlock = recentlyBlockedPackages[pkg] ?: 0L
                            val isDebounced = (nowRealtime - lastBlock < 2000L)
                            recentlyBlockedPackages[pkg] = nowRealtime

                            withContext(Dispatchers.Main) {
                                triggerBlockAction(
                                    blockedItem = appLabel,
                                    type = decision.ruleType,
                                    sourceApp = appLabel,
                                    userMessage = decision.userMessage,
                                    targetPackage = pkg,
                                    suppressToast = isDebounced
                                )
                            }
                            continue
                        }

                        // Accumulate incremental foreground time safely (~3.0s tick) while screen is active for non-blocked apps only
                        SaffahBlockRepository.recordPeriodicForegroundTick(this@SaffahAccessibilityService, pkg, 3000L)
                    }
                } catch (e: Exception) {
                    Log.w("SaffahAccessibility", "Error in periodic usage check: ${e.message}")
                } finally {
                    if (isServiceBound && isScreenInteractive) {
                        val nextInterval = if (activeUserSessionPackage.isNullOrBlank()) 5000L else 3000L
                        periodicCheckHandler.postDelayed(periodicCheckRunnable, nextInterval)
                    }
                }
            }
        }
    }

    // --- ZERO-SECOND PRECISION MINUTE SCHEDULER ---
    // Fires precisely at the :00.000 millisecond mark of every minute to ensure
    // schedule blocks and bedtime blocks start and end in the EXACT first second.
    private val minuteTickHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val minuteTickRunnable: Runnable = object : Runnable {
        override fun run() {
            if (!isServiceBound) return

            // 1. Invalidate stale time & bedtime caches immediately
            SaffahBlockRepository.invalidateTimeCache()

            // 2. Perform zero-second precision evaluation of Bedtime and Schedules
            serviceScope.launch(Dispatchers.IO) {
                try {
                    com.example.util.SaffahBedtimeManager.evaluateBedtimeState(this@SaffahAccessibilityService)
                    SaffahBlockRepository.syncAllPackageSuspensions(this@SaffahAccessibilityService, force = true)
                    com.example.util.SaffahNotificationManager.evaluateAndTriggerScheduledBlockNotifications(this@SaffahAccessibilityService)
                    com.example.util.SaffahNotificationManager.evaluateAndTriggerBedtimeNotifications(this@SaffahAccessibilityService)
                    withContext(Dispatchers.Main) {
                        checkAndEnforceImmediateForegroundBlock()
                    }
                } catch (e: Exception) {
                    Log.w("SaffahAccessibility", "Error in precision minute tick: ${e.message}")
                }
            }

            // 3. Schedule next execution precisely at the next :00.000 second mark
            scheduleNextMinuteTick()
        }
    }

    private fun scheduleNextMinuteTick() {
        minuteTickHandler.removeCallbacks(minuteTickRunnable)
        if (!isServiceBound || !isScreenInteractive) return
        val now = System.currentTimeMillis()
        val delayMs = (60_000L - (now % 60_000L)).coerceIn(50L, 60_000L)
        minuteTickHandler.postDelayed(minuteTickRunnable, delayMs)
    }

    fun checkAndEnforceImmediateForegroundBlock() {
        try {
            val sessionPkg = activeUserSessionPackage
            val topPkg = sessionPkg ?: try { rootInActiveWindow?.packageName?.toString() } catch (_: Exception) { null }
            if (topPkg.isNullOrBlank()) return
            if (SaffahBlockRepository.isStrictUnblockableSystemPackage(this, topPkg) || isTargetLauncher(topPkg)) return

            val decision = SaffahBlockRepository.evaluateAppBlockDecision(this, topPkg)
            if (decision != null && decision.isBlocked) {
                val appLabel = getAppNameFromPackage(topPkg)
                triggerBlockAction(
                    blockedItem = appLabel,
                    type = decision.ruleType,
                    sourceApp = appLabel,
                    userMessage = decision.userMessage,
                    targetPackage = topPkg
                )
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error enforcing immediate foreground block: ${e.message}")
        }
    }

    private var lastStateCheckTimestamp = 0L
    private var lastKeeperRevivalCheckTimestamp = 0L
    private var lastKeeperNotificationHeartbeatTimestamp = 0L
    private var activeUserSessionPackage: String?
        get() = Companion.activeUserSessionPackage
        set(value) { Companion.activeUserSessionPackage = value }
    private val packageLastExitRealtimeMap = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val packageLastLaunchIncrementRealtimeMap = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val pendingSessionCompletionMap = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val sessionEnteredRealtimeMap = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun startAppSession(packageName: String) {
        if (packageName.isBlank()) return
        if (SaffahBlockRepository.isStrictUnblockableSystemPackage(this, packageName) ||
            isTargetLauncher(packageName) ||
            isRecentsOrOverview(packageName, "") ||
            SaffahBlockRepository.isSystemSettingsPackage(this, packageName) ||
            SaffahBlockRepository.isSystemSettingsPackageName(packageName)
        ) {
            return
        }

        val nowRealtime = SystemClock.elapsedRealtime()
        sessionEnteredRealtimeMap[packageName] = nowRealtime
        pendingSessionCompletionMap[packageName] = true
    }

    private fun completeAppSession(packageName: String?) {
        if (packageName.isNullOrBlank()) return
        if (SaffahBlockRepository.isStrictUnblockableSystemPackage(this, packageName) ||
            isTargetLauncher(packageName) ||
            isRecentsOrOverview(packageName, "") ||
            SaffahBlockRepository.isSystemSettingsPackage(this, packageName) ||
            SaffahBlockRepository.isSystemSettingsPackageName(packageName)
        ) {
            pendingSessionCompletionMap.remove(packageName)
            sessionEnteredRealtimeMap.remove(packageName)
            return
        }

        val isPending = pendingSessionCompletionMap[packageName] ?: false
        if (!isPending) return

        val enterTime = sessionEnteredRealtimeMap[packageName] ?: 0L
        val nowRealtime = SystemClock.elapsedRealtime()
        val sessionDurationMs = if (enterTime > 0L) nowRealtime - enterTime else 0L

        // Require at least 300ms active interaction to qualify as a real session
        // (avoids phantom micro-switches or sub-frame flickers)
        if (enterTime == 0L || sessionDurationMs >= 300L) {
            pendingSessionCompletionMap[packageName] = false
            sessionEnteredRealtimeMap.remove(packageName)
            packageLastExitRealtimeMap[packageName] = nowRealtime

            val newCount = SaffahBlockRepository.incrementDailyLaunchCount(this, packageName)
            Log.i("SaffahAccessibility", "App session completed & counted for $packageName (duration: ${sessionDurationMs}ms). New daily count: $newCount")
        } else {
            pendingSessionCompletionMap.remove(packageName)
            sessionEnteredRealtimeMap.remove(packageName)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceBound = true
        isScreenInteractive = true

        // Enforce unbreakable system shield & foreground keeper service
        try {
            SaffahProtectionManager.applyAllSystemImmunity(this)
        } catch (e: Exception) {
            Log.e("SaffahAccessibility", "Error in applyAllSystemImmunity: ${e.message}")
        }
        try {
            val info = serviceInfo ?: android.accessibilityservice.AccessibilityServiceInfo()
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED
            info.flags = info.flags or
                    android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            info.notificationTimeout = 80L
            serviceInfo = info
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Could not set dynamic accessibility flags: ${e.message}")
        }
        SaffahLockTaskManager.updateStateAndCheck(this)
        try {
            val filter = android.content.IntentFilter().apply {
                addAction(android.content.Intent.ACTION_SCREEN_OFF)
                addAction(android.content.Intent.ACTION_SCREEN_ON)
                addAction(android.content.Intent.ACTION_POWER_CONNECTED)
                addAction(android.content.Intent.ACTION_POWER_DISCONNECTED)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(screenStateReceiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(screenStateReceiver, filter)
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Could not register screenStateReceiver: ${e.message}")
        }

        SaffahBlockRepository.registerEnforcementListener(object : SaffahBlockRepository.BlockEnforcementListener {
            override fun onAppBlockedImmediately(packageName: String, reason: String, message: String) {
                val appLabel = getAppNameFromPackage(packageName)
                triggerBlockAction(
                    blockedItem = appLabel,
                    type = reason,
                    sourceApp = appLabel,
                    userMessage = message,
                    targetPackage = packageName
                )
            }
        })

        val powerManager = getSystemService(android.content.Context.POWER_SERVICE) as? android.os.PowerManager
        isScreenInteractive = powerManager?.isInteractive ?: true

        if (isScreenInteractive) {
            val currentPkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Exception) { null }
            if (!currentPkg.isNullOrBlank() && !isTargetLauncher(currentPkg) && !isRecentsOrOverview(currentPkg, "") && !SaffahBlockRepository.isStrictUnblockableSystemPackage(this, currentPkg) && !SaffahBlockRepository.isTransientSystemComponent(this, currentPkg)) {
                activeUserSessionPackage = currentPkg
                startAppSession(currentPkg)
                packageLastLaunchIncrementRealtimeMap[currentPkg] = SystemClock.elapsedRealtime()
                SaffahBlockRepository.notifyAppForegroundChanged(this, currentPkg)
            }
            periodicCheckHandler.postDelayed(periodicCheckRunnable, 1000L)
        }
        instance = this
        scheduleNextMinuteTick()
        minuteTickHandler.post(minuteTickRunnable)
        SaffahBlockRepository.reconcileAndFixInflatedLaunchCounts(this)
        startKeeperSupervisorLoop()
        updateAiProtectionState()
        Log.i("SaffahAccessibility", "SaffahAccessibilityService connected & ready for active blocking")
    }

    private var keeperSupervisorJob: Job? = null

    private fun startKeeperSupervisorLoop() {
        keeperSupervisorJob?.cancel()
        keeperSupervisorJob = serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    if (SaffahProtectionManager.isKeeperServiceEnabled(applicationContext)) {
                        val isForeground = SaffahProtectionManager.isKeeperServiceForeground(applicationContext)
                        if (!isForeground || !com.example.service.SaffahKeeperService.isKeeperRunning.value) {
                            Log.w("SaffahAccessibility", "SaffahKeeperService missing from Active Apps / foreground (isForeground=$isForeground)! Instantly reviving...")
                            SaffahProtectionManager.startKeeperService(applicationContext)
                            com.example.service.SaffahKeeperService.ensureKeeperNotification(applicationContext)
                        }
                    }
                } catch (e: Exception) {
                    Log.w("SaffahAccessibility", "Keeper supervisor error: ${e.message}")
                }
                delay(3_000L) // 3 seconds continuous supervisor
            }
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceBound = false
        if (instance == this) instance = null
        keeperSupervisorJob?.cancel()
        periodicCheckHandler.removeCallbacks(periodicCheckRunnable)
        minuteTickHandler.removeCallbacks(minuteTickRunnable)
        try {
            unregisterReceiver(screenStateReceiver)
        } catch (e: Exception) { }

        Log.w("SaffahAccessibility", "onUnbind called by Android system! Triggering immediate auto-revival kick...")
        try {
            SaffahProtectionManager.reviveAccessibilityService(applicationContext, reason = "system_unbind")
        } catch (e: Exception) {
            Log.e("SaffahAccessibility", "Error requesting revival in onUnbind: ${e.message}")
        }

        // When Android unbinds or recycles the service, let the system
        // manage state cleanly without raising premature LockTask alarms.
        return true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !isScreenInteractive) return
        try {
            val nowRealtime = SystemClock.elapsedRealtime()

            // Ultra-fast background revival for SaffahKeeperService if stopped or killed by task removal / OEM killer
            val isKeeperForeground = SaffahProtectionManager.isKeeperServiceForeground(this)
            if ((!isKeeperForeground || !com.example.service.SaffahKeeperService.isKeeperRunning.value) &&
                SaffahProtectionManager.isKeeperServiceEnabled(this) &&
                (nowRealtime - lastKeeperRevivalCheckTimestamp > 400L)) {
                lastKeeperRevivalCheckTimestamp = nowRealtime
                Log.w("SaffahAccessibility", "SaffahKeeperService stopped/missing detected! Immediately reviving in background...")
                SaffahProtectionManager.startKeeperService(this)
                com.example.service.SaffahKeeperService.ensureKeeperNotification(this)
            } else if (SaffahProtectionManager.isKeeperServiceEnabled(this) &&
                (nowRealtime - lastKeeperNotificationHeartbeatTimestamp > 15_000L)) {
                lastKeeperNotificationHeartbeatTimestamp = nowRealtime
                com.example.service.SaffahKeeperService.ensureKeeperNotification(this)
            }

            val eventType = event.eventType
            val eventPkg = event.packageName?.toString() ?: ""

        // Completely skip empty or Saffah's own package events to eliminate any typing, scrolling, clicking, or recording lag inside Saffah
        if (eventPkg.isEmpty() || eventPkg == ownPackageName || eventPkg == "com.example" || eventPkg.startsWith("com.example.") || eventPkg.startsWith(ownPrefix)) {
            return
        }

        // Real-time zero-delay typing inspection: catch blocked keywords & websites as typed in ANY app before Enter
        if (eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            checkAndHandleTypingEvent(event, eventPkg)
            return
        }

        // Filter non-content and noisy events early to eliminate unnecessary processing
        if (eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED ||
            eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED ||
            eventType == AccessibilityEvent.TYPE_VIEW_HOVER_ENTER ||
            eventType == AccessibilityEvent.TYPE_VIEW_HOVER_EXIT ||
            eventType == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START ||
            eventType == AccessibilityEvent.TYPE_TOUCH_INTERACTION_END ||
            eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ||
            eventType == AccessibilityEvent.TYPE_ANNOUNCEMENT ||
            eventType == AccessibilityEvent.TYPE_ASSIST_READING_CONTEXT ||
            eventType == AccessibilityEvent.TYPE_GESTURE_DETECTION_START ||
            eventType == AccessibilityEvent.TYPE_GESTURE_DETECTION_END ||
            eventType == AccessibilityEvent.TYPE_TOUCH_EXPLORATION_GESTURE_START ||
            eventType == AccessibilityEvent.TYPE_TOUCH_EXPLORATION_GESTURE_END ||
            eventType == AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED ||
            eventType == AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED
        ) {
            return
        }

        // Keyboards, soft inputs, and password methods must never be processed as apps or settings
        if (SaffahBlockRepository.isInputMethodPackage(this, eventPkg)) {
            return
        }

        // Saffah's own UI: strictly skip internal UI events to prevent self-inspection loops and CPU heating
        if (eventPkg == packageName || eventPkg == "com.example") {
            return
        }

        // Multi-window / Split-screen / Floating Window transition events
        if (eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            if (SaffahBlockRepository.isAiProtectionEnabled(applicationContext)) {
                val activeApp = getActiveIncludedApp()
                if (activeApp != null) {
                    triggerImmediateAiCheckIfApplicable()
                }
            }
            return
        }

        // Floating volume panel suppression & transient charging overlay skip:
        // Automatically dismisses unwanted floating volume panels triggered by charger plug-in,
        // and avoids processing system charging/battery overlays.
        if (eventPkg == "com.oplus.volume" || eventPkg == "com.coloros.volume" || eventPkg.endsWith(".volume")) {
            if (com.example.util.SaffahChargingManager.isRecentPowerConnected()) {
                com.example.util.SaffahChargingManager.dismissFloatingVolumePanelIfNeeded(this, eventPkg)
            }
            return
        }

        if (eventPkg == "com.oplus.charging" || eventPkg == "com.coloros.charging" ||
            eventPkg == "com.oplus.battery" || eventPkg == "com.coloros.battery" ||
            eventPkg.endsWith(".charging") || eventPkg.contains(".battery")
        ) {
            return
        }

        if (nowRealtime - lastStateCheckTimestamp > 5000L) {
            lastStateCheckTimestamp = nowRealtime
            SaffahLockTaskManager.updateStateAndCheck(this)
        }

        // Completely exempt applications from all blocking, tracking, overlay, and event inspection
        if (SaffahBlockRepository.isAlwaysExemptPackage(eventPkg)) {
            return
        }

        val isSettings = (SaffahBlockRepository.isSystemSettingsPackage(this, eventPkg) ||
                SaffahBlockRepository.isSystemSettingsPackageName(eventPkg) ||
                eventPkg.endsWith(".settings") ||
                eventPkg.endsWith(".setting")) &&
                !SaffahBlockRepository.isInputMethodPackage(this, eventPkg) &&
                !eventPkg.contains("safecenter", ignoreCase = true)

        if (isSettings) {
            checkAndProtectSaffahSettings(event)
        }

        // Fast-path immediate block evaluation across all blocking systems (Permanent, Bedtime, Schedule, Usage)
        // Evaluates with 0ms delay on app launch/switch/window change, and throttles repetitive calls during active usage to eliminate frame drops
        val earlyPkg = if (eventPkg.isNotBlank()) eventPkg else ""
        if (earlyPkg.isNotBlank() && !isTargetLauncher(earlyPkg) && !SaffahBlockRepository.isStrictUnblockableSystemPackage(this, earlyPkg) && !SaffahBlockRepository.isTransientSystemComponent(this, earlyPkg)) {
            val isNewPkg = earlyPkg != lastEvaluatedPackage
            val isStateChange = eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            val isExpired = (nowRealtime - lastEvaluatedPackageTimestamp > 1000L)

            val decision = if (isNewPkg || isStateChange || isExpired) {
                val evaluated = SaffahBlockRepository.evaluateAppBlockDecision(this, earlyPkg)
                lastEvaluatedPackage = earlyPkg
                lastEvaluatedPackageTimestamp = nowRealtime
                lastEvaluatedDecision = evaluated
                evaluated
            } else {
                lastEvaluatedDecision
            }

            if (decision != null && decision.isBlocked) {
                val appLabel = getAppNameFromPackage(earlyPkg)
                val lastBlock = recentlyBlockedPackages[earlyPkg] ?: 0L
                val isDebounced = (nowRealtime - lastBlock < 800L)
                recentlyBlockedPackages[earlyPkg] = nowRealtime

                // Always evict blocked app to Home immediately!
                triggerBlockAction(
                    blockedItem = appLabel,
                    type = decision.ruleType,
                    sourceApp = appLabel,
                    userMessage = decision.userMessage,
                    targetPackage = earlyPkg,
                    suppressToast = isDebounced
                )
                return
            }
        }

        // Secondary check: If eventPkg is a transient system component (System UI, Dialog, Notification),
        // verify whether the underlying active window contains a blocked app and evict it immediately!
        // Throttled on content change to eliminate lag and frame drops on notification shade & status bar
        if (earlyPkg.isNotBlank() && SaffahBlockRepository.isTransientSystemComponent(this, earlyPkg)) {
            val isStateChange = eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            val isIntervalElapsed = (nowRealtime - lastTransientRootCheckTimestamp > 1200L)
            if (isStateChange || isIntervalElapsed) {
                lastTransientRootCheckTimestamp = nowRealtime
                val rootPkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Exception) { null }
                if (!rootPkg.isNullOrBlank() && !isTargetLauncher(rootPkg) && !SaffahBlockRepository.isStrictUnblockableSystemPackage(this, rootPkg) && !SaffahBlockRepository.isTransientSystemComponent(this, rootPkg)) {
                    val decision = SaffahBlockRepository.evaluateAppBlockDecision(this, rootPkg)
                    if (decision != null && decision.isBlocked) {
                        val appLabel = getAppNameFromPackage(rootPkg)
                        triggerBlockAction(
                            blockedItem = appLabel,
                            type = decision.ruleType,
                            sourceApp = appLabel,
                            userMessage = decision.userMessage,
                            targetPackage = rootPkg,
                            suppressToast = true
                        )
                        return
                    }
                }
            }
        }

        // High-performance filter: Throttle and filter TYPE_WINDOW_CONTENT_CHANGED to eliminate UI thread ANR freezes
        if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            // Games and camera/media capture apps use high-rate GPU surfaces; scanning window nodes on content change drops FPS
            if (isGameApp(eventPkg) || isUtilityOrMediaCaptureApp(eventPkg)) {
                return
            }

            val isBrowser = isSupportedBrowser(eventPkg)
            val isTrigger = isTriggerApp(eventPkg)
            val isSettingsApp = isSettings
            val hasKeywords = SaffahBlockRepository.getCompiledBlockedKeywords(this).isNotEmpty() &&
                    !SaffahBlockRepository.isAppExemptedFromKeywords(this, eventPkg)

            // If the app is neither a browser, a trigger app, settings, nor has active keywords to inspect, skip
            if (!isBrowser && !isTrigger && !isSettingsApp && !hasKeywords) {
                return
            }

            // Rate-limit content change events: 250ms for instant keyword detection, 400ms for media triggers
            val throttleMs = if (hasKeywords) 250L else 400L
            val lastScan = lastContentChangeScanTimestampMap[eventPkg] ?: 0L
            if (nowRealtime - lastScan < throttleMs) {
                return
            }
            lastContentChangeScanTimestampMap[eventPkg] = nowRealtime
        }

        // Inspect tree on scroll events if media reels or keyword scanning is active for this app
        if (eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            // Fast scroll in games and local utility apps (camera, gallery, dialer, clock, calculator):
            // Skip node dumps during rapid scrolling of local media or gaming to guarantee 120Hz locked smoothness
            if (isGameApp(eventPkg) || isUtilityOrMediaCaptureApp(eventPkg)) {
                return
            }

            val isMediaReelsApp = (isYouTubePackage(eventPkg) && SaffahBlockRepository.isYouTubeShortsBlocked(this)) ||
                    (isInstagramPackage(eventPkg) && SaffahBlockRepository.isInstagramReelsBlocked(this)) ||
                    (isFacebookLitePackage(eventPkg) && SaffahBlockRepository.isFacebookLiteReelsBlocked(this))
            val hasKeywords = SaffahBlockRepository.getCompiledBlockedKeywords(this).isNotEmpty() &&
                    !SaffahBlockRepository.isAppExemptedFromKeywords(this, eventPkg)

            if (!isMediaReelsApp && !hasKeywords) {
                return
            }
            val throttleMs = if (hasKeywords) 350L else 500L
            val lastScroll = lastScrollScanTimestampMap[eventPkg] ?: 0L
            if (nowRealtime - lastScroll < throttleMs) {
                return
            }
            lastScrollScanTimestampMap[eventPkg] = nowRealtime
        }

        // Track app session and launch counts on window state changes
        if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && eventPkg.isNotBlank()) {
            // Absolute Lock Task Enforcement: If penalty or urge session is active, force user into Saffah Lock Task Mode
            val isPenaltyActive = com.example.util.SaffahPenaltyManager.isPenaltyActive(this)
            val isUrgeActive = com.example.util.SaffahUrgeManager.isUrgeSessionActive(this)
            if (isPenaltyActive || isUrgeActive) {
                if (eventPkg != packageName && eventPkg != "com.example" &&
                    !SaffahBlockRepository.isTransientSystemComponent(this, eventPkg)) {
                    val reason = if (isPenaltyActive) com.example.util.SaffahLockTaskManager.LockReason.PENALTY_ACTIVE else com.example.util.SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE
                    com.example.util.SaffahLockTaskManager.launchLockTaskApp(this, reason)
                    return
                }
            }

            val eventClass = event.className?.toString() ?: ""
            if (eventClass.contains("Activity") || eventClass.contains(".")) {
                currentTopActivityName = eventClass
            }

            val isLauncher = isTargetLauncher(eventPkg)
            val isRecents = isRecentsOrOverview(eventPkg, eventClass)
            isCurrentlyInLauncher = isLauncher
            isCurrentlyInRecents = isRecents

            if (isLauncher || isRecents) {
                currentTopActivityName = ""
                val prev = activeUserSessionPackage
                if (prev != null) {
                    completeAppSession(prev)
                    activeUserSessionPackage = null
                    SaffahBlockRepository.notifyAppForegroundChanged(this, "")
                }
            } else if (SaffahBlockRepository.isTransientSystemComponent(this, eventPkg) || SaffahBlockRepository.isStrictUnblockableSystemPackage(this, eventPkg)) {
                // Transient component (Keyboards, System UI notifications, Permission dialogs, Screenshot, Autofill) - Keep active user session intact
            } else {
                isCurrentlyInLauncher = false
                isCurrentlyInRecents = false
                if (eventPkg != activeUserSessionPackage) {
                    val prev = activeUserSessionPackage
                    if (prev != null) {
                        completeAppSession(prev)
                    }
                    activeUserSessionPackage = eventPkg
                    SaffahNudeNetClassifier.clearHistory()
                    SaffahAnimeClassifier.clearHistory()

                    if (SaffahBlockRepository.isAiProtectionEnabled(applicationContext) &&
                        SaffahBlockRepository.getAiProtectionIncludedApps(applicationContext).contains(eventPkg)) {
                        triggerImmediateAiCheckIfApplicable()
                    }

                    if (isSettings) {
                        SaffahBlockRepository.notifyAppForegroundChanged(this, "")
                    } else {
                        // Check if newly entered app is already blocked by usage/schedule/bedtime limits
                        val decision = SaffahBlockRepository.evaluateAppBlockDecision(this, eventPkg)
                        if (decision != null && decision.isBlocked) {
                            val appLabel = getAppNameFromPackage(eventPkg)
                            recentlyBlockedPackages[eventPkg] = nowRealtime
                            triggerBlockAction(
                                blockedItem = appLabel,
                                type = decision.ruleType,
                                sourceApp = appLabel,
                                userMessage = decision.userMessage,
                                targetPackage = eventPkg
                            )
                            activeUserSessionPackage = null
                            return
                        }

                        startAppSession(eventPkg)
                        SaffahBlockRepository.notifyAppForegroundChanged(this, eventPkg)
                    }
                } else if (!isSettings) {
                    SaffahBlockRepository.notifyAppForegroundChanged(this, eventPkg)
                }
            }
        }

        // Skip scanning if the event comes directly from a launcher or system app
        if (isLauncherOrSystemApp(eventPkg)) {
            return
        }

        // Check if user entered an unsupported browser (when feature is enabled)
        if (SaffahBlockRepository.isBlockUnsupportedBrowsers(this)) {
            if (eventPkg.isNotBlank() && isUnsupportedBrowser(eventPkg)) {
                val appLabel = getAppNameFromPackage(eventPkg)
                triggerBlockAction(
                    blockedItem = appLabel,
                    type = "متصفح غير مدعوم",
                    sourceApp = appLabel,
                    userMessage = "تم حظر المتصفح ($appLabel) لأنه غير مدعوم لحمايتك",
                    targetPackage = eventPkg
                )
                return
            }
        }

        // Fast early check for In-App Browser & Custom Tab activities
        if (SaffahBlockRepository.isBlockInAppBrowsers(this)) {
            if (eventPkg.isNotBlank()) {
                val eventClass = event.className?.toString() ?: ""
                val activeClass = if (eventClass.isNotBlank()) eventClass else currentTopActivityName
                val isSupported = isSupportedBrowser(eventPkg)
                val isCustomTab = isCustomTabActivity(activeClass)
                val isKnownInApp = isKnownInAppBrowserActivity(activeClass, eventPkg)

                // User rule: Do NOT block Custom Tabs for a supported browser!
                val isBlockedCustomTab = isCustomTab && !isSupported
                val isBlockedInApp = isKnownInApp && !isSupported

                if (isBlockedCustomTab || isBlockedInApp) {
                    val appLabel = getAppNameFromPackage(eventPkg)
                    val blockedItem = if (isBlockedCustomTab) "Custom Tab غير مدعوم ($appLabel)" else "المتصفح المدمج ($appLabel)"
                    dismissInAppBrowser(
                        sourcePackage = eventPkg,
                        sourceAppName = appLabel,
                        blockedItem = blockedItem,
                        rootNode = null
                    )
                    return
                }
            }
        }

        // Guard against unnecessary rootInActiveWindow IPC calls
        val isBrowserApp = isSupportedBrowser(eventPkg)
        val isTriggerApp = when {
            isTelegramPackage(eventPkg) -> SaffahBlockRepository.isTelegramSearchBlocked(this)
            isWhatsAppPackage(eventPkg) -> SaffahBlockRepository.isWhatsAppChannelsBlocked(this)
            isYouTubePackage(eventPkg) -> SaffahBlockRepository.isYouTubeShortsBlocked(this)
            isFacebookLitePackage(eventPkg) -> SaffahBlockRepository.isFacebookLiteReelsBlocked(this)
            isInstagramPackage(eventPkg) -> SaffahBlockRepository.isInstagramReelsBlocked(this)
            else -> false
        }
        val isInAppBrowserCheck = !isBrowserApp && SaffahBlockRepository.isBlockInAppBrowsers(this)
        val isKeywordScanNeeded = !SaffahBlockRepository.isAppExemptedFromKeywords(this, eventPkg) &&
                SaffahBlockRepository.getCompiledBlockedKeywords(this).isNotEmpty()

        if (isGameApp(eventPkg)) {
            // Ultra gaming performance optimization:
            // Games render 2D/3D frames via native SurfaceView/Vulkan/OpenGL and do not host browser tabs or webviews.
            // Skipping rootInActiveWindow IPC dumps during active gameplay eliminates 1% low FPS drops, micro-stutters, and touch latency,
            // while preserving 100% app-level blocking, usage time limits, bedtime, schedule, and DNS VPN protection.
            return
        }

        if (!isTriggerApp && !isInAppBrowserCheck && !isBrowserApp && !isKeywordScanNeeded) {
            return
        }

        val rootNode = try { rootInActiveWindow } catch (e: Exception) { null } ?: return
        try {
            val rootPkg = try { rootNode.packageName?.toString() ?: "" } catch (e: Exception) { "" }
            if (rootPkg == ownPackageName || rootPkg.startsWith("com.example")) {
                return
            }

            if (SaffahBlockRepository.isBlockUnsupportedBrowsers(this)) {
                if (rootPkg.isNotBlank() && isUnsupportedBrowser(rootPkg)) {
                    val appLabel = getAppNameFromPackage(rootPkg)
                    triggerBlockAction(
                        blockedItem = appLabel,
                        type = "متصفح غير مدعوم",
                        sourceApp = appLabel,
                        userMessage = "تم حظر المتصفح ($appLabel) لأنه غير مدعوم لحمايتك"
                    )
                    return
                }
            }

            // Check In-App Browser & WebView blocking (حظر المتصفح داخل التطبيق)
            if (SaffahBlockRepository.isBlockInAppBrowsers(this)) {
                val effectivePkg = if (eventPkg.isNotBlank()) eventPkg else rootPkg
                val eventClass = event.className?.toString() ?: ""
                val activeClass = if (eventClass.isNotBlank()) eventClass else currentTopActivityName
                val eventSource = try { event.source } catch (e: Exception) { null }
                if (isInAppBrowserOrCustomTab(effectivePkg, activeClass, rootNode, eventSource, rootPkg)) {
                    val appLabel = getAppNameFromPackage(effectivePkg)
                    val isCustomTab = isCustomTabActivity(activeClass) || hasCustomTabUi(rootNode)
                    val blockedItem = if (isCustomTab) "Custom Tab غير مدعوم ($appLabel)" else "المتصفح المدمج ($appLabel)"
                    dismissInAppBrowser(
                        sourcePackage = effectivePkg,
                        sourceAppName = appLabel,
                        blockedItem = blockedItem,
                        rootNode = rootNode
                    )
                    return
                }
            }

            // Check social media trigger blocking (Shorts, Reels, Channels, Search)
            val targetAppPkg = if (eventPkg.isNotBlank()) eventPkg else rootPkg
            when {
                (isTelegramPackage(eventPkg) || isTelegramPackage(rootPkg)) && SaffahBlockRepository.isTelegramSearchBlocked(this) -> {
                    if (isTelegramGlobalSearch(rootNode)) {
                        triggerBlockAction(
                            blockedItem = "البحث العام في تلغرام",
                            type = "حظر المحفزات",
                            sourceApp = "Telegram",
                            userMessage = "تم حظر البحث العام في تلغرام لمنع المحفزات",
                            targetPackage = targetAppPkg
                        )
                        return
                    }
                }
                (isWhatsAppPackage(eventPkg) || isWhatsAppPackage(rootPkg)) && SaffahBlockRepository.isWhatsAppChannelsBlocked(this) -> {
                    if (isWhatsAppChannelSearchOrDirectory(rootNode)) {
                        triggerBlockAction(
                            blockedItem = "استكشاف وقنوات واتساب",
                            type = "حظر المحفزات",
                            sourceApp = "WhatsApp",
                            userMessage = "تم حظر البحث واستكشاف قنوات واتساب لمنع المحفزات",
                            targetPackage = targetAppPkg
                        )
                        return
                    }
                }
                (isYouTubePackage(eventPkg) || isYouTubePackage(rootPkg)) && SaffahBlockRepository.isYouTubeShortsBlocked(this) -> {
                    if (isYouTubeShortsActive(rootNode)) {
                        triggerBlockAction(
                            blockedItem = "شورتس يوتيوب (YouTube Shorts)",
                            type = "حظر المحفزات",
                            sourceApp = "YouTube",
                            userMessage = "تم حظر شورتس يوتيوب لمنع المحفزات والإلهاء",
                            targetPackage = targetAppPkg
                        )
                        return
                    }
                }
                (isFacebookLitePackage(eventPkg) || isFacebookLitePackage(rootPkg)) && SaffahBlockRepository.isFacebookLiteReelsBlocked(this) -> {
                    if (isFacebookLiteReelsActive(rootNode)) {
                        triggerBlockAction(
                            blockedItem = "مقاطع ريلز فيسبوك لايت (FB Lite Reels)",
                            type = "حظر المحفزات",
                            sourceApp = "Facebook Lite",
                            userMessage = "تم حظر مقاطع ريلز Facebook Lite للحفاظ على تركيزك",
                            targetPackage = targetAppPkg
                        )
                        return
                    }
                }
                (isInstagramPackage(eventPkg) || isInstagramPackage(rootPkg)) && SaffahBlockRepository.isInstagramReelsBlocked(this) -> {
                    if (isInstagramReelsActive(rootNode)) {
                        triggerBlockAction(
                            blockedItem = "مقاطع انستغرام ريلز (Instagram Reels)",
                            type = "حظر المحفزات",
                            sourceApp = "Instagram",
                            userMessage = "تم حظر مقاطع Instagram Reels للحفاظ على تركيزك",
                            targetPackage = targetAppPkg
                        )
                        return
                    }
                }
            }

            if (eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && !isSupportedBrowser(eventPkg) && !isKeywordScanNeeded) {
                // Non-browser scrolling events do not alter URLs or require full tree scans
                return
            }

            if (isBrowserApp || isKeywordScanNeeded) {
                inspectNodeHierarchy(rootNode, eventPkg)
            }
        } catch (e: Exception) {
            Log.e("SaffahAccessibility", "Error during node hierarchy inspection: ${e.message}")
        }
        } catch (t: Throwable) {
            Log.e("SaffahAccessibility", "Safety net: Caught unexpected error in onAccessibilityEvent: ${t.message}", t)
        }
    }

    /**
     * Real-time zero-delay typing inspection.
     * Evaluates typed text against blocked keywords (universally in all apps)
     * and blocked websites (in browsers) as each character is typed, before Enter or search is ever pressed.
     */
    private fun checkAndHandleTypingEvent(event: AccessibilityEvent, eventPkg: String) {
        val ownPackageName = applicationContext.packageName
        if (eventPkg == ownPackageName || eventPkg.startsWith("com.example")) return
        if (SaffahBlockRepository.isAlwaysExemptPackage(eventPkg)) return

        // Skip passwords to protect user security
        if (event.isPassword) return
        val sourceNode = try { event.source } catch (_: Exception) { null }
        if (sourceNode?.isPassword == true) return
        val className = (event.className ?: sourceNode?.className)?.toString() ?: ""
        if (className.contains("Password", ignoreCase = true)) return

        val compiledKeywords = SaffahBlockRepository.getCompiledBlockedKeywords(this)
        val compiledSites = SaffahBlockRepository.getCompiledBlockedSites(this)
        if (compiledKeywords.isEmpty() && compiledSites.isEmpty()) return

        // Resolve real application package even if IME/keyboard fired the event
        val effectivePkg = if (SaffahBlockRepository.isInputMethodPackage(this, eventPkg)) {
            val sourcePkg = sourceNode?.packageName?.toString()
            if (!sourcePkg.isNullOrBlank() && !SaffahBlockRepository.isInputMethodPackage(this, sourcePkg)) {
                sourcePkg
            } else {
                activeUserSessionPackage ?: eventPkg
            }
        } else {
            eventPkg
        }

        if (effectivePkg == ownPackageName || SaffahBlockRepository.isAlwaysExemptPackage(effectivePkg)) return

        val isKeywordExempt = SaffahBlockRepository.isAppExemptedFromKeywords(this, effectivePkg)
        val isBrowser = isSupportedBrowser(effectivePkg) || isBrowserAppPackage(effectivePkg)

        fun inspectCandidate(candidate: CharSequence?): Boolean {
            if (candidate.isNullOrBlank()) return false
            // 1. Real-time Keyword Blocking: Enforced universally across ALL apps
            if (!isKeywordExempt && compiledKeywords.isNotEmpty()) {
                val matchedKeyword = SaffahBlockRepository.findMatchedBlockedKeywordFast(candidate, compiledKeywords)
                if (matchedKeyword != null) {
                    val appLabel = getAppNameFromPackage(effectivePkg)
                    triggerBlockAction(
                        blockedItem = matchedKeyword,
                        type = "كلمة محظورة",
                        sourceApp = appLabel,
                        userMessage = "تم حظر المحتوى لاحتوائه على كلمة محظورة: $matchedKeyword",
                        targetPackage = effectivePkg
                    )
                    return true
                }
            }

            // 2. Real-time Website Blocking in Browsers (intercept typing domain before Enter)
            if (isBrowser && compiledSites.isNotEmpty()) {
                val matchedSite = SaffahBlockRepository.findMatchedBlockedSiteFast(candidate.toString(), compiledSites)
                if (matchedSite != null) {
                    val appLabel = getAppNameFromPackage(effectivePkg)
                    triggerBlockAction(
                        blockedItem = matchedSite,
                        type = "موقع محظور",
                        sourceApp = appLabel,
                        userMessage = "تم حظر فتح الموقع المحظور: $matchedSite",
                        targetPackage = effectivePkg
                    )
                    return true
                }
            }
            return false
        }

        // Zero-allocation direct inspection on typing event stream
        for (item in event.text) {
            if (inspectCandidate(item)) return
        }
        if (inspectCandidate(sourceNode?.text)) return
        if (inspectCandidate(sourceNode?.contentDescription)) return
    }

    private fun inspectNodeHierarchy(rootNode: AccessibilityNodeInfo, packageName: String) {
        val compiledKeywords = SaffahBlockRepository.getCompiledBlockedKeywords(this)
        val compiledSites = SaffahBlockRepository.getCompiledBlockedSites(this)

        if (compiledKeywords.isEmpty() && compiledSites.isEmpty()) return

        val nodeRootPkg = rootNode.packageName?.toString() ?: ""
        val effectivePkg = if (packageName.isNotBlank()) packageName else nodeRootPkg
        fun getEffectiveAppLabel(pkg: String = effectivePkg): String = getAppNameFromPackage(pkg)
        val isBrowserApp = isSupportedBrowser(effectivePkg) || (nodeRootPkg.isNotBlank() && isSupportedBrowser(nodeRootPkg))
        val isKeywordExemptForApp = SaffahBlockRepository.isAppExemptedFromKeywords(this, effectivePkg)

        // Performance guard: Sites only apply to web browsers! If no keywords are active, skip non-browsers immediately!
        if (compiledKeywords.isEmpty() && !isBrowserApp) {
            return
        }

        // If app is exempt from keyword scanning and not a browser, skip immediately!
        if (isKeywordExemptForApp && !isBrowserApp) {
            return
        }

        val nodesToProcess = reusableHierarchyNodesQueue
        nodesToProcess.clear()
        nodesToProcess.add(rootNode)

        var nodesExamined = 0
        val maxNodes = 60 // Streamlined cap covering full visible screen hierarchy in milliseconds
        var urlBarChecked = false

        val ownPackageName = applicationContext.packageName

        try {
            while (nodesToProcess.isNotEmpty() && nodesExamined < maxNodes) {
                val node = nodesToProcess.removeFirst()
                nodesExamined++

                val nodePkg = node.packageName?.toString() ?: ""
                if (nodePkg == ownPackageName || nodePkg.startsWith("com.example") || SaffahBlockRepository.isInputMethodPackage(this, nodePkg)) {
                    continue
                }

                // Never inspect passwords or secure inputs to preserve security and avoid OEM security interference
                if (node.isPassword) {
                    continue
                }

                val textCandidate = node.text
                val descCandidate = node.contentDescription
                if (textCandidate.isNullOrBlank() && descCandidate.isNullOrBlank()) {
                    for (i in 0 until node.safeChildCount) {
                        val child = node.safeGetChild(i)
                        if (child != null) nodesToProcess.add(child)
                    }
                    continue
                }

                // 1. CHECK WEBSITE BLOCKING (STRICT RULE: ONLY IN BROWSER URL / ADDRESS BAR)
                // Blocked websites are strictly evaluated on the browser's URL/Address bar input, never on page text or search results
                if (isBrowserApp && compiledSites.isNotEmpty()) {
                    val viewId = node.viewIdResourceName?.lowercase() ?: ""
                    val className = node.className?.toString() ?: ""
                    val isEditable = node.isEditable || className.contains("EditText") || className.contains("AutoCompleteTextView")
                    val isUrlBarNode = isUrlBar(node, viewId, className, isEditable, isBrowserApp)

                    val textStr = textCandidate?.toString()?.trim() ?: ""
                    val descStr = descCandidate?.toString()?.trim() ?: ""

                    // Detect URL / domain pattern for Quetta and all supported browsers
                    val isUrlPattern = textStr.isNotEmpty() && !textStr.contains(" ") && (
                        textStr.startsWith("http://", ignoreCase = true) ||
                        textStr.startsWith("https://", ignoreCase = true) ||
                        textStr.startsWith("www.", ignoreCase = true) ||
                        (textStr.contains(".") && textStr.length in 4..120 && !textStr.endsWith("."))
                    )

                    if (isUrlBarNode || (isUrlPattern && !className.contains("WebView", ignoreCase = true))) {
                        if (textStr.isNotEmpty()) {
                            val matchedSite = SaffahBlockRepository.findMatchedBlockedSiteFast(textStr, compiledSites)
                            if (matchedSite != null) {
                                triggerBlockAction(
                                    blockedItem = matchedSite,
                                    type = "موقع محظور",
                                    sourceApp = getEffectiveAppLabel(),
                                    userMessage = "تم حظر فتح الموقع المحظور: $matchedSite",
                                    targetPackage = effectivePkg
                                )
                                return
                            }
                        }
                        if (descStr.isNotEmpty() && descStr != textStr) {
                            val matchedSite = SaffahBlockRepository.findMatchedBlockedSiteFast(descStr, compiledSites)
                            if (matchedSite != null) {
                                triggerBlockAction(
                                    blockedItem = matchedSite,
                                    type = "موقع محظور",
                                    sourceApp = getEffectiveAppLabel(),
                                    userMessage = "تم حظر فتح الموقع المحظور: $matchedSite",
                                    targetPackage = effectivePkg
                                )
                                return
                            }
                        }
                    }
                }

                // 2. CHECK KEYWORD BLOCKING (ANYWHERE ON SCREEN OR IN INPUT ACROSS ALL APPS)
                if (!isKeywordExemptForApp && compiledKeywords.isNotEmpty()) {
                    val nodePkgExempt = nodePkg.isNotBlank() && SaffahBlockRepository.isAppExemptedFromKeywords(this, nodePkg)
                    if (!nodePkgExempt) {
                        val targetAppPkg = if (nodePkg.isNotBlank() && nodePkg != ownPackageName) nodePkg else effectivePkg
                        if (!textCandidate.isNullOrBlank()) {
                            val matchedKeyword = SaffahBlockRepository.findMatchedBlockedKeywordFast(textCandidate, compiledKeywords)
                            if (matchedKeyword != null) {
                                triggerBlockAction(
                                    blockedItem = matchedKeyword,
                                    type = "كلمة محظورة",
                                    sourceApp = getEffectiveAppLabel(targetAppPkg),
                                    userMessage = "تم حظر المحتوى لاحتوائه على كلمة محظورة: $matchedKeyword",
                                    targetPackage = targetAppPkg
                                )
                                return
                            }
                        }
                        if (!descCandidate.isNullOrBlank()) {
                            val matchedKeyword = SaffahBlockRepository.findMatchedBlockedKeywordFast(descCandidate, compiledKeywords)
                            if (matchedKeyword != null) {
                                triggerBlockAction(
                                    blockedItem = matchedKeyword,
                                    type = "كلمة محظورة",
                                    sourceApp = getEffectiveAppLabel(targetAppPkg),
                                    userMessage = "تم حظر المحتوى لاحتوائه على كلمة محظورة: $matchedKeyword",
                                    targetPackage = targetAppPkg
                                )
                                return
                            }
                        }
                    }
                }

                // Add children to queue
                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) {
                        nodesToProcess.add(child)
                    }
                }
            }
        } finally {
            nodesToProcess.clear()
        }
    }

    /**
     * Determines whether a node is strictly the Browser's URL / Address Bar.
     * Excludes web page content, search results, in-page links, articles, and non-browser apps.
     */
    private fun isUrlBar(
        node: AccessibilityNodeInfo,
        viewId: String,
        className: String,
        isEditable: Boolean,
        isBrowserApp: Boolean
    ): Boolean {
        // STRICT RULE: Non-browser apps NEVER contain a browser URL bar.
        if (!isBrowserApp) {
            return false
        }

        // Exclude web page views and inner HTML elements
        if (className.contains("WebView", ignoreCase = true) ||
            className.contains("ChromiumWebView", ignoreCase = true) ||
            className.contains("WebSettings", ignoreCase = true)
        ) {
            return false
        }

        val lowerViewId = viewId.lowercase()
        val idName = if (lowerViewId.contains(":id/")) lowerViewId.substringAfter(":id/") else lowerViewId

        // 1. Precise resource IDs of URL bar / Omnibox in Android browsers & Custom Tabs
        if (idName.contains("url_bar") ||
            idName.contains("location_bar") ||
            idName.contains("omnibox") ||
            idName.contains("url_field") ||
            idName.contains("toolbar_url") ||
            idName.contains("address_bar") ||
            idName.contains("display_url") ||
            idName.contains("custom_tab_domain") ||
            idName.contains("custom_tab_title") ||
            idName.contains("search_src_text") ||
            idName.contains("search_box_text") ||
            idName.contains("search_box") ||
            idName.contains("search_bar") ||
            idName.contains("search_text") ||
            idName.contains("search_edit") ||
            idName.contains("url_edit") ||
            idName.contains("tv_url") ||
            idName.contains("tv_title") ||
            idName.contains("toolbar_title") ||
            idName.contains("omnibar") ||
            idName == "url" ||
            idName == "address" ||
            idName == "search" ||
            idName == "domain" ||
            idName.endsWith("_url") ||
            idName.endsWith("_address") ||
            (idName.contains("custom_tab") && (idName.contains("title") || idName.contains("url")))
        ) {
            return true
        }

        // 2. Active address bar input field in browser toolbar (outside WebView)
        if (isEditable && (className.contains("EditText") || className.contains("AutoCompleteTextView"))) {
            if (!idName.contains("web") && !idName.contains("content") && !idName.contains("body") && !idName.contains("article")) {
                return true
            }
        }

        return false
    }

    private fun triggerBlockAction(
        blockedItem: String,
        type: String,
        sourceApp: String,
        userMessage: String,
        targetPackage: String? = null,
        suppressToast: Boolean = false
    ) {
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            periodicCheckHandler.post {
                triggerBlockAction(blockedItem, type, sourceApp, userMessage, targetPackage, suppressToast)
            }
            return
        }

        val now = SystemClock.elapsedRealtime()
        val pkg = targetPackage?.trim()?.lowercase() ?: ""

        // 1. Immediate State Quarantine:
        // Reset all active foreground session trackers immediately so no other component,
        // watchdog, or background worker thinks the blocked app is still running.
        activeUserSessionPackage = null
        currentTopActivityName = ""
        if (pkg.isNotBlank()) {
            pendingSessionCompletionMap.remove(pkg)
            sessionEnteredRealtimeMap.remove(pkg)
            packageLastExitRealtimeMap[pkg] = now
            recentlyBlockedPackages[pkg] = now
        }
        SaffahBlockRepository.notifyAppForegroundChanged(this, "")
        SaffahBlockRepository.clearActiveForegroundPackage()

        // 2. Kill background processes safely
        if (pkg.isNotBlank() && !SaffahBlockRepository.isStrictUnblockableSystemPackage(this, pkg)) {
            SaffahBlockRepository.applySinglePackageSuspension(this, pkg, true)
            try {
                val am = getSystemService(ACTIVITY_SERVICE) as? android.app.ActivityManager
                am?.killBackgroundProcesses(pkg)
            } catch (_: Exception) {}
        }

        // 3. Multi-layer immediate eviction intervention:
        // Always trigger physical Home and Back navigation immediately without throttling
        lastGlobalBlockActionRealtime = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        performGlobalAction(GLOBAL_ACTION_BACK)

        // Direct Home launcher intent to guarantee task switch even if OS gesture was dropped
        lastHomeIntentRealtime = now
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
            }
            startActivity(homeIntent)
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error starting home intent: ${e.message}")
        }

        // 4. Secondary eviction verification:
        // If rapid tapping on ColorOS/Realme keeps the activity alive across transition, kick again after 100ms
        if (pkg.isNotBlank()) {
            periodicCheckHandler.postDelayed({
                try {
                    val currentTop = try { rootInActiveWindow?.packageName?.toString() } catch (_: Exception) { null }
                    if (currentTop != null && currentTop.equals(pkg, ignoreCase = true)) {
                        performGlobalAction(GLOBAL_ACTION_HOME)
                        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_HOME)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        startActivity(homeIntent)
                    }
                } catch (_: Exception) {}
            }, 100L)
        }

        val isDuplicate = (blockedItem == lastBlockedItem && (now - lastBlockTimestamp) < DEBOUNCE_MS)

        if (!isDuplicate && !suppressToast) {
            lastBlockedItem = blockedItem
            lastBlockTimestamp = now

            // 1. Trigger Penalty Overlay immediately if enabled & occurrence threshold met:
            // - Blocked Keyword: 1st & 2nd time today -> standard block without penalty screen. 3rd time today -> triggers locked penalty screen!
            // - Blocked Website: 1st time today -> standard block without penalty screen. 2nd time today -> triggers locked penalty screen immediately!
            val isSite = (type == "موقع محظور" || type.contains("موقع"))
            val isKeyword = (type == "كلمة محظورة" || type.contains("كلمة"))
            val isKeywordOrSiteBlock = isSite || isKeyword

            if (isKeywordOrSiteBlock && com.example.util.SaffahPenaltyManager.isPenaltyFeatureEnabled(this)) {
                val shouldTriggerPenalty = com.example.util.SaffahPenaltyManager.recordAndCheckShouldTriggerPenalty(
                    context = this,
                    isWebsite = isSite,
                    rawBlockedItem = blockedItem
                )
                if (shouldTriggerPenalty) {
                    val pkgForPenalty = targetPackage ?: sourceApp
                    com.example.util.SaffahPenaltyManager.startPenalty(
                        context = this,
                        reason = "$type: $blockedItem",
                        blockedItem = blockedItem,
                        blockType = type,
                        sourcePackage = pkgForPenalty,
                        sourceAppName = sourceApp
                    )
                } else {
                    val count = com.example.util.SaffahPenaltyManager.getItemDailyCount(this, isSite, blockedItem)
                    val warningMessage = if (!isSite) {
                        "تم رصد الكلمة المحظورة (المرة $count من 3 اليوم) - تم الحظر، وسيتم قفل شاشة العقوبة عند المرة الثالثة"
                    } else {
                        "تم رصد الموقع المحظور (المرة $count من 2 اليوم) - تم الحظر، وسيتم قفل شاشة العقوبة عند المرة الثانية"
                    }
                    showBlockedToast(warningMessage)
                }
            } else {
                // Show user toast
                showBlockedToast(userMessage)
            }

            // Offload heavy DPM suspension synchronization to background IO with throttling
            if (now - lastPackageSuspensionSyncRealtime >= 5000L) {
                lastPackageSuspensionSyncRealtime = now
                serviceScope.launch(Dispatchers.IO) {
                    try {
                        SaffahBlockRepository.syncAllPackageSuspensions(this@SaffahAccessibilityService)
                    } catch (e: Exception) {
                        Log.w("SaffahAccessibility", "Error syncing package suspensions: ${e.message}")
                    }
                }
            }

            // Afterwards: Log block event on background thread
            serviceScope.launch(Dispatchers.IO) {
                try {
                    val appSourceIdentifier = targetPackage?.takeIf { it.isNotBlank() } ?: sourceApp
                    SaffahBlockRepository.addBlockLog(this@SaffahAccessibilityService, blockedItem, type, appSourceIdentifier)
                } catch (_: Exception) {}
            }

            // Immediately trigger real-time notification if blocked by usage limits
            if (type == "حد الاستخدام اليومي" || type == "سقف مرات الفتح" || type.contains("استخدام") || type.contains("فتح")) {
                val pkgToNotify = targetPackage ?: sourceApp
                if (pkgToNotify.isNotBlank()) {
                    com.example.util.SaffahNotificationManager.notifyAppBlockedByUsageImmediately(this, pkgToNotify)
                }
            }
        }
    }

    private fun showBlockedToast(message: String) {
        val now = System.currentTimeMillis()
        if (now - lastToastTime > 2000) {
            lastToastTime = now
            periodicCheckHandler.post {
                try {
                    Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
                } catch (_: Exception) {}
            }
        }
    }

    private val appLabelCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    private fun getAppNameFromPackage(packageName: String): String {
        if (packageName.isBlank()) return ""
        appLabelCache[packageName]?.let { return it }
        val label = try {
            val pm = applicationContext.packageManager
            val appInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }
        appLabelCache[packageName] = label
        return label
    }

    private var lastSettingsProtectionCheckTime = 0L

    /**
     * Anti-tamper protection for Saffah within System Settings.
     * Continuously guarantees Accessibility service remains enabled.
     * Auto-dismisses confirmation dialogs attempting to stop or disable Saffah.
     * Guarantees immunity against battery saver restrictions, app freeze, and force stop.
     */
    private fun checkAndProtectSaffahSettings(event: AccessibilityEvent) {
        val eventPkg = event.packageName?.toString() ?: ""
        if (!SaffahBlockRepository.isSystemSettingsPackage(this, eventPkg) &&
            !SaffahBlockRepository.isSystemSettingsPackageName(eventPkg)
        ) {
            return
        }

        val eventType = event.eventType
        // Inspect window state changes, user interactions, or content modifications
        if (eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            eventType != AccessibilityEvent.TYPE_VIEW_CLICKED &&
            eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            return
        }

        val now = SystemClock.elapsedRealtime()
        if (eventType != AccessibilityEvent.TYPE_VIEW_CLICKED && now - lastSettingsProtectionCheckTime < 600L) return
        lastSettingsProtectionCheckTime = now

        // Immediate click defense: If user clicked Clear Data / Force Stop on Saffah or Alramy
        if (eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val clickedText = event.text?.joinToString(" ")?.lowercase() ?: ""
            val clickedDesc = event.contentDescription?.toString()?.lowercase() ?: ""
            val clickedCombined = "$clickedText $clickedDesc"
            if (clickedCombined.contains("مسح البيانات") || clickedCombined.contains("clear data") ||
                clickedCombined.contains("مسح مساحة التخزين") || clickedCombined.contains("clear storage") ||
                clickedCombined.contains("فرض الإيقاف") || clickedCombined.contains("force stop") ||
                clickedCombined.contains("حذف البيانات") || clickedCombined.contains("delete data")
            ) {
                val root = rootInActiveWindow
                if (root != null) {
                    var isProtected = false
                    val testQueue = ArrayDeque<AccessibilityNodeInfo>()
                    testQueue.add(root)
                    var c = 0
                    while (testQueue.isNotEmpty() && c < 50) {
                        val n = testQueue.removeFirst()
                        c++
                        val t = (n.text?.toString() ?: "").lowercase()
                        val d = (n.contentDescription?.toString() ?: "").lowercase()
                        val comb = "$t $d"
                        if (comb.contains("السفاح") || comb.contains("saffah") || comb.contains(packageName)) {
                            isProtected = true
                            break
                        }
                        for (i in 0 until n.safeChildCount) {
                            val ch = n.safeGetChild(i)
                            if (ch != null) testQueue.add(ch)
                        }
                    }
                    if (isProtected) {
                        performGlobalAction(GLOBAL_ACTION_BACK)
                        return
                    }
                }
            }
        }
        try {
            val root = rootInActiveWindow ?: return

            val queue = reusableMediaCheckNodesQueue
            queue.clear()
            queue.add(root)
            var count = 0

            var isSaffahScreen = false
            var cancelNode: AccessibilityNodeInfo? = null
            var hasForceStopOrDangerousAction = false
            var unrestrictedNode: AccessibilityNodeInfo? = null
            var restrictedNodeIsChecked = false
            var backgroundActivitySwitchOff: AccessibilityNodeInfo? = null
            var autoLaunchSwitchOff: AccessibilityNodeInfo? = null
            var autoFreezeSwitchOn: AccessibilityNodeInfo? = null

            while (queue.isNotEmpty() && count < 80) {
                val node = queue.removeFirst()
                count++

                val text = (node.text?.toString() ?: "").trim()
                val desc = (node.contentDescription?.toString() ?: "").trim()
                val combined = if (desc.isNotEmpty()) "$text $desc".lowercase() else text.lowercase()

                if (!isSaffahScreen) {
                    if (combined.contains("السفاح") || combined.contains("saffah") || combined.contains(packageName)) {
                        isSaffahScreen = true
                    }
                }

                // Check for cancel / dismiss buttons
                if (cancelNode == null) {
                    if (combined == "إلغاء" || combined == "cancel" || combined.contains("إلغاء") || combined == "close" || combined == "تراجع") {
                        if (node.isClickable || node.parent?.isClickable == true) {
                            cancelNode = node
                        }
                    }
                }

                // Check for dangerous prompts: Force Stop, Freeze, Clear Data
                if (combined.contains("فرض الإيقاف") || combined.contains("force stop") ||
                    combined == "إيقاف" || combined == "stop" ||
                    combined.contains("تجميد") || combined.contains("السكون العميق") || combined.contains("وضع السكون") ||
                    combined.contains("deep sleep") || combined.contains("app freeze") ||
                    combined.contains("مسح البيانات") || combined.contains("مسح مساحة التخزين") ||
                    combined.contains("clear data") || combined.contains("clear storage")
                ) {
                    hasForceStopOrDangerousAction = true
                }

                // Check for Allow Background Activity switch (Realme UI / ColorOS / Samsung / Xiaomi)
                if (combined.contains("نشاط في الخلفية") || combined.contains("background activity") || combined.contains("السماح بالبدء في الخلفية")) {
                    val targetSwitch = findSwitchNode(node)
                    if (targetSwitch != null && !targetSwitch.isChecked) {
                        backgroundActivitySwitchOff = targetSwitch
                    }
                }

                // Check for Auto-Launch switch
                if (combined.contains("بدء التشغيل التلقائي") || combined.contains("auto-launch") || combined.contains("تشغيل تلقائي") || combined.contains("auto start")) {
                    val targetSwitch = findSwitchNode(node)
                    if (targetSwitch != null && !targetSwitch.isChecked) {
                        autoLaunchSwitchOff = targetSwitch
                    }
                }

                // Check for Auto-Freeze / Quick Freeze switch
                if (combined.contains("تجميد تلقائي") || combined.contains("تجميد التطبيق") || combined.contains("quick freeze") || combined.contains("auto freeze")) {
                    val targetSwitch = findSwitchNode(node)
                    if (targetSwitch != null && targetSwitch.isChecked) {
                        autoFreezeSwitchOn = targetSwitch
                    }
                }

                // Check for battery optimization nodes
                if (combined.contains("غير مقيد") || combined.contains("لا توجد قيود") || combined.contains("بدون قيود") ||
                    combined.contains("unrestricted") || combined.contains("don't optimize") || combined.contains("عدم التحسين") ||
                    combined.contains("بلا قيود")
                ) {
                    unrestrictedNode = node
                }

                if ((combined.contains("مقيد") || combined.contains("restricted") || combined.contains("توفير البطارية") || combined.contains("battery saver")) &&
                    !combined.contains("غير") && !combined.contains("unrestricted") && !combined.contains("لا توجد") && !combined.contains("بدون")
                ) {
                    val checkNode = findCheckableNode(node)
                    if (checkNode != null && checkNode.isChecked) {
                        restrictedNodeIsChecked = true
                    } else if (node.isChecked) {
                        restrictedNodeIsChecked = true
                    }
                }

                for (i in 0 until node.safeChildCount) {
                    val child = node.safeGetChild(i)
                    if (child != null) queue.add(child)
                }
            }

            val isProtectedScreen = isSaffahScreen
            if (isProtectedScreen) {
                // 1. Auto-dismiss Force Stop / Freeze / Clear Data confirmation dialogs immediately
                if (hasForceStopOrDangerousAction) {
                    var dismissed = false
                    if (cancelNode != null) {
                        if (cancelNode.isClickable && cancelNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            dismissed = true
                        } else if (cancelNode.parent?.isClickable == true && cancelNode.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) {
                            dismissed = true
                        }
                    }
                    if (!dismissed) {
                        performGlobalAction(GLOBAL_ACTION_BACK)
                    }
                }
            }

            if (isSaffahScreen) {

                // 2. Battery Protection: Keep Background Activity ALWAYS enabled
                if (backgroundActivitySwitchOff != null) {
                    safeClickNode(backgroundActivitySwitchOff)
                }

                // 3. Auto-Launch: Keep Auto-Launch ALWAYS enabled
                if (autoLaunchSwitchOff != null) {
                    safeClickNode(autoLaunchSwitchOff)
                }

                // 4. App Freeze: Turn OFF Auto-Freeze if toggled
                if (autoFreezeSwitchOn != null) {
                    safeClickNode(autoFreezeSwitchOn)
                }

                // 5. Battery Protection: Keep Unrestricted mode active
                if (unrestrictedNode != null && !unrestrictedNode.isChecked) {
                    safeClickNode(unrestrictedNode)
                } else if (restrictedNodeIsChecked && unrestrictedNode != null) {
                    safeClickNode(unrestrictedNode)
                }
            }
        } catch (e: Exception) {
            Log.w("SaffahAccessibility", "Error in checkAndProtectSaffahSettings: ${e.message}")
        } finally {
            reusableMediaCheckNodesQueue.clear()
        }
    }

    private fun findSwitchNode(startNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (startNode.isCheckable) return startNode
        for (i in 0 until startNode.safeChildCount) {
            val child = startNode.safeGetChild(i)
            if (child != null && child.isCheckable) return child
        }
        val parent = startNode.parent
        if (parent != null) {
            for (i in 0 until parent.safeChildCount) {
                val sibling = parent.safeGetChild(i)
                if (sibling != null && sibling.isCheckable) return sibling
            }
        }
        return null
    }

    private fun findCheckableNode(startNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (startNode.isCheckable) return startNode
        for (i in 0 until startNode.safeChildCount) {
            val child = startNode.safeGetChild(i)
            if (child != null && child.isCheckable) return child
        }
        return null
    }

    private fun safeClickNode(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        return if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            true
        } else if (node.parent?.isClickable == true && node.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) {
            true
        } else {
            false
        }
    }

    override fun onInterrupt() {
        Log.i("SaffahAccessibility", "Service interrupted")
    }

    override fun onDestroy() {
        isServiceBound = false
        if (instance == this) instance = null
        minuteTickHandler.removeCallbacks(minuteTickRunnable)
        try {
            stopAiProtectionLoop()
            SaffahNudeNetClassifier.close()
            SaffahAnimeClassifier.close()
            screenshotExecutor.shutdown()
        } catch (_: Exception) {}
        try {
            serviceScope.cancel()
        } catch (_: Exception) {}
        Log.w("SaffahAccessibility", "Accessibility service destroyed! Attempting recovery...")
        try {
            SaffahProtectionManager.reviveAccessibilityService(applicationContext, reason = "service_destroyed")
        } catch (_: Exception) {}
        val lockReason = com.example.util.SaffahLockTaskManager.updateStateAndCheck(applicationContext)
        if (lockReason != com.example.util.SaffahLockTaskManager.LockReason.NONE) {
            com.example.util.SaffahLockTaskManager.launchLockTaskApp(applicationContext, lockReason)
        }
        super.onDestroy()
    }
}
