package com.example.service

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.R
import com.example.util.SaffahUrgeManager
import com.example.widget.SaffahUrgeWidgetProvider
import java.util.Locale

/**
 * بلاطة الإعدادات السريعة (Quick Settings Tile):
 * تتيح للمستخدم عند قدوم ومضة أو رغبة ملحة مفاجئة تشغيل وضع
 * "النافذة العائمة الخاصة بـ قاعدة 15د لدحر الرغبة" بلمسة واحدة
 * من شريط الإشعارات العلوي فوق أي تطبيق يعمل دون الحاجة للرجوع للشاشة الرئيسية.
 */
@RequiresApi(Build.VERSION_CODES.N)
class SaffahUrgeTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onTileAdded() {
        super.onTileAdded()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()
        val context = applicationContext
        Log.i(TAG, "Urge 15-Min Quick Settings Tile clicked by user from Notification Shade!")

        val isAlreadyActive = SaffahUrgeManager.isUrgeSessionActive(context)

        if (isAlreadyActive) {
            val remainingMs = SaffahUrgeManager.getUrgeSessionRemainingMs(context)
            val remainingMinutes = (remainingMs / 1000L / 60L).coerceAtLeast(1L)
            Toast.makeText(
                context,
                "جلسة دحر الرغبة نشطة بالفعل (متبقي $remainingMinutes دقيقة)",
                Toast.LENGTH_SHORT
            ).show()

            // Open/bring forward Saffah in Lock Task Mode immediately
            com.example.util.SaffahLockTaskManager.launchLockTaskApp(context, com.example.util.SaffahLockTaskManager.LockReason.URGE_SESSION_ACTIVE)
        } else {
            // Activate urge suppression rule immediately
            SaffahUrgeManager.setUrgeFeatureEnabled(context, true)
            SaffahUrgeManager.startUrgeSession(context, 15)

            Toast.makeText(
                context,
                "تم تفعيل قاعدة الـ 15 دقيقة لدحر الرغبة فوراً!",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Refresh UI of tile and home screen widgets
        updateTileState()
        SaffahUrgeWidgetProvider.updateAllWidgets(context)
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val context = applicationContext

        val isActive = SaffahUrgeManager.isUrgeSessionActive(context)

        tile.label = getString(R.string.tile_urge_label)
        tile.icon = Icon.createWithResource(context, R.drawable.ic_qs_urge_tile)

        if (isActive) {
            tile.state = Tile.STATE_ACTIVE
            val remainingMs = SaffahUrgeManager.getUrgeSessionRemainingMs(context)
            val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
            val minutes = totalSeconds / 60L
            val seconds = totalSeconds % 60L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                tile.subtitle = String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds)
            }
        } else {
            tile.state = Tile.STATE_INACTIVE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                tile.subtitle = getString(R.string.tile_urge_subtitle_idle)
            }
        }

        try {
            tile.updateTile()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update QS Tile: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "SaffahUrgeTileService"

        /**
         * تحديث حالة البلاطة السريعة من أي مكان في التطبيق (عند انتهاء الجلسة أو بدئها)
         */
        fun requestTileUpdate(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    requestListeningState(
                        context.applicationContext,
                        ComponentName(context.applicationContext, SaffahUrgeTileService::class.java)
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "Unable to request tile listening state: ${e.message}")
                }
            }
        }
    }
}
