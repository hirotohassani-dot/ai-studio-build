package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.util.SaffahLockTaskManager
import com.example.util.SaffahProtectionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * خدمة الحماية المستمرة للسفاح (Saffah Guardian Foreground Service)
 * تعمل بشكل دائم في الواجهة الأمامية (Foreground Service) لضمان بقاء التطبيق
 * في قائمة التطبيقات النشطة في الخلفية (Active Apps / Android Task Manager)
 * وحمايته من التجميد أو القتل بواسطة قيود البطارية حتى بدون تفعيل الـ VPN.
 */
class SaffahKeeperService : Service() {

    companion object {
        private const val TAG = "SaffahKeeperService"
        const val CHANNEL_ID = "saffah_guardian_channel"
        const val NOTIFICATION_ID = 9001

        const val ACTION_START_KEEPER = "com.example.ACTION_START_KEEPER"
        const val ACTION_STOP_KEEPER = "com.example.ACTION_STOP_KEEPER"
        const val ACTION_ENSURE_NOTIFICATION = "com.example.ACTION_ENSURE_NOTIFICATION"

        private val _isKeeperRunning = MutableStateFlow(false)
        val isKeeperRunning: StateFlow<Boolean> = _isKeeperRunning.asStateFlow()

        /**
         * Actively asserts that SaffahKeeperService is running and its permanent notification is visible in the status bar.
         */
        fun ensureKeeperNotification(context: Context) {
            try {
                if (!SaffahProtectionManager.isKeeperServiceEnabled(context)) return
                val intent = Intent(context, SaffahKeeperService::class.java).apply {
                    action = ACTION_ENSURE_NOTIFICATION
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                // Background start restriction fallback: schedule instantaneous AlarmClock revival
                SaffahProtectionManager.scheduleEmergencyRevival(context, delayMillis = 50L)
            }
        }
    }

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private var notifListenerObserver: ContentObserver? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Saffah:KeeperWakeLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            wakeLock?.acquire(10 * 60 * 1000L) // 10 minutes safety timeout, periodically renewed
        } catch (e: Exception) {
            Log.w(TAG, "acquireWakeLock note: ${e.message}")
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "SaffahKeeperService created")
        acquireWakeLock()
        createNotificationChannel()
        registerNotificationListenerObserver()
    }

    private fun registerNotificationListenerObserver() {
        try {
            val uri = Settings.Secure.getUriFor("enabled_notification_listeners")
            notifListenerObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) {
                    super.onChange(selfChange)
                    try {
                        val isGranted = com.example.service.SaffahNotificationListenerService.isNotificationAccessGranted(applicationContext)
                        if (isGranted) {
                            SaffahLockTaskManager.setNotificationAccessEverEnabled(applicationContext, true)
                        } else {
                            SaffahProtectionManager.ensureNotificationListenerAccess(applicationContext)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error in notifListenerObserver onChange: ${e.message}")
                    }
                }
            }
            contentResolver.registerContentObserver(uri, false, notifListenerObserver!!)
            Log.i(TAG, "Registered ContentObserver for enabled_notification_listeners successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register ContentObserver for enabled_notification_listeners: ${e.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_KEEPER) {
            Log.i(TAG, "Stopping SaffahKeeperService by request...")
            _isKeeperRunning.value = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
            return START_NOT_STICKY
        }

        // Always promote to foreground immediately and ensure notification is active and visible
        promoteToForegroundSafely()

        startMaintenanceLoop()

        // START_STICKY ensures Android OS automatically restarts the service if killed
        return START_STICKY
    }

    /**
     * Promotes the service to Foreground and guarantees the notification is rendered
     * and registered in NotificationManager with maximum resilience.
     */
    fun promoteToForegroundSafely() {
        createNotificationChannel()
        val notification = createKeeperNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                var started = false
                try {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                    started = true
                } catch (e: Exception) {
                    Log.w(TAG, "startForeground with systemExempted|specialUse failed: ${e.message}")
                }
                if (!started) {
                    try {
                        startForeground(
                            NOTIFICATION_ID,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                        )
                        started = true
                    } catch (e: Exception) {
                        Log.w(TAG, "startForeground with specialUse failed: ${e.message}")
                    }
                }
                if (!started) {
                    try {
                        startForeground(
                            NOTIFICATION_ID,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
                        )
                        started = true
                    } catch (e: Exception) {
                        Log.w(TAG, "startForeground with systemExempted failed: ${e.message}")
                    }
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE
                    )
                } catch (e: Exception) {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            _isKeeperRunning.value = true
            Log.i(TAG, "SaffahKeeperService promoted to foreground successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Error in promoteToForegroundSafely for SaffahKeeperService: ${e.message}")
        }
    }

    private fun startMaintenanceLoop() {
        serviceScope.launch {
            var counter = 0
            while (isActive) {
                try {
                    acquireWakeLock()
                    if (SaffahProtectionManager.isKeeperServiceEnabled(applicationContext)) {
                        val isForeground = SaffahProtectionManager.isKeeperServiceForeground(applicationContext)
                        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

                        // Check if notification is actively displayed
                        val isShowing = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            try {
                                manager?.activeNotifications?.any { it.id == NOTIFICATION_ID } == true
                            } catch (_: Exception) {
                                true
                            }
                        } else {
                            true
                        }

                        // If not in OS foreground state or notification is missing, re-assert foreground immediately
                        if (!isForeground || !isShowing) {
                            Log.w(TAG, "Keeper missing from foreground or notification missing (foreground=$isForeground, notif=$isShowing)! Re-promoting immediately...")
                            promoteToForegroundSafely()
                        }
                    }

                    // Lightweight maintenance: only re-enable accessibility if it is unbound or stopped (every 60s)
                    if (counter % 4 == 0) {
                        if (!com.example.service.SaffahAccessibilityService.isServiceBound) {
                            Log.i(TAG, "Accessibility service unbound detected in keeper loop, re-ensuring...")
                            SaffahProtectionManager.ensureAccessibilityServiceEnabled(applicationContext)
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Maintenance loop heartbeat note: ${e.message}")
                }
                counter++
                delay(15_000L) // 15 seconds heartbeat interval
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                val existingChannel = manager?.getNotificationChannel(CHANNEL_ID)
                if (existingChannel == null || existingChannel.importance == NotificationManager.IMPORTANCE_NONE) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        "درع حماية السفاح الدائم (Foreground Service)",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "إبقاء التطبيق نشطاً في الخلفية وفي قائمة التطبيقات النشطة بدون انقطاع"
                        setShowBadge(false)
                        enableLights(false)
                        enableVibration(false)
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    }
                    manager?.createNotificationChannel(channel)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error creating keeper notification channel: ${e.message}")
            }
        }
    }

    private fun createKeeperNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            NOTIFICATION_ID,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("درع السفاح نشط في الخلفية")
            .setContentText("الحماية وفحص القيود تعمل بنشاط ومستمرة في العمل")
            .setSmallIcon(R.drawable.ic_notification_saffah)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setLocalOnly(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build().apply {
                flags = flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR or Notification.FLAG_FOREGROUND_SERVICE
            }
    }

    override fun onDestroy() {
        Log.w(TAG, "SaffahKeeperService destroyed! Auto-reviving instantly...")
        _isKeeperRunning.value = false
        serviceJob.cancel()
        releaseWakeLock()
        try {
            notifListenerObserver?.let { contentResolver.unregisterContentObserver(it) }
        } catch (_: Exception) {}
        super.onDestroy()

        // Immediate revival and emergency alarm if keeper service is enabled
        if (SaffahProtectionManager.isKeeperServiceEnabled(applicationContext)) {
            // Stage 1: Ultra-fast revival (150ms) via direct AlarmClock ForegroundService PendingIntent
            SaffahProtectionManager.scheduleEmergencyRevival(applicationContext, delayMillis = 150L)
            // Stage 2: Secondary redundant revival (600ms)
            SaffahProtectionManager.scheduleEmergencyRevival(applicationContext, delayMillis = 600L)
            // Stage 3: Expedited WorkManager watchdog backup
            SaffahProtectionManager.triggerExpeditedWatchdog(applicationContext)

            if (com.example.util.SaffahLockTaskManager.isVpnIntendedActive(applicationContext)) {
                SaffahProtectionManager.scheduleVpnEmergencyRevival(applicationContext, delayMillis = 250L)
            }
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.i(TAG, "App task removed from recents: executing instant emergency revival...")
        if (SaffahProtectionManager.isKeeperServiceEnabled(applicationContext)) {
            // Stage 1: Ultra-fast revival (150ms) via direct AlarmClock ForegroundService PendingIntent
            SaffahProtectionManager.scheduleEmergencyRevival(applicationContext, delayMillis = 150L)
            // Stage 2: Secondary redundant revival (600ms)
            SaffahProtectionManager.scheduleEmergencyRevival(applicationContext, delayMillis = 600L)
            // Stage 3: Expedited WorkManager watchdog backup
            SaffahProtectionManager.triggerExpeditedWatchdog(applicationContext)

            if (com.example.util.SaffahLockTaskManager.isVpnIntendedActive(applicationContext)) {
                SaffahProtectionManager.scheduleVpnEmergencyRevival(applicationContext, delayMillis = 250L)
            }
        }
    }
}
