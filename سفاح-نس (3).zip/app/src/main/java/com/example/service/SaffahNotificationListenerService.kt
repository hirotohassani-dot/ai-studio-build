package com.example.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.util.SaffahBlockRepository

class SaffahNotificationListenerService : NotificationListenerService() {

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.i(TAG, "SaffahNotificationListenerService created")
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        Log.i(TAG, "SaffahNotificationListenerService connected")

        // Record that Notification Access was enabled by user
        com.example.util.SaffahLockTaskManager.setNotificationAccessEverEnabled(this, true)

        if (SaffahBlockRepository.isHideVpnNotification(this)) {
            hideActiveVpnNotifications()
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) {
            instance = null
        }
        Log.i(TAG, "SaffahNotificationListenerService disconnected")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val pkg = sbn.packageName.orEmpty()

        // 1. VPN notification hiding
        if (SaffahBlockRepository.isHideVpnNotification(this)) {
            if (isVpnNotification(sbn)) {
                Log.i(TAG, "Detected VPN notification from [$pkg], hiding it immediately.")
                hideNotificationSafely(sbn)
                return
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        if (sbn == null) return
        try {
            if (sbn.packageName == packageName && sbn.id == SaffahKeeperService.NOTIFICATION_ID) {
                if (com.example.util.SaffahProtectionManager.isKeeperServiceEnabled(this)) {
                    Log.w(TAG, "Keeper notification was removed externally! Instantly restoring notification...")
                    SaffahKeeperService.ensureKeeperNotification(this)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in onNotificationRemoved: ${e.message}")
        }
    }

    private fun hideActiveVpnNotifications() {
        try {
            val activeNotifs = activeNotifications ?: return
            for (sbn in activeNotifs) {
                if (isVpnNotification(sbn)) {
                    Log.i(TAG, "Hiding active VPN notification: ${sbn.key} from ${sbn.packageName}")
                    hideNotificationSafely(sbn)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying active notifications: ${e.message}")
        }
    }

    private fun hideNotificationSafely(sbn: StatusBarNotification) {
        // 1. Direct cancel by key (standard NotificationListenerService API)
        try {
            cancelNotification(sbn.key)
        } catch (e: Exception) {
            Log.w(TAG, "cancelNotification(key) note: ${e.message}")
        }

        // 2. Direct cancel by pkg, tag, id
        try {
            cancelNotification(sbn.packageName, sbn.tag, sbn.id)
        } catch (e: Exception) {
            Log.w(TAG, "cancelNotification(pkg, tag, id) note: ${e.message}")
        }

        // 3. Batch cancel for modern Android
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                cancelNotifications(arrayOf(sbn.key))
            } catch (_: Exception) {}

            // 4. Safe snooze (6 hours) to remove sticky/foreground/ongoing alerts from status bar
            try {
                snoozeNotification(sbn.key, 1000L * 60 * 60 * 6)
            } catch (e: Exception) {
                Log.w(TAG, "snoozeNotification note: ${e.message}")
            }
        }
    }

    private fun isVpnNotification(sbn: StatusBarNotification): Boolean {
        // ABSOLUTE IMMUNITY: The permanent protection service notification must NEVER be hidden under ANY circumstance!
        if (sbn.id == SaffahKeeperService.NOTIFICATION_ID || 
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && sbn.notification?.channelId == SaffahKeeperService.CHANNEL_ID)) {
            return false
        }

        val pkg = sbn.packageName ?: return false
        val isOwnApp = pkg == packageName
        val isSystem = pkg == "android" || pkg == "com.android.systemui" || pkg.contains("systemui")
        if (!isOwnApp && !isSystem) {
            return false
        }

        val notif = sbn.notification ?: return false
        val extras = notif.extras

        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val subText = extras?.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val channelId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) notif.channelId.orEmpty() else ""

        val combined = "$title $text $bigText $subText $channelId".lowercase()

        // 1. App's own VPN foreground notification
        if (isOwnApp) {
            if (sbn.id == SaffahVpnService.NOTIFICATION_ID ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && channelId == SaffahVpnService.CHANNEL_ID) ||
                combined.contains("شبكة vpn") ||
                (combined.contains("vpn") && !combined.contains("درع السفاح نشط"))
            ) {
                return true
            }
        }

        // 2. Android System / SystemUI VPN notification (e.g. "VPN activated", "Connected to السَّفاح VPN")
        if (isSystem) {
            if (combined.contains("vpn") ||
                combined.contains("السَّفاح") ||
                combined.contains("saffah") ||
                combined.contains("connected to") ||
                combined.contains("vpn activated") ||
                combined.contains("شبكة vpn") ||
                combined.contains("تم تفعيل vpn") ||
                combined.contains("متصل بـ") ||
                combined.contains("tap to manage") ||
                channelId.contains("vpn", ignoreCase = true)
            ) {
                return true
            }
        }

        return false
    }

    companion object {
        private const val TAG = "SaffahNotifListener"
        @Volatile private var instance: SaffahNotificationListenerService? = null

        fun requestHideVpnNotification(context: Context) {
            instance?.let { service ->
                service.hideActiveVpnNotifications()
            }
        }

        fun isNotificationAccessGranted(context: Context): Boolean {
            return try {
                val flat = Settings.Secure.getString(
                    context.contentResolver,
                    "enabled_notification_listeners"
                ) ?: ""
                val cn = ComponentName(context, SaffahNotificationListenerService::class.java).flattenToString()
                val shortCn = ComponentName(context, SaffahNotificationListenerService::class.java).flattenToShortString()
                flat.contains(cn) || flat.contains(shortCn) || flat.contains(context.packageName)
            } catch (e: Exception) {
                false
            }
        }

        fun openNotificationAccessSettings(context: Context) {
            val intentsToTry = mutableListOf<Intent>()

            // 1. Android 11+ Direct detail settings for Saffah
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val detailIntent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).apply {
                        putExtra(
                            Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                            ComponentName(context, SaffahNotificationListenerService::class.java).flattenToString()
                        )
                    }
                    intentsToTry.add(detailIntent)
                } catch (_: Exception) {}
            }

            // 2. Standard notification listener settings
            intentsToTry.add(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            intentsToTry.add(Intent("android.settings.NOTIFICATION_LISTENER_SETTINGS"))
            intentsToTry.add(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))

            // 3. Realme UI / ColorOS / Oppo OEM settings activities
            intentsToTry.add(Intent().apply {
                component = ComponentName("com.oplus.settings", "com.oplus.settings.Settings\$NotificationAccessSettingsActivity")
            })
            intentsToTry.add(Intent().apply {
                component = ComponentName("com.coloros.settings", "com.coloros.settings.Settings\$NotificationAccessSettingsActivity")
            })
            intentsToTry.add(Intent().apply {
                component = ComponentName("com.oplus.settings", "com.oplus.settings.SubSettings")
                putExtra(":settings:show_fragment", "com.android.settings.notification.NotificationAccessSettings")
            })
            intentsToTry.add(Intent().apply {
                component = ComponentName("com.coloros.settings", "com.coloros.settings.SubSettings")
                putExtra(":settings:show_fragment", "com.android.settings.notification.NotificationAccessSettings")
            })

            // 4. Stock Android SubSettings
            intentsToTry.add(Intent().apply {
                component = ComponentName("com.android.settings", "com.android.settings.Settings\$NotificationAccessSettingsActivity")
            })
            intentsToTry.add(Intent().apply {
                component = ComponentName("com.android.settings", "com.android.settings.SubSettings")
                putExtra(":settings:show_fragment", "com.android.settings.notification.NotificationAccessSettings")
            })

            // 5. Ultimate fallback
            intentsToTry.add(Intent(Settings.ACTION_SETTINGS))

            for (intent in intentsToTry) {
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    context.startActivity(intent)
                    Log.i(TAG, "Successfully launched notification listener settings with intent: ${intent.action ?: intent.component?.flattenToString()}")
                    return
                } catch (e: Exception) {
                    Log.w(TAG, "Failed notification listener settings intent attempt: ${e.message}")
                }
            }
        }

        fun notifyUnlockIfApplicable(context: Context) {
            try {
                val intent = Intent(context, com.example.MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or 
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or 
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("EXTRA_ACTION_UNLOCK", true)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error notifying MainActivity to unlock: ${e.message}")
            }
        }
    }
}
