package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import com.example.util.SaffahNotificationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SaffahNotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.i("SaffahNotifReceiver", "Broadcast received: $action")

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Saffah:NotificationReceiverWakeLock")
        try {
            wakeLock?.acquire(15000L) // 15-second safeguard timeout
        } catch (_: Exception) {}

        val pendingResult = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                when (action) {
                    SaffahNotificationManager.ACTION_DOPAMINE_SURVEY_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerDopamineSurveyNotification(context)
                        SaffahNotificationManager.scheduleAlarms(context)
                    }
                    SaffahNotificationManager.ACTION_CLEAN_DAY_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerCleanDayAndMapNotifications(context)
                        SaffahNotificationManager.scheduleAlarms(context)
                    }
                    SaffahNotificationManager.ACTION_DANGER_WINDOW_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerDangerWindowNotification(context)
                        SaffahNotificationManager.scheduleDangerWindowAlarm(context)
                    }
                    SaffahNotificationManager.ACTION_BEDTIME_REMINDER_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerBedtimeNotifications(context)
                        SaffahNotificationManager.scheduleBedtimeReminderAlarms(context)
                    }
                    SaffahNotificationManager.ACTION_BEDTIME_MOD_WINDOW_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerBedtimeModWindowNotification(context)
                        SaffahNotificationManager.scheduleBedtimeModWindowAlarm(context)
                    }
                    SaffahNotificationManager.ACTION_MODIFICATION_WINDOW_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerModificationWindowNotification(context)
                        SaffahNotificationManager.scheduleModificationWindowAlarm(context)
                    }
                    SaffahNotificationManager.ACTION_SCHEDULED_BLOCK_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerScheduledBlockNotifications(context)
                        SaffahNotificationManager.scheduleScheduledBlockAlarms(context)
                    }
                    SaffahNotificationManager.ACTION_DAILY_BLOCK_HARVEST_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerDailyBlockHarvestNotification(context)
                    }
                    SaffahNotificationManager.ACTION_TIME_DELAY_EXPIRATION_ALARM -> {
                        SaffahNotificationManager.evaluateAndTriggerTimeDelayExpirationNotification(context)
                    }
                    Intent.ACTION_BOOT_COMPLETED,
                    Intent.ACTION_MY_PACKAGE_REPLACED,
                    Intent.ACTION_DATE_CHANGED,
                    Intent.ACTION_TIME_CHANGED,
                    Intent.ACTION_TIMEZONE_CHANGED,
                    "com.example.ACTION_SCHEDULE_TICK" -> {
                        com.example.util.SaffahPenaltyManager.onDateChanged(context)
                        SaffahNotificationManager.evaluateAllNotifications(context)
                        SaffahNotificationManager.scheduleAlarms(context)
                    }
                }
            } catch (e: Exception) {
                Log.e("SaffahNotifReceiver", "Error in onReceive for action $action: ${e.message}", e)
            } finally {
                try {
                    if (wakeLock?.isHeld == true) {
                        wakeLock.release()
                    }
                } catch (_: Exception) {}
                pendingResult.finish()
            }
        }
    }
}
