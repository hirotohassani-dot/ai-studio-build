package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.util.SaffahBedtimeManager
import com.example.util.SaffahBlockRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SaffahBedtimeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return

        val action = intent.action ?: return
        Log.d("SaffahBedtimeReceiver", "Received broadcast action: $action")

        val pendingResult = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                when (action) {
                    Intent.ACTION_BOOT_COMPLETED,
                    Intent.ACTION_MY_PACKAGE_REPLACED,
                    Intent.ACTION_DATE_CHANGED,
                    Intent.ACTION_TIME_CHANGED,
                    Intent.ACTION_TIMEZONE_CHANGED,
                    SaffahBedtimeManager.ACTION_BEDTIME_PRE_START,
                    SaffahBedtimeManager.ACTION_BEDTIME_START,
                    SaffahBedtimeManager.ACTION_BEDTIME_END,
                    "com.example.ACTION_SCHEDULE_TICK",
                    "com.example.ACTION_PRODUCTIVITY_STATE_CHANGE",
                    "com.example.ACTION_MIDNIGHT_RESET" -> {
                        SaffahBlockRepository.invalidateTimeCache()
                        val hour = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            java.time.LocalTime.now().hour
                        } else {
                            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                        }
                        if (hour >= 22 || hour < 6) {
                            // Zero out productivity app time past 22:00
                            SaffahBlockRepository.resetProductivityUsageData(context)
                        }
                        SaffahBlockRepository.checkAndPerformMidnightReset(context)
                        SaffahBedtimeManager.evaluateBedtimeState(context)
                        SaffahBlockRepository.syncAllPackageSuspensions(context, force = true)
                        SaffahBlockRepository.scheduleAppScheduleAlarms(context)
                        SaffahBlockRepository.scheduleProductivityAlarms(context)
                        SaffahBlockRepository.scheduleMidnightAlarm(context)
                        com.example.util.SaffahNotificationManager.evaluateAndTriggerBedtimeNotifications(context)
                        com.example.util.SaffahNotificationManager.evaluateAndTriggerScheduledBlockNotifications(context)
                        com.example.util.SaffahNotificationManager.scheduleScheduledBlockAlarms(context)
                        try {
                            com.example.service.SaffahAccessibilityService.notifyScheduleOrBedtimeChanged(context)
                        } catch (_: Throwable) {}
                    }
                }
            } catch (e: Exception) {
                Log.e("SaffahBedtimeReceiver", "Error in async bedtime processing: ${e.message}")
            } finally {
                pendingResult.finish()
            }
        }
    }
}
