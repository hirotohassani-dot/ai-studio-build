package com.example.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.util.SaffahProtectionManager

class SaffahDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        try {
            SaffahProtectionManager.applyDeviceOwnerRestrictions(context)
            SaffahProtectionManager.scheduleWatchdog(context)
            Toast.makeText(context, "تم تفعيل صلاحية مسئول الجهاز وتطبيق الحماية بنجاح", Toast.LENGTH_LONG).show()
        } catch (t: Throwable) {
            android.util.Log.e("DeviceAdminReceiver", "Error onEnabled: ${t.message}")
        }
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        try {
            SaffahProtectionManager.applyDeviceOwnerRestrictions(context)
            SaffahProtectionManager.scheduleWatchdog(context)
        } catch (t: Throwable) {
            android.util.Log.e("DeviceAdminReceiver", "Error onProfileProvisioningComplete: ${t.message}")
        }
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        try {
            Toast.makeText(context, "تم إلغاء تفعيل صلاحية مسئول الجهاز", Toast.LENGTH_LONG).show()
        } catch (t: Throwable) {
            android.util.Log.e("DeviceAdminReceiver", "Error onDisabled: ${t.message}")
        }
    }
}
