package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.util.SaffahChargingManager

/**
 * Handles system power connected and disconnected broadcasts to eliminate
 * automatic Do Not Disturb activation and unwanted floating volume panel appearances.
 */
class SaffahPowerReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return
        val action = intent.action ?: return

        when (action) {
            Intent.ACTION_POWER_CONNECTED -> {
                Log.i("SaffahPowerReceiver", "Power connected event received")
                SaffahChargingManager.onPowerConnected(context)
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                Log.i("SaffahPowerReceiver", "Power disconnected event received")
                SaffahChargingManager.onPowerDisconnected(context)
            }
        }
    }
}
