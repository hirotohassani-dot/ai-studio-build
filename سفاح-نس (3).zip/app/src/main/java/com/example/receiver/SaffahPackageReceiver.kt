package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.util.SaffahBlockRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SaffahPackageReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val pkgName = intent.data?.schemeSpecificPart
        Log.i("SaffahPackageReceiver", "Package event received: $action for package: $pkgName")

        // Invalidate installed packages cache so new app changes are picked up immediately
        SaffahBlockRepository.invalidateInstalledPackagesCache()
        com.example.util.AppListHelper.notifyPackageChanged(context, pkgName)

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (!pkgName.isNullOrBlank()) {
                    if (SaffahBlockRepository.isPackagePermanentlyBlocked(context, pkgName)) {
                        Log.i("SaffahPackageReceiver", "Permanently blocked app installed/reinstalled: $pkgName. Applying immediate suspension.")
                        SaffahBlockRepository.applySinglePackageSuspension(context, pkgName, true)
                    }
                }
                // Synchronize all package suspensions across the device off the main thread
                SaffahBlockRepository.syncAllPackageSuspensions(context)
            } catch (e: Exception) {
                Log.w("SaffahPackageReceiver", "Error processing package event: ${e.message}")
            } finally {
                pendingResult.finish()
            }
        }
    }
}
