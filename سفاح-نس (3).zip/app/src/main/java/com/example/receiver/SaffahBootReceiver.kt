package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.util.SaffahBedtimeManager
import com.example.util.SaffahBlockRepository
import com.example.util.SaffahLockTaskManager
import com.example.util.SaffahNotificationManager
import com.example.util.SaffahProtectionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SaffahBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.i("SaffahBootReceiver", "System event received: $action")
        val isKeepAlivePing = (action == "com.example.ACTION_SAFFAH_KEEPALIVE_PING")
        val isLockedBoot = (action == Intent.ACTION_LOCKED_BOOT_COMPLETED)

        // CRITICAL: Launch SaffahKeeperService SYNCHRONOUSLY within onReceive.
        // Android foreground service start exemption is tied to the immediate broadcast dispatch window on the main thread.
        try {
            if (SaffahProtectionManager.isKeeperServiceEnabled(context)) {
                SaffahProtectionManager.startKeeperService(context)
                com.example.service.SaffahKeeperService.ensureKeeperNotification(context)
            }
        } catch (e: Exception) {
            Log.e("SaffahBootReceiver", "Immediate synchronous startKeeperService failed: ${e.message}")
        }

        // Direct Boot Mode: Device started and running BEFORE user enters lockscreen password
        if (isLockedBoot) {
            Log.i("SaffahBootReceiver", "Direct Boot Mode active (device is locked before password entry). Saffah protection running!")
            try {
                if (SaffahLockTaskManager.isVpnIntendedActive(context)) {
                    val vpnIntent = Intent(context, com.example.service.SaffahVpnService::class.java).apply {
                        this.action = com.example.service.SaffahVpnService.ACTION_START_VPN
                    }
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        context.startForegroundService(vpnIntent)
                    } else {
                        context.startService(vpnIntent)
                    }
                }
            } catch (e: Exception) {
                Log.w("SaffahBootReceiver", "Direct Boot VPN startup note: ${e.message}")
            }
            return
        }

        val pendingResult = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                // Always enforce unbreakable system shield & foreground keeper service
                try {
                    SaffahProtectionManager.startKeeperService(context)
                    com.example.service.SaffahKeeperService.ensureKeeperNotification(context)
                    if (!isKeepAlivePing) {
                        SaffahProtectionManager.applyAllSystemImmunity(context)
                        com.example.util.SaffahChargingManager.disableOemChargingDndTriggers(context)
                    } else {
                        SaffahProtectionManager.ensureAccessibilityServiceEnabled(context)
                    }
                } catch (e: Exception) {
                    Log.e("SaffahBootReceiver", "Error in applyAllSystemImmunity: ${e.message}")
                }

                // Re-initialize notification channels and re-arm all alarms ONLY on actual system events, not routine pings
                if (!isKeepAlivePing) {
                    try {
                        SaffahNotificationManager.initChannels(context)
                        SaffahNotificationManager.ensureNotificationPermissionGranted(context)
                        SaffahNotificationManager.scheduleAlarms(context)
                        SaffahNotificationManager.evaluateAllNotifications(context)

                        SaffahBedtimeManager.scheduleBedtimeAlarms(context)
                        SaffahBlockRepository.scheduleAppScheduleAlarms(context)
                        SaffahBlockRepository.scheduleProductivityAlarms(context)
                        SaffahBlockRepository.scheduleMidnightAlarm(context)
                    } catch (e: Exception) {
                        Log.e("SaffahBootReceiver", "Error re-arming notification alarms on $action: ${e.message}", e)
                    }
                }

                // Check state on system broadcast (Boot, Connectivity change, Unlock, etc.)
                val lockReason = SaffahLockTaskManager.updateStateAndCheck(context)
                if (lockReason != SaffahLockTaskManager.LockReason.NONE) {
                    SaffahLockTaskManager.launchLockTaskApp(context, lockReason)
                }
            } catch (t: Throwable) {
                Log.e("SaffahBootReceiver", "Error processing boot event: ${t.message}", t)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
